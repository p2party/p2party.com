/**
 * Store identity and routes (Section 4.2).
 *
 * A `StoreId` is stable across compatible descriptor and route rotation, so
 * adding a route or refreshing a lease does not create a different store. What
 * changes with each descriptor is `DescriptorHash` and a monotonic generation.
 *
 * Neither a descriptor nor a route is part of room identity. That separation is
 * the point: a client can add, deny, or replace a store without rekeying a room
 * or reissuing an invitation, and a store learns nothing about the room from
 * either object.
 *
 * The descriptor signature proves possession of the store's identity key, and
 * every route signature is made with that same key — so a route binds the exact
 * `StoreId`, `DescriptorHash`, locator, parameters, family, and lease, and a
 * route cannot be transplanted onto another store or another descriptor.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
export interface StoreCheckpointChainStartV1 {
    deliveryProfileHash: Uint8Array;
    chainStartIngressWindow: bigint;
}
export interface StoreDescriptorV1 {
    version: 1;
    storeIdentityEd25519Key: Uint8Array;
    allocationIssuerPublicKeyDer: Uint8Array;
    descriptorGeneration: bigint;
    compatibilityHash: Uint8Array;
    supportedDeliveryProfileHashes: readonly Uint8Array[];
    checkpointChainStarts: readonly StoreCheckpointChainStartV1[];
    notBeforeUnixMs: bigint;
    notAfterUnixMs: bigint;
    descriptorSignature: Uint8Array;
}
export interface StoreRouteV1 {
    version: 1;
    storeId: Uint8Array;
    descriptorHash: Uint8Array;
    routeFamily: number;
    opaqueLocator: Uint8Array;
    routePublicParameters: Uint8Array;
    notBeforeUnixMs: bigint;
    notAfterUnixMs: bigint;
    routeSignature: Uint8Array;
}
export declare class StoreDescriptorError extends Error {
    readonly name = "StoreDescriptorError";
    constructor(message: string);
}
/**
 * `StoreId = H("p2party/store-id/v1" || storeIdentityEd25519Key)`
 *
 * Derived from the key alone, which is what makes it survive descriptor and
 * route rotation.
 */
export declare const storeId: (storeIdentityEd25519Key: Uint8Array) => Promise<Uint8Array>;
/**
 * `DescriptorHash = H("p2party/store-descriptor/v1" ||
 *    Canonical(StoreDescriptorV1 without descriptorSignature))`
 */
export declare const descriptorHash: (descriptor: StoreDescriptorV1) => Promise<Uint8Array>;
/**
 * `RouteId = H("p2party/store-route/v1" ||
 *    Canonical(StoreRouteV1 without routeSignature))`
 */
export declare const routeId: (route: StoreRouteV1) => Promise<Uint8Array>;
/** `"p2party/store-descriptor-signature/v1" || DescriptorHash` */
export declare const storeDescriptorSignedMessage: (descriptor: StoreDescriptorV1) => Promise<Uint8Array>;
/** `"p2party/store-route-signature/v1" || RouteId` */
export declare const storeRouteSignedMessage: (route: StoreRouteV1) => Promise<Uint8Array>;
/**
 * `PublicCarrierContextId = H("p2party/public-carrier-context/v1" ||
 *    StoreId || DeliveryProfileHash)`
 *
 * This scopes cryptography and store idempotency: one wrapping, allocation and
 * scheduled-work domain per store and profile, no matter how many routes reach
 * it.
 */
export declare const publicCarrierContextId: (storeIdBytes: Uint8Array, deliveryProfileHash: Uint8Array) => Promise<Uint8Array>;
/**
 * `PublicRouteInstanceId = H("p2party/public-route-instance/v1" ||
 *    PublicCarrierContextId || RouteId)`
 *
 * This scopes path health and assurance evidence. Two routes to one store are
 * two instances of one context — never two stores, and never two chances to
 * publish the same object.
 */
export declare const publicRouteInstanceId: (carrierContextId: Uint8Array, routeIdBytes: Uint8Array) => Promise<Uint8Array>;
export type StoreValidity = {
    readonly valid: true;
} | {
    readonly valid: false;
    readonly reason: string;
};
/**
 * Structural and signature validation of a descriptor.
 *
 * `atUnixMs` is explicit rather than read from the clock: historical evidence
 * must be verifiable against the instant it described, and a descriptor that
 * has since expired does not retroactively invalidate a checkpoint it was valid
 * for.
 */
export declare const validateStoreDescriptor: (descriptor: StoreDescriptorV1, atUnixMs: bigint, module?: LibCrypto) => Promise<StoreValidity>;
/**
 * Validate a route against the descriptor it claims to belong to.
 *
 * The route's own signature is made with the store's identity key, so a route
 * lifted from another store or another descriptor generation fails here rather
 * than becoming an unauthorized path to this one.
 */
export declare const validateStoreRoute: (route: StoreRouteV1, descriptor: StoreDescriptorV1, atUnixMs: bigint, module?: LibCrypto) => Promise<StoreValidity>;
/** Whether a descriptor serves a given delivery profile. */
export declare const descriptorSupportsProfile: (descriptor: StoreDescriptorV1, deliveryProfileHash: Uint8Array) => boolean;
/** The immutable chain start this store declares for a profile, if any. */
export declare const descriptorChainStart: (descriptor: StoreDescriptorV1, deliveryProfileHash: Uint8Array) => bigint | null;
/**
 * Two valid descriptors deriving one `StoreId` that name different chain
 * starts for one profile.
 *
 * This is signed equivocation about where the accountability chain begins, and
 * the specification makes it permanent for that store and profile: a higher
 * descriptor generation cannot clear it, because a clean reset requires a new
 * store identity. Canonical order is by descriptor hash, so one fault yields
 * one proof.
 */
export declare const chainStartConflict: (first: StoreDescriptorV1, second: StoreDescriptorV1, deliveryProfileHash: Uint8Array) => Promise<{
    readonly conflicting: false;
} | {
    readonly conflicting: true;
    readonly canonicalOrder: readonly [StoreDescriptorV1, StoreDescriptorV1];
}>;
