/**
 * Canonical descriptors for the blind-rendezvous wire objects.
 *
 * These descriptors are the schema SSOT named in Section 1.4: they own field
 * order, integer widths, enum bytes, collection ordering, and bounds. Every
 * other module derives its encoder, decoder, key table, and bound check from
 * here rather than restating them.
 *
 * Field order below follows the specification's declaration order in Sections
 * 4.0 through 4.5. A TypeScript interface may list the same fields in a
 * different order for readability; interface order is not wire order.
 *
 * Status: PROPOSED, NOT FROZEN. Integer widths are this artifact's proposal
 * for the Phase-0 freeze, not published v0.4 release bytes.
 */
import type { TypeDescriptor } from "./canonicalSchema";
/** Section 4.4 operation payload classes: exact signed inner byte counts. */
export declare const OPERATION_PAYLOAD_CLASS_BYTES: Readonly<Record<0 | 1, number>>;
export declare const MAX_OPERATION_PAYLOAD_BYTES: number;
/** Section 4.11 suite-1 bootstrap KEM ciphertext width. */
export declare const PAIR_BOOTSTRAP_KEM_CIPHERTEXT_BYTES_V1 = 1120;
/** Section 4.0 closes the kernel at 8 modules and 9 entrypoints. */
export declare const KERNEL_MODULE_IDS: readonly [1, 2, 3, 4, 5, 6, 7, 8];
export declare const KERNEL_ENTRYPOINT_IDS: readonly [1, 2, 3, 4, 5, 6, 7, 8, 9];
/**
 * Section 4.0: modules 1..5 own entrypoints 1..5; module 6 owns the delivery
 * scheduler (6) and `R2Conforms` (7); module 7 owns the eventual pair-control
 * transition (8); module 8 owns claim evaluation (9).
 */
export declare const KERNEL_ENTRYPOINT_IDS_BY_MODULE: Readonly<Record<(typeof KERNEL_MODULE_IDS)[number], readonly number[]>>;
/** Section 4.0: a v0.4 release must carry FPO-001 through FPO-006. */
export declare const V04_REQUIRED_FORMAL_OBLIGATION_IDS: readonly [1, 2, 3, 4, 5, 6];
export declare const roomProtocolLimitsV1Schema: TypeDescriptor;
export declare const admissionFloorV4Schema: TypeDescriptor;
export declare const roomPolicyV4Schema: TypeDescriptor;
export declare const appendScheduleRoleV1Schema: TypeDescriptor;
export declare const appendScheduleEntryV1Schema: TypeDescriptor;
export declare const deliverySizeClassV1Schema: TypeDescriptor;
export declare const deliveryProfileV1Schema: TypeDescriptor;
export declare const operationKindV1Schema: TypeDescriptor;
export declare const operationLifetimeV1Schema: TypeDescriptor;
export declare const authenticatedRoomOperationUnsignedV1Schema: TypeDescriptor;
export declare const authenticatedRoomOperationV1Schema: TypeDescriptor;
export declare const pairBootstrapHeaderV1Schema: TypeDescriptor;
export declare const pairStepEnvelopeV1Schema: TypeDescriptor;
export declare const carrierEnvelopeV1Schema: TypeDescriptor;
export declare const carrierPlaintextV1Schema: TypeDescriptor;
/** The sorted duplicate-free operation-ID projection hashed by
 * `operationsDigest` and by the R2 required-operation digest. */
export declare const operationIdSetSchema: TypeDescriptor;
export declare const kernelEntrypointV1Schema: TypeDescriptor;
export declare const executableRendezvousKernelModuleV1Schema: TypeDescriptor;
export declare const executableRendezvousKernelManifestV1Schema: TypeDescriptor;
export declare const blindRendezvousImplementationBuildManifestV1Schema: TypeDescriptor;
export declare const claimEvaluationStateV1Schema: TypeDescriptor;
export declare const claimScopeKindV1Schema: TypeDescriptor;
export declare const claimAssumptionKindV1Schema: TypeDescriptor;
export declare const claimAssumptionVerificationV1Schema: TypeDescriptor;
export declare const claimAssumptionV1Schema: TypeDescriptor;
export declare const claimEvidenceKindV1Schema: TypeDescriptor;
export declare const claimWordingByStateV1Schema: TypeDescriptor;
export declare const claimDefinitionV1Schema: TypeDescriptor;
export declare const claimRegistryV1Schema: TypeDescriptor;
export declare const claimWordingEntryV1Schema: TypeDescriptor;
export declare const claimReasonEntryV1Schema: TypeDescriptor;
export declare const claimWordingCatalogV1Schema: TypeDescriptor;
export declare const claimEvidenceBindingV1Schema: TypeDescriptor;
export declare const claimPrerequisiteBindingV1Schema: TypeDescriptor;
export declare const claimFormalResultBindingV1Schema: TypeDescriptor;
export declare const claimAssumptionBindingV1Schema: TypeDescriptor;
export declare const claimEvaluationDatasetV1Schema: TypeDescriptor;
export declare const claimEvaluationInputV1Schema: TypeDescriptor;
export declare const claimEvaluationV1Schema: TypeDescriptor;
export declare const formalObligationKindV1Schema: TypeDescriptor;
export declare const formalObligationV1Schema: TypeDescriptor;
export declare const formalObligationRegistryV1Schema: TypeDescriptor;
export declare const formalProofScopeArtifactV1Schema: TypeDescriptor;
export declare const formalProofResultKindV1Schema: TypeDescriptor;
export declare const formalProofResultV1Schema: TypeDescriptor;
/** The resolved assumption sequence hashed by `FormalAssumptionSetHash`. */
export declare const resolvedAssumptionSetSchema: TypeDescriptor;
/** The normalized source-tree projection hashed by `KernelSourceTreeHash`. */
export declare const kernelSourceTreeEntrySchema: TypeDescriptor;
export declare const kernelSourceTreeSchema: TypeDescriptor;
/** The per-entrypoint projection hashed by `KernelModuleSemanticsHash`. */
export declare const kernelModuleSemanticsEntrySchema: TypeDescriptor;
export declare const kernelModuleSemanticsSchema: TypeDescriptor;
/** No room-derived value appears here: every room in a profile shares it. */
export declare const publicBucketV1Schema: TypeDescriptor;
export declare const publicChunkBodyV1Schema: TypeDescriptor;
export declare const publicChunkV1Schema: TypeDescriptor;
export declare const publicStoreCheckpointBodyV1Schema: TypeDescriptor;
export declare const publicStoreCheckpointV1Schema: TypeDescriptor;
export declare const publicCheckpointChunkLeafV1Schema: TypeDescriptor;
export declare const publicCheckpointChunkInclusionProofV1Schema: TypeDescriptor;
export declare const storeCheckpointChainStartV1Schema: TypeDescriptor;
export declare const storeDescriptorUnsignedV1Schema: TypeDescriptor;
export declare const storeDescriptorV1Schema: TypeDescriptor;
export declare const storeRouteUnsignedV1Schema: TypeDescriptor;
export declare const storeRouteV1Schema: TypeDescriptor;
