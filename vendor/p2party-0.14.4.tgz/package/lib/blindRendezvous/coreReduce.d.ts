/**
 * Deterministic outer-layer reduction (Section 4.7).
 *
 * `Merge` is set union and `CoreReduce` is a pure function of the validated
 * operation set, the immutable room policy, and an explicit reference window.
 * It reads no arrival timestamp, server identity, fetch order, frontend
 * allow/deny state, planner preference, wall clock, "first response" state,
 * pair secret, or inner pair validity — that exclusion list is the whole
 * reason two honest clients with the same delivered set derive byte-identical
 * state no matter which carrier delivered what, in which order.
 *
 * Scope: this module implements the outer layer — author-chain and quota
 * faults, the active operation set, the pair-step projection, and
 * `operationsDigest`. The payload-level facts of `CoreRoomStateV1`
 * (`observedPresences`, `effectiveLeaveOperationIds`, `storeCatalogFacts`,
 * `revocationFloors`) require the Section 4.2/4.9 nested payload codecs, which
 * are not implemented yet; `coreReduceOuter` therefore returns exactly the
 * facts it can derive and names the rest as pending rather than emitting an
 * empty array that would read as "no presences observed".
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { AuthenticatedRoomOperationV1, OperationValidationContext } from "./operation";
import type { RoomPolicyV4 } from "./roomPolicyV4";
declare const validatedIdentifiedOperationBrand: unique symbol;
/** One fully validated operation together with its derived private ID. */
export interface ValidatedIdentifiedOperationV1 {
    readonly [validatedIdentifiedOperationBrand]: true;
    readonly operationId: Uint8Array;
    readonly operation: AuthenticatedRoomOperationV1;
}
/**
 * The sole ingress from untrusted decoded bytes into the reducer domain.
 *
 * The caller-owned object is canonically snapshotted before the first await;
 * all validation and ID derivation use that private copy. OperationId is
 * derived only after complete outer validation, including PAIR_STEP slot
 * binding and the author signature. The returned provenance brand is an
 * in-memory trust marker, never persisted protocol state and never a
 * substitute for revalidation after restore.
 */
export declare const validateAndIdentifyOperation: (operation: AuthenticatedRoomOperationV1, context: OperationValidationContext, module?: LibCrypto) => Promise<ValidatedIdentifiedOperationV1>;
export type CoreFaultV1 = {
    readonly kind: "author-fork-or-overquota";
    readonly authorEpochEd25519Key: Uint8Array;
    readonly logicalWindow: bigint;
    readonly proofOperationIds: readonly Uint8Array[];
};
export interface CoreOuterStateV1 {
    readonly version: 1;
    readonly referenceWindow: bigint;
    readonly activeOperationIds: readonly Uint8Array[];
    readonly activePairOuterOperationIds: readonly Uint8Array[];
    readonly faults: readonly CoreFaultV1[];
    readonly operationsDigest: Uint8Array;
    /**
     * Payload-level reduction that this increment does not perform. A caller
     * must not present the absence of these facts as an observation.
     */
    readonly pendingPayloadReduction: readonly ("observedPresences" | "effectiveLeaveOperationIds" | "storeCatalogFacts" | "revocationFloors" | "roomCapacityState")[];
}
export declare const mergeOperationSets: (left: readonly ValidatedIdentifiedOperationV1[], right: readonly ValidatedIdentifiedOperationV1[]) => ValidatedIdentifiedOperationV1[];
/**
 * `CoreReduce` over the outer layer.
 *
 * Every decision below is a function of the operation bytes and the explicit
 * reference window. In particular, fork and overquota classification precedes
 * any payload work and is arrival-independent: an author that occupies one
 * `(key, window, sequence)` slot with two different byte strings, or that
 * exceeds `maxOperationsPerAuthorWindow` candidates, has its whole window
 * excluded no matter which operation arrived first.
 */
export declare const coreReduceOuter: (operations: readonly ValidatedIdentifiedOperationV1[], roomPolicy: RoomPolicyV4, referenceWindow: bigint) => Promise<CoreOuterStateV1>;
export {};
