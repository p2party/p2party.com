/**
 * Canonical room-visible pair envelope framing (Section 4.11).
 *
 * This is deliberately only the endpoint-independent outer boundary. It
 * validates routing-tag framing, bootstrap-header/nonce state, and exact
 * class-sized ciphertext framing without opening pair AEAD or interpreting a
 * `PairPlaintextV1`. Tag expectation/one-use, admission, and the edge-local
 * pair state machine remain outside this module.
 *
 * Status: PROPOSED, NOT FROZEN. This implements the Phase-0 outer boundary,
 * but does not by itself publish a release-registry vector or interoperability
 * claim.
 *
 * The schema and operation class table are the size SSOTs. Framing overhead is
 * measured from a canonical empty-ciphertext encoding, then the exact
 * ciphertext and plaintext targets are derived from it. No second target table
 * is maintained here.
 */
import type { OperationPayloadClassV1 } from "./operation";
export declare const PAIR_STEP_ENVELOPE_VERSION_V1 = 1;
export declare const PAIR_BOOTSTRAP_HEADER_VERSION_V1 = 1;
export declare const PAIR_BOOTSTRAP_SUITE_ID_V1 = 1;
export declare const PAIR_AEAD_TAG_BYTES_V1 = 16;
export interface PairBootstrapHeaderV1 {
    version: 1;
    suiteId: 1;
    hybridKemCiphertext: Uint8Array;
}
export interface PairStepEnvelopeV1 {
    version: 1;
    pairRoutingTag: Uint8Array;
    bootstrapHeader: PairBootstrapHeaderV1 | null;
    nonce: Uint8Array | null;
    pairCiphertextAndTag: Uint8Array;
}
export declare class PairStepEnvelopeError extends Error {
    readonly name = "PairStepEnvelopeError";
    constructor(message: string);
}
/**
 * These exported values are projections of the schema above, not literals.
 * Changing an optional tag, fixed field, or length prefix changes them
 * automatically and therefore changes every derived target/vector.
 */
export declare const PAIR_BOOTSTRAP_ENVELOPE_OVERHEAD_BYTES_V1: number;
export declare const PAIR_ESTABLISHED_ENVELOPE_OVERHEAD_BYTES_V1: number;
/**
 * Exact `pairCiphertextAndTag` bytes for one permitted outer envelope form.
 * Suite 1 deliberately has no class-1 bootstrap form.
 */
export declare const pairCiphertextAndTagTargetBytesV1: (operationPayloadClass: OperationPayloadClassV1, bootstrap: boolean) => number;
/** Exact authenticated pair-plaintext target after removing the AEAD tag. */
export declare const pairPlaintextTargetBytesV1: (operationPayloadClass: OperationPayloadClassV1, bootstrap: boolean) => number;
/** Validate a decoded envelope against its signed outer payload class. */
export declare const validatePairStepEnvelopeV1: (envelope: PairStepEnvelopeV1, operationPayloadClass: OperationPayloadClassV1) => void;
/** Encode only after all class-dependent outer invariants hold. */
export declare const encodePairStepEnvelopeV1: (envelope: PairStepEnvelopeV1, operationPayloadClass: OperationPayloadClassV1) => Uint8Array;
/** Decode uniquely, then enforce the signed class-dependent invariants. */
export declare const decodePairStepEnvelopeV1: (encoded: Uint8Array, operationPayloadClass: OperationPayloadClassV1) => PairStepEnvelopeV1;
