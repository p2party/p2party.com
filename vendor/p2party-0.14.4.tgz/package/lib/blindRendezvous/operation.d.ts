/**
 * The canonical authenticated room operation (Section 4.4).
 *
 * Outer validity is deliberately endpoint-independent: every room member can
 * validate the canonical framing, author chain, lifetime, payload class, slot,
 * and signature of any operation — including a `PAIR_STEP` addressed to two
 * other members — so the same delivered bytes enter every member's core set.
 * Pair AEAD and inner ledger rules are a separate edge-local step that can
 * fail one edge without removing the operation from `CoreRoomState`. That
 * split is what keeps another pair's private plaintext out of room convergence.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { RoomPolicyV4 } from "./roomPolicyV4";
export type OperationKindV1 = "PRESENCE" | "LEAVE" | "PAIR_STEP" | "STORE_HINT" | "ADMISSION_REVOKE";
export type OperationLifetimeV1 = "WINDOW_TRANSIENT" | "GRANT_HORIZON" | "PAIR_CAUSAL";
export type OperationPayloadClassV1 = 0 | 1;
export interface AuthenticatedRoomOperationV1 {
    version: 1;
    roomContextConfirmation: Uint8Array;
    logicalWindow: bigint;
    expiresAfterWindow: bigint;
    lifetime: OperationLifetimeV1;
    authorEpochEd25519Key: Uint8Array;
    authorSequence: bigint;
    previousAuthorOperationId: Uint8Array | null;
    kind: OperationKindV1;
    semanticSlot: Uint8Array;
    dependencies: readonly Uint8Array[];
    operationPayloadClass: OperationPayloadClassV1;
    fixedPayload: Uint8Array;
    operationPadding: Uint8Array;
    authorSignature: Uint8Array;
}
export type UnsignedRoomOperationV1 = Omit<AuthenticatedRoomOperationV1, "authorSignature">;
export declare class OperationValidationError extends Error {
    readonly name = "OperationValidationError";
    constructor(message: string);
}
/**
 * The numerically smallest permitted class whose frozen codec fits the payload
 * (`OperationPayloadClassFor`). The sender must use it and the receiver
 * recomputes it, so a larger-than-necessary class is noncanonical rather than
 * merely wasteful — otherwise class choice would leak a sender-selectable
 * signal into a fixed-size traffic model.
 */
export declare const operationPayloadClassFor: (kind: OperationKindV1, payloadBytes: number) => OperationPayloadClassV1;
export interface OperationValidationContext {
    /** `RoomContextConfirmation` derived from the local room context. */
    readonly roomContextConfirmation: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    /** The explicit reference window; never ambient wall-clock time. */
    readonly referenceWindow: bigint;
}
/**
 * Public cheap structural gate.
 *
 * Its return type intentionally remains void: the decoded pair envelope is an
 * internal validation artifact, not a value callers may treat as trusted
 * without the semantic-slot and author-signature checks below.
 */
export declare const validateOperationStructure: (operation: AuthenticatedRoomOperationV1, context: OperationValidationContext) => void;
/** Verify the author signature over the exact domain-separated transcript. */
export declare const verifyOperationSignature: (operation: AuthenticatedRoomOperationV1, module?: LibCrypto) => Promise<boolean>;
/**
 * Full outer validation: structure, bounds, then signature.
 *
 * Order matters — an operation that fails a bound never reaches the
 * verification, and an operation that fails verification never reaches any
 * set, roster, admission view, catalog, or pair ledger (SEC-003).
 */
export declare const validateOperation: (operation: AuthenticatedRoomOperationV1, context: OperationValidationContext, module?: LibCrypto) => Promise<void>;
/** Sign an operation over the exact transcript and return the signed form. */
export declare const signOperation: (unsigned: UnsignedRoomOperationV1, authorSecretKey: Uint8Array, module?: LibCrypto) => Promise<AuthenticatedRoomOperationV1>;
/** The unique canonical encoding of a signed operation. */
export declare const encodeOperation: (operation: AuthenticatedRoomOperationV1) => Uint8Array;
/** Decode and prove the bytes are the unique encoding of the result. */
export declare const decodeOperation: (encoded: Uint8Array) => AuthenticatedRoomOperationV1;
/**
 * `OperationId`, derived only after carrier decryption and validation. It is
 * never sent to a store as a logical identifier.
 */
export declare const deriveOperationId: (operation: AuthenticatedRoomOperationV1) => Promise<Uint8Array>;
/** Build the all-zero padding a payload needs to reach its class length. */
export declare const operationPaddingFor: (operationPayloadClass: OperationPayloadClassV1, payloadBytes: number) => Uint8Array;
