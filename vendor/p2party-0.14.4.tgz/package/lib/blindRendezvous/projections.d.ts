/**
 * Generated projections of the canonical binary schema.
 *
 * REQ-024 and AC-047 make this indirection mandatory rather than stylistic:
 * types, codecs, fixtures, protocol tables, and UI claim keys are projections
 * of the schema, never a second hand-maintained authority. A validator that
 * kept its own key list would silently disagree with the wire format the day
 * one field is added.
 *
 * Everything here is derived by `recordFieldNames`/`enumValues` at module load
 * from `schemas.ts`. There is nothing to keep in sync by hand, which is the
 * point: `tests/blindRendezvous/projections.test.ts` proves the derivation
 * covers every validator table and every specified field.
 */
export declare const KERNEL_MANIFEST_KEYS: ReadonlySet<string>;
export declare const KERNEL_MODULE_KEYS: ReadonlySet<string>;
export declare const KERNEL_ENTRYPOINT_KEYS: ReadonlySet<string>;
export declare const CLAIM_REGISTRY_KEYS: ReadonlySet<string>;
export declare const CLAIM_ASSUMPTION_KEYS: ReadonlySet<string>;
export declare const CLAIM_EVIDENCE_KIND_KEYS: ReadonlySet<string>;
export declare const CLAIM_DEFINITION_KEYS: ReadonlySet<string>;
export declare const CLAIM_WORDING_KEY_LIST: readonly string[];
export declare const CLAIM_WORDING_KEYS: ReadonlySet<string>;
export declare const CLAIM_EVALUATION_KEYS: ReadonlySet<string>;
export declare const CLAIM_EVALUATION_INPUT_KEYS: ReadonlySet<string>;
export declare const CLAIM_ASSUMPTION_FOUNDATIONAL_VERIFICATION_KEYS: ReadonlySet<string>;
export declare const CLAIM_ASSUMPTION_EVIDENCE_VERIFICATION_KEYS: ReadonlySet<string>;
export declare const FORMAL_REGISTRY_KEYS: ReadonlySet<string>;
export declare const FORMAL_OBLIGATION_KEYS: ReadonlySet<string>;
export declare const FORMAL_RESULT_KEYS: ReadonlySet<string>;
export declare const ROOM_POLICY_V4_KEYS: ReadonlySet<string>;
export declare const DELIVERY_PROFILE_V1_KEYS: ReadonlySet<string>;
export declare const AUTHENTICATED_ROOM_OPERATION_V1_KEYS: ReadonlySet<string>;
export declare const PAIR_BOOTSTRAP_HEADER_V1_KEYS: ReadonlySet<string>;
export declare const PAIR_STEP_ENVELOPE_V1_KEYS: ReadonlySet<string>;
export declare const CARRIER_ENVELOPE_V1_KEYS: ReadonlySet<string>;
export declare const CLAIM_EVALUATION_STATES_ORDER: readonly string[];
export declare const CLAIM_SCOPE_KINDS_ORDER: readonly string[];
export declare const CLAIM_ASSUMPTION_KINDS_ORDER: readonly string[];
export declare const FORMAL_OBLIGATION_KINDS_ORDER: readonly string[];
export declare const FORMAL_PROOF_RESULTS_ORDER: readonly string[];
export declare const OPERATION_KINDS_ORDER: readonly string[];
export declare const OPERATION_LIFETIMES_ORDER: readonly string[];
export declare const CLAIM_EVALUATION_STATES: ReadonlySet<string>;
export declare const CLAIM_SCOPE_KINDS: ReadonlySet<string>;
export declare const CLAIM_ASSUMPTION_KINDS: ReadonlySet<string>;
export declare const FORMAL_OBLIGATION_KINDS: ReadonlySet<string>;
export declare const FORMAL_PROOF_RESULTS: ReadonlySet<string>;
export declare const OPERATION_KINDS: ReadonlySet<string>;
export declare const OPERATION_LIFETIMES: ReadonlySet<string>;
