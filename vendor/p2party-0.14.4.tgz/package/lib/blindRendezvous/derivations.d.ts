/**
 * Domain-separated derivations for blind rendezvous.
 *
 * Section 3.3 fixes the conventions used throughout: `H(x)` is SHA-256, `||`
 * is byte concatenation, a quoted domain string is its exact ASCII octets with
 * no terminator, and `U16BE`/`U32BE`/`U64BE`/`Byte` are exact big-endian
 * encodings that reject out-of-range input before a preimage is formed.
 *
 * Every formula below is transcribed from the specification and carries its
 * source label. A caller must not build one of these preimages by hand: the
 * domain string, argument order, and canonical encoding are protocol-visible.
 *
 * Status: PROPOSED, NOT FROZEN. The formulas are fixed by the specification,
 * but any value derived over a `Canonical(...)` argument inherits the
 * unfrozen status of `canonicalSchema.ts`, so no output here is a published
 * v0.4 release artifact yet.
 */
export declare class DerivationError extends Error {
    readonly name = "DerivationError";
    constructor(message: string);
}
/** Exact ASCII octets of a domain-separation string; no terminator. */
export declare const domain: (value: string) => Uint8Array;
export declare const byteOf: (value: number) => Uint8Array;
export declare const u16be: (value: number) => Uint8Array;
export declare const u32be: (value: number) => Uint8Array;
export declare const u64be: (value: bigint) => Uint8Array;
export declare const concatBytes: (...parts: readonly Uint8Array[]) => Uint8Array<ArrayBuffer>;
/** RFC 4648 URL-safe base64 with no padding. No lowercase variant exists. */
export declare const base64urlNoPad: (bytes: Uint8Array) => string;
export declare const base64urlNoPadDecode: (encoded: string) => Uint8Array;
/** `H(x) = SHA-256(x)` (Section 3.3). */
export declare const sha256: (input: Uint8Array) => Promise<Uint8Array>;
/**
 * RFC 5869 HKDF-Extract with SHA-256, which is exactly
 * `HMAC-SHA-256(key = salt, msg = ikm)`. The HMAC itself comes from WebCrypto;
 * this composes the standard construction and does not implement a primitive.
 */
export declare const hkdfSha256Extract: (salt: Uint8Array, ikm: Uint8Array) => Promise<Uint8Array>;
/** RFC 5869 §2.3 HKDF-Expand with SHA-256. */
export declare const hkdfSha256Expand: (prk: Uint8Array, info: Uint8Array, length: number) => Promise<Uint8Array>;
/** `PolicyHash = H("p2party/room-policy/v4" || Canonical(RoomPolicyV4))` */
export declare const policyHash: (roomPolicy: unknown) => Promise<Uint8Array>;
/**
 * `RoomRoot = HKDF-Extract(salt = PolicyHash, ikm = capability)`
 *
 * The result is a local secret and never crosses a carrier.
 */
export declare const roomRoot: (capability: Uint8Array, policyHashBytes: Uint8Array) => Promise<Uint8Array>;
/** `RoomContextId = H("p2party/room-context/v4" || capability || PolicyHash)` */
export declare const roomContextId: (capability: Uint8Array, policyHashBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `DeliveryProfileHash =
 *    H("p2party/delivery-profile/v1" || Canonical(DeliveryProfileV1))`
 */
export declare const deliveryProfileHash: (profile: unknown) => Promise<Uint8Array>;
/**
 * `LocalRoomId = Base64urlNoPad(H("p2party/local-room-id/v1" || RoomContextId))`
 *
 * This replaces the legacy server-assigned room UUID in local state and never
 * crosses a carrier.
 */
export declare const localRoomId: (roomContextIdBytes: Uint8Array) => Promise<string>;
/**
 * `StableIdentityCommitment =
 *    H("p2party/stable-identity-commitment/v1" ||
 *      RoomContextId || stableEd25519PublicKey)`
 *
 * This is a room-scoped pseudonym, not key hiding: a capability holder that
 * already knows a candidate public key can test it. The raw stable key never
 * needs to enter a room-wide presence payload.
 */
export declare const stableIdentityCommitment: (roomContextIdBytes: Uint8Array, stableEd25519PublicKey: Uint8Array) => Promise<Uint8Array>;
/**
 * `LocalPeerIdDigest =
 *    H("p2party/local-peer-id/v1" ||
 *      RoomContextId || StableIdentityCommitment)`
 */
export declare const localPeerIdDigest: (roomContextIdBytes: Uint8Array, stableIdentityCommitmentBytes: Uint8Array) => Promise<Uint8Array>;
/** `"peer.v1." || Base64urlNoPad(LocalPeerIdDigest)` */
export declare const localPeerId: (roomContextIdBytes: Uint8Array, stableIdentityCommitmentBytes: Uint8Array) => Promise<string>;
/**
 * `RoomContextConfirmation = H("p2party/room-confirmation/v1" || RoomContextId)`
 */
export declare const roomContextConfirmation: (roomContextIdBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `OperationId =
 *    H("p2party/room-operation/v1" || Canonical(AuthenticatedRoomOperationV1))`
 *
 * Derived only after carrier AEAD and operation validation; it is never sent
 * to a store as a logical identifier.
 */
export declare const operationId: (operation: unknown) => Promise<Uint8Array>;
/**
 * The operation signature transcript:
 * `"p2party/room-operation-signature/v1" || Canonical(every preceding field)`.
 * The length-disjoint domain prefix is part of the signed bytes.
 */
export declare const operationSignatureMessage: (unsignedOperation: unknown) => Uint8Array;
/**
 * `PresenceSemanticSlot = H("p2party/presence-slot/v1" ||
 *    authorEpochEd25519Key || U64BE(logicalWindow) || presenceNonce)`
 */
export declare const presenceSemanticSlot: (authorEpochEd25519Key: Uint8Array, logicalWindow: bigint, presenceNonce: Uint8Array) => Promise<Uint8Array>;
/**
 * `LeaveSemanticSlot = H("p2party/leave-slot/v1" ||
 *    presenceOperationId || U64BE(effectiveLogicalWindow))`
 */
export declare const leaveSemanticSlot: (presenceOperationId: Uint8Array, effectiveLogicalWindow: bigint) => Promise<Uint8Array>;
/**
 * `StoreHintSemanticSlot = H("p2party/store-hint-slot/v1" ||
 *    StoreId(descriptor) || U64BE(descriptorGeneration))`
 */
export declare const storeHintSemanticSlot: (storeId: Uint8Array, descriptorGeneration: bigint) => Promise<Uint8Array>;
/**
 * `AdmissionRevokeSemanticSlot = H("p2party/admission-revoke-slot/v1" ||
 *    stableIdentityCommitment || U64BE(minimumAcceptedGeneration) ||
 *    U64BE(effectiveLogicalWindow) || U64BE(expiresAfterLogicalWindow))`
 */
export declare const admissionRevokeSemanticSlot: (stableIdentityCommitment: Uint8Array, minimumAcceptedGeneration: bigint, effectiveLogicalWindow: bigint, expiresAfterLogicalWindow: bigint) => Promise<Uint8Array>;
/** `H("p2party/pair-slot/v1" || pairRoutingTag)` (Section 4.4 slot table). */
export declare const pairSemanticSlot: (pairRoutingTag: Uint8Array) => Promise<Uint8Array>;
export interface CarrierEnvelopeCoordinates {
    readonly deliveryProfileHash: Uint8Array;
    readonly carrierContextId: Uint8Array;
    readonly ingressWindow: bigint;
    readonly sizeClass: number;
}
/**
 * `CarrierKey = HKDF-Expand(RoomRoot,
 *    "p2party/carrier-envelope-key/v1" || DeliveryProfileHash ||
 *    carrierContextId || U64BE(ingressWindow) || Byte(sizeClass) || nonce, 32)`
 */
export declare const carrierKey: (roomRootBytes: Uint8Array, coordinates: CarrierEnvelopeCoordinates, nonce: Uint8Array) => Promise<Uint8Array>;
/**
 * `CarrierAAD = "p2party/carrier-envelope-aad/v1" || Byte(version) ||
 *    DeliveryProfileHash || U64BE(ingressWindow) || Byte(sizeClass) ||
 *    carrierContextId`
 *
 * The AAD deliberately omits the nonce: the nonce is a key selector, and the
 * key schedule already binds it.
 */
export declare const carrierAad: (version: number, coordinates: CarrierEnvelopeCoordinates) => Uint8Array;
/**
 * `CarrierObjectId = H("p2party/carrier-object/v1" || Canonical(CarrierEnvelopeV1))`
 *
 * Useful only inside one carrier context; clients deduplicate by the private
 * `OperationId` after decryption.
 */
export declare const carrierObjectId: (envelope: unknown) => Promise<Uint8Array>;
/**
 * `operationsDigest =
 *    H("p2party/core-operation-set/v1" || Canonical(activeOperationIds))`
 *
 * The same formula serves the R2 conformance record's required-operation
 * digest.
 */
export declare const coreOperationSetDigest: (operationIds: readonly Uint8Array[]) => Promise<Uint8Array>;
export declare const executableKernelManifestHash: (manifest: unknown) => Promise<Uint8Array>;
/**
 * `KernelModuleSemanticsHash(module) =
 *    H("p2party/executable-kernel-module-semantics/v1" || module.moduleId ||
 *      Canonical(sorted entrypoint tuples))`
 *
 * `moduleId` is a `Uint16` schema field, so it enters the preimage as `U16BE`.
 */
export declare const kernelModuleSemanticsHash: (module: {
    readonly moduleId: number;
    readonly entrypoints: readonly unknown[];
}) => Promise<Uint8Array>;
/**
 * `KernelSourceTreeHash(files) = H("p2party/executable-kernel-source-tree/v1"
 *    || Canonical(Sort(normalizedRelativePath, H(fileBytes))))`
 *
 * Absolute paths, timestamps, filesystem order, and build-host metadata are
 * excluded by construction.
 */
export declare const kernelSourceTreeHash: (files: readonly {
    readonly normalizedRelativePath: string;
    readonly fileDigest: Uint8Array;
}[]) => Promise<Uint8Array>;
export declare const claimRegistryHash: (registry: unknown) => Promise<Uint8Array>;
export declare const claimWordingCatalogHash: (catalog: unknown) => Promise<Uint8Array>;
export declare const formalObligationRegistryHash: (registry: unknown) => Promise<Uint8Array>;
/**
 * `ClaimScopeDigest = H("p2party/claim-scope/v1" || U16BE(claimId) ||
 *    ClaimScopeKindByte(scopeKind) || scopeSchemaHash || canonicalScope)`
 */
export declare const claimScopeDigest: (claimId: number, scopeKindByte: number, scopeSchemaHash: Uint8Array, canonicalScope: Uint8Array) => Promise<Uint8Array>;
export declare const claimEvaluationDatasetDigest: (dataset: unknown) => Promise<Uint8Array>;
/**
 * `FormalAssumptionSetHash = H("p2party/formal-assumption-set/v1" ||
 *    claimRegistryHash || Canonical(resolved sorted ClaimAssumptionV1 records))`
 */
export declare const formalAssumptionSetHash: (claimRegistryHashBytes: Uint8Array, resolvedAssumptions: readonly unknown[]) => Promise<Uint8Array>;
/**
 * `FormalProofScopeDigest = H("p2party/formal-proof-scope/v1" ||
 *    U16BE(obligationId) || proofScopeSchemaHash || canonicalScope)`
 */
export declare const formalProofScopeDigest: (obligationId: number, proofScopeSchemaHash: Uint8Array, canonicalScope: Uint8Array) => Promise<Uint8Array>;
/**
 * `EmptySchedulerWorkloadDigest = H("p2party/scheduler-workload/v1/none")`
 *
 * Only FPO-002 accepts a nonempty scheduler workload; every other obligation
 * uses this closed sentinel so an unrelated workload cannot alter another
 * property's identity.
 */
export declare const emptySchedulerWorkloadDigest: () => Promise<Uint8Array>;
export declare const claimEvaluationDigest: (evaluation: unknown) => Promise<Uint8Array>;
export declare const formalProofResultDigest: (result: unknown) => Promise<Uint8Array>;
