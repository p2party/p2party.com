export type SignalingPeerRequestKind = "join" | "empty-roster";
/**
 * Bounds repeated peer-list requests only within one socket lifecycle.
 *
 * A reconnect must never inherit the previous socket's timestamp: the first
 * post-proof request is what rebuilds all WebRTC edges after teardown.
 */
export declare class SignalingPeerRequestDebouncer {
    #private;
    shouldSend(kind: SignalingPeerRequestKind, roomId: string, minimumIntervalMs: number, now?: number): boolean;
    resetSocketLifecycle(): void;
}
export declare const signalingPeerRequestDebouncer: SignalingPeerRequestDebouncer;
