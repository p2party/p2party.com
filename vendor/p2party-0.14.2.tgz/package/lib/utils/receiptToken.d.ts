/**
 * Chunk receipts are deliberately not raw Merkle leaf hashes. Binding the
 * receipt to the message root and leaf position prevents an identical leaf in
 * another transfer from acknowledging the wrong outbound chunk.
 */
export declare const CHUNK_RECEIPT_DOMAIN: Uint8Array<ArrayBuffer>;
export declare const createChunkReceiptToken: (merkleRoot: Uint8Array, chunkIndex: number, leafHash: Uint8Array) => Promise<Uint8Array>;
