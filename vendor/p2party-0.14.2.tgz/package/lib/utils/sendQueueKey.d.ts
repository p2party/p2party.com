/** Scope the legacy IndexedDB send-queue key to one room without changing its schema. */
export declare const roomSendQueueLabel: (roomId: string, label: string) => string;
