import type { WebSocketMessageChallengeRequest, WebSocketMessageSuccessfulChallenge } from "./interfaces";
/**
 * Exact protocol-v3 server challenge. Legacy reconnect credentials are
 * deliberately not accepted: every WebSocket must prove possession anew.
 */
export declare const isFreshV3Challenge: (value: unknown) => value is WebSocketMessageChallengeRequest;
/** Exact protocol-v3 proof-success response, with an all-or-none TURN pair. */
export declare const isV3ChallengeSuccess: (value: unknown) => value is WebSocketMessageSuccessfulChallenge;
