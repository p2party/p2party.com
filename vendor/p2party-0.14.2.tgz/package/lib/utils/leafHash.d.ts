import type { LibCrypto } from "../cryptography/libcrypto";
export declare const MERKLE_LEAF_DOMAIN = 0;
/**
 * Domain-separated Merkle leaf hash computed in **libsodium (C)**:
 * `SHA-512(0x00 ‖ chunk)`, byte-identical to the WebCrypto `hashMerkleLeaf`
 * above and to the C `receive_message_with_key` leaf (pake_ratchet.c:155-164).
 * Synchronous — the WASM SHA-512 runs inline (init → update(0x00 ‖ chunk) →
 * final). Used on the RECEIVE path (Merkle verification + the receipt token) so
 * every leaf hash there is libsodium rather than browser crypto. `module` must
 * expose `_sha512_init/update/final` + `_malloc/_free` (the main crypto module).
 */
export declare const hashMerkleLeafWasm: (chunk: Uint8Array, module: LibCrypto) => Uint8Array;
export declare const hashMerkleLeaf: (chunk: Uint8Array) => Promise<Uint8Array>;
