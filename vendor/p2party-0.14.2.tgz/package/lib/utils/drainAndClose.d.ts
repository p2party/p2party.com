export declare const drainAndClose: (dc: {
    readyState: string;
    bufferedAmount: number;
    close: () => void;
}, timeoutMs?: number, pollMs?: number) => Promise<void>;
