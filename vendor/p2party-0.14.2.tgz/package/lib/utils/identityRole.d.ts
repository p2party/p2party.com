/**
 * Deterministic role for one stable Ed25519 identity edge.
 *
 * Lexical ordering is safe only for the one canonical wire representation:
 * exactly 32 bytes encoded as 64 lowercase hexadecimal characters. Rejecting
 * uppercase/invalid encodings is part of role agreement, not cosmetic input
 * cleanup — otherwise two peers can compare different strings for the same key
 * and both (or neither) decide to open the persistent `main` channel.
 */
export declare const CANONICAL_ED25519_IDENTITY_RE: RegExp;
export declare const isCanonicalEd25519Identity: (publicKey: unknown) => publicKey is string;
export declare const assertCanonicalEd25519Identity: (publicKey: string, label?: string) => void;
export declare const isIdentityInitiator: (selfPublicKey: string, peerPublicKey: string) => boolean;
/**
 * Only the non-opener may accept a remotely-created `main` DataChannel. The
 * designated opener receives `main`; accepting another inbound copy on that
 * side would allow duplicate handshakes to race for one room/peer edge.
 */
export declare const shouldAcceptIncomingMain: (selfPublicKey: string, peerPublicKey: string) => boolean;
