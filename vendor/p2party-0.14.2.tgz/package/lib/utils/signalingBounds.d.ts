export declare const MAX_SIGNALING_MESSAGE_CHARS: number;
export declare const MAX_SDP_CHARS: number;
export declare const MAX_ICE_CANDIDATE_CHARS = 4096;
export declare const MAX_ICE_FIELD_CHARS = 256;
export declare const MAX_SIGNALING_LABELS = 64;
export declare const MAX_DATA_CHANNEL_LABEL_CHARS = 193;
export declare const isBoundedDescription: (description: RTCSessionDescription | RTCSessionDescriptionInit) => boolean;
export declare const isBoundedIceCandidate: (candidate: RTCIceCandidateInit | RTCIceCandidate) => boolean;
export declare const areBoundedDataChannelLabels: (labels: unknown) => labels is string[];
