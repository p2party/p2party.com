/**
 * A simple async mutex for serializing access to shared resources.
 *
 * In this codebase, shared WebAssembly.Memory objects back WASM module
 * instances used across async operations. Because JavaScript is
 * single-threaded, synchronous WASM calls between `await` points are
 * atomic. However, multiple async operations (e.g. concurrent RTK Query
 * mutations) can interleave at `await` boundaries, leading to
 * corruption of the shared linear memory (overlapping _malloc regions,
 * stale ArrayBuffer views after memory growth, etc.).
 *
 * Wrapping the critical section with this mutex ensures only one async
 * operation accesses the shared WASM memory at a time.
 */
export declare class AsyncMutex {
    private queue;
    private locked;
    private idleWaiters;
    acquire(): Promise<void>;
    release(): void;
    isIdle(): boolean;
    whenIdle(): Promise<void>;
    runExclusive<T>(fn: () => Promise<T>): Promise<T>;
}
