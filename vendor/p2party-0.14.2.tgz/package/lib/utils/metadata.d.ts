export interface BasicMetadata {
    schemaVersion: number;
    messageType: number;
    hash: Uint8Array;
    totalSize: number;
    date: Date;
    name: string;
    chunkStartIndex: number;
    chunkEndIndex: number;
}
export interface Metadata extends BasicMetadata {
    chunkIndex: number;
}
/**
 * Validate the authenticated metadata profile before any offsets are used or
 * storage is allocated. All numeric wire fields are uint64s; converting a
 * value above 2^53-1 to Number loses precision, so those values fail closed.
 */
export declare const assertMetadataV1: (metadata: Metadata) => void;
export declare const formatSize: (size: number) => string;
export declare const serializeMetadata: (metadata: Metadata) => Uint8Array;
export declare const deserializeMetadata: (buffer: Uint8Array) => Metadata;
