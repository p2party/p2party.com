export declare const waitForOpen: (dc: {
    readyState: string;
}, timeoutMs?: number, pollMs?: number, signal?: AbortSignal) => Promise<boolean>;
