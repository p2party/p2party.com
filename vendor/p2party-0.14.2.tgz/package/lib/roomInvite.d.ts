export declare const ROOM_CAPABILITY_BYTES = 32;
export declare const ROOM_CAPABILITY_HEX_CHARS: number;
export declare const ROOM_CAPABILITY_BASE64URL_CHARS = 43;
export declare const ROOM_INVITE_WORDS = 24;
export declare const ROOM_INVITE_VERSION = 1;
export declare const ROOM_INVITE_PREFIX: string;
export declare const ROOM_INVITE_WORDLIST_ID = "p2party-invite-en-v1";
export declare const generateRoomCapability: () => Uint8Array;
export declare const encodeRoomCapabilityBase64Url: (capability: Uint8Array) => string;
export declare const decodeRoomCapabilityBase64Url: (encoded: string) => Uint8Array;
/** Accept the compact representation or the legacy hex migration form. */
export declare const decodeRoomCapability: (encoded: string) => Uint8Array;
/** Canonical internal/server representation while the legacy signaling path exists. */
export declare const normalizeRoomCapability: (encoded: string) => string;
export declare const encodeRoomInviteFragment: (capability: Uint8Array) => string;
export declare const decodeRoomInviteFragment: (fragment: string) => Uint8Array;
export declare const encodeRoomCapabilityWords: (capability: Uint8Array) => Promise<string>;
export declare const decodeRoomCapabilityWords: (encoded: string) => Promise<Uint8Array>;
