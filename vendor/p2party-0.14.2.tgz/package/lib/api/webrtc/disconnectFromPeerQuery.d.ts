import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCIceCandidate, IRTCPeerConnection, RTCDisconnectFromPeerParams } from "./interfaces";
export interface RTCDisconnectFromPeerParamsExtension extends RTCDisconnectFromPeerParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
    iceCandidates: IRTCIceCandidate[];
}
declare const webrtcDisconnectPeerQuery: BaseQueryFn<RTCDisconnectFromPeerParamsExtension, undefined>;
export default webrtcDisconnectPeerQuery;
