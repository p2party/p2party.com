/**
 * Return every ICE username fragment advertised by the active remote SDP.
 * Multiple values are legitimate when media sections are not bundled.
 */
export declare const remoteIceUsernameFragments: (description: RTCSessionDescription | RTCSessionDescriptionInit | null) => Set<string>;
/**
 * Prefer the structured usernameFragment, but recover the optional `ufrag`
 * candidate extension when signaling supplied only a candidate string.
 */
export declare const candidateIceUsernameFragment: (candidate: RTCIceCandidateInit) => string | null;
/**
 * Reject a candidate that explicitly names an ICE generation absent from the
 * active remote description. Candidates without a ufrag remain acceptable:
 * older signaling payloads omit it and the browser can still route them by
 * sdpMid/sdpMLineIndex.
 */
export declare const candidateMatchesRemoteIceGeneration: (candidate: RTCIceCandidateInit, remoteDescription: RTCSessionDescription | RTCSessionDescriptionInit | null) => boolean;
