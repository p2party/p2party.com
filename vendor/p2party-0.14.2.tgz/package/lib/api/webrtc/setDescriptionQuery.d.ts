import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { RTCSetDescriptionParams, IRTCPeerConnection, IRTCIceCandidate, IRTCDataChannel } from "./interfaces";
export interface RTCSetDescriptionParamsExtension extends RTCSetDescriptionParams {
    peerConnections: IRTCPeerConnection[];
    iceCandidates: IRTCIceCandidate[];
    dataChannels: IRTCDataChannel[];
}
declare const webrtcSetDescriptionQuery: BaseQueryFn<RTCSetDescriptionParamsExtension, undefined>;
export default webrtcSetDescriptionQuery;
