import { AsyncMutex } from "../../utils/mutex";
export declare const getRoomPeerMutex: (roomId: string, peerId: string) => AsyncMutex;
/**
 * Forget a terminal edge only after its current owner and queued signaling
 * operations drain. Deleting a locked mutex would permit a second instance to
 * enter the same critical section concurrently.
 */
export declare const releaseRoomPeerMutex: (roomId: string, peerId: string) => void;
/** Narrow test visibility without exposing the mutable registry. */
export declare const hasRoomPeerMutex: (roomId: string, peerId: string) => boolean;
export declare const getRoomIdentityMutex: (roomId: string, peerPublicKey: string) => AsyncMutex;
export declare const releaseRoomIdentityMutex: (roomId: string, peerPublicKey: string) => void;
