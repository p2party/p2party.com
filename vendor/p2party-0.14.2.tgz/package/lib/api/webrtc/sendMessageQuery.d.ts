import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCPeerConnection, RTCSendMessageParams } from "./interfaces";
import type { SendMessageResult } from "../../handlers/handleSendMessage";
export interface RTCChannelMessageParamsExtension extends RTCSendMessageParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
}
/**
 * Every logical send owns independent fixed WASM memories. Large-file hashing,
 * per-message reconciliation, and reconnect waits therefore never hold a
 * process-wide crypto mutex or block sends in another room.
 */
declare const webrtcMessageQuery: BaseQueryFn<RTCChannelMessageParamsExtension, SendMessageResult | undefined>;
export default webrtcMessageQuery;
