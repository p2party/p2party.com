import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { RTCOpenChannelParams, IRTCDataChannel, IRTCPeerConnection } from "./interfaces";
export interface RTCOpenChannelParamsExtention extends RTCOpenChannelParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
}
declare const webrtcOpenChannelQuery: BaseQueryFn<RTCOpenChannelParamsExtention, undefined>;
export default webrtcOpenChannelQuery;
