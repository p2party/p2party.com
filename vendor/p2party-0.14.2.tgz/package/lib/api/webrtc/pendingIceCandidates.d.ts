import type { IRTCIceCandidate } from "./interfaces";
/** Bounds unauthenticated signaling state held before an SDP creates an edge. */
export declare const MAX_PENDING_ICE_PER_EDGE = 64;
export declare const MAX_PENDING_ICE_TOTAL = 1024;
export declare const normalizeIceCandidate: (candidate: RTCIceCandidateInit | RTCIceCandidate) => RTCIceCandidateInit;
export declare const enqueuePendingIceCandidate: (queue: IRTCIceCandidate[], roomId: string, peerId: string, candidate: RTCIceCandidateInit) => void;
export declare const enqueueConnectionIceCandidate: (queue: RTCIceCandidateInit[], candidate: RTCIceCandidateInit) => void;
export declare const takePendingIceCandidates: (queue: IRTCIceCandidate[], roomId: string, peerId: string) => RTCIceCandidateInit[];
export declare const discardPendingIceCandidates: (queue: IRTCIceCandidate[], roomId: string, peerId: string) => void;
/**
 * Abandon one room/peer SDP attempt without disturbing the same peer's ICE
 * candidates in another room.
 */
export declare const discardIceCandidatesForAttempt: (connectionQueue: RTCIceCandidateInit[], pendingQueue: IRTCIceCandidate[], roomId: string, peerId: string) => void;
