import type { IRTCPeerConnection } from "./interfaces";
export declare const isRoomPeerConnection: (connection: IRTCPeerConnection, roomId: string, peerId: string) => boolean;
export declare const findRoomPeerConnectionIndex: (connections: IRTCPeerConnection[], roomId: string, peerId: string) => number;
export declare const findRoomPeerConnection: (connections: IRTCPeerConnection[], roomId: string, peerId: string) => IRTCPeerConnection | undefined;
/**
 * A peerId is a transient signaling handle; the Ed25519 public key is the
 * stable cryptographic identity. Return transports in this room which claim
 * the same stable identity under a different peerId so callers can replace
 * them before a second live ratchet owner is created.
 */
export declare const findRoomIdentityAliases: (connections: IRTCPeerConnection[], roomId: string, peerId: string, peerPublicKey: string) => IRTCPeerConnection[];
