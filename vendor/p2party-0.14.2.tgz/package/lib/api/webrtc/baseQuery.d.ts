import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { RTCPeerConnectionParams, IRTCPeerConnection, IRTCDataChannel } from "./interfaces";
export interface RTCPeerConnectionParamsExtend extends RTCPeerConnectionParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
}
declare const webrtcBaseQuery: BaseQueryFn<RTCPeerConnectionParamsExtend, undefined>;
export default webrtcBaseQuery;
