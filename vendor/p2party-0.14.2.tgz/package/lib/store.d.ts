export declare const store: import("@reduxjs/toolkit").EnhancedStore<{
    commonState: import("./reducers/commonSlice").CommonState;
    keyPair: import(".").KeyPair;
    rooms: import(".").Room[];
    signalingServer: import(".").SignalingState;
    signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
        connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
    }, never, "signalingServerApi">;
    webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
        connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, import("./handlers/handleSendMessage").SendMessageResult | undefined, "webrtcApi", undefined>;
        disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
    }, never, "webrtcApi">;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        commonState: import("./reducers/commonSlice").CommonState;
        keyPair: import(".").KeyPair;
        rooms: import(".").Room[];
        signalingServer: import(".").SignalingState;
        signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        }, never, "signalingServerApi">;
        webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, import("./handlers/handleSendMessage").SendMessageResult | undefined, "webrtcApi", undefined>;
            disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        }, never, "webrtcApi">;
    }, undefined, import("redux").UnknownAction> & ((action: import("redux").Action<"listenerMiddleware/add">) => import("@reduxjs/toolkit").UnsubscribeListener);
}>, import("redux").StoreEnhancer]>>;
export type AppDispatch = typeof store.dispatch;
export type State = ReturnType<typeof store.getState>;
export declare const dispatch: AppDispatch;
