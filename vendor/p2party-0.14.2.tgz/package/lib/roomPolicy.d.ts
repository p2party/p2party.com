import type { RatchetRootSuite } from "./utils/constants";
/**
 * Canonical, non-secret room policy descriptor.
 *
 * The PIN is deliberately not a field: only the fact that CPace/PIN
 * authentication is required is authenticated with the policy. PIN bytes live
 * exclusively in the transient roomPinVault module.
 */
export type RoomAuthMode = "nopin" | "pin";
/**
 * The room creator fixes one authenticated hybrid bootstrap suite for every
 * edge in the room. Peers never negotiate, downgrade, or fall back: a policy
 * mismatch changes the transcript and makes the handshake fail closed.
 */
export type RoomPqMode = "hybrid-mlkem512" | "hybrid-mlkem768" | "hybrid-mlkem1024";
export type RoomRendezvousMode = "legacy-signaling" | "opaque-token" | "blind-meeting-point";
export type RoomCoverMode = "immediate" | "scheduled";
export declare const roomPqModeToParameterSet: (mode: RoomPqMode) => 512 | 768 | 1024;
export declare const roomPqModeToRootSuite: (mode: RoomPqMode) => RatchetRootSuite;
export declare const rootSuiteToRoomPqMode: (suite: RatchetRootSuite) => RoomPqMode;
export interface RoomPolicyV1 {
    version: 1;
    revision: number;
    wireVersion: 4;
    authMode: RoomAuthMode;
    pqMode: RoomPqMode;
    rendezvousMode: RoomRendezvousMode;
    coverMode: RoomCoverMode;
    coverCadenceMs: number;
    coverLanes: number;
    coverFramesPerCell: number;
    coverDurationEpochs: number;
}
export declare const ROOM_POLICY_V1_ENCODED_LEN = 32;
export declare const ROOM_POLICY_V1_HASH_LEN = 32;
export declare const MIN_COVER_CADENCE_MS = 1000;
export declare const MAX_COVER_CADENCE_MS = 3600000;
export declare const MAX_COVER_LANES = 16;
export declare const MAX_COVER_FRAMES_PER_CELL = 1024;
export declare const MIN_COVER_SLOT_MS = 25;
export declare const validateRoomPolicyV1: (policy: RoomPolicyV1) => void;
/**
 * Fixed-width V1 wire form (all integers big-endian):
 *
 *   magic(4) | format(1) | wire(1) | auth(1) | pq(1) |
 *   rendezvous(1) | cover(1) | revision(4) | cadence_ms(4) |
 *   lanes(2) | frames_per_cell(2) | duration_epochs(2) | reserved_zero(8)
 */
export declare const encodeRoomPolicyV1: (policy: RoomPolicyV1) => Uint8Array;
export declare const decodeRoomPolicyV1: (encoded: Uint8Array) => RoomPolicyV1;
/** Validate and return a detached plain-object copy suitable for Redux state. */
export declare const canonicalizeRoomPolicyV1: (policy: RoomPolicyV1) => RoomPolicyV1;
export declare const roomPoliciesEqualV1: (left: RoomPolicyV1, right: RoomPolicyV1) => boolean;
/** SHA-256(domain || canonical fixed-width policy); suitable for transcript CI. */
export declare const hashRoomPolicyV1: (policy: RoomPolicyV1) => Promise<Uint8Array>;
/**
 * Current v3 behavior: no PIN, mandatory hybrid ML-KEM-768, legacy
 * signaling rendezvous, and immediate/no-cover delivery.
 */
export declare const DEFAULT_ROOM_POLICY_V1: Readonly<RoomPolicyV1>;
