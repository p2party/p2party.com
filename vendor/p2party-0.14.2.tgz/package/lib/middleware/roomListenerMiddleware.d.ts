declare const roomListenerMiddleware: import("@reduxjs/toolkit").ListenerMiddlewareInstance<unknown, import("redux-thunk").ThunkDispatch<unknown, unknown, import("redux").UnknownAction>, unknown>;
export default roomListenerMiddleware;
