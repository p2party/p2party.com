/**
 * Point the browser root at a self-hosted copy of this release's exact WASM.
 * The build-pinned SRI is still enforced. Configure once, before connect() or
 * any other operation first loads cryptography.
 */
export declare const setWasmSourceUrl: (source: string | URL) => void;
export declare const wasmLoader: (wasmMemory: WebAssembly.Memory) => Promise<import("./libcrypto").LibCrypto>;
