import type { LibCrypto } from "./libcrypto";
import type { RatchetHeader } from "./ratchet";
import type { RatchetRootSuite } from "../utils/constants";
/**
 * Context authenticated by the hybrid bootstrap and advanced by sparse PQ
 * healing. `rootKey` is reusable epoch state: this module copies it and never
 * wipes the caller's live buffer.
 */
export interface PqMessageKeyContext {
    readonly rootKey: Uint8Array;
    readonly binding: Uint8Array;
    readonly rootSuite: RatchetRootSuite;
    readonly epoch: bigint;
}
export declare const PQ_MESSAGE_KEY_BYTES: number;
export declare const PQ_MESSAGE_KEY_ROOT_BYTES = 32;
export declare const PQ_MESSAGE_KEY_BINDING_BYTES = 32;
/**
 * Combine one classical Double-Ratchet message key with the current PQ epoch
 * root:
 *
 *   PRK = HKDF-Extract-SHA512(salt = pqRoot, IKM = classicalMessageKey)
 *   key = HKDF-Expand-SHA512(PRK, canonicalContext, 32)
 *
 * Ownership is deliberate: `classicalMessageKey` is consumed and zeroed on
 * every success/failure path. The live `context.rootKey` remains reusable; only
 * an owned copy and the transient PRK are wiped. Callers that need the
 * classical key for multiple chunks must pass an owned copy on each call.
 */
export declare const combinePqMessageKey: (classicalMessageKey: Uint8Array, context: PqMessageKeyContext, header: RatchetHeader, module: LibCrypto) => Uint8Array;
