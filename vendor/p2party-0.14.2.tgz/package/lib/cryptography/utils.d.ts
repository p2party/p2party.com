export declare const randomNumberInRange: (min: number, max: number) => Promise<number>;
export declare const randomBytesToString: (len: number, withAlphabetSmall?: boolean, withAlphabetCapital?: boolean, withNumbers?: boolean) => Promise<string>;
export declare const generateRandomRoomUrl: (lenMin: number, lenMax?: number, withAlphabetSmall?: boolean, withAlphabetCapital?: boolean, withNumbers?: boolean) => Promise<string>;
export declare function uniformInt(min: number, max: number): number;
export declare function fisherYatesShuffle<T>(arr: T[]): T[];
/**
 * @function
 * Fisher-Yates shuffle of array.
 *
 * @param array: The array to randomly shuffle.
 *
 * @returns Promise<T[]>
 */
