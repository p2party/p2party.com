import type { LibCrypto } from "./libcrypto";
/** The signed/verified transcript: IDENTITY_CROSS_SIGN_DOMAIN ‖ X25519_pub. */
export declare const identityCrossSignMessage: (x25519Pub: Uint8Array) => Uint8Array;
/** Produce the cross-signature over (DOMAIN ‖ x25519Pub) with the Ed25519 secret. */
export declare const crossSignIdentityX25519: (x25519Pub: Uint8Array, ed25519Secret: Uint8Array, module?: LibCrypto) => Promise<Uint8Array>;
/** Verify a cross-signature against the peer's pinned Ed25519 identity pub. */
export declare const verifyIdentityCrossSig: (x25519Pub: Uint8Array, crossSig: Uint8Array, ed25519Pub: Uint8Array, module?: LibCrypto) => Promise<boolean>;
