import { type RatchetRootSuite } from "../utils/constants";
import type { LibCrypto } from "./libcrypto";
export declare const COVER_CELL_HEADER_BYTES: number;
export declare const COVER_CELL_PLAINTEXT_BYTES: number;
export declare const COVER_CELL_BINDING_BYTES = 32;
export declare const COVER_CELL_ROOT_BYTES = 32;
export declare const COVER_CELL_TOKEN_BYTES: number;
export declare const COVER_CELL_MAX_PAYLOAD_BYTES: number;
export type CoverCellDirection = "initiator-to-responder" | "responder-to-initiator";
export type CoverCellContent = {
    readonly subtype: "dummy";
} | {
    /** Explicit encrypted CANCEL for exactly one admitted transfer. */
    readonly subtype: "cancel";
    readonly merkleRoot: Uint8Array;
} | {
    /**
     * Scheduled receipt (per-cell ack or terminal completion token), scoped
     * to its transfer root. Never the 65-byte immediate receipt frame.
     */
    readonly subtype: "receipt";
    readonly merkleRoot: Uint8Array;
    readonly token: Uint8Array;
};
export type CoverCellErrorCode = "authentication-failed" | "binding-mismatch" | "epoch-mismatch" | "invalid-cell" | "invalid-direction" | "invalid-padding" | "replayed-counter";
export declare class CoverCellError extends Error {
    readonly code: CoverCellErrorCode;
    constructor(code: CoverCellErrorCode, message: string);
}
export interface SealCoverCellOptions {
    readonly module: LibCrypto;
    readonly rootSuite: RatchetRootSuite;
    /** Current epoch's PQ message root (borrowed; never wiped here). */
    readonly rootKey: Uint8Array;
    readonly binding: Uint8Array;
    readonly direction: CoverCellDirection;
    readonly keyEpoch: bigint;
    /** Strictly increasing per-direction cover counter (replay ordering). */
    readonly counter: bigint;
    readonly content: CoverCellContent;
}
export interface OpenCoverCellOptions {
    readonly module: LibCrypto;
    readonly rootSuite: RatchetRootSuite;
    readonly rootKey: Uint8Array;
    readonly binding: Uint8Array;
    /** Expected inbound direction; the opposite direction derives another key. */
    readonly direction: CoverCellDirection;
    readonly keyEpoch: bigint;
    /** Highest already-accepted counter; the cell must be strictly newer. */
    readonly counterAbove?: bigint;
    readonly frame: Uint8Array;
}
export interface OpenedCoverCell {
    readonly content: CoverCellContent;
    readonly counter: bigint;
}
/** Seal one authenticated fixed-size cover cell (dummy, CANCEL, or receipt). */
export declare const sealCoverCell: (options: SealCoverCellOptions) => Uint8Array;
/**
 * Authenticate one fixed-size cover cell and return its content. The subtype
 * is knowable only after this authentication succeeds; an unauthentic cell
 * reveals nothing and terminates nothing.
 */
export declare const openCoverCell: (options: OpenCoverCellOptions) => OpenedCoverCell;
