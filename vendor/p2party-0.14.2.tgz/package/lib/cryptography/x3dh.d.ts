import type { LibCrypto } from "./libcrypto";
/**
 * No-PIN identity-mixed ephemeral DH. Mixes
 *   DH(IK_a, EK_b) || DH(EK_a, IK_b) || DH(EK_a, EK_b)
 * (initiator orientation) then HKDF-SHA512 to a 32-byte root seed. The responder
 * passes amInitiator=false; the three DH calls are re-ordered so both sides
 * concatenate the identical shared values.
 */
export declare const deriveInteractive3dhSecret: (idSelfSec: Uint8Array, idPeerPub: Uint8Array, ephSelfSec: Uint8Array, ephPeerPub: Uint8Array, amInitiator: boolean, module: LibCrypto) => Uint8Array;
