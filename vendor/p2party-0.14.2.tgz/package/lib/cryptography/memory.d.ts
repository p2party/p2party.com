declare const _default: {
    newKeyPairMemory: () => WebAssembly.Memory;
    identityX25519KeypairMemory: () => WebAssembly.Memory;
    keyPairFromSeedMemory: () => WebAssembly.Memory;
    keyPairFromSecretKeyMemory: () => WebAssembly.Memory;
    signMemory: (messageLen: number) => WebAssembly.Memory;
    verifyMemory: (messageLen: number) => WebAssembly.Memory;
    protocolV3Memory: () => WebAssembly.Memory;
    getMerkleRootMemory: (leavesLen: number) => WebAssembly.Memory;
    getMerkleProofMemory: (leavesLen: number) => WebAssembly.Memory;
    verifyMerkleProofMemory: (proofLen: number) => WebAssembly.Memory;
    argon2Memory: (mnemonicLen: number) => WebAssembly.Memory;
};
export default _default;
