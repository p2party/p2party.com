import type { LibCrypto } from "./libcrypto";
/**
 * Compute the plain SHA-512 of a File incrementally: read it one
 * HASH_WINDOW_BYTES slice at a time (O(1) memory — the whole file is never
 * resident) and feed each slice to the WASM streaming hash in
 * HASH_WASM_CHUNK_BYTES sub-chunks (the WASM heap buffer is tiny and fixed,
 * since the merkle module's memory cannot grow). The result is byte-identical
 * to `crypto.subtle.digest("SHA-512", <whole file>)` (plain SHA-512, no domain
 * separation), so it drops in for the previous whole-file-in-RAM digest.
 *
 * @param file - the File to hash (disk-backed; slices load lazily).
 * @param module - a LibCrypto exposing _sha512_init/update/final + _malloc/_free.
 * @returns the 64-byte SHA-512 digest.
 */
export declare const hashFileStreaming: (file: File, module: LibCrypto, signal?: AbortSignal) => Promise<Uint8Array>;
