import type { LibCrypto } from "./libcrypto";
export interface X25519KeyPair {
    publicKey: Uint8Array;
    secretKey: Uint8Array;
}
export declare const x25519Keypair: (module: LibCrypto) => X25519KeyPair;
/**
 * Async, optional-module wrapper over `x25519Keypair`, mirroring `ed25519.newKeyPair`:
 * self-loads a LibCrypto module (sizing its own fixed 2 MiB heap) when none is passed,
 * so identity-generation call sites can mint the dedicated X25519 identity keypair the
 * same way they call `newKeyPair()`. The keypair is random (`_x25519_keypair` draws its
 * own entropy); `x25519Keypair` copies the secret out and zero-frees the wasm scratch.
 */
export declare const newX25519KeyPair: (module?: LibCrypto) => Promise<X25519KeyPair>;
export declare const x25519Dh: (secretKey: Uint8Array, publicKey: Uint8Array, module: LibCrypto) => Uint8Array;
