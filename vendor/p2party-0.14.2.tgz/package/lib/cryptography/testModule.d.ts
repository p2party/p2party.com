import type { LibCrypto } from "./libcrypto";
/**
 * Instantiate the locally-built libcrypto.wasm for unit tests, bypassing the
 * CDN + SRI fetch in wasmLoader.ts. 32 pages == 2 MiB == INITIAL_MEMORY; growth
 * is off so every op fits the largest-single-op budget.
 */
export declare const loadTestModule: () => Promise<LibCrypto>;
