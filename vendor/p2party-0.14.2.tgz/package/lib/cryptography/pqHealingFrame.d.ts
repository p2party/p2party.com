import type { LibCrypto } from "./libcrypto";
import type { MlKemParameterSet, MlKemSuiteDescriptor } from "./mlkem";
export declare const PQ_CONTROL_FRAME_HEADER_BYTES: number;
export declare const PQ_CONTROL_FRAME_PLAINTEXT_BYTES: number;
export type PqControlDirection = "initiator-to-responder" | "responder-to-initiator";
export type PqControlFrameErrorCode = "authentication-failed" | "binding-mismatch" | "epoch-mismatch" | "invalid-direction" | "invalid-frame" | "invalid-padding" | "record-mismatch";
export declare class PqControlFrameError extends Error {
    readonly code: PqControlFrameErrorCode;
    constructor(code: PqControlFrameErrorCode, message: string);
}
export interface SealPqControlFrameOptions<P extends MlKemParameterSet = MlKemParameterSet> {
    readonly module: LibCrypto;
    readonly suite: Readonly<MlKemSuiteDescriptor<P>>;
    readonly rootKey: Uint8Array;
    readonly binding: Uint8Array;
    readonly direction: PqControlDirection;
    /** Epoch whose PQ root authenticates this frame. */
    readonly keyEpoch: bigint;
    /** Exact canonical OFFER, ADVANCE, or 64-byte ACK. */
    readonly record: Uint8Array;
}
export interface OpenPqControlFrameOptions<P extends MlKemParameterSet = MlKemParameterSet> {
    readonly module: LibCrypto;
    readonly suite: Readonly<MlKemSuiteDescriptor<P>>;
    readonly rootKey: Uint8Array;
    readonly binding: Uint8Array;
    /** Expected inbound direction; the opposite direction derives another key. */
    readonly direction: PqControlDirection;
    /** Exact expected authentication epoch. */
    readonly keyEpoch: bigint;
    readonly frame: Uint8Array;
}
/** Seal one exact canonical control record into a fixed-size v4 cell. */
export declare const sealPqControlFrame: <P extends MlKemParameterSet>(options: SealPqControlFrameOptions<P>) => Uint8Array;
/**
 * Authenticate a fixed-size cell and return an owned exact canonical record.
 * The caller supplies the expected edge, direction, suite, root, and epoch.
 */
export declare const openPqControlFrame: <P extends MlKemParameterSet>(options: OpenPqControlFrameOptions<P>) => Uint8Array;
