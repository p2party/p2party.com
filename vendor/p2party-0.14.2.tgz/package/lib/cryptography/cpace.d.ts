import type { LibCrypto } from "./libcrypto";
/**
 * CPace draft-21 prepend_len(): unsigned LEB128 byte length followed by value.
 * Exported so the standards KAT can freeze the transcript encoding independently
 * of the group operation.
 */
export declare const encodeCpaceLength: (length: number) => Uint8Array;
/**
 * CPACE-RISTR255-SHA512 generator from draft-irtf-cfrg-cpace-21:
 *
 * generator_string =
 *   lv_cat(DSI, PRS, zero_bytes(len_zpad), CI, sid)
 *
 * where len_zpad fills the first SHA-512 input block after DSI and PRS.
 */
export declare const deriveGenerator: (pin: Uint8Array, sid: Uint8Array, channelInput: Uint8Array, module: LibCrypto) => Uint8Array;
/** y <- uniform non-zero ristretto255 scalar; Y = y*G. */
export declare const cpaceStart: (generator: Uint8Array, module: LibCrypto) => {
    y: Uint8Array;
    Y: Uint8Array;
};
export interface CpaceFinishParams {
    /** Caller's one-use private scalar. */
    y: Uint8Array;
    /** Remote party's encoded Ristretto255 share. */
    peerShare: Uint8Array;
    /** Shared CPace session identifier. */
    sid: Uint8Array;
    /** Initiator and responder shares in protocol order. */
    initiatorShare: Uint8Array;
    responderShare: Uint8Array;
    /** Optional associated data; identities are already role-bound in CI here. */
    initiatorAssociatedData?: Uint8Array;
    responderAssociatedData?: Uint8Array;
}
/**
 * Finish draft-21 CPace and return only ISK. The intermediate shared point K
 * never enters JavaScript and is wiped in WASM before return, as required by
 * draft §10.3.
 */
export declare const cpaceFinish: (params: CpaceFinishParams, module: LibCrypto) => Uint8Array;
