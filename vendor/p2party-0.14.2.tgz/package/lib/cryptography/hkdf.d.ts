import type { LibCrypto } from "./libcrypto";
export declare const hkdfExtract: (salt: Uint8Array, ikm: Uint8Array, module: LibCrypto) => Uint8Array;
export declare const hkdfExpand: (prk: Uint8Array, info: Uint8Array, outLen: number, module: LibCrypto) => Uint8Array;
