type PinZeroizer = (pin: Uint8Array) => void;
/**
 * In-memory-only PIN owner. The production instance below is module-scoped;
 * this class is exported only so its copy/zeroization contract can be tested
 * without exposing the production map.
 *
 * No Redux, database, localStorage, logging, or serialization path touches
 * these bytes. Callers receive copies and should wipe them after handshake use.
 *
 * @internal
 */
export declare class TransientRoomPinVault {
    #private;
    constructor(zeroize?: PinZeroizer);
    put(roomContext: string, pin: Uint8Array): void;
    get(roomContext: string): Uint8Array | undefined;
    has(roomContext: string): boolean;
    delete(roomContext: string): boolean;
    clear(): void;
}
export declare const putRoomPin: (roomContext: string, pin: Uint8Array) => void;
export declare const getRoomPin: (roomContext: string) => Uint8Array | undefined;
export declare const hasRoomPin: (roomContext: string) => boolean;
export declare const deleteRoomPin: (roomContext: string) => boolean;
export declare const clearRoomPins: () => void;
export {};
