import type { IRTCDataChannel, IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
import type { RatchetHeader } from "../cryptography/ratchet";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
export declare const SEND_RECEIPT_WINDOW: number;
export declare const SEND_WINDOW_STALL_MS = 10000;
export interface ReceiptWindowParams {
    readonly windowSize: number;
    readonly stallTimeoutMs: number;
    readonly pollMs: number;
    readonly isOpen: () => boolean;
    readonly inFlight: () => number;
    readonly signal?: AbortSignal;
}
/**
 * Resolve once in-flight drops below the window, the channel leaves "open",
 * or receipt progress stalls for stallTimeoutMs. Any receipt progress while
 * still over the window resets the stall clock. Throws only on transfer abort.
 */
export declare const waitForReceiptWindow: (params: ReceiptWindowParams) => Promise<void>;
interface TransferCipher {
    epc: IRTCPeerConnection;
    messageKey: Uint8Array;
    header: RatchetHeader;
    /**
     * OWNED copy of the PQ message context captured in the same edge
     * transaction as the ratchet step (v4). Null only on runtime-free
     * bootstrap/test edges. Wiped with the message key.
     */
    pqContext?: PqMessageKeyContext | null;
}
/**
 * Stop a per-message transport without depending on its eventual `close`
 * event to release protocol accounting. This also covers cancellation while
 * the SCTP stream is still connecting and has not entered `dataChannels`.
 */
export declare const closeTransferChannel: (channel: IRTCDataChannel) => void;
/**
 * Own the one normal terminal close for a message-scoped channel. Receipt
 * handling only records authenticated completion; sendWithReconcile reaches
 * this boundary after its send/reconcile work settles.
 */
export declare const runWithTerminalChannelClose: <T>(currentChannel: () => IRTCDataChannel, operation: () => Promise<T>) => Promise<T>;
type WaitForRatchetGate = (roomId: string, peerId: string) => Promise<void>;
type DurableRatchetStep = (epc: IRTCPeerConnection, roomId: string, module: LibCrypto) => Promise<{
    messageKey: Uint8Array;
    header: RatchetHeader;
    pqContext: PqMessageKeyContext | null;
}>;
/**
 * Bind an in-flight message to the active cryptographic transport.
 *
 * Reopening only its DataChannel on the SAME RTCPeerConnection retains the
 * ratchet session, so the per-message key/header remain valid. A replacement
 * RTCPeerConnection, however, performs a fresh hybrid handshake and owns an
 * unrelated ratchet. It must advance that ratchet once and reseal the missing
 * plaintext chunks; replaying the old ciphertext/key/header cannot decrypt.
 *
 * Exported only so the transport-identity and key-erasure contract has a focused
 * unit test. It is not part of the package's public root exports.
 */
export declare const bindTransferCipherToConnection: (transfer: TransferCipher, nextEpc: IRTCPeerConnection, roomId: string, module: LibCrypto, waitForGate?: WaitForRatchetGate, ratchetStep?: DurableRatchetStep, signal?: AbortSignal) => Promise<TransferCipher>;
export declare const isAuthenticatedPeerCancel: (currentEpc: IRTCPeerConnection, peerConnections: IRTCPeerConnection[], roomId: string, peerId: string) => boolean;
export interface PeerSendTarget {
    peerId: string;
    epc?: IRTCPeerConnection;
}
export type PeerDeliveryOutcome = {
    peerId: string;
    status: "delivered";
} | {
    peerId: string;
    status: "failed";
    phase: "setup" | "transfer";
    reason: unknown;
} | {
    peerId: string;
    status: "skipped";
    reason: "not-connected" | "unauthenticated" | "cancelled";
};
export interface PeerSendFanoutResult {
    outcomes: PeerDeliveryOutcome[];
    startedTransfers: number;
}
type OpenPeerTransferChannel = (target: Required<PeerSendTarget>) => Promise<IRTCDataChannel>;
type StartPeerTransfer = (target: Required<PeerSendTarget>, channel: IRTCDataChannel) => Promise<void>;
/**
 * Set up every eligible room edge and settle every transfer that was started.
 *
 * Opening channels remains sequential so it cannot burst through the per-edge
 * channel budget. Transfer promises run concurrently, however, and are given a
 * rejection handler immediately. A later setup failure therefore becomes that
 * peer's outcome instead of unwinding past already-running sends and freeing
 * their shared `newChunks` staging records.
 */
export declare const runPeerSendFanout: (targets: readonly PeerSendTarget[], openChannel: OpenPeerTransferChannel, startTransfer: StartPeerTransfer, signal?: AbortSignal, onTransferStarted?: () => void) => Promise<PeerSendFanoutResult>;
export interface SendMessageResult extends PeerSendFanoutResult {
    transferId: string;
    merkleRootHex: string;
}
export declare class MessageDeliveryError extends AggregateError {
    readonly result: SendMessageResult;
    constructor(result: SendMessageResult, message: string);
}
/**
 * The sender's history is independent of remote delivery once splitToChunks
 * has committed its complete local copy. Network/setup failures may annotate
 * delivery status, but only an explicit local cancel removes that history.
 */
export declare const shouldDeleteLocalMessageAfterFailure: (localMessageCommitted: boolean, wireWorkStarted: boolean, explicitlyCancelled: boolean) => boolean;
export declare const handleSendMessage: (data: string | File, api: BaseQueryApi, label: string, roomId: string, peerConnections: IRTCPeerConnection[], dataChannels: IRTCDataChannel[], encryptionModule: LibCrypto, merkleModule: LibCrypto, transferId: string, minChunks?: number, chunkSize?: number, percentageFilledChunk?: number, metadataSchemaVersion?: number) => Promise<SendMessageResult | undefined>;
export {};
