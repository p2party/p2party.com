import type { LibCrypto } from "../cryptography/libcrypto";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
import type { RatchetHeader, RatchetState } from "../cryptography/ratchet";
import type { DecryptedChunk } from "./messageChunkCrypto";
/**
 * Claim the stable persistence edge before a replacement handshake writes its
 * seed. The synchronous claim invalidates queued mutations from the old PC;
 * the edge-wide write lock ensures any already-running old write finishes
 * before the replacement seed is written last.
 */
export declare const claimRatchetPersistence: (epc: IRTCPeerConnection, roomId: string) => void;
export declare const persistRatchetState: (state: RatchetState, roomId: string, peerPublicKey: string, peerId: string, edgeCryptoState?: Uint8Array | null) => Promise<void>;
export declare const persistClaimedRatchetState: (epc: IRTCPeerConnection, state: RatchetState, roomId: string, edgeCryptoStateOverride?: () => Uint8Array) => Promise<void>;
export type PersistInitialRatchetState = (state: RatchetState, roomId: string, peerPublicKey: string, peerId: string, edgeCryptoState?: Uint8Array | null) => Promise<void>;
export type RollbackInitialRatchetState = (roomId: string, peerPublicKey: string) => Promise<void>;
/**
 * Atomically order the initial durable seed and its synchronous gate/RAM
 * activation under the stable-edge lock. If close/replacement settles the gate
 * while the worker write is in flight, delete that just-written seed before a
 * replacement is allowed to write. This prevents a never-established root from
 * being restored later.
 */
export declare const persistAndActivateClaimedRatchetState: (epc: IRTCPeerConnection, state: RatchetState, roomId: string, activate: () => void, persist?: PersistInitialRatchetState, rollback?: RollbackInitialRatchetState) => Promise<void>;
export type PersistRatchetState = typeof persistRatchetState;
export declare const withEdgeCryptoMutationLock: <T>(epc: IRTCPeerConnection, mutation: () => Promise<T>) => Promise<T>;
/**
 * Advance the sending chain exactly once, durably, before its key/header can be
 * used to build a frame. The returned message key remains caller-owned, as is
 * the returned OWNED copy of the current PQ message context (null only on the
 * bootstrap/test path with no installed PQ runtime). Capturing the context and
 * counting the application message happen inside the same edge transaction as
 * the ratchet step, so a concurrent PQ healing transition cannot interleave.
 */
export declare const ratchetEncryptDurably: (epc: IRTCPeerConnection, roomId: string, module: LibCrypto, persist?: PersistRatchetState) => Promise<{
    messageKey: Uint8Array;
    header: RatchetHeader;
    pqContext: PqMessageKeyContext | null;
}>;
/**
 * Decrypt one inbound chunk with a staged state/cache. An authenticated ratchet
 * advance becomes visible only after its snapshot is durable; persistence
 * failure rejects without advancing live state, caching a key, or exposing the
 * decrypted bytes. Cache hits do not advance or persist the ratchet.
 */
export declare const decryptMessageChunkDurably: (epc: IRTCPeerConnection, roomId: string, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto, persist?: PersistRatchetState) => Promise<DecryptedChunk>;
/**
 * Durably retire the active receive key after the atomic chunk manifest reports
 * completion, then erase the RAM cache copy. If persistence fails, both copies
 * remain usable for an idempotent retransmit/retry rather than diverging.
 */
export declare const forgetReceiveMessageKeyDurably: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, persist?: PersistRatchetState) => Promise<void>;
export declare const persistRatchetSession: (epc: IRTCPeerConnection, roomId: string) => Promise<void>;
