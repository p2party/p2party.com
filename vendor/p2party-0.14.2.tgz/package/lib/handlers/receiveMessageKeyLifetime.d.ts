import { forgetReceiveMessageKeyDurably } from "./ratchetPersist";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { MessageData } from "../db/types";
type ForgetReceiveMessageKey = typeof forgetReceiveMessageKeyDurably;
type ReceiveProgress = Pick<MessageData, "savedSize" | "totalSize">;
/**
 * Bind the authenticated transfer root to the receive-ratchet key used by all
 * of its cells. Completion of the real bytes does not end this lifetime: valid
 * padded/cover cells may still be draining from an unordered data channel.
 */
export declare const bindReceiveMessageKey: (epc: IRTCPeerConnection, merkleRootHex: string, cacheKey: string) => void;
/**
 * Durably retire the key mapped to one transfer. The root binding is removed
 * only after persistence succeeds, so failure leaves an idempotent retry path.
 */
export declare const forgetMappedReceiveMessageKey: (epc: IRTCPeerConnection, roomId: string, merkleRootHex: string, forget?: ForgetReceiveMessageKey) => Promise<boolean>;
/**
 * A normal channel close retires a receive key only after its queue drained and
 * the durable manifest confirms all real bytes. Incomplete transfers retain
 * their key so a failed transport can resume; explicit cancel uses the
 * unconditional helper above.
 */
export declare const forgetCompletedReceiveMessageKey: (epc: IRTCPeerConnection, roomId: string, merkleRootHex: string, progress: ReceiveProgress | undefined, forget?: ForgetReceiveMessageKey) => Promise<boolean>;
export {};
