import type { MiddlewareAPI } from "@reduxjs/toolkit";
import type { KeyPair } from "../reducers/keyPairSlice";
export declare const handleChallenge: (keyPair: KeyPair, peerId: string, challenge: string, store: MiddlewareAPI) => Promise<void>;
