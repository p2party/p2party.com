interface ReceiptSendChannel {
    readonly readyState: string;
    readonly bufferedAmount: number;
    send(data: ArrayBuffer): void;
}
/** Encode a chunk token or terminal message hash as one canonical wire frame. */
export declare const encodeReceiptFrame: (token: Uint8Array) => Uint8Array;
/** Return the zero-copy token only for the exact tagged receipt geometry. */
export declare const decodeReceiptFrame: (frame: Uint8Array) => Uint8Array | undefined;
export declare const sendReceiptFrame: (channel: Pick<ReceiptSendChannel, "readyState" | "send">, token: Uint8Array) => boolean;
export declare const RECEIPT_REPLAY_BATCH_SIZE = 32;
export declare const RECEIPT_REPLAY_PAUSE_MS = 10;
/**
 * Replay a reconnect have-set without filling SCTP or monopolising the event
 * loop. The caller may then send the terminal receipt on the same channel.
 */
export declare const sendReceiptFramesPaced: (channel: ReceiptSendChannel, tokens: Iterable<Uint8Array>) => Promise<boolean>;
export {};
