import { type ReceiveMessageResult } from "./handleReceiveMessage";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCPeerConnection } from "../api/webrtc/interfaces";
/**
 * True while this room/peer edge still has queued inbound chunk frames or an
 * in-flight frame handler. The sparse-PQ orchestrator drains to quiescence
 * before an epoch transition so old-epoch first-chunks are not orphaned.
 */
export declare const hasQueuedEdgeReceiveWork: (roomId: string, peerId: string) => boolean;
export declare const waitForEdgeReceiveQuiescence: (roomId: string, peerId: string) => Promise<void>;
/**
 * A terminal receipt may ride an immediate frame only in immediate mode. In a
 * scheduled-cover room acknowledgement substitutes into a reverse cover slot,
 * so an immediate frame here would be an unscheduled emission correlated with
 * message completion.
 */
export declare const shouldSendImmediateTerminalReceipt: (epc?: Pick<IRTCPeerConnection, "coverRuntime">) => boolean;
export declare const MAX_QUEUED_FRAMES_PER_CHANNEL = 64;
export declare const MAX_QUEUED_BYTES_PER_EDGE: number;
export declare const MAX_QUEUED_RECEIPTS_PER_CHANNEL = 2048;
export declare const MAX_QUEUED_RECEIPTS_PER_EDGE = 8192;
export interface MessageProcessingState {
    value: boolean;
    released?: boolean;
    idleWaiters?: Set<() => void>;
}
export declare const waitForQueuedMessageFrames: (queue: Uint8Array[], state: MessageProcessingState) => Promise<void>;
export declare const releaseQueuedMessageFrames: (queue: Uint8Array[], roomId: string, peerId: string, state?: MessageProcessingState) => void;
export interface ReceiptProcessingQueue {
    readonly roomId: string;
    readonly peerId: string;
    readonly pending: Uint8Array[];
    readonly seen: Set<string>;
    draining: boolean;
    released: boolean;
}
export declare const createReceiptProcessingQueue: (roomId: string, peerId: string) => ReceiptProcessingQueue;
export declare const releaseQueuedReceipts: (state: ReceiptProcessingQueue) => void;
/**
 * Queue one already-classified 64-byte receipt token. This is deliberately a
 * bounded data queue, not one promise per onmessage event. At most one handler
 * executes per room/peer edge, even when many message channels are open.
 */
export declare const enqueueReceipt: (receipt: Uint8Array, state: ReceiptProcessingQueue, processReceipt: (receipt: Uint8Array) => Promise<void>) => boolean;
type PerFrameReceiptResult = Pick<ReceiveMessageResult, "chunkHash" | "chunkIndex" | "chunkSize" | "totalSize">;
/**
 * Emit exactly one receipt-shaped frame for every inbound chunk frame. Real
 * cells use their rooted token; cover/dropped cells use an unlinkable random
 * token so an observer cannot infer which slot carried bytes.
 */
export declare const sendReceiveFrameReceipt: (result: PerFrameReceiptResult, channel: IRTCDataChannel | undefined) => boolean;
export declare const enqueue: (data: Uint8Array, queue: Uint8Array[], seen: Set<string>, drainingRef: MessageProcessingState, api: BaseQueryApi, roomId: string, peerId: string, channelLabel: string, merkleRootHex: string, merkleRoot: Uint8Array, extChannel: IRTCDataChannel | undefined, epc: IRTCPeerConnection | undefined, receiveMessageModule: LibCrypto, signal?: AbortSignal) => boolean;
export {};
