import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { RatchetState } from "../cryptography/ratchet";
/** Persist the (unchanged) live ratchet plus one candidate edge checkpoint. */
export type PersistEdgeCheckpoint = (epc: IRTCPeerConnection, state: RatchetState, roomId: string, serializeCandidate: () => Uint8Array) => Promise<void>;
export interface PqOrchestratorHooks {
    /** Dispatch one exact sealed control cell; false when the lane is not open. */
    readonly sendControlFrame: (frame: Uint8Array) => boolean;
    /** Fail/reconnect the authenticated edge (retry exhaustion, fork). */
    readonly failEdge: (reason: Error) => void;
    /** Injectable clock for deterministic tests. */
    readonly now?: () => number;
    /** Injectable persistence for fault-injection tests. */
    readonly persistEdge?: PersistEdgeCheckpoint;
    /** Tick cadence for the due/retry timer; 0 disables the interval (tests). */
    readonly tickMs?: number;
}
/**
 * True while new application sends must not derive a message key on this edge:
 * either the runtime's machine is mid-exchange, or an inbound control frame is
 * being processed and the local gate has already closed.
 */
export declare const isPqApplicationTrafficBlocked: (epc: IRTCPeerConnection) => boolean;
/**
 * Install the live orchestrator after a successful handshake has installed
 * `epc.pqHealingState`. Idempotent per connection: a replacement handshake on
 * the same connection object reuses the interval with the fresh runtime.
 */
export declare const installPqHealingOrchestrator: (epc: IRTCPeerConnection, roomId: string, hooks: PqOrchestratorHooks) => void;
export declare const destroyPqHealingOrchestrator: (epc: IRTCPeerConnection) => void;
/**
 * One due/retry pass. Retransmits the exact persisted control frame when its
 * 5-second deadline passed (durably counting the attempt first), fails the
 * edge after the 8-attempt budget, and starts a due local exchange only when
 * the stable role owns the turn and the edge is at a quiescent boundary.
 * Exported for deterministic tests; the installed interval calls it.
 */
export declare const tickPqHealing: (epc: IRTCPeerConnection) => Promise<void>;
/**
 * Route one authenticated-transport FRAME_TYPE_PQ_CONTROL cell. Closes the
 * local application gate, drains queued inbound frames to the quiescent
 * boundary, then runs the exact durable OFFER/ADVANCE/ACK ordering. An exact
 * duplicate re-emits the exact persisted response without a write. Any
 * authentication failure is a fork/replay outside the protocol and fails the
 * authenticated edge.
 */
export declare const handleInboundPqControlFrame: (epc: IRTCPeerConnection, roomId: string, frame: Uint8Array) => Promise<void>;
