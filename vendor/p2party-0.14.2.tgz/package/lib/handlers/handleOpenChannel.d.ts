import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { IRTCPeerConnection, IRTCDataChannel } from "../api/webrtc/interfaces";
export declare const MAX_MESSAGE_CHANNELS_PER_EDGE = 64;
export interface OpenChannelHelperParams {
    channel: string | RTCDataChannel;
    epc: IRTCPeerConnection;
    roomId: string;
    dataChannels: IRTCDataChannel[];
    /** True only for a channel delivered by RTCPeerConnection.ondatachannel. */
    incoming?: boolean;
}
export declare const handleOpenChannel: ({ channel, epc, roomId, dataChannels, incoming, }: OpenChannelHelperParams, api: BaseQueryApi) => Promise<IRTCDataChannel>;
