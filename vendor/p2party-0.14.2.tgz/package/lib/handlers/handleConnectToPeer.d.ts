import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { IRTCPeerConnection, RTCPeerConnectionParams } from "../api/webrtc/interfaces";
export interface IRTCPeerConnectionParams extends RTCPeerConnectionParams {
    peerConnections: IRTCPeerConnection[];
}
export declare const handleConnectToPeer: ({ peerId, peerPublicKey, roomId, peerConnections, rtcConfig, }: IRTCPeerConnectionParams, api: BaseQueryApi) => Promise<IRTCPeerConnection>;
