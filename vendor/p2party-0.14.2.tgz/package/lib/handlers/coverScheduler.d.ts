export type CoverSchedulerStatus = "starting" | "active" | "degraded" | "suspended" | "stopped";
export type CoverJobKind = "real" | "control";
export type CoverCellSource = CoverJobKind | "cancel" | "dummy";
type MaybePromise<T> = T | PromiseLike<T>;
export interface CoverClock {
    now(): number;
    setTimeout(callback: () => void, delayMs: number): unknown;
    clearTimeout(handle: unknown): void;
}
/**
 * The phase is an absolute clock offset. Epoch zero starts at phaseOffsetMs;
 * negative epoch/cycle indices are valid when a test or monotonic clock starts
 * before that offset.
 */
export interface CoverSchedule {
    phaseOffsetMs: number;
    coverCadenceMs: number;
    coverLanes: number;
    coverFramesPerCell: number;
    coverDurationEpochs: number;
}
export interface CoverSlot {
    readonly deadlineMs: number;
    readonly cycleIndex: number;
    readonly cycleStartMs: number;
    readonly cycleEndMs: number;
    readonly epochIndex: number;
    readonly epochInCycle: number;
    readonly laneIndex: number;
    readonly frameIndex: number;
    readonly laneSlotIndex: number;
}
export interface CoverJobSlot extends CoverSlot {
    readonly jobId: string;
    readonly jobKind: CoverJobKind;
    /** Index of the next not-yet-accepted job cell. */
    readonly jobCellIndex: number;
}
/**
 * A producer is deliberately lazy: ratchet state and encrypted cell bytes can
 * be prepared at the scheduled slot instead of buffering a complete cycle.
 * Returning null substitutes a dummy for this slot without consuming a job
 * cell. declaredCellCount enforces the authenticated F x D capacity class.
 */
export interface CoverJob {
    readonly id: string;
    readonly kind: CoverJobKind;
    readonly declaredCellCount: number;
    readonly priority?: number;
    nextCell(slot: CoverJobSlot): MaybePromise<Uint8Array | null>;
    cancelCell?(slot: CoverJobSlot): MaybePromise<Uint8Array>;
}
export interface CoverJobSummary {
    readonly id: string;
    readonly kind: CoverJobKind;
    readonly declaredCellCount: number;
}
export interface CoverLaneOpenContext {
    readonly cycleIndex: number;
    readonly cycleStartMs: number;
    readonly cycleEndMs: number;
    readonly laneIndex: number;
    readonly job: CoverJobSummary | null;
}
export interface CoverSendRequest {
    readonly cell: Uint8Array;
    readonly source: CoverCellSource;
    readonly slot: CoverSlot;
    readonly jobId?: string;
    readonly jobCellIndex?: number;
}
export interface CoverLaneCloseContext extends CoverLaneOpenContext {
    readonly reason: "boundary" | "late-cleanup";
}
export interface CoverLane {
    /**
     * Return false only when the transport rejected the cell for backpressure.
     * A thrown/rejected send is treated as a transport failure.
     */
    send(request: CoverSendRequest): MaybePromise<boolean | void>;
    close(context: CoverLaneCloseContext): void;
}
export type CoverJobOutcome = "completed" | "cancelled-before-admission" | "cancelled" | "failed";
export interface CoverJobResult {
    readonly jobId: string;
    readonly outcome: CoverJobOutcome;
    readonly reason?: "capacity-exhausted" | "stopped";
}
export interface CoverJobInterruption {
    readonly jobId: string;
    readonly reason: "backpressure" | "cell-production-failed" | "lane-open-failed" | "missed-deadline" | "send-failed" | "suspended";
}
export interface CoverStatusChange {
    readonly previous: CoverSchedulerStatus;
    readonly status: CoverSchedulerStatus;
    readonly reason?: string;
}
export interface CoverSchedulerOptions {
    readonly schedule: CoverSchedule;
    readonly clock: CoverClock;
    readonly laneFactory: (context: CoverLaneOpenContext) => CoverLane;
    readonly makeDummy: (slot: CoverSlot) => MaybePromise<Uint8Array>;
    /**
     * Defaults to zero. A runtime may opt into a small, explicit timer tolerance;
     * deadlines and metadata remain the absolute unshifted values.
     */
    readonly maxTimerDriftMs?: number;
    readonly onStatusChange?: (change: CoverStatusChange) => void;
    readonly onJobResult?: (result: CoverJobResult) => void;
    readonly onJobInterrupted?: (interruption: CoverJobInterruption) => void;
}
export type CoverCancelResult = "not-found" | "cancelled-before-admission" | "cancel-pending";
export declare class CoverScheduler {
    readonly schedule: Readonly<CoverSchedule>;
    private readonly clock;
    private readonly laneFactory;
    private readonly makeDummy;
    private readonly maxTimerDriftMs;
    private readonly onStatusChange?;
    private readonly onJobResult?;
    private readonly onJobInterrupted?;
    private readonly cycleDurationMs;
    private readonly slotsPerEpoch;
    private readonly slotsPerLane;
    private status;
    private running;
    private sequence;
    private generation;
    private timer;
    private hasTimer;
    private cycle?;
    private readonly queued;
    private readonly jobs;
    constructor(options: CoverSchedulerOptions);
    getStatus(): CoverSchedulerStatus;
    getQueuedJobIds(): readonly string[];
    enqueue(job: CoverJob): void;
    cancel(jobId: string): CoverCancelResult;
    /**
     * Mark a producer complete without adding a terminal frame. Receipt/control
     * traffic is queued as its own control job; this lane becomes dummy tail.
     */
    complete(jobId: string): boolean;
    start(): boolean;
    suspend(reason?: string): boolean;
    resume(): boolean;
    /**
     * Stop is graceful for an already-open cover cycle: sends cease immediately,
     * but channel close remains pinned to the authenticated cycle boundary.
     */
    stop(): boolean;
    private assertClockNow;
    private nextCycleBoundary;
    private cycleIndexAtBoundary;
    private sortQueue;
    private removeQueued;
    private dequeue;
    private requeue;
    private settle;
    private setStatus;
    private safeNotify;
    private disarm;
    private arm;
    private armOpenBoundary;
    private armCycleBoundary;
    private armSlot;
    private handleLateTimer;
    private openCycle;
    private slotAt;
    private jobSlot;
    private requestForSlot;
    private cacheUnsent;
    private acceptSent;
    private sendSlot;
    private degrade;
    private interruptCycle;
    private finalizeCycleJobs;
    private closeCurrentCycle;
    private handleCycleBoundary;
}
export declare const coverSlotSpacingMs: (schedule: CoverSchedule) => number;
export declare const validateCoverSchedule: (schedule: CoverSchedule) => void;
export declare const createCoverScheduler: (options: CoverSchedulerOptions) => CoverScheduler;
export {};
