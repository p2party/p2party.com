export declare const markChunkAcked: (roomId: string, peerId: string, transferId: string, chunkIndex: number) => boolean;
export declare const getAckedChunks: (roomId: string, peerId: string, transferId: string) => Set<number>;
export declare const getAckedChunkCount: (roomId: string, peerId: string, transferId: string) => number;
export declare const markTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
export interface PeerTransferOutcome {
    readonly roomId: string;
    readonly peerId: string;
    readonly transferId: string;
    readonly ackedChunks: ReadonlySet<number>;
    readonly complete: boolean;
}
/** Accurate, defensive per-peer delivery state for UI/diagnostics consumers. */
export declare const getPeerTransferOutcome: (roomId: string, peerId: string, transferId: string) => PeerTransferOutcome;
export declare const isTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
export declare const clearTransfer: (roomId: string, peerId: string, transferId: string) => void;
export declare const waitForCompletion: (roomId: string, peerId: string, transferId: string, timeoutMs: number, signal?: AbortSignal) => Promise<boolean>;
