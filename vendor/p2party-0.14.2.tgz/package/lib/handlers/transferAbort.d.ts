export interface TransferAbortHandle {
    readonly transferId: string;
    readonly signal: AbortSignal;
    bindHash(hashHex: string): void;
    bindMerkleRoot(merkleRootHex: string): void;
    finish(): void;
}
/**
 * Registers one logical outbound message. Its identifiers are bound as soon as
 * streaming hashing/Merkle construction learns them, so cancellation remains
 * message-scoped instead of broadcasting a window-global event.
 */
export declare const createTransferId: () => string;
export declare const beginTransfer: (roomId: string, transferId?: string) => TransferAbortHandle;
/**
 * Internal handoff from the public API to the async send pipeline. The public
 * boundary registers first so `handle.cancel()` works even while WASM is still
 * loading; the handler later claims that exact live controller.
 */
export declare const claimTransfer: (roomId: string, transferId: string) => TransferAbortHandle;
export interface TransferSelector {
    transferId?: string;
    hashHex?: string;
    merkleRootHex?: string;
}
export interface IncomingTransferProgress {
    fromPeerId: string;
    savedSize: number;
    totalSize: number;
}
/**
 * In immediate mode, closing only a message-scoped DataChannel while its
 * authenticated peer connection remains alive is the remote CANCEL signal.
 * Delete only an incomplete receive owned by that peer; completed messages and
 * the sender's local self-copy must survive the ordinary terminal close.
 */
export declare const isRemoteCancelClose: (progress: IncomingTransferProgress | undefined, remotePeerId: string, authenticatedTransportStillAlive: boolean) => boolean;
export declare const abortTransfer: (roomId: string, selector: TransferSelector) => number;
export declare const abortRoomTransfers: (roomId: string) => number;
export declare const abortAllTransfers: () => number;
export declare const throwIfTransferAborted: (signal?: AbortSignal) => void;
export declare const waitWithTransferAbort: <T>(pending: Promise<T>, signal?: AbortSignal) => Promise<T>;
