import type { LibCrypto } from "../cryptography/libcrypto";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { ReceiveChunk, ReceiveChunkStoreResult } from "../db/types";
import type { PersistRatchetState } from "./ratchetPersist";
export interface ReceiveMessageResult {
    date: Date;
    chunkSize: number;
    chunkIndex: number;
    receivedFullSize: boolean;
    chunkAlreadyExists: boolean;
    totalSize: number;
    messageType: number;
    filename: string;
    /** 64-byte root/index/leaf-bound receipt token (legacy field name). */
    chunkHash: Uint8Array;
    messageHash: Uint8Array;
}
type ReceiveChunkStore = (chunk: ReceiveChunk) => Promise<ReceiveChunkStoreResult>;
export interface ReceiveMessageDependencies {
    /** Test/fault-injection seam; production uses the ratchet worker database. */
    persistRatchetState?: PersistRatchetState;
    /** Test/fault-injection seam; production uses the receive-chunk worker. */
    storeReceiveChunk?: ReceiveChunkStore;
}
/**
 * Worker storage is the durability boundary for a receipt. A failed write must
 * look exactly like a decoy/drop to the caller, and the owned real-byte copy is
 * erased after postMessage has cloned it (or after an injected failure).
 */
export declare const storeReceiveChunkFailClosed: (chunk: Omit<ReceiveChunk, "data">, realChunk: Uint8Array, store?: ReceiveChunkStore) => Promise<ReceiveChunkStoreResult | null>;
export declare const handleReceiveMessage: (frame: Uint8Array, roomId: string, channelLabel: string, epc: IRTCPeerConnection, merkleRoot: Uint8Array, module: LibCrypto, signal?: AbortSignal, dependencies?: ReceiveMessageDependencies) => Promise<ReceiveMessageResult>;
export {};
