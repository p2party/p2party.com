import type { CoverJob } from "./coverScheduler";
import type { CoverRuntime } from "./coverRuntime";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
/**
 * Queue one scheduled receipt (per-cell ack or terminal completion token) for
 * the next available reverse control slots. Returns false when the edge has no
 * cover runtime (immediate mode) so the caller falls back to immediate
 * receipts, and drops oldest-first beyond the flood bound.
 */
export declare const queueScheduledReceipt: (epc: IRTCPeerConnection, merkleRoot: Uint8Array, token: Uint8Array) => boolean;
/** Wipe and drop every queued scheduled receipt (edge teardown). */
export declare const releaseScheduledReceipts: (epc: IRTCPeerConnection) => void;
/**
 * A synthetic constant-shape label for receipt routing: handleReadReceipt only
 * consumes the Merkle-root element, so the name element is canonical zeros.
 */
export declare const syntheticScheduledLabel: (merkleRootHex: string) => string;
/** Seal exactly one already-staged chunk into its uniform 65,490-byte cell. */
export type SealTransferSlotCell = (chunkIndex: number) => Promise<Uint8Array | null> | Uint8Array | null;
export interface ScheduledSendJobOptions {
    readonly runtime: CoverRuntime;
    /** The compiled per-message channel label; it is the job/lane id. */
    readonly channelMessageLabel: string;
    readonly totalChunks: number;
    /** Seal the sender's cell for one chunk index (real bytes). */
    readonly sealSlotCell: SealTransferSlotCell;
    /** Set of already-acked real chunk indices for reconcile skipping. */
    readonly getAckedChunks?: () => ReadonlySet<number>;
    /** Real chunk indices only (decoys never resend); default is all indices. */
    readonly realChunkIndices?: readonly number[];
}
/**
 * Build the lazy scheduled-send job for one message on one edge. It seals at
 * most ONE chunk per scheduled slot (never a burst), returns null (dummy
 * substitution) once every not-yet-acked real chunk has been offered this
 * pass, and refuses admission if the declared cell count cannot fit the
 * authenticated `F × D` capacity class. Reconcile is scheduled, not burst: an
 * un-acked chunk is re-offered on the next pass through the job's cells.
 */
export declare const buildScheduledSendJob: (options: ScheduledSendJobOptions) => CoverJob;
/**
 * The scheduled-mode wire CANCEL for one transfer on one edge: scheduler
 * cancellation emits the encrypted CANCEL cell in the job's next slot and
 * leaves a dummy tail through the fixed boundary. Never a channel close.
 */
export declare const cancelScheduledTransfer: (epc: IRTCPeerConnection, channelLabel: string, merkleRootHex: string) => Promise<boolean>;
