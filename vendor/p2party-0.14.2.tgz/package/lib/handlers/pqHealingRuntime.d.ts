import { type PqHealingPhase, type PqHealingTurn } from "../cryptography/pqHealing";
import { type RoomPqMode } from "../roomPolicy";
import { type RatchetRootSuite } from "../utils/constants";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
export declare const PQ_HEAL_AFTER_MESSAGES = 64;
export declare const PQ_HEAL_AFTER_MS: number;
export declare const PQ_HEAL_RETRY_MS = 5000;
export declare const PQ_HEAL_MAX_RETRIES = 8;
export type PqHealingOutboxKind = "offer" | "advance";
export interface PqHealingOutbox {
    readonly kind: PqHealingOutboxKind;
    readonly frame: Uint8Array;
    readonly attempts: number;
    readonly nextRetryAt: number;
}
export interface PqHealingControlResult {
    /**
     * Exact already-sealed cell to dispatch after the candidate checkpoint is
     * durable. It may be an OFFER, ADVANCE, ACK, or cached duplicate response.
     */
    readonly dispatch: Uint8Array | null;
    /**
     * False only for an exact duplicate whose cached response can be resent
     * without another persistence write.
     */
    readonly changed: boolean;
}
export interface SparsePqHealingOptions {
    readonly module: LibCrypto;
    readonly pqMode: RoomPqMode;
    readonly rootSuite: RatchetRootSuite;
    readonly binding: Uint8Array;
    readonly rootKey: Uint8Array;
    readonly nextOfferer: PqHealingTurn;
    readonly amInitiator: boolean;
    readonly now?: number;
}
export interface RestoreSparsePqHealingOptions {
    readonly module: LibCrypto;
    readonly pqMode: RoomPqMode;
    readonly rootSuite: RatchetRootSuite;
    readonly binding: Uint8Array;
    readonly amInitiator: boolean;
}
export declare class SparsePqHealingState {
    #private;
    constructor(options: SparsePqHealingOptions);
    get pqMode(): RoomPqMode;
    get rootSuite(): RatchetRootSuite;
    get epoch(): bigint;
    get phase(): PqHealingPhase;
    get trafficBlocked(): boolean;
    get nextOfferer(): PqHealingTurn;
    get activeReceiveKeys(): Map<string, Uint8Array>;
    get messagesSinceHealing(): number;
    get lastHealedAt(): number;
    currentMessageContext(): PqMessageKeyContext;
    resolveMessageContext(epoch: bigint): PqMessageKeyContext | null;
    noteApplicationMessage(): void;
    healingDue(now?: number): boolean;
    copyPendingFrame(): Uint8Array | null;
    get pendingRetryAt(): number | null;
    get pendingAttempts(): number;
    markPendingDispatched(now?: number): void;
    prepareHealingOffer(now?: number): Promise<Uint8Array>;
    acceptControlFrame(frame: Uint8Array, now?: number): Promise<PqHealingControlResult>;
    clone(): SparsePqHealingState;
    adopt(next: SparsePqHealingState): void;
    serialize(activeReceiveKeys?: ReadonlyMap<string, Uint8Array>): Uint8Array;
    /**
     * Read the public edge binding out of a checkpoint without instantiating the
     * runtime. A store-free consumer that keeps the whole checkpoint under
     * authenticated encryption (rather than a separate binding) uses this to
     * supply the expected binding to `restore`. The binding layout is fixed:
     * magic(8) | version(1) | suite(1) | direction(1) | reserved(1) |
     * lastHealedAt(8) | messagesSinceHealing(8) | binding(32).
     */
    static readCheckpointBinding(bytes: Uint8Array): Uint8Array;
    static restore(bytes: Uint8Array, options: RestoreSparsePqHealingOptions): SparsePqHealingState;
    destroy(): void;
}
