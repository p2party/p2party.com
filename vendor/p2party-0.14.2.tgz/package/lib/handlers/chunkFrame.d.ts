import type { RatchetHeader } from "../cryptography/ratchet";
/** Total cleartext header length; ciphertext begins here. = 69. */
export declare const CHUNK_FRAME_HEADER_LEN: number;
/** Build the 69-byte cleartext chunk-frame header. */
export declare const packChunkFrameHeader: (header: RatchetHeader, nonce: Uint8Array, pqEpoch?: bigint) => Uint8Array;
export interface ParsedChunkFrame {
    header: RatchetHeader;
    pqEpoch: bigint;
    nonce: Uint8Array;
    ciphertext: Uint8Array;
}
/** Parse a v4 CHUNK frame into its header fields and zero-copy byte views. */
export declare const parseChunkFrameHeader: (frame: Uint8Array) => ParsedChunkFrame;
