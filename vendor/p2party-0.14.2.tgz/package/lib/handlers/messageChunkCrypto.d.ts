import type { RatchetState, RatchetHeader } from "../cryptography/ratchet";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
/**
 * Per-message key-cache key. Production passes the parsed epoch explicitly and
 * gets an epoch-bound `(dhPub,N,epoch)` identity. Omitting the epoch preserves
 * the legacy low-level `dhPub:N` identity for raw/bootstrap tests only; this is
 * needed while those tests still round-trip keys through RatchetState.skipped,
 * whose historical serializer understands exactly that two-field shape.
 */
export declare const messageCacheKey: (dhPub: Uint8Array, N: number, pqEpoch?: bigint) => string;
/**
 * Seal ONE chunk under an already-derived classical `messageKey` + `header`.
 * With a PQ context, an owned copy of the classical key is consumed by the v4
 * combiner and the resulting key is wiped after this one AEAD operation. The
 * caller's classical key remains live across streamed chunks/retransmit rounds.
 * The low-level context-free default emits bootstrap epoch zero and uses the
 * raw classical key for backwards-compatible tests only.
 *
 * This is the streaming/reconcile-friendly primitive the live send path uses: it
 * seals chunks one-at-a-time as they are read from IndexedDB, so a multi-GB
 * message is never materialised in RAM. A retransmit re-seals the same plaintext
 * under the SAME `messageKey` with a FRESH random nonce — cryptographically safe
 * (distinct 96-bit random nonces under one key) and decryptable by the receiver's
 * cached per-message key (a HIT on `(dhPub, N)`), so no frame-cache is needed.
 */
export declare const sealChunk: (messageKey: Uint8Array, header: RatchetHeader, chunk: Uint8Array, merkleRoot: Uint8Array, module: LibCrypto, pqContext?: PqMessageKeyContext) => Uint8Array;
export interface DecryptedChunk {
    /** The DECRYPTED_LEN plaintext `metadata ‖ receiptLeaf ‖ chunk` written by the C
     *  receive, or `null` when the chunk was dropped (AEAD or Merkle failure). */
    decrypted: Uint8Array | null;
    /** True iff C returned 0 — AEAD **and** Merkle both passed. When false the caller
     *  drops the chunk (but still persists the ratchet if `stateAdvanced`). */
    ok: boolean;
    /** True iff this chunk stepped the ratchet (first-arriving chunk of a message
     *  whose AEAD authenticated). The caller persists `state` when true — even if
     *  `ok` is false, since the DH step is real once the AEAD authenticates. */
    stateAdvanced: boolean;
}
/**
 * Resolve an authenticated, currently acceptable PQ epoch. Returning null
 * rejects unknown/stale/future epochs before a Double-Ratchet clone is touched.
 */
export type PqMessageKeyContextResolver = (epoch: bigint) => PqMessageKeyContext | null;
/**
 * RECEIVE one chunk frame: derive the per-message key off the ratchet (in TS —
 * the ratchet state is a TS object), then do ALL the crypto in ONE C call
 * (`receiveWithKey` → `_receive_message_with_key`: decrypt + leaf-hash + Merkle +
 * receipt, in place).
 *
 * The production `cache` is caller-owned and keyed by
 * `messageCacheKey(dhPub,N,pqEpoch)`. It stores already-combined active receive
 * keys separately from classical skipped keys. On a HIT the key is reused
 * without touching the ratchet. On a MISS, the resolver must authorize the
 * epoch before the classical key is derived on a clone and combined.
 *
 * Clone-rollback (MANDATORY — `ratchetDecrypt` mutates BEFORE the AEAD
 * authenticates, so a replayed/old-chain header could otherwise fire a spurious
 * DH-step and desync the session):
 *   1. `clone = deserializeRatchet(serializeRatchet(state))`.
 *   2. `messageKey = ratchetDecrypt(clone, header)` — mutates the CLONE only.
 *   3. C decrypts+verifies. COMMIT (adopt the clone, cache the key) iff the AEAD
 *      authenticated (`code !== -2`); on `-2` DISCARD the clone — the live `state`
 *      is byte-for-byte untouched. `ok` (store-vs-drop) then follows `code === 0`.
 *
 * Cache lifecycle: the caller evicts a message's key (via `messageCacheKey`) when
 * the message completes (all leaves present) or on a TTL, so a peer can't pin keys
 * with never-completing messages.
 */
export declare const decryptMessageChunk: (state: RatchetState, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto, pqContextResolver?: PqMessageKeyContextResolver) => DecryptedChunk;
