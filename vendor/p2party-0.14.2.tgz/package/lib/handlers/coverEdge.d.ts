import type { CoverStatusChange } from "./coverScheduler";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { RoomPolicyV1 } from "../roomPolicy";
import type { LibCrypto } from "../cryptography/libcrypto";
export interface InstallCoverEdgeOptions {
    readonly epc: IRTCPeerConnection;
    readonly roomId: string;
    readonly policy: RoomPolicyV1;
    readonly policyHash: Uint8Array;
    readonly amInitiator: boolean;
    readonly module: LibCrypto;
    readonly onRemoteCancel?: (merkleRootHex: string) => void;
    readonly onStatusChange?: (change: CoverStatusChange) => void;
}
/**
 * Stop scheduled cover on an edge and release its lanes.
 *
 * destroy() emits the terminal "stopped" status, so any observer of
 * rooms[].coverStatusByPeer stops claiming cover for this edge. Safe to call
 * on an edge that never had a runtime.
 */
export declare const teardownCoverEdge: (epc: IRTCPeerConnection) => void;
/**
 * Construct and START the scheduled-cover runtime for one authenticated edge.
 * Called after `runHandshake` on a `coverMode: "scheduled"` room. Idempotent
 * per connection: a replacement handshake destroys the previous runtime first.
 */
export declare const installCoverEdge: (options: InstallCoverEdgeOptions) => void;
/** Record the root→transferId mapping so a terminal receipt settles the send. */
export declare const trackScheduledSend: (epc: IRTCPeerConnection, roomId: string, peerId: string, merkleRootHex: string, transferId: string) => void;
export interface ScheduledSendParams {
    readonly epc: IRTCPeerConnection;
    readonly channelMessageLabel: string;
    readonly totalChunks: number;
    readonly sealSlotCell: (chunkIndex: number) => Promise<Uint8Array | null>;
    readonly getAckedChunks?: () => ReadonlySet<number>;
}
/**
 * Enqueue one message as a lazy scheduled-send job on this edge's cover
 * runtime. Returns false when the edge has no cover runtime (immediate mode).
 */
export declare const enqueueScheduledSend: (params: ScheduledSendParams) => boolean;
