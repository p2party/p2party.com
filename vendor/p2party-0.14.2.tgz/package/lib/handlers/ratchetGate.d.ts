/**
 * Opaque ownership token for one concrete room/peer transport attempt.
 *
 * A reconnect replaces the gate at the same map key. Async completion from the
 * old transport must present its old lease and is then ignored instead of
 * opening/rejecting the replacement transport's promise.
 */
export interface RatchetGateLease {
    readonly token: symbol;
}
export declare const getRatchetGate: (roomId: string, peerId: string) => Promise<void>;
/** Claim the gate already created for the current transport attempt. */
export declare const claimRatchetGate: (roomId: string, peerId: string) => RatchetGateLease;
export declare const isCurrentRatchetGateLease: (roomId: string, peerId: string, lease: RatchetGateLease) => boolean;
export declare const isRatchetGateOpen: (roomId: string, peerId: string, lease?: RatchetGateLease) => boolean;
export declare const openRatchetGate: (roomId: string, peerId: string, lease: RatchetGateLease) => boolean;
export declare const rejectRatchetGate: (roomId: string, peerId: string, err: unknown, lease?: RatchetGateLease) => boolean;
export declare const resetRatchetGate: (roomId: string, peerId: string, reason?: unknown) => RatchetGateLease;
