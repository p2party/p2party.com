export interface ClassifiedFrame {
    type: number;
    payload: Uint8Array;
}
/**
 * Reads the protocol-v3 1-byte frame tag and returns it together with a
 * zero-copy view of the remaining bytes. An empty frame is reported as type -1
 * so the caller can log-and-drop rather than throw.
 */
export declare const classifyFrame: (data: Uint8Array) => ClassifiedFrame;
