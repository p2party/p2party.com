import type { BaseQueryApi } from "@reduxjs/toolkit/query";
declare const handleWebSocketMessage: (event: MessageEvent, ws: WebSocket, api: BaseQueryApi) => Promise<void>;
export default handleWebSocketMessage;
