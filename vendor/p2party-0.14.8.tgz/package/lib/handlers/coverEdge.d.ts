import type { InboundTransferSweepDeps } from "./inboundTransferSweep";
import type { CoverStatusChange } from "./coverScheduler";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { RoomPolicyV1 } from "../roomPolicy";
import type { LibCrypto } from "../cryptography/libcrypto";
/**
 * How many scheduled-cover runtimes this edge has had installed. 0 before the
 * first one, and for every immediate-mode edge (installCoverEdge returns
 * without installing anything there, so nothing is ever published).
 */
export declare const coverEdgeGeneration: (roomId: string, peerId: string) => number;
/**
 * Resolve with this edge's cover generation once it is past `since`, or with
 * the unchanged current generation if none is installed within `timeoutMs`.
 *
 * A caller compares the result with what it passed in: strictly greater means a
 * replacement runtime exists and the caller's retired job may be re-derived
 * onto it; equal means nothing replaced anything.
 *
 * `signal` ends the wait early with the CURRENT generation, i.e. with "nothing
 * replaced anything" unless something actually did. A cancelled send must not
 * sit here for the whole resume budget — the fan-out is serial, so that budget
 * is charged to every later peer as well — and answering "no replacement" is
 * the answer that makes the caller stop rather than re-derive onto an edge
 * nobody is waiting for any more.
 */
export declare const waitForCoverEdgeGeneration: (roomId: string, peerId: string, since: number, timeoutMs: number, signal?: AbortSignal) => Promise<number>;
export interface InstallCoverEdgeOptions {
    readonly epc: IRTCPeerConnection;
    readonly roomId: string;
    readonly policy: RoomPolicyV1;
    readonly policyHash: Uint8Array;
    readonly amInitiator: boolean;
    readonly module: LibCrypto;
    readonly onRemoteCancel?: (merkleRootHex: string) => void;
    readonly onStatusChange?: (change: CoverStatusChange) => void;
    /**
     * Storage seam for the inbound half of a remote CANCEL. Defaults to the
     * production Worker-backed functions.
     */
    readonly inboundSweepDeps?: InboundTransferSweepDeps;
}
/**
 * Stop scheduled cover on an edge and release its lanes.
 *
 * destroy() emits the terminal "stopped" status, so any observer of
 * rooms[].coverStatusByPeer stops claiming cover for this edge. Safe to call
 * on an edge that never had a runtime.
 */
export declare const teardownCoverEdge: (epc: IRTCPeerConnection) => void;
/**
 * Construct and START the scheduled-cover runtime for one authenticated edge.
 * Called after `runHandshake` on a `coverMode: "scheduled"` room. Idempotent
 * per connection: a replacement handshake destroys the previous runtime first.
 */
export declare const installCoverEdge: (options: InstallCoverEdgeOptions) => void;
/** Record the root→transferId mapping so a terminal receipt settles the send. */
export declare const trackScheduledSend: (epc: IRTCPeerConnection, roomId: string, peerId: string, merkleRootHex: string, transferId: string) => void;
export interface ScheduledSendParams {
    readonly epc: IRTCPeerConnection;
    readonly channelMessageLabel: string;
    readonly totalChunks: number;
    /** This transfer's 64-byte Merkle root; the job's wire CANCEL is scoped to it. */
    readonly merkleRoot: Uint8Array;
    readonly sealSlotCell: (chunkIndex: number) => Promise<Uint8Array | null>;
    readonly getAckedChunks?: () => ReadonlySet<number>;
}
/**
 * Enqueue one message as a lazy scheduled-send job on this edge's cover
 * runtime. Returns false when the edge has no cover runtime (immediate mode).
 */
export declare const enqueueScheduledSend: (params: ScheduledSendParams) => boolean;
/**
 * Ask the runtime to emit this transfer's wire CANCEL in its next slot.
 *
 * A job the scheduler still holds carries its own `cancelCell`. A job that has
 * already settled — the usual state once a delivery bound expires, because the
 * cells were all emitted and only the receipt is missing — answers "not-found",
 * and before C3 that is where the receiver was abandoned: it kept an unfillable
 * N/M partial forever while the sender deleted the only thing that could have
 * filled it. That case falls back to a standalone CANCEL control cell, which
 * substitutes into an already-scheduled slot exactly as a receipt does, so it
 * changes nothing observable about the room's fixed schedule.
 */
export declare const cancelScheduledSend: (epc: IRTCPeerConnection, channelMessageLabel: string) => "not-found" | "cancelled-before-admission" | "cancel-pending";
