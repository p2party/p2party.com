import type { PeerHandshakeFailureReason, PeerHandshakeStatus } from "../reducers/roomSlice";
export type HandshakeRetryStatus = Pick<PeerHandshakeStatus, "reason" | "peerPublicKey"> & {
    readonly status: string;
};
export declare const isTerminalHandshakeStatus: (status: HandshakeRetryStatus | undefined) => boolean;
/** A new socket or peerId cannot repair a PIN or policy mismatch. */
export declare const hasTerminalPeerHandshakeFailure: (statuses: Readonly<Record<string, HandshakeRetryStatus | undefined>> | undefined, peerId: string, peerPublicKey?: string) => boolean;
/**
 * A handshake failure that already knows why it failed.
 *
 * The catch in handleOpenChannel used to classify by regex on the error
 * message alone, which mis-typed the framing rejection in deliverHandshakeFrame
 * as "transport" — so a pq-suite or policy mismatch re-dialled forever and was
 * never reported as a policy failure (C2).
 */
export declare class HandshakeFailure extends Error {
    readonly reason: PeerHandshakeFailureReason;
    readonly retryAfter?: number;
    constructor(message: string, reason: PeerHandshakeFailureReason, retryAfter?: number);
}
export interface HandshakeFailureContext {
    /** False before the first frame: a failure there is a transport failure. */
    readonly handshakeStarted: boolean;
    readonly pinRoom: boolean;
}
export interface ClassifiedHandshakeFailure {
    readonly reason: PeerHandshakeFailureReason;
    readonly retryAfter?: number;
}
/**
 * "transport" is the ONLY reason a fresh transport can fix. A PIN or policy
 * mismatch fails again on any transport, and a re-dial would burn another
 * attempt against the PIN throttle.
 */
export declare const isTerminalHandshakeFailure: (reason: PeerHandshakeFailureReason) => boolean;
export declare const classifyHandshakeFailure: (error: unknown, context: HandshakeFailureContext) => ClassifiedHandshakeFailure;
