import { deleteReceiveTransfer, getDBMessageData } from "../db/api";
import { forgetMappedReceiveMessageKey } from "./receiveMessageKeyLifetime";
import { waitForEdgeReceiveQuiescence } from "./handleMessageQueueing";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { MessageData } from "../db/types";
export type InboundReceiveProgress = Pick<MessageData, "transferId" | "fromPeerId" | "savedSize" | "totalSize">;
/**
 * Whether a remote CANCEL from `fromPeerId` may destroy this stored row.
 *
 * Deletion is irreversible, so every clause here is a refusal:
 *
 * - `transferId` is written only on rows this device SENT (db.worker), so it
 *   marks the sender's own self-copy. A CANCEL must never delete that: the
 *   peer is telling us about its receive, not about our library.
 * - a row owned by a different peer is not this edge's to cancel.
 * - a COMPLETED message is a delivered file. A late or replayed CANCEL, or a
 *   sender whose delivery bound expired after the last cell landed, must not
 *   take it away.
 */
export declare const shouldSweepCancelledInboundTransfer: (progress: InboundReceiveProgress | undefined, fromPeerId: string) => boolean;
/**
 * Storage seam. Defaults to the production Worker-backed functions; a caller
 * (and a test, for which the Worker is not available) may substitute them —
 * the same convention `forgetMappedReceiveMessageKey` already uses for its own
 * durable retirement.
 */
export interface InboundTransferSweepDeps {
    readonly waitForReceiveIdle: typeof waitForEdgeReceiveQuiescence;
    readonly readProgress: typeof getDBMessageData;
    readonly forgetKey: typeof forgetMappedReceiveMessageKey;
    readonly deleteReceive: typeof deleteReceiveTransfer;
    /**
     * Drop the message from the LIVE room state. `deleteReceive` is the durable
     * half only — chunks, the messageData row and the pre-sized OPFS file — and
     * both immediate-mode cancels do this second half too
     * (disconnectFromPeerChannelLabelQuery, disconnectFromChannelLabelQuery both
     * dispatch deleteMessage). Without it the user is left looking at a partial
     * whose bytes no longer exist and which no re-send can ever fill.
     */
    readonly dropStateRow: (roomId: string, merkleRootHex: string) => void | Promise<void>;
}
export declare const productionInboundTransferSweepDeps: InboundTransferSweepDeps;
/**
 * Drop the partial WE are receiving for one cancelled transfer root.
 *
 * The immediate-mode cancel is TWO deletions, and this is both of them:
 * `cancelReceiveTransfer` in the Worker (chunks, the messageData row, the
 * pre-sized OPFS file), and then `deleteMessage` on the room state — which is
 * what `disconnectFromPeerChannelLabelQuery` and `disconnectFromChannelLabelQuery`
 * each dispatch alongside it. Doing only the durable half leaves the user
 * looking at an N/M partial whose bytes are already gone.
 *
 * Order matters and is the same as immediate mode's: retire the mapped receive
 * key first (so no key outlives the data it opens), then the durable data, and
 * the state row last — it is the only remaining evidence the partial exists, so
 * it must not go while anything a reconnect could still resume is on disk.
 *
 * Never throws: it runs from a cover-cell handler on the fixed schedule, and
 * an observer must not be able to perturb that. Storage uncertainty leaves the
 * partial in place, which a reconnect can still resume — the safe direction.
 */
export declare const sweepCancelledInboundTransfer: (epc: IRTCPeerConnection, roomId: string, merkleRootHex: string, deps?: InboundTransferSweepDeps) => Promise<boolean>;
