import { type PersistInitialRatchetState, type RollbackInitialRatchetState } from "./ratchetPersist";
import { SparsePqHealingState } from "./pqHealingRuntime";
import { parseFingerprintFromSdp } from "../utils/sdpFingerprint";
import { type HandshakeTransport, type PqHealingBootstrap } from "./handshakeCore";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { RatchetRootSuite } from "../utils/constants";
import type { RatchetState } from "../cryptography/ratchet";
import type { RatchetGateLease } from "./ratchetGate";
import type { RoomPqMode } from "../roomPolicy";
import type { IRTCPeerConnection, IRTCDataChannel } from "../api/webrtc/interfaces";
export { parseFingerprintFromSdp };
/**
 * Post-connect DTLS binding check (spec §5): the fingerprint declared in the
 * SDP (and bound into the CPace channel-input via buildChannelInput) must
 * equal the live certificate reported by getStats(). A disagreement means the
 * DTLS transport terminates on a different certificate than the one that was
 * authenticated by the handshake — i.e. a signaling server (or any on-path
 * attacker) swapped the SDP fingerprint/cert after the CPace transcript was
 * bound. This is the actual MITM tripwire, so it THROWS (never returns a
 * boolean, never logs-and-continues) — the caller must abort the channel.
 */
export declare const verifyDtlsFingerprints: (epc: IRTCPeerConnection) => Promise<void>;
/** Opaque owner of one concrete main-channel handshake attempt. */
export interface HandshakeLease {
    readonly token: symbol;
}
export declare const setHandshakeChannel: (roomId: string, peerId: string, channel: IRTCDataChannel | {
    send: (b: ArrayBuffer | Uint8Array) => void;
}, pqMode?: RoomPqMode, expectFinish?: boolean) => HandshakeLease;
export declare const clearHandshakeChannel: (roomId: string, peerId: string, reason?: Error, lease?: HandshakeLease) => boolean;
export declare const deliverHandshakeFrame: (roomId: string, peerId: string, payload: Uint8Array, lease: HandshakeLease) => boolean;
/**
 * The send/recv pair runHandshake drives the inbox with. Exported so the frame
 * bounds — including the framing rejection's typed failure, which is only ever
 * observable through a parked recv — can be exercised without a full handshake.
 */
export declare const transportForPeer: (roomId: string, peerId: string, lease: HandshakeLease) => HandshakeTransport;
/**
 * Consume the handshake's PQ-healing bootstrap into a live store-free runtime.
 * The constructor copies the root/binding, so the caller-owned bootstrap
 * buffers are wiped on every exit — including a failed construction — leaving
 * the returned runtime as the only holder of the derived PQ root.
 */
export declare const createHandshakePqRuntime: (module: LibCrypto, pqMode: RoomPqMode, rootSuite: RatchetRootSuite, amInitiator: boolean, bootstrap: PqHealingBootstrap) => SparsePqHealingState;
export interface EdgeCryptoCandidate {
    readonly state: RatchetState;
    readonly pqRuntime: SparsePqHealingState;
}
/**
 * Atomically persist the handshake-established Double Ratchet together with
 * the initial sparse-PQ checkpoint in ONE stable-edge row, then synchronously
 * install both on the live connection. The candidate serializer hook is
 * installed before the row is written, so even the very first persisted row
 * carries a non-null encrypted edge state. `beforeInstall` runs inside the
 * synchronous activation (lease/gate checks); if it — or persistence — throws,
 * the hook is removed, the seed row is rolled back by the persistence layer,
 * nothing is installed, and ownership of both candidates stays with the
 * caller (which must wipe/destroy them). Ownership transfers to `epc` only
 * when this resolves.
 */
export declare const persistAndActivateEdgeCrypto: (epc: IRTCPeerConnection, roomId: string, candidate: EdgeCryptoCandidate, beforeInstall: () => void, persist?: PersistInitialRatchetState, rollback?: RollbackInitialRatchetState) => Promise<void>;
/**
 * Orchestrates the handshake on the persistent `main` channel (spec §5): verifies
 * the DTLS fingerprints (getStats vs SDP), runs the triple-confirmation core,
 * then — ONLY
 * on success — seeds + persists the (wrapped) ratchet together with the
 * initial sparse-PQ checkpoint in one row, sets epc.ratchetState /
 * epc.pqHealingState, and opens the per-peer gate. Any failure (fingerprint
 * mismatch,
 * CPace/interactive-3DH error, key-confirmation mismatch, a bad/short frame,
 * a transport or
 * persistence error) rejects the gate and re-throws, having persisted NOTHING —
 * the caller tears the channel down. No PQ root, binding, or runtime survives
 * a failure path outside this function.
 */
export declare const runHandshake: (epc: IRTCPeerConnection, roomId: string, mode: "pin" | "nopin", pqMode: RoomPqMode, pin: Uint8Array | null, channelInput: Uint8Array, module: LibCrypto, handshakeLease: HandshakeLease, gateLease: RatchetGateLease) => Promise<void>;
