import type { UnknownAction } from "@reduxjs/toolkit";
import type { RoomRosterReconciler } from "../utils/roomRosterReconciler";
export declare const createRoomListenerMiddleware: (reconciler?: RoomRosterReconciler) => import("@reduxjs/toolkit").ListenerMiddlewareInstance<unknown, import("redux-thunk").ThunkDispatch<unknown, unknown, UnknownAction>, unknown>;
declare const roomListenerMiddleware: import("@reduxjs/toolkit").ListenerMiddlewareInstance<unknown, import("redux-thunk").ThunkDispatch<unknown, unknown, UnknownAction>, unknown>;
export default roomListenerMiddleware;
