/**
 * Domain-separated derivations for blind rendezvous.
 *
 * Section 3.3 fixes the conventions used throughout: `H(x)` is SHA-256, `||`
 * is byte concatenation, a quoted domain string is its exact ASCII octets with
 * no terminator, and `U16BE`/`U32BE`/`U64BE`/`Byte` are exact big-endian
 * encodings that reject out-of-range input before a preimage is formed.
 *
 * Every formula below is transcribed from the specification and carries its
 * source label. A caller must not build one of these preimages by hand: the
 * domain string, argument order, and canonical encoding are protocol-visible.
 *
 * Status: PROPOSED, NOT FROZEN. The formulas are fixed by the specification,
 * but any value derived over a `Canonical(...)` argument inherits the
 * unfrozen status of `canonicalSchema.ts`, so no output here is a published
 * v0.4 release artifact yet.
 */
export { hmacSha256, hkdfSha256Expand, hkdfSha256Extract, sha256, } from "../cryptography/webCryptoSha256";
export declare class DerivationError extends Error {
    readonly name = "DerivationError";
    constructor(message: string);
}
/** Exact ASCII octets of a domain-separation string; no terminator. */
export declare const domain: (value: string) => Uint8Array;
export declare const byteOf: (value: number) => Uint8Array;
export declare const u16be: (value: number) => Uint8Array;
export declare const u32be: (value: number) => Uint8Array;
export declare const u64be: (value: bigint) => Uint8Array;
export declare const concatBytes: (...parts: readonly Uint8Array[]) => Uint8Array<ArrayBuffer>;
/** RFC 4648 URL-safe base64 with no padding. No lowercase variant exists. */
export declare const base64urlNoPad: (bytes: Uint8Array) => string;
export declare const base64urlNoPadDecode: (encoded: string) => Uint8Array;
/** `PolicyHash = H("p2party/room-policy/v4" || Canonical(RoomPolicyV4))` */
export declare const policyHash: (roomPolicy: unknown) => Promise<Uint8Array>;
/**
 * `RoomRoot = HKDF-Extract(salt = PolicyHash, ikm = capability)`
 *
 * The result is a local secret and never crosses a carrier.
 */
export declare const roomRoot: (capability: Uint8Array, policyHashBytes: Uint8Array) => Promise<Uint8Array>;
/** `RoomContextId = H("p2party/room-context/v4" || capability || PolicyHash)` */
export declare const roomContextId: (capability: Uint8Array, policyHashBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `DeliveryProfileHash =
 *    H("p2party/delivery-profile/v1" || Canonical(DeliveryProfileV1))`
 */
export declare const deliveryProfileHash: (profile: unknown) => Promise<Uint8Array>;
/**
 * `LocalRoomId = Base64urlNoPad(H("p2party/local-room-id/v1" || RoomContextId))`
 *
 * This replaces the legacy server-assigned room UUID in local state and never
 * crosses a carrier.
 */
export declare const localRoomId: (roomContextIdBytes: Uint8Array) => Promise<string>;
/**
 * `StableIdentityCommitment =
 *    H("p2party/stable-identity-commitment/v1" ||
 *      RoomContextId || stableEd25519PublicKey)`
 *
 * This is a room-scoped pseudonym, not key hiding: a capability holder that
 * already knows a candidate public key can test it. The raw stable key never
 * needs to enter a room-wide presence payload.
 */
export declare const stableIdentityCommitment: (roomContextIdBytes: Uint8Array, stableEd25519PublicKey: Uint8Array) => Promise<Uint8Array>;
/**
 * `LocalPeerIdDigest =
 *    H("p2party/local-peer-id/v1" ||
 *      RoomContextId || StableIdentityCommitment)`
 */
export declare const localPeerIdDigest: (roomContextIdBytes: Uint8Array, stableIdentityCommitmentBytes: Uint8Array) => Promise<Uint8Array>;
/** `"peer.v1." || Base64urlNoPad(LocalPeerIdDigest)` */
export declare const localPeerId: (roomContextIdBytes: Uint8Array, stableIdentityCommitmentBytes: Uint8Array) => Promise<string>;
/**
 * `EligiblePresenceRank =
 *    H("p2party/presence-rank/authority/v1" ||
 *      RoomContextId || permitSerial || U64BE(generation))`
 */
export declare const authorityPresenceRank: (roomContextIdBytes: Uint8Array, permitSerialBytes: Uint8Array, generation: bigint) => Promise<Uint8Array>;
/**
 * `EligiblePresenceRank =
 *    H("p2party/presence-rank/address-book/v1" ||
 *      RoomContextId || StableIdentityCommitment)`
 */
export declare const addressBookPresenceRank: (roomContextIdBytes: Uint8Array, stableIdentityCommitmentBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `EligiblePresenceRank =
 *    H("p2party/presence-rank/open/v1" ||
 *      RoomContextId || PresenceOperationId)`
 */
export declare const openPresenceRank: (roomContextIdBytes: Uint8Array, presenceOperationIdBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `RoomContextConfirmation = H("p2party/room-confirmation/v1" || RoomContextId)`
 */
export declare const roomContextConfirmation: (roomContextIdBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `OperationId =
 *    H("p2party/room-operation/v1" || Canonical(AuthenticatedRoomOperationV1))`
 *
 * Derived only after carrier AEAD and operation validation; it is never sent
 * to a store as a logical identifier.
 */
export declare const operationId: (operation: unknown) => Promise<Uint8Array>;
/**
 * The operation signature transcript:
 * `"p2party/room-operation-signature/v1" || Canonical(every preceding field)`.
 * The length-disjoint domain prefix is part of the signed bytes.
 */
export declare const operationSignatureMessage: (unsignedOperation: unknown) => Uint8Array;
/**
 * `PresenceSemanticSlot = H("p2party/presence-slot/v1" ||
 *    authorEpochEd25519Key || U64BE(logicalWindow) || presenceNonce)`
 */
export declare const presenceSemanticSlot: (authorEpochEd25519Key: Uint8Array, logicalWindow: bigint, presenceNonce: Uint8Array) => Promise<Uint8Array>;
/**
 * `LeaveSemanticSlot = H("p2party/leave-slot/v1" ||
 *    presenceOperationId || U64BE(effectiveLogicalWindow))`
 */
export declare const leaveSemanticSlot: (presenceOperationId: Uint8Array, effectiveLogicalWindow: bigint) => Promise<Uint8Array>;
/**
 * `StoreHintSemanticSlot = H("p2party/store-hint-slot/v1" ||
 *    StoreId(descriptor) || U64BE(descriptorGeneration))`
 */
export declare const storeHintSemanticSlot: (storeId: Uint8Array, descriptorGeneration: bigint) => Promise<Uint8Array>;
/**
 * `AdmissionRevokeSemanticSlot = H("p2party/admission-revoke-slot/v1" ||
 *    stableIdentityCommitment || U64BE(minimumAcceptedGeneration) ||
 *    U64BE(effectiveLogicalWindow) || U64BE(expiresAfterLogicalWindow))`
 */
export declare const admissionRevokeSemanticSlot: (stableIdentityCommitment: Uint8Array, minimumAcceptedGeneration: bigint, effectiveLogicalWindow: bigint, expiresAfterLogicalWindow: bigint) => Promise<Uint8Array>;
/** `H("p2party/pair-slot/v1" || pairRoutingTag)` (Section 4.4 slot table). */
export declare const pairSemanticSlot: (pairRoutingTag: Uint8Array) => Promise<Uint8Array>;
/** The schema-owned one-byte registry value for a pair-step kind. */
export declare const pairStepKindByte: (kind: string) => Uint8Array;
/**
 * `PairEdgeId = H("p2party/pair-edge/v1" || RoomContextId ||
 *   Sort2(PresenceOperationIdA, PresenceOperationIdB))`
 */
export declare const pairEdgeId: (roomContextIdBytes: Uint8Array, firstPresenceOperationId: Uint8Array, secondPresenceOperationId: Uint8Array) => Promise<Uint8Array>;
/**
 * `StableEdgeId = H("p2party/stable-edge/v1" || RoomContextId ||
 *   Sort2(stableEd25519PublicKeyA, stableEd25519PublicKeyB))`
 */
export declare const stableEdgeId: (roomContextIdBytes: Uint8Array, firstStableEd25519PublicKey: Uint8Array, secondStableEd25519PublicKey: Uint8Array) => Promise<Uint8Array>;
/** Hash the exact canonical transport candidate used as its ordering key. */
export declare const transportOfferCandidateId: (candidate: unknown) => Promise<Uint8Array>;
/**
 * Construct the one complete pair-AAD binding. The prebinding is snapshotted
 * before the asynchronous semantic-slot derivation.
 */
export declare const bindPairOuter: (prebinding: unknown, pairRoutingTag: Uint8Array) => Promise<{
    readonly prebinding: unknown;
    readonly pairRoutingTag: Uint8Array;
    readonly semanticSlot: Uint8Array;
}>;
/** `"p2party/pair-aad/v1" || Canonical(PairOuterBindingV1)`. */
export declare const pairAad: (binding: unknown) => Promise<Uint8Array>;
/**
 * Hash the exact outer binding and unsigned pair-identity plaintext
 * projection. No field other than the nested identity signature is omitted.
 */
export declare const pairIdentitySignatureHash: (binding: unknown, unsignedProjection: unknown) => Promise<Uint8Array>;
/**
 * Stable-identity Ed25519 message for HELLO or ACCEPT.
 *
 * The kind byte remains outside the hash so this transcript cannot collide
 * with an existing API that signs a bare 32-byte challenge.
 */
export declare const pairIdentitySignedMessage: (binding: unknown, unsignedProjection: unknown) => Promise<Uint8Array>;
/** Exact operation-ID transcript for the confirmed two-flight identity gate. */
export declare const confirmedPairTranscriptId: (helloOperationId: Uint8Array, acceptOperationId: Uint8Array) => Promise<Uint8Array>;
/**
 * HELLO's room- and recipient-bound HPKE PSK identifier.
 *
 * `H("p2party/identity-hello-psk-id/v1" || PolicyHash ||
 *    responderPresenceOperationId)`
 */
export declare const identityHelloPskId: (policyHashBytes: Uint8Array, responderPresenceOperationId: Uint8Array) => Promise<Uint8Array>;
/**
 * ACCEPT's room- and HELLO-bound HPKE PSK identifier.
 *
 * `H("p2party/identity-accept-psk-id/v1" || PolicyHash ||
 *    HelloOperationId)`
 */
export declare const identityAcceptPskId: (policyHashBytes: Uint8Array, helloOperationId: Uint8Array) => Promise<Uint8Array>;
/** Hash the exact canonical suite-1 HPKE bootstrap header. */
export declare const pairBootstrapHeaderHash: (bootstrapHeader: unknown) => Promise<Uint8Array>;
/**
 * HPKE exporter context for the one-use public bootstrap routing tag.
 *
 * `"p2party/bootstrap-tag/v1" || Canonical(PairOuterPrebindingV1)`
 */
export declare const pairBootstrapTagExporterContext: (prebinding: unknown) => Uint8Array;
/**
 * HPKE exporter context used only after a bootstrap plaintext authenticates
 * and passes the complete canonical pair-plaintext validator.
 */
export declare const validatedPairRootExporterContext: (kind: "IDENTITY_HELLO" | "IDENTITY_ACCEPT", canonicalPairPlaintext: Uint8Array) => Promise<Uint8Array>;
/**
 * Root shared by both endpoints after the two exact identity operation IDs
 * and both validated HPKE bootstrap roots are known.
 */
export declare const establishedPairRoot: (helloRoot: Uint8Array, acceptRoot: Uint8Array, helloOperationId: Uint8Array, acceptOperationId: Uint8Array) => Promise<Uint8Array>;
/**
 * First stage of the established-flight schedule. The slot is the complete
 * kind/direction/sequence coordinate and no output length is implicit.
 */
export declare const pairFlightRoot: (baseSecret: Uint8Array, slot: {
    readonly kind: string;
    readonly direction: number;
    readonly pairSequence: bigint;
}) => Promise<Uint8Array>;
/**
 * Second stage of the established-flight schedule, binding the exact signed
 * outer prebinding before the public routing tag exists.
 */
export declare const pairFlightSecret: (flightRoot: Uint8Array, kind: string, prebinding: unknown) => Promise<Uint8Array>;
/** `HMAC-SHA-256(PairFlightSecret, "p2party/pair-flight-tag/v1")`. */
export declare const pairFlightRoutingTag: (flightSecret: Uint8Array) => Promise<Uint8Array>;
/**
 * Final established-flight key, bound to the complete routing-tag-derived
 * outer binding.
 */
export declare const pairFlightAeadKey: (flightSecret: Uint8Array, binding: unknown) => Promise<Uint8Array>;
/**
 * Stable-edge attempt claim signature transcript.
 *
 * The unsigned descriptor is shared with the signed schema, so adding or
 * reordering a claim field cannot silently leave the signature projection.
 */
export declare const stableEdgeAttemptClaimSignedMessage: (unsignedClaim: unknown) => Promise<Uint8Array>;
/** Exact offer/answer operation-ID negotiation transcript. */
export declare const transportNegotiationTranscriptId: (offerOperationId: Uint8Array, answerOperationId: Uint8Array) => Promise<Uint8Array>;
/**
 * Stable-key-ordered endpoint binding for the mandatory operation carrier.
 *
 * `endpointSessionRole` is 0 for the stable-key-ordered v4 initiator and 1
 * for the responder; it is deliberately not a rendezvous direction.
 */
export declare const operationCarrierTransportBinding: (roomContextIdBytes: Uint8Array, stableEdgeIdBytes: Uint8Array, confirmedPairTranscriptIdBytes: Uint8Array, transportNegotiationTranscriptIdBytes: Uint8Array, endpointSessionRole: 0 | 1, endpointStableEd25519PublicKey: Uint8Array) => Promise<Uint8Array>;
/**
 * Handoff identifier shared by WebRTC and non-WebRTC v4 transports.
 */
export declare const rendezvousChannelId: (roomContextIdBytes: Uint8Array, pairEdgeIdBytes: Uint8Array, confirmedPairTranscriptIdBytes: Uint8Array, transportNegotiationTranscriptIdBytes: Uint8Array) => Promise<Uint8Array>;
/**
 * `PresenceProofTranscriptHash =
 *   H("p2party/presence-proof/v1" || Canonical(PresenceProofTranscript))`
 */
export declare const presenceProofTranscriptHash: (transcript: unknown) => Promise<Uint8Array>;
/**
 * `PresenceOwnershipSignedMessage =
 *   "p2party/presence-ownership-signature/v1" ||
 *   PresenceProofTranscriptHash`
 */
export declare const presenceOwnershipSignedMessage: (transcriptHash: Uint8Array) => Uint8Array;
/**
 * `PresencePermitSignedMessage =
 *   "p2party/presence-permit-signature/v1" ||
 *   H(Canonical(PresencePermitV1 without authoritySignature))`
 */
export declare const presencePermitSignedMessage: (unsignedPermit: unknown) => Promise<Uint8Array>;
/**
 * `AdmissionGrantId =
 *   H("p2party/admission-grant/v1" || Canonical(AdmissionGrantV1))`
 */
export declare const admissionGrantId: (grant: unknown) => Promise<Uint8Array>;
/**
 * `AdmissionGrantSignedMessage =
 *   "p2party/admission-grant-signature/v1" ||
 *   H(Canonical(AdmissionGrantV1 without authoritySignature))`
 */
export declare const admissionGrantSignedMessage: (unsignedGrant: unknown) => Promise<Uint8Array>;
/**
 * `AdmissionRevokeSignedMessage =
 *   "p2party/admission-revoke-signature/v1" ||
 *   H(Canonical(AdmissionRevokeV1 without authoritySignature))`
 */
export declare const admissionRevokeSignedMessage: (unsignedRevoke: unknown) => Promise<Uint8Array>;
/**
 * Decision-relevant authority state. The schema itself excludes the moving
 * reference window, whole-Core/custody digests, and unrelated identities.
 */
export declare const authorityAdmissionStateDigest: (input: unknown) => Promise<Uint8Array>;
export interface CarrierEnvelopeCoordinates {
    readonly deliveryProfileHash: Uint8Array;
    readonly carrierContextId: Uint8Array;
    readonly ingressWindow: bigint;
    readonly sizeClass: number;
}
/**
 * `CarrierKey = HKDF-Expand(RoomRoot,
 *    "p2party/carrier-envelope-key/v1" || DeliveryProfileHash ||
 *    carrierContextId || U64BE(ingressWindow) || Byte(sizeClass) || nonce, 32)`
 */
export declare const carrierKey: (roomRootBytes: Uint8Array, coordinates: CarrierEnvelopeCoordinates, nonce: Uint8Array) => Promise<Uint8Array>;
/**
 * `CarrierAAD = "p2party/carrier-envelope-aad/v1" || Byte(version) ||
 *    DeliveryProfileHash || U64BE(ingressWindow) || Byte(sizeClass) ||
 *    carrierContextId`
 *
 * The AAD deliberately omits the nonce: the nonce is a key selector, and the
 * key schedule already binds it.
 */
export declare const carrierAad: (version: number, coordinates: CarrierEnvelopeCoordinates) => Uint8Array;
/**
 * `CarrierObjectId = H("p2party/carrier-object/v1" || Canonical(CarrierEnvelopeV1))`
 *
 * Useful only inside one carrier context; clients deduplicate by the private
 * `OperationId` after decryption.
 */
export declare const carrierObjectId: (envelope: unknown) => Promise<Uint8Array>;
/**
 * `operationsDigest =
 *    H("p2party/core-operation-set/v1" || Canonical(activeOperationIds))`
 *
 * The same formula serves the R2 conformance record's required-operation
 * digest.
 */
export declare const coreOperationSetDigest: (operationIds: readonly Uint8Array[]) => Promise<Uint8Array>;
/**
 * `ObservedRosterHash =
 *    H("p2party/observed-roster/v1" ||
 *      U64BE(referenceWindow) ||
 *      Canonical(Sort(validActivePresenceOperationIds)))`
 *
 * `CoreRoomStateV1.observedPresences` already carries this set in canonical
 * operation-ID order. Requiring that order here keeps the schema registry as
 * the one sorted-set validator instead of silently inventing another sorter.
 */
export declare const observedRosterHash: (referenceWindow: bigint, validActivePresenceOperationIds: readonly Uint8Array[]) => Promise<Uint8Array>;
export declare const executableKernelManifestHash: (manifest: unknown) => Promise<Uint8Array>;
/**
 * `KernelModuleSemanticsHash(module) =
 *    H("p2party/executable-kernel-module-semantics/v1" || module.moduleId ||
 *      Canonical(sorted entrypoint tuples))`
 *
 * `moduleId` is a `Uint16` schema field, so it enters the preimage as `U16BE`.
 */
export declare const kernelModuleSemanticsHash: (module: {
    readonly moduleId: number;
    readonly entrypoints: readonly unknown[];
}) => Promise<Uint8Array>;
/**
 * `KernelSourceTreeHash(files) = H("p2party/executable-kernel-source-tree/v1"
 *    || Canonical(Sort(normalizedRelativePath, H(fileBytes))))`
 *
 * Absolute paths, timestamps, filesystem order, and build-host metadata are
 * excluded by construction.
 */
export declare const kernelSourceTreeHash: (files: readonly {
    readonly normalizedRelativePath: string;
    readonly fileDigest: Uint8Array;
}[]) => Promise<Uint8Array>;
export declare const claimRegistryHash: (registry: unknown) => Promise<Uint8Array>;
export declare const claimWordingCatalogHash: (catalog: unknown) => Promise<Uint8Array>;
export declare const formalObligationRegistryHash: (registry: unknown) => Promise<Uint8Array>;
/**
 * `ClaimScopeDigest = H("p2party/claim-scope/v1" || U16BE(claimId) ||
 *    ClaimScopeKindByte(scopeKind) || scopeSchemaHash || canonicalScope)`
 */
export declare const claimScopeDigest: (claimId: number, scopeKindByte: number, scopeSchemaHash: Uint8Array, canonicalScope: Uint8Array) => Promise<Uint8Array>;
export declare const claimEvaluationDatasetDigest: (dataset: unknown) => Promise<Uint8Array>;
/**
 * `FormalAssumptionSetHash = H("p2party/formal-assumption-set/v1" ||
 *    claimRegistryHash || Canonical(resolved sorted ClaimAssumptionV1 records))`
 */
export declare const formalAssumptionSetHash: (claimRegistryHashBytes: Uint8Array, resolvedAssumptions: readonly unknown[]) => Promise<Uint8Array>;
/**
 * `FormalProofScopeDigest = H("p2party/formal-proof-scope/v1" ||
 *    U16BE(obligationId) || proofScopeSchemaHash || canonicalScope)`
 */
export declare const formalProofScopeDigest: (obligationId: number, proofScopeSchemaHash: Uint8Array, canonicalScope: Uint8Array) => Promise<Uint8Array>;
/**
 * `EmptySchedulerWorkloadDigest = H("p2party/scheduler-workload/v1/none")`
 *
 * Only FPO-002 accepts a nonempty scheduler workload; every other obligation
 * uses this closed sentinel so an unrelated workload cannot alter another
 * property's identity.
 */
export declare const emptySchedulerWorkloadDigest: () => Promise<Uint8Array>;
export declare const claimEvaluationDigest: (evaluation: unknown) => Promise<Uint8Array>;
export declare const formalProofResultDigest: (result: unknown) => Promise<Uint8Array>;
/**
 * `AppendRequestHash =
 *    H("p2party/public-append-request/v1" || Canonical(PublicAppendRequestV1))`
 *
 * The store echoes this in its result so a client can match an answer to the
 * request it sent without the store holding any per-client state.
 */
export declare const publicAppendRequestHash: (request: unknown) => Promise<Uint8Array>;
/**
 * `AppendResultSignedMessage =
 *    "p2party/public-append-result/v1" ||
 *    H(Canonical(PublicAppendResultBodyV1))`
 */
export declare const publicAppendResultSignedMessage: (body: unknown) => Promise<Uint8Array>;
/**
 * `AllocationRequestHash = H("p2party/public-allocation-request/v1" ||
 *    Canonical(PublicAllocationRequestV1))`
 */
export declare const publicAllocationRequestHash: (request: unknown) => Promise<Uint8Array>;
/**
 * `AllocationLeaseSignedMessage =
 *    "p2party/public-allocation-lease-signature/v1" ||
 *    H(Canonical(PublicAllocationLeaseBodyV1))`
 *
 * The body descriptor is shared with the signed lease, so adding a lease
 * field cannot silently leave the signature projection.
 */
export declare const publicAllocationLeaseSignedMessage: (body: unknown) => Promise<Uint8Array>;
/**
 * `AllocationStatusSignedMessage =
 *    "p2party/public-allocation-status-signature/v1" ||
 *    H(Canonical(PublicAllocationStatusBodyV1))`
 *
 * A refusal is signed for the same reason a lease is: an unsigned refusal
 * could be forged by the network to push a client onto one store.
 */
export declare const publicAllocationStatusSignedMessage: (body: unknown) => Promise<Uint8Array>;
/**
 * `TokenIssueRequestHash = H("p2party/allocation-token-issue-request/v1" ||
 *    Canonical(AllocationTokenIssueRequestV1))`
 */
export declare const allocationTokenIssueRequestHash: (request: unknown) => Promise<Uint8Array>;
/**
 * `TokenIssueResultSignedMessage =
 *    "p2party/allocation-token-issue-result-signature/v1" ||
 *    H(Canonical(AllocationTokenIssueResultBodyV1))`
 *
 * The covered value is the union body, so the issued and refused answers can
 * never share a transcript: the union tag byte is inside the hash.
 */
export declare const allocationTokenIssueResultSignedMessage: (body: unknown) => Promise<Uint8Array>;
/**
 * `AllocationAppendSignedMessage =
 *    "p2party/allocation-append-signature/v1" ||
 *    H(Canonical(PublicAllocationLeaseBodyV1)) || Byte(sizeClass) ||
 *    U32BE(objectOrdinalWithinAllocation) || H(exactFixedObject)`
 *
 * Signed by the lease's ephemeral allocation key, not the store key. Binding
 * the size class and the ordinal alongside the object hash is what stops one
 * admission being replayed into a different slot of the same allocation.
 */
export declare const allocationAppendSignedMessage: (leaseBody: unknown, sizeClass: number, objectOrdinalWithinAllocation: number, exactFixedObject: Uint8Array) => Promise<Uint8Array>;
/**
 * `ChunkStatusSigningHash = H("p2party/public-chunk-status/v1" ||
 *    Canonical(PublicChunkStatusBodyV1))`
 *
 * A refused chunk read is signed so a store cannot deny a finalized chunk to
 * one reader and serve it to another without leaving evidence.
 */
export declare const publicChunkStatusSigningHash: (body: unknown) => Promise<Uint8Array>;
/**
 * `CheckpointStatusSigningHash = H("p2party/public-checkpoint-status/v1" ||
 *    Canonical(PublicStoreCheckpointStatusBodyV1))`
 */
export declare const publicCheckpointStatusSigningHash: (body: unknown) => Promise<Uint8Array>;
/**
 * `compatibilityHash = H("p2party/blind-store-prototype-v0/compatibility" ||
 *    DeliveryProfileHash)`
 *
 * A prototype store advertises this in its descriptor. It is deliberately
 * prototype-scoped: a client that expects release compatibility bytes will
 * refuse a prototype store rather than half-speak to it.
 */
export declare const prototypeStoreCompatibilityHash: (deliveryProfileHashBytes: Uint8Array) => Promise<Uint8Array>;
