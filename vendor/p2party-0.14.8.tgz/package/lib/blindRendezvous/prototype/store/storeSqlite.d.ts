/**
 * The durable half of the prototype store: `StorePersistencePort` over one
 * SQLite file (`bun:sqlite`, no new dependency).
 *
 * Every column here is public geometry — an ingress window, a size class, an
 * ordinal, and opaque object bytes. There is no room, member, peer or account
 * column, so seizing this file yields the same thing a passive reader of the
 * chunks already has: which fixed positions were occupied, and nothing about
 * who occupied them or which conversation they belonged to.
 *
 * Two properties this file must not break:
 *
 * - **A finalized window is never lost.** Re-signing one window is a permanent
 *   fault proof against the store, and `lastFinalizedWindow()` is the only
 *   thing that stops `finalizeDue` from starting over. Hence `synchronous =
 *   FULL`: WAL's usual `NORMAL` can drop the last commits on power loss, and
 *   here that loss is not "a little data", it is the store equivocating.
 * - **No row aliases a caller's buffer.** Values cross this boundary as
 *   canonical bytes and are re-decoded on the way out, so the core's mutable
 *   working state and the stored state are never the same objects.
 *
 * `bun:sqlite` is imported here and nowhere else in the prototype, so nothing
 * a browser bundle can reach ever pulls a server-only module in.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry.
 */
import type { StoreWitnessRecordV1 } from "../storeWire";
import type { StorePersistencePort, StoreWindowState } from "./storePersistence";
export declare class StorePersistenceError extends Error {
    readonly name = "StorePersistenceError";
    constructor(message: string);
}
export declare class SqliteStorePersistence implements StorePersistencePort {
    #private;
    constructor(path: string);
    close(): void;
    loadWindow(window: bigint): Promise<StoreWindowState | null>;
    saveWindow(state: StoreWindowState): Promise<void>;
    lastFinalizedWindow(): Promise<bigint | null>;
    loadWitnessRecords(window: bigint): Promise<StoreWitnessRecordV1[]>;
    saveWitnessRecord(record: StoreWitnessRecordV1): Promise<void>;
    loadMeta(key: string): string | null;
    saveMeta(key: string, value: string): void;
}
