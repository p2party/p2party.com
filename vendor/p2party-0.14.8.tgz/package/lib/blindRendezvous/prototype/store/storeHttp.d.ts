/**
 * The prototype store's transport: routing, coordinate parsing, and canonical
 * serialization. Nothing else.
 *
 * Everything this file can name is public geometry — a delivery-profile hash,
 * an ingress window, a size class, and two ordinals. There is no room, member,
 * peer or invitation value in any path, header or body, and no request carries
 * one, which is what lets unrelated rooms share a bucket and cover for each
 * other. The one deliberate exception is `logBodiesPath`, a harness-only file
 * sink that exists precisely so the E2E can *prove* that claim by hexdumping
 * every body the store parsed; a store run for real never sets it.
 *
 * Three properties this layer is responsible for:
 *
 * - **One constant refusal.** A wrong media type, an oversized body, a body
 *   that is not the unique canonical encoding of its value, and a path
 *   coordinate spelled in a second way all answer `400 malformed` with no
 *   further detail. A refusal that described *what* was wrong would be an
 *   oracle for probing what this store holds.
 * - **Protocol answers are 200.** `not-final`, `out-of-range`,
 *   `window-closed`, `slot-conflict` and friends are signed statements from
 *   the store, not transport errors, so they travel as ordinary bodies. A
 *   reader that trusted HTTP status codes would be trusting an unsigned value.
 * - **Only immutable things are cacheable.** A finalized chunk or checkpoint
 *   can never be re-signed, so it gets a year of `immutable`. Everything else
 *   — the descriptor, every status, health — is `no-store`.
 *
 * Configuration lives in `storeServer.ts`; this file reads no environment.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry.
 */
import { PROTOTYPE_STORE_MEDIA_TYPES, PROTOTYPE_STORE_ROUTES } from "../storeRoutes";
import type { PrototypeStoreCore } from "./storeCore";
export interface StoreHttpOptions {
    readonly core: PrototypeStoreCore;
    /**
     * Harness only. When set, every POST body the store parses is appended as
     * one hex line, so the E2E can assert the store never received a
     * room-derived value. Never set this on a store anyone relies on.
     */
    readonly logBodiesPath?: string;
}
/**
 * Re-exported from `../storeRoutes`, where the browser-side client can import
 * them without pulling this file's `node:fs` dependency in with them.
 */
export { PROTOTYPE_STORE_MEDIA_TYPES, PROTOTYPE_STORE_ROUTES };
/**
 * The largest body any prototype request has, plus headroom. The biggest is an
 * append of the largest size class (73 728 payload bytes plus the envelope and
 * admission), so a megabyte is generous; the cap exists so a request cannot be
 * turned into a memory bill.
 */
export declare const PROTOTYPE_STORE_MAX_REQUEST_BODY_BYTES: number;
export declare const createPrototypeStoreHandler: (options: StoreHttpOptions) => ((request: Request) => Promise<Response>);
