/**
 * The prototype store entrypoint: configuration, the identity key file, and
 * process lifecycle. `bun run store:prototype`.
 *
 * This process is **not conformant**. It implements open allocation only —
 * there is no Privacy Pass issuer, so it carries no Sybil or fairness claim at
 * all, only a fixed traffic shape. Two environment flags must both be set
 * before it will start, so nobody deploys it by accident and nobody can point
 * at a running instance as evidence of the specified store.
 *
 * What it owns that no other file does:
 *
 * - **The chain start is chosen once and then persisted.** The descriptor's
 *   validity interval is anchored to it so a restart re-derives byte-identical
 *   descriptor bytes; every finalized checkpoint names the `descriptorHash` it
 *   was signed under, so a store that re-chose its chain start on each boot
 *   would orphan its own chain and be marked inert by every client.
 * - **The delivery profile is pinned to that chain.** A restart under a
 *   different `P2PARTY_STORE_WINDOW_MS` would measure windows with a different
 *   ruler and sign a chain that disagrees with the one already on disk, so a
 *   mismatch refuses to start rather than equivocate.
 * - **The identity seed is created 0600 or not at all.**
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry.
 */
export {};
