/**
 * The prototype store's durable state, and the in-memory implementation the
 * tests and the E2E's ephemeral mode run on.
 *
 * Everything a store keeps is public geometry: a delivery-profile hash, an
 * ingress window, a size class, an ordinal, and opaque object bytes. There is
 * deliberately no room, peer, member, or account key anywhere in these rows,
 * because a store that cannot name a room cannot be asked which rooms a
 * request belonged to.
 *
 * The port is whole-window replace rather than per-row upsert. A window is the
 * unit the specification makes atomic — allocation ordinals, slot bindings and
 * the finalization that freezes both — so a single `saveWindow` is the
 * smallest transaction that can never publish half a finalization. The SQLite
 * implementation lands in a later task behind this same interface.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry.
 */
import type { PublicAllocationLeaseBodyV1, PublicAllocationLeaseV1, StoreWitnessRecordV1 } from "../storeWire";
import type { PublicBucketV1, PublicChunkV1, PublicStoreCheckpointV1 } from "../../publicWindow";
/** One bound append position: the object and the hash that binds it. */
export interface StoreWindowSlot {
    objectHash: Uint8Array;
    object: Uint8Array;
}
/**
 * One issued lease, kept so an exact duplicate allocation request replays the
 * byte-identical result instead of consuming a second ordinal.
 */
export interface StoreAllocationRecord {
    leaseBody: PublicAllocationLeaseBodyV1;
    lease: PublicAllocationLeaseV1;
    requestHash: Uint8Array;
}
/** The immutable half of a window: signed once, then never re-signed. */
export interface StoreFinalizedWindow {
    chunks: Map<number, PublicChunkV1[]>;
    checkpoint: PublicStoreCheckpointV1;
}
export interface StoreWindowState {
    readonly window: bigint;
    allocations: Map<number, StoreAllocationRecord>;
    /** Keyed `${sizeClass}:${chunkIndex}:${objectIndexWithinChunk}`. */
    slots: Map<string, StoreWindowSlot>;
    finalized: StoreFinalizedWindow | null;
}
export interface StorePersistencePort {
    loadWindow(window: bigint): Promise<StoreWindowState | null>;
    /** Whole-window replace; the implementation must not alias caller buffers. */
    saveWindow(state: StoreWindowState): Promise<void>;
    lastFinalizedWindow(): Promise<bigint | null>;
    loadWitnessRecords(window: bigint): Promise<StoreWitnessRecordV1[]>;
    /** Idempotent on identical canonical bytes. */
    saveWitnessRecord(record: StoreWitnessRecordV1): Promise<void>;
}
export declare const emptyStoreWindowState: (window: bigint) => StoreWindowState;
export declare const copyBytes: (value: Uint8Array) => Uint8Array;
export declare const copyBucket: (bucket: PublicBucketV1) => PublicBucketV1;
export declare const copyLease: (lease: PublicAllocationLeaseV1) => PublicAllocationLeaseV1;
export declare const copyChunk: (chunk: PublicChunkV1) => PublicChunkV1;
export declare const copyCheckpoint: (checkpoint: PublicStoreCheckpointV1) => PublicStoreCheckpointV1;
export declare const copyWitnessRecord: (record: StoreWitnessRecordV1) => StoreWitnessRecordV1;
export declare const copyStoreWindowState: (state: StoreWindowState) => StoreWindowState;
/** Shared with `storeCore.ts`, which keys its witness dedup the same way. */
export declare const hexOf: (value: Uint8Array) => string;
/**
 * Volatile store state for tests and for a store started without a database
 * path. It copies on the way in and on the way out, so the core's mutable
 * working state and the stored state are never the same objects — the same
 * isolation a real transaction gives, at the cost of the copy.
 */
export declare class MemoryStorePersistence implements StorePersistencePort {
    #private;
    loadWindow(window: bigint): Promise<StoreWindowState | null>;
    saveWindow(state: StoreWindowState): Promise<void>;
    lastFinalizedWindow(): Promise<bigint | null>;
    loadWitnessRecords(window: bigint): Promise<StoreWitnessRecordV1[]>;
    saveWitnessRecord(record: StoreWitnessRecordV1): Promise<void>;
}
