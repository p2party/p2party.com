/**
 * The prototype store's window machine: allocation, append, finalization, and
 * the checkpoint chain (design doc §4.3, specification §4.3).
 *
 * Everything this file touches is public geometry — a delivery-profile hash,
 * an ingress window, a size class, an ordinal, and opaque fixed-length bytes.
 * No room, member, peer, invitation or operation value is an input to any
 * method here, and none is derivable from what is stored, which is the whole
 * reason unrelated rooms can share one bucket and cover for each other.
 *
 * Two properties this file is responsible for and that nothing downstream can
 * repair:
 *
 * - A window closes on the clock, not on when `finalizeDue` happened to run.
 *   An append is refused once `IngressWindowStart(w) + chunkFinalizationOffsetMs`
 *   has passed even if the chunks are not signed yet, so a slow finalizer can
 *   never let one client's object into a chunk another client already read a
 *   checkpoint for.
 * - A finalized window is never re-signed. Signing two different chunk bodies
 *   for one index, or two checkpoints for one window, is a permanent fault
 *   proof against the store — so `#finalizeWindow` returns early rather than
 *   recompute, and every mutating entry point is serialized.
 *
 * Transport lives in `storeHttp.ts`; durable rows live behind
 * `StorePersistencePort`. This file knows about neither.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry, and nothing here is a v0.4 release artifact.
 */
import type { LibCrypto } from "../../../cryptography/libcrypto";
import type { PublicBucketV1 } from "../../publicWindow";
import type { StoreDescriptorV1, StoreRouteV1 } from "../../storeDescriptor";
import type { DeliveryProfileV1 } from "../profile";
import type { AllocationTokenIssueRequestV1, AllocationTokenIssueResultV1, PublicAllocationRequestV1, PublicAllocationResultV1, PublicAppendRequestV1, PublicAppendResultV1, PublicChunkReadV1, PublicStoreCheckpointReadV1, PrototypeStoreDescriptorDocumentV1, StoreWitnessRecordV1 } from "../storeWire";
import type { StorePersistencePort } from "./storePersistence";
export declare class StoreRequestError extends Error {
    readonly name: string;
    constructor(message: string);
}
/**
 * A start-up refusal: the options this process was given contradict what it
 * already signed, or could not produce a servable identity.
 *
 * It extends `StoreRequestError` so a caller that catches the family still
 * catches it, but it is a separate name because the two are acted on
 * differently — a request error is one client's 400, and this one means the
 * process must not run at all.
 */
export declare class StoreConfigurationError extends StoreRequestError {
    readonly name = "StoreConfigurationError";
}
export interface StoreClock {
    nowMs(): bigint;
}
/** The one secret a store process holds; the server writes it to a key file. */
export interface StoreIdentityFiles {
    seed: Uint8Array;
}
export interface PrototypeStoreCoreOptions {
    readonly module: LibCrypto;
    readonly seed: Uint8Array;
    readonly profile: DeliveryProfileV1;
    readonly clock: StoreClock;
    readonly persistence: StorePersistencePort;
    readonly chainStartIngressWindow: bigint;
    /** The origin a route advertises, e.g. `"http://127.0.0.1:5910"`. */
    readonly origin: string;
    readonly descriptorValidityMs: bigint;
    /** Test-only: `"withhold"` accepts appends and finalizes them all-dummy. */
    readonly fault?: "withhold" | null;
}
export declare class PrototypeStoreCore {
    #private;
    private constructor();
    get storeId(): Uint8Array;
    get descriptor(): StoreDescriptorV1;
    get descriptorHash(): Uint8Array;
    get routes(): readonly StoreRouteV1[];
    get profileHash(): Uint8Array;
    static create(options: PrototypeStoreCoreOptions): Promise<PrototypeStoreCore>;
    descriptorDocument(): PrototypeStoreDescriptorDocumentV1;
    currentWindow(): bigint;
    /**
     * Open-mode issuance: the store answers every well-formed request with the
     * fixed `issued` shape and 32 zero bytes, and records nothing.
     *
     * Scheme 1 (Blind-RSA Privacy Pass) is not implemented in the prototype, so
     * there is no quota to consume and no replay row to keep — which is exactly
     * why open mode carries no Sybil or fairness claim, only fixed traffic shape.
     */
    issueToken(request: AllocationTokenIssueRequestV1): Promise<AllocationTokenIssueResultV1>;
    allocate(request: PublicAllocationRequestV1): Promise<PublicAllocationResultV1>;
    /**
     * Redeem one admission into one slot, or accept and discard cover.
     *
     * A malformed admission throws `StoreRequestError` (the transport's one
     * constant 400) rather than returning a status: `slot-conflict` is carrier
     * evidence about a slot two clients both claimed, and answering a forged
     * signature with it would manufacture that evidence out of nothing.
     */
    append(request: PublicAppendRequestV1): Promise<PublicAppendResultV1>;
    /**
     * Finalize every window in chain order whose finalization instant has
     * passed, and return the windows this call closed.
     *
     * Chain order is not an optimization: `previousCheckpointHash` must be the
     * exact hash of the immediately preceding window's checkpoint, so a gap can
     * never be filled in later without equivocating.
     */
    finalizeDue(): Promise<readonly bigint[]>;
    readCheckpoint(deliveryProfileHashBytes: Uint8Array, window: bigint): Promise<PublicStoreCheckpointReadV1>;
    readChunk(bucket: PublicBucketV1, chunkIndex: bigint): Promise<PublicChunkReadV1>;
    /**
     * Record one observation of another store's checkpoint.
     *
     * Bounded and idempotent: a witness log is unauthenticated input from a peer
     * store, so it may not grow without limit, and re-offering an observation
     * must not make it look like two.
     */
    addWitness(record: StoreWitnessRecordV1): Promise<void>;
    witnessRecords(window: bigint): Promise<StoreWitnessRecordV1[]>;
}
