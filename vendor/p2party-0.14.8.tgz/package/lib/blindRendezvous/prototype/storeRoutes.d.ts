/**
 * The `prototype-v0` route paths and media types: constants, nothing else.
 *
 * These strings are the one contract the store server and the browser-side
 * client must agree on letter for letter, so they live in a file both can
 * import. They were in `store/storeHttp.ts`, which is where the handler that
 * requires them lives — but that file imports `node:fs` for its body-audit
 * sink, and the client is bundled for the browser, where pulling a Node
 * builtin in is not a size problem but a build failure. Splitting the
 * constants out is what lets the client name the same strings instead of
 * repeating the literals and drifting from them.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry.
 */
export declare const PROTOTYPE_STORE_ROUTES: {
    readonly descriptor: "/.well-known/p2party-store/prototype-v0";
    readonly token: "/p2party/prototype-v0/allocation-token";
    readonly allocation: "/p2party/prototype-v0/allocation";
    readonly append: "/p2party/prototype-v0/append";
    readonly checkpoint: "/p2party/prototype-v0/checkpoint";
    readonly chunk: "/p2party/prototype-v0/chunk";
    readonly witness: "/p2party/prototype-v0/witness";
    readonly health: "/health";
};
/**
 * One media type per wire type, exported so the client adapter names the same
 * strings this handler requires rather than repeating the literals.
 */
export declare const PROTOTYPE_STORE_MEDIA_TYPES: {
    readonly descriptor: string;
    readonly tokenRequest: string;
    readonly tokenResult: string;
    readonly allocationRequest: string;
    readonly allocationResult: string;
    readonly appendRequest: string;
    readonly appendResult: string;
    readonly checkpoint: string;
    readonly chunk: string;
    readonly witnessRecord: string;
    readonly witness: string;
};
