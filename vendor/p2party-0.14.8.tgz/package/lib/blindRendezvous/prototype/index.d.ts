/**
 * The browser composition of the flagged two-store rendezvous prototype: the
 * one call a page makes to go from a room capability to an authenticated,
 * encrypted protocol-v4 session with a peer it has never signalled with.
 *
 * Everything below this file already exists and is tested on its own. What is
 * here is the wiring, and the wiring is where the prototype's claims live or
 * die, so three joins are deliberate rather than incidental:
 *
 *   1. THE WEBRTC PROVIDER IS BUILT LAZILY. `RTCPeerConnection` construction is
 *      role-asymmetric — the initiator must create its data channel before the
 *      offer, the responder must be listening on `ondatachannel` before it sets
 *      the remote description — but which role this endpoint plays is not known
 *      until the driver has seen the peer's presence and compared operation
 *      ids. So the driver is handed a lazy `TransportCandidateProvider` that
 *      builds the real one on the first call, and the call itself names the
 *      role: only a rendezvous initiator ever calls `createOffer`, only a
 *      responder ever calls `acceptOffer`. The role is therefore the driver's,
 *      derived from the driver, never guessed here.
 *   2. THE DTLS CHECK GATES THE SESSION. `verifyCertificates` runs after the
 *      connection reports `connected` and before `createSession`, against the
 *      fingerprints the pair transcript bound. A throw ends the run — not just
 *      the session: the endpoint is stopped, so the peer connection closes and
 *      the carrier schedule is disarmed against every store, and a
 *      `run-stopped` event says so. A tripwire that cannot confirm must abort,
 *      and an aborted edge must not leave a connection and a publisher behind
 *      it. (`"unsupported"` — an engine with no certificate stats — is reported
 *      and allowed, exactly as `webrtcProvider.ts` documents.)
 *   3. NOTHING HERE IS NODE. This module is bundled for the browser with
 *      `bun build --target=browser`, so it may not import `node:*`, the Redux
 *      layer, or anything under `prototype/store/` (which reaches for
 *      `node:fs` and `bun:sqlite`). The store is spoken to over `fetch` and
 *      nothing else.
 *
 * Status: PROTOTYPE. Nothing here is a v0.4 release byte, and the prototype
 * earns no privacy label — see the design doc's "What this is not".
 */
import { CarrierRuntime } from "./carrierRuntime";
import { PairDriver } from "./pairDriver";
import type { StoreTopology } from "./carrierRuntime";
import type { PairDriverPhase } from "./pairDriver";
import type { StoreFaultRecord } from "./storeClient";
export declare class PrototypeRunError extends Error {
    readonly name = "PrototypeRunError";
    constructor(message: string);
}
/** One observable step of a run, in wall-clock time so two pages can be
 * interleaved into one timeline by a harness. */
export interface PrototypeRunEvent {
    readonly atMs: number;
    readonly kind: string;
    readonly detail?: string;
}
export interface PrototypeRunOptions {
    /** The 32-byte room capability both endpoints hold out of band. */
    readonly capability: Uint8Array;
    /**
     * One or more store origins, exactly as the store signed them into its route
     * locator. A store that cannot be reached or cannot be validated is skipped
     * with a `store-unreachable` event; zero usable stores is a failed run.
     */
    readonly storeOrigins: readonly string[];
    readonly wasmBinary: ArrayBuffer;
    readonly rtcConfig: RTCConfiguration;
    /**
     * Rescale the pinned delivery profile to a faster cadence. BOTH endpoints and
     * every store must use the same value: the profile hash is derived from the
     * geometry, and a store serving a different hash serves a different bucket.
     */
    readonly deliveryWindowMs?: bigint;
    readonly onEvent: (event: PrototypeRunEvent) => void;
}
/**
 * The room secrets a harness greps a store's wire log for, so it can state
 * — for that run — that the store never received them.
 *
 * This is the room capability itself and the exact SDP that carries both DTLS
 * fingerprints. The result must never be logged, persisted or sent anywhere.
 */
export interface PrototypeRunAudit {
    readonly capabilityHex: string;
    readonly roomContextIdHex: string;
    readonly stableKeyHex: string;
    readonly sdpLocalUtf8: string | null;
    readonly sdpRemoteUtf8: string | null;
}
export interface PrototypeRun {
    readonly driver: PairDriver;
    readonly runtime: CarrierRuntime;
    /**
     * Resolve when the pair driver reaches `phase`; reject if the edge fails,
     * the run is stopped, or the deadline passes.
     *
     * Phases are role-specific: only a rendezvous initiator ever reaches
     * `hello-sent` and `offer-sent`, only a responder `hello-opened`,
     * `offer-opened` and `answered`. Both reach `handoff`, which is the one a
     * caller that just wants to talk should wait for.
     */
    waitForPhase(phase: PairDriverPhase, timeoutMs: number): Promise<void>;
    sendMessage(bytes: Uint8Array): Promise<void>;
    recvMessage(timeoutMs: number): Promise<Uint8Array>;
    auditSecrets(): PrototypeRunAudit;
    storeTopology(): StoreTopology;
    faults(): readonly StoreFaultRecord[];
    stop(): void;
}
/**
 * Compose one endpoint of the two-store rendezvous and start it.
 *
 * The returned run is live: its schedule is armed, its PRESENCE is published,
 * and it will proceed to a WebRTC session on its own as soon as it observes a
 * peer holding the same capability. The caller only waits and then speaks.
 */
export declare const runBlindRendezvousPrototype: (options: PrototypeRunOptions) => Promise<PrototypeRun>;
