/**
 * The carrier runtime: one fixed schedule per store, a union across both
 * (design doc §4.5), and the cross-store checkpoint gossip of §8.
 *
 * This is the component that turns two independently run stores into a
 * fault-tolerant pair. It publishes every operation to both, scans both, unions
 * the results by the private `OperationId`, and re-queues whatever only one of
 * them carried. Either store may fail, withhold, or lie, and the room still
 * converges as long as one honest store stays reachable.
 *
 * Three properties this file is responsible for:
 *
 * - **The schedule is fixed, not event-driven.** The same number of
 *   same-sized requests leave for every store in every window whether the
 *   outbox is empty or full: one token, one allocation, one append per
 *   `appendSchedule` entry, and one read — thirteen requests, always. The
 *   witness pair is the one exception: it is conditional on the other
 *   store's scan, not fixed (design doc §3a item 14). A real object simply
 *   takes a dummy's place. A store therefore cannot learn from traffic shape
 *   whether this client had anything to say, and a missed event stays
 *   missed — retrying inside a window would make the shape event-driven
 *   again, and retrying at the surviving store after an omission would be an
 *   active cross-store tagging channel.
 * - **The two stores never receive the same bytes.** Each publication is
 *   sealed separately under that store's `carrierContextId` with a fresh
 *   24-byte nonce, so one store cannot recognize the other's copy of an
 *   operation, and neither can a party watching both.
 * - **Nothing room-derived leaves.** Everything this file hands a store is
 *   either an opaque fixed-length object or public geometry. The room root,
 *   the operations, and the private `OperationId` union all stay here.
 *
 * And one it is responsible for NOT doing: every store is scheduled at the
 * same offsets, so the two stores' copies of one operation leave in the same
 * millisecond (design doc §3a item 1, the prototype's worst disclosed leak).
 * `#eventsForWindow` carries the measured reason a per-store phase offset was
 * rejected rather than added.
 *
 * Browser-safe by construction: like `storeClient.ts` it imports no `store/`
 * module (those reach for `node:fs` and `bun:sqlite`) and nothing Node-only.
 * It owns no wall clock either — the clock and the timer pair are injected, so
 * a harness or a test drives the schedule deterministically.
 *
 * Status: PROTOTYPE. Nothing here is a v0.4 release byte.
 */
import type { LibCrypto } from "../../cryptography/libcrypto";
import type { OuterValidatedIdentifiedOperationV1 } from "../coreReduce";
import type { AuthenticatedRoomOperationV1, OperationValidationContext } from "../operation";
import type { DeliveryProfileV1 } from "./profile";
import type { PrototypeStoreClient, StoreFaultRecord } from "./storeClient";
import type { ServiceWorkKindV1 } from "./workKinds";
/** Re-exported so one import gives a caller the runtime and the work vocabulary
 * it must label a publication with. The definition stays in `workKinds.ts`. */
export type { ServiceWorkKindV1 } from "./workKinds";
/**
 * What this client can currently say about carriage, from what it observed
 * itself and nothing else.
 *
 * It is deliberately not a trust or independence label: two stores on one
 * laptop produce `multi-store-union` exactly like two operators in two
 * jurisdictions would. It says how many carriers answered this client's last
 * read, and no more.
 */
export type StoreTopology = "multi-store-union" | "single-carrier-dependent" | "no-usable-carrier";
export interface CarrierEvent {
    readonly kind: "allocated" | "append" | "scan" | "operations" | "fault" | "missed";
    readonly storeIdHex?: string;
    readonly window: bigint;
    readonly detail?: string;
    readonly count?: number;
}
/**
 * Whatever the injected `setTimeout` returned, handed back only to the
 * injected `clearTimeout`.
 *
 * Deliberately not `ReturnType<typeof setTimeout>`: that is `number` in a
 * browser and `NodeJS.Timeout` under `@types/node`, and this file is bundled
 * for both. It is `unknown` and not `{}` because `clearTimeout`'s overloads
 * accept `undefined`, which `{}` excludes — the real global would then not be
 * assignable to `CarrierTimers`, and every production caller would need a cast.
 */
export type CarrierTimerHandle = unknown;
/**
 * The timer pair, as call signatures rather than `typeof setTimeout`.
 *
 * The global carries engine-specific extras (`__promisify__` under
 * `@types/node`) that a substitute scheduler cannot supply, and a caller that
 * cannot substitute its own timers cannot drive this schedule
 * deterministically. `{ setTimeout, clearTimeout }` — the real globals — is
 * assignable to this; the test file asserts that with the compiler.
 */
export interface CarrierTimers {
    setTimeout(callback: () => void, delayMs: number): CarrierTimerHandle;
    clearTimeout(handle: CarrierTimerHandle): void;
}
export interface CarrierRuntimeOptions {
    readonly module: LibCrypto;
    readonly roomRoot: Uint8Array;
    readonly profile: DeliveryProfileV1;
    readonly profileHash: Uint8Array;
    readonly stores: readonly PrototypeStoreClient[];
    readonly validationContextAt: (referenceLogicalWindow: bigint) => OperationValidationContext;
    readonly logicalWindowMs: bigint;
    readonly clock: {
        nowMs(): bigint;
    };
    readonly timers: CarrierTimers;
    readonly onOperations: (fresh: readonly OuterValidatedIdentifiedOperationV1[]) => void | Promise<void>;
    readonly onEvent?: (event: CarrierEvent) => void;
}
export interface CarrierCounters {
    /** Scheduled appends that carried an operation. */
    readonly appendsReal: number;
    /** Scheduled appends that carried cover. Their sum is the fixed schedule. */
    readonly appendsDummy: number;
    /** `scanWindow` calls, so one read of two stores counts two. */
    readonly scans: number;
    /** Distinct operations handed to `onOperations`, never redeliveries. */
    readonly operationsSeen: number;
    /** `(operation, store)` pairs queued for replication. */
    readonly backfills: number;
}
export declare class CarrierRuntimeError extends Error {
    readonly name = "CarrierRuntimeError";
    constructor(message: string);
}
export declare class CarrierRuntime {
    #private;
    constructor(options: CarrierRuntimeOptions);
    /**
     * Arm every store's schedule from the current instant.
     *
     * A runtime that starts after this window's allocation instant has no lease
     * for the window it is in: its appends still go out, on time and at full
     * size, as unallocated cover, and one immediate allocation is issued for the
     * next window so the schedule is admitted from there on. Suppressing them
     * instead would make the very first window of a session distinguishable.
     */
    start(): void;
    /** Disarm every schedule and wipe the allocation secrets still held. */
    stop(): void;
    /**
     * Resolve once every handler this runtime has already started has settled.
     *
     * The scheduler is deliberately fire-and-forget — one slow store must not
     * delay another store's next event — so a caller that drives the clock
     * itself needs one way to await the work a tick released. It starts nothing
     * and arms nothing.
     *
     * Handlers start no handlers, so one pass settles everything. Returning
     * quietly with work still in flight would make a harness that trusts this as
     * its synchronisation point flake for no visible reason, so it throws.
     */
    drain(): Promise<void>;
    /**
     * Queue one operation for every store this runtime carries.
     *
     * Nothing is sent here. The operation waits for the next scheduled append of
     * its service role and size class, which is what makes a publication look
     * exactly like silence from a store's side.
     */
    publish(operation: AuthenticatedRoomOperationV1, workKind: ServiceWorkKindV1): void;
    /**
     * Counted from this client's own last completed read and nothing else.
     *
     * It is never evidence that the stores are independently operated, and it
     * never becomes one: a store's own claims about other stores are not read.
     */
    get storeTopology(): StoreTopology;
    /** Every store's own faults, plus the cross-store hints only this layer can
     * see because only it holds both stores' verified checkpoint hashes. */
    get faults(): readonly StoreFaultRecord[];
    get counters(): CarrierCounters;
}
