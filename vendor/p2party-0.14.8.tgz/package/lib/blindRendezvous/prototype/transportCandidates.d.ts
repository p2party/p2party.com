/**
 * Pure transport-candidate helpers for the flagged two-store prototype.
 *
 * Section 4.12 keeps SDP inside the pair-encrypted, class-padded payload and
 * puts one strict parser in charge of bounds and RFC 8122 syntax: 1 through
 * 32,768 exact UTF-8 bytes with exactly one SHA-256 DTLS fingerprint, and no
 * semantic parse/reserialize "canonicalization" of the bytes. An offer holds
 * one to three candidates sorted by unique `TransportOfferCandidateId`, with
 * exactly one mandatory `operation-carrier`, at most one `webrtc-complete`,
 * and at most one `registered-local-link`.
 *
 * Nothing here touches a browser API, a peer connection, or an adapter
 * registry: the prototype offers only the mandatory carrier plus WebRTC, and
 * `registered-local-link` is deferred (Section 4.12 permits an offer without
 * one). Every check runs before any candidate reaches a transport.
 *
 * Status: PROTOTYPE. Nothing here is a v0.4 release byte.
 */
import type { PairTransportCandidateV1 } from "../pairPlaintext";
export declare class TransportCandidateError extends Error {
    readonly name = "TransportCandidateError";
    constructor(message: string);
}
/**
 * Bytewise ordering shared by candidate sorting and the pair driver.
 *
 * @internal
 */
export declare const compareBytes: (left: Uint8Array, right: Uint8Array) => number;
/** Decode exact SDP bytes without altering them. Invalid UTF-8 fails closed. */
export declare const decodeSdpUtf8: (sdp: Uint8Array) => string;
/**
 * The one strict parser: bounds, UTF-8, and exactly one SHA-256 fingerprint.
 *
 * Zero, multiple, or non-SHA-256 fingerprints fail here, before any handoff.
 */
export declare const validateWebRtcSdp: (sdp: Uint8Array) => {
    readonly fingerprint: Uint8Array;
};
/**
 * The prototype's complete offer set: the mandatory operation carrier plus the
 * WebRTC candidate, sorted by `TransportOfferCandidateId`.
 */
export declare const buildOfferCandidates: (sdp: Uint8Array) => Promise<readonly PairTransportCandidateV1[]>;
/**
 * Validate a received offer's composition and return the WebRTC candidate.
 *
 * Selection happens by exact candidate ID, so the caller can echo that ID in
 * its answer. Unknown kinds, a missing or duplicated ID, an out-of-order set,
 * or a noncanonical candidate fails before any adapter sees the bytes.
 */
export declare const selectWebRtcCandidate: (candidates: readonly PairTransportCandidateV1[]) => Promise<{
    readonly id: Uint8Array;
    readonly sdp: Uint8Array;
}>;
