/**
 * The browser-side client of one prototype store (design doc §4.4, §8).
 *
 * This is the verifying half of the carrier. The store is assumed hostile: it
 * may withhold an object it signed a receipt for, serve one window to this
 * client and another to somebody else, or answer with bytes that decode but
 * commit to nothing. Every claim it makes therefore arrives signed, and this
 * file checks each signature against the key pinned at `connect` before any
 * field of the value is read.
 *
 * Three properties this adapter is responsible for:
 *
 * - **Nothing room-derived leaves.** Every request names a delivery-profile
 *   hash, an ingress window, a size class, two ordinals, an ephemeral
 *   allocation key and opaque fixed-length bytes. There is no room, member,
 *   peer or invitation value in any path or body, which is what lets unrelated
 *   rooms share a bucket and cover for each other.
 * - **A scan never throws, and never waits forever.** A store that is
 *   unreachable, malformed, or lying must degrade one event for one store, not
 *   abort the caller's whole window. Faults are recorded and the scan answers
 *   `unreachable`. Every request also carries a deadline (see
 *   `requestDeadlineMs`), so a store that accepts the connection and then
 *   answers nothing degrades exactly the way one that refused the connection
 *   does — otherwise it would hold the carrier runtime's union open and stall
 *   the *other* store's objects with its own.
 * - **Blame is separated from absence.** `chain-fault`, `root-mismatch` and
 *   `custody-breach` mark the store **inert** — its objects are still returned
 *   so the caller can union every observed branch, but it is out of the
 *   availability set. An unreachable route, a gap in the observed chain, and a
 *   window below the chain start are none of those and mark nothing.
 *
 * Browser-safe by construction: it imports no `store/` module (those reach for
 * `node:fs` and `bun:sqlite`) and nothing Node-only. The route strings come
 * from `storeRoutes.ts`, which both halves share.
 *
 * Status: PROTOTYPE. This is the `prototype-v0` route family, not a frozen
 * registry, and nothing here is a v0.4 release artifact.
 */
import type { LibCrypto } from "../../cryptography/libcrypto";
import type { StoreDescriptorV1 } from "../storeDescriptor";
import type { DeliveryProfileV1 } from "./profile";
import type { PublicAllocationLeaseV1, PublicAppendAdmissionV1, PublicAppendResultV1, StoreWitnessRecordV1 } from "./storeWire";
export interface StoreClientOptions {
    readonly origin: string;
    readonly profile: DeliveryProfileV1;
    readonly profileHash: Uint8Array;
    readonly module: LibCrypto;
    /** Injected so a test, a worker or a proxy can supply its own transport. */
    readonly fetch?: typeof fetch;
    readonly nowMs: () => bigint;
}
/**
 * What a scan or request found wrong with one store's answer.
 *
 * `unreachable` is a transport failure: a fetch that was rejected outright, a
 * request that outlived its own deadline (`requestDeadlineMs`), a non-200
 * status, a missing or wrong `x-p2party-store` header, or bytes that
 * do not even decode as the expected canonical type. None of these yields a
 * signature this client could check, so none of them says anything about
 * whether the store is honest — only that this attempt produced no usable
 * answer, which a store that is merely switched off produces exactly as
 * reliably as one that is actively cheating. It is therefore never grounds
 * for `inert`: the store may come back.
 *
 * `signature-invalid` is reserved for an answer this client *could* judge:
 * bytes that decoded as the expected type, carrying a signature, which either
 * does not verify under the pinned descriptor key or verifies but names the
 * wrong store, profile, window or version — a well-formed, signed answer to a
 * different question than the one this client asked. A response that decodes
 * and verifies but names the wrong coordinates is deliberately kept here
 * rather than folded into `unreachable`: the store was reachable and spent a
 * real signature over real bytes, which is closer to "signed something
 * false" than to absence, even when the mistake reads as a mismatch rather
 * than an outright forgery. What must never happen is the reverse — a store
 * that said nothing at all ending up in the same bucket as one that signed a
 * lie.
 */
export type StoreFaultKind = "unreachable" | "descriptor-invalid" | "signature-invalid" | "chain-fault" | "root-mismatch" | "custody-breach" | "checkpoint-split-view-hint";
export interface StoreFaultRecord {
    readonly storeIdHex: string;
    readonly kind: StoreFaultKind;
    readonly window: bigint | null;
    readonly detail: string;
}
/**
 * What one fixed scan of one window came back with.
 *
 * `status` is deliberately **not** the `StoreFaultKind` taxonomy, and the two
 * are not in one-to-one correspondence. `unreachable` here means only "this
 * scan produced no usable window", and it is what a switched-off store, a
 * stalled store, a malformed answer *and* a proved `root-mismatch` breach all
 * come back as — see the `#breach` call in `scanWindow`. The `f1f5aa4` split
 * between absence and blame lives in `StoreFaultKind` and in `inert`, which is
 * where every consumer reads it: a breach records `root-mismatch` and sets
 * `inert` permanently, while absence records `unreachable` and sets nothing.
 * Nothing in the tree branches on this field to decide blame — the carrier
 * runtime uses it only as `status === "finalized"` to count usable carriers
 * and to gate a witness post — so a fourth status would add a value with no
 * reader. Recorded here rather than fixed, because a taxonomy documented in
 * one place and contradicted in another is the defect; if a consumer ever does
 * need to tell a breached window from an absent one, it should read `inert`
 * and the fault list, not this string.
 */
export interface WindowScan {
    readonly window: bigint;
    readonly status: "finalized" | "not-final" | "out-of-range" | "unreachable";
    readonly objects: readonly Uint8Array[];
    readonly checkpointHash: Uint8Array | null;
}
/**
 * What this client appended and the store signed for, kept until the window it
 * names is scanned. It is the whole input to the custody check: without the
 * lease's ordinal there is no slot to look in, and without `objectHash` there
 * is nothing to compare the slot's contents against.
 */
export interface AppendReceipt {
    readonly window: bigint;
    readonly sizeClass: number;
    readonly lease: PublicAllocationLeaseV1;
    readonly objectOrdinal: number;
    readonly objectHash: Uint8Array;
    readonly result: PublicAppendResultV1;
}
export declare class StoreClientError extends Error {
    readonly name = "StoreClientError";
    constructor(message: string);
}
/**
 * Sign one admission over the lease this store issued.
 *
 * The transcript binds the store, profile, window, size class, ordinal and the
 * exact object bytes at once, so an admission cannot be replayed into another
 * slot of the same allocation or against different bytes. The secret key is
 * the caller's ephemeral allocation key and is neither copied nor retained
 * here.
 */
export declare const buildAppendAdmission: (lease: PublicAllocationLeaseV1, allocationSecretKey: Uint8Array, sizeClass: number, objectOrdinal: number, exactFixedObject: Uint8Array, module: LibCrypto) => Promise<PublicAppendAdmissionV1>;
export declare class PrototypeStoreClient {
    #private;
    /**
     * Public identity, as the design's adapter shape requires it. These are
     * copies: every security decision this file makes uses the private key and
     * hashes below, so a caller that mutates one of them changes what it reads,
     * never what is verified.
     */
    readonly storeId: Uint8Array;
    readonly storeIdHex: string;
    readonly descriptor: StoreDescriptorV1;
    readonly carrierContextId: Uint8Array;
    readonly origin: string;
    private constructor();
    /**
     * Fetch the descriptor, validate it, and pin the identity every later answer
     * is checked against.
     *
     * This is the one place that throws: a client that could not establish whom
     * it is talking to has no store, and returning a half-usable object would
     * push that decision to a caller with less context. Everything after this
     * point degrades instead.
     *
     * `nowMs` is read here and only here. The descriptor and route leases are
     * about now, but every later check is anchored to the instant the window it
     * concerns was finalized — historical evidence must not change meaning
     * because the wall clock moved.
     */
    static connect(options: StoreClientOptions): Promise<PrototypeStoreClient>;
    /** True once this store has been caught in a fault no absence explains. */
    get inert(): boolean;
    get faults(): readonly StoreFaultRecord[];
    /**
     * Ask for an allocation token for `targetWindow`.
     *
     * Open mode has no quota to consume, so the answer carries no authority; it
     * is requested and verified anyway because the traffic shape is part of the
     * profile — a client that skipped it would be distinguishable from one that
     * did not.
     */
    issueToken(targetWindow: bigint): Promise<boolean>;
    /**
     * Redeem a token for a lease over `targetWindow`.
     *
     * Only the public half of `allocationKey` is sent; the secret stays with the
     * caller, which is what makes the lease usable by nobody else.
     */
    allocate(targetWindow: bigint, allocationKey: {
        publicKey: Uint8Array;
        secretKey: Uint8Array;
    }): Promise<PublicAllocationLeaseV1 | null>;
    /**
     * Publish one fixed-size object into `(window, sizeClass)`.
     *
     * `admission === null` is a deliberate unallocated cover append: the store
     * accepts it, answers the one fixed status, and discards it.
     */
    append(window: bigint, sizeClass: number, exactFixedObject: Uint8Array, admission: PublicAppendAdmissionV1 | null): Promise<PublicAppendResultV1 | null>;
    /**
     * Remember what the store promised, until the window it names is scanned.
     *
     * Validated eagerly, and each coordinate against the half it comes from: the
     * object ordinal is the caller's, so an out-of-range one is a caller bug and
     * says so; the allocation ordinal is the store's, and `allocate` has already
     * refused it if it named no slot — the check here is the belt to that brace,
     * for a lease that reached this client by some other path. Either way the
     * bounds are decided before `appendSlotCoordinates`, which throws, and a
     * throw inside a scan would turn a bad coordinate into a fault report
     * against a store that did nothing wrong.
     */
    recordReceipt(receipt: AppendReceipt): void;
    /**
     * Read one window whole and decide what it proves.
     *
     * The checkpoint and every chunk are issued together and only then awaited:
     * the profile's fixed geometry is the point of the scan, and one round trip
     * per chunk would both leak the reader's pace and miss the window.
     */
    scanWindow(window: bigint): Promise<WindowScan>;
    /** The verified checkpoint hash for a window this client scanned. */
    checkpointHashFor(window: bigint): Uint8Array | null;
    /**
     * Offer this store one observation of another store's checkpoint.
     *
     * Certificate-Transparency-style gossip with the other store as the carrier
     * and no witness network. Unlike every other route here, this one is not a
     * fixed per-window POST: the caller invokes it only when its scan of the
     * *other* store came back `finalized` and neither store is inert, which
     * makes it the cross-store status oracle disclosed in design doc §3a item
     * 14.
     */
    postWitness(record: StoreWitnessRecordV1): Promise<boolean>;
    /**
     * Read the observations this store holds for `window`.
     *
     * Witness records are unauthenticated peer input and are returned as data,
     * never as a claim. The one thing this client can decide locally is whether
     * a record about *itself* contradicts the checkpoint it was shown: that is a
     * split-view hint, not a proof — the specification's conflict proof needs
     * two checkpoints signed by the store — so it is logged and does not make
     * the store inert. Comparing records about *other* stores is the carrier
     * runtime's job, since only it holds both stores' verified hashes.
     */
    readWitnesses(window: bigint): Promise<readonly StoreWitnessRecordV1[]>;
}
