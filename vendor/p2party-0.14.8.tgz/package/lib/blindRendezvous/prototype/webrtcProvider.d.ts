/**
 * Real WebRTC transport for the flagged two-store rendezvous prototype.
 *
 * This is the piece that turns the pair driver's abstract offer/answer exchange
 * (`TransportCandidateProvider`, `pairDriver.ts`) into an actual
 * `RTCPeerConnection` carrying one bootstrap `RTCDataChannel`, and then hands
 * that channel to the store-free protocol-v4 session API as a
 * `HandshakeTransport`.
 *
 * BROWSER ONLY. Nothing here may import the Redux store, `src/api/**`,
 * `src/reducers/**` or anything under `prototype/store/`: the prototype's
 * browser bundle is built from this module and must stay free of the app's
 * state machinery. `verifyCertificates` therefore *copies* the certificate
 * comparison of `src/handlers/handleHandshake.ts` (`verifyDtlsFingerprints`)
 * rather than importing it — that function reaches the store through its
 * `IRTCPeerConnection` wrappers. The only import in this file is a type, which
 * `verbatimModuleSyntax` erases entirely at build time.
 *
 * Three properties of this file are load-bearing, and each one has cost a
 * debugging session before:
 *
 *   1. THE INITIATOR CREATES ITS DATA CHANNEL BEFORE THE OFFER. An SDP offer
 *      produced by a peer connection with no data channel negotiates no SCTP
 *      transport at all, so no channel can ever open afterwards — the peers
 *      connect at ICE/DTLS level and then sit there forever. The channel is
 *      therefore created in the constructor, before `createOffer()` can be
 *      called (see `docs/e2e/README.md`).
 *   2. COMPLETE GATHERING, NEVER TRICKLE. The blind profile carries one SDP
 *      blob inside a pair-encrypted, class-padded operation; there is no
 *      channel to trickle candidates over afterwards. Both `createOffer` and
 *      `acceptOffer` therefore wait for `iceGatheringState === "complete"`
 *      before reading the local description.
 *   3. EXACT BYTES. The SDP bytes returned here are what the peer signs over
 *      inside the pair transcript, and the DTLS fingerprint parsed out of them
 *      is bound into the protocol-v4 channel input. They are the UTF-8 encoding
 *      of `localDescription.sdp` verbatim — never re-serialized, never
 *      normalized — and remote SDP is decoded with a fatal UTF-8 decoder and
 *      handed to `setRemoteDescription` as-is.
 *
 * Status: PROTOTYPE. Nothing here is a v0.4 release byte.
 */
import type { TransportCandidateProvider } from "./pairDriver";
import type { HandshakeTransport } from "../../session";
/** Every failure raised by this module, so callers can tell it apart. */
export declare class WebRtcProviderError extends Error {
    constructor(message: string);
}
export interface WebRtcProviderOptions {
    readonly rtcConfig: RTCConfiguration;
    readonly role: "initiator" | "responder";
    /** Complete-ICE-gathering deadline; defaults to 15,000 ms. */
    readonly gatheringTimeoutMs?: number;
}
/**
 * One `RTCPeerConnection` plus its bootstrap data channel, driven by the pair
 * driver's complete-ICE offer/answer contract.
 */
export declare class WebRtcCandidateProvider implements TransportCandidateProvider {
    #private;
    readonly peerConnection: RTCPeerConnection;
    readonly role: "initiator" | "responder";
    constructor(options: WebRtcProviderOptions);
    /**
     * The one bootstrap data channel of this edge: for the initiator the channel
     * it created in the constructor (resolved immediately, before it opens); for
     * the responder the channel `ondatachannel` delivers. Rejects if the provider
     * is closed before a channel exists. The caller waits for `readyState`.
     */
    channel(): Promise<RTCDataChannel>;
    /** Complete-ICE offer, bootstrap data channel already created. */
    createOffer(): Promise<Uint8Array>;
    /** Set the remote offer and return the complete-ICE answer. */
    acceptOffer(remoteSdp: Uint8Array): Promise<Uint8Array>;
    /** Set the remote answer; completes the initiator's negotiation. */
    acceptAnswer(remoteSdp: Uint8Array): Promise<void>;
    /**
     * Post-connect DTLS binding check, copied in substance from
     * `handleHandshake.ts`'s `verifyDtlsFingerprints`: the fingerprints the two
     * SDP blobs declared (and that the handshake transcript is bound to) must
     * equal the live certificates `getStats()` reports. A disagreement means the
     * DTLS transport terminates on a different certificate than the one that was
     * authenticated — i.e. someone rewrote SDP after the transcript was bound —
     * so it throws.
     *
     * Returns `"unsupported"` (not a failure) when the engine reports neither a
     * `transport` stat nor any `certificate` rows: that is Firefox, which
     * implements neither, and treating it as a mismatch would make every
     * rendezvous fail there. What survives without the check is what the
     * transcript already binds — both SDP fingerprints — so an attacker who
     * rewrites SDP still produces a transcript both peers reject. Where the
     * engine can answer, a disagreement stays fatal, and so does a certificate
     * that cannot be located at all: a tripwire that cannot confirm must abort.
     */
    verifyCertificates(localFingerprint: Uint8Array, remoteFingerprint: Uint8Array): Promise<"verified" | "unsupported">;
    /** Idempotent teardown: unblocks every waiter, then closes channel and pc. */
    close(): void;
}
/**
 * The two logical streams a rendezvous edge carries over its one data channel:
 * the protocol-v4 handshake / sparse-PQ control lane (`send` / `recv`, the
 * `HandshakeTransport` the session API consumes) and the application lane
 * (`sendApp` / `recvApp`) that carries encrypted chunk frames.
 */
export interface DataChannelTransport extends HandshakeTransport {
    sendApp(bytes: Uint8Array): void;
    recvApp(): Promise<Uint8Array>;
    /** Rejects every pending receive and closes the underlying channel. */
    close(): void;
}
/**
 * Frame the two lanes over one `RTCDataChannel` as `[tag(1)][payload]`, the
 * same framing `docs/e2e/webrtc-e2e/entry.ts` proved against real Chromium.
 *
 * Anything that arrives with no waiter is queued, and waiters are served FIFO.
 * A close — of the channel, or through this transport's own `close()` — rejects
 * every pending receive with a `WebRtcProviderError` instead of leaving it
 * pending, so a handshake whose peer went away surfaces as a failure rather
 * than hanging forever. Bytes that already arrived are still drained after a
 * close; only the waiting stops.
 */
export declare const dataChannelTransport: (channel: RTCDataChannel) => DataChannelTransport;
