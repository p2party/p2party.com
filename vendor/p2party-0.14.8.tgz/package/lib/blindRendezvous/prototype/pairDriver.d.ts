/**
 * Pair driver for the flagged two-store prototype.
 *
 * This module is the first caller that runs the pair-bootstrap cryptography
 * end to end: PRESENCE, the two-flight HPKE identity bootstrap
 * (`IDENTITY_HELLO` / `IDENTITY_ACCEPT`), the derived `EstablishedPairRoot`,
 * and the established-flight `TRANSPORT_OFFER` / `TRANSPORT_ANSWER` exchange
 * that carries SDP inside a pair-encrypted, class-padded pair operation. It
 * ends at the handoff facts a protocol-v4 handshake needs — it opens no
 * `RTCPeerConnection`, performs no I/O, and persists nothing.
 *
 * WHAT THIS DELIBERATELY BYPASSES. The prototype runs an explicit OPEN policy:
 * any capability holder is admitted. It therefore does not consult the
 * reservation / trial / admission kernel (`identityHelloTrial.ts`,
 * `identityHelloOpen.ts`, `identityHelloAdmission.ts`), whose exported surface
 * still terminates at `policy-allowed-pre-topology` and never releases
 * HelloRoot. Instead `openIdentityHelloOpenPolicyPrototype` below calls
 * `openPairBootstrapV1` directly and replicates, check for check, the closed
 * identity gate that `identityHelloOpen.ts:567-742` performs inside its
 * `validateAuthenticatedPlaintext` callback. What it drops is the durable
 * pair-open budget, the one-use reservation capability, the fenced historical
 * presence-evidence view, and `Admit()` — not one identity check. This is the
 * honest equivalent of the spec's `eligibility="open"` room with no deny-list
 * (design doc §2, §4.6), and it is not conformant v0.4.
 *
 * Status: PROTOTYPE. Nothing here is a v0.4 release byte.
 */
import type { ActivePairOperationCandidateSnapshotV1, OuterValidatedIdentifiedOperationV1 } from "../coreReduce";
import type { AuthenticatedRoomOperationV1, OperationValidationContext } from "../operation";
import type { PresenceV1 } from "../operationPayload";
import type { PairIdentityHelloV1 } from "../pairPlaintext";
import type { RoomPolicyV4 } from "../roomPolicyV4";
import type { LibCrypto } from "../../cryptography/libcrypto";
import type { RoomPqMode } from "../../roomPolicy";
import type { ServiceWorkKindV1 } from "./workKinds";
export declare class PairDriverError extends Error {
    readonly name = "PairDriverError";
    constructor(message: string);
}
/**
 * The endpoint side of a complete-ICE WebRTC negotiation.
 *
 * Every method returns or consumes the exact UTF-8 SDP bytes the engine
 * produced; Section 4.12 forbids any parse-and-reserialize between them.
 */
export interface TransportCandidateProvider {
    /** Complete-ICE offer, bootstrap data channel already created. */
    createOffer(): Promise<Uint8Array>;
    /** Set the remote offer and return the complete-ICE answer. */
    acceptOffer(remoteSdp: Uint8Array): Promise<Uint8Array>;
    acceptAnswer(remoteSdp: Uint8Array): Promise<void>;
}
export type PairDriverPhase = "idle" | "presence-published" | "peer-observed" | "hello-sent" | "hello-opened" | "accepted" | "offer-sent" | "offer-opened" | "answered" | "handoff" | "failed";
export type PairEndpointRole = "initiator" | "responder";
/** Everything a protocol-v4 handshake needs once the pair exchange completes. */
export interface HandoffFacts {
    readonly rendezvousChannelId: Uint8Array;
    readonly localFingerprint: Uint8Array;
    readonly remoteFingerprint: Uint8Array;
    readonly sessionRole: PairEndpointRole;
    readonly rendezvousRole: PairEndpointRole;
    readonly peerStableEd25519PublicKey: Uint8Array;
    readonly stableEdgeId: Uint8Array;
}
export interface PairDriverIdentity {
    readonly ed25519PublicKey: Uint8Array;
    readonly ed25519SecretKey: Uint8Array;
    readonly x25519PublicKey: Uint8Array;
    readonly x25519CrossSignature: Uint8Array;
}
export interface PairDriverOptions {
    readonly module: LibCrypto;
    readonly capability: Uint8Array;
    readonly roomPolicy?: RoomPolicyV4;
    readonly identity: PairDriverIdentity;
    readonly publish: (operation: AuthenticatedRoomOperationV1, workKind: ServiceWorkKindV1) => void;
    readonly transport: TransportCandidateProvider;
    readonly clock: {
        nowMs(): bigint;
    };
    readonly random: (length: number) => Uint8Array;
    readonly onPhase?: (phase: PairDriverPhase, detail?: string) => void;
    /**
     * Publish a PRESENCE whose `stableOwnershipSignature` is not the stable
     * key's, so this prototype's own tests can prove that both identity
     * validators verify that proof.
     *
     * The defect cannot be injected from outside the driver: both endpoints must
     * agree on the exact presence operation IDs before either identity flight
     * validates, so a presence forged by a third party is rejected on the
     * endpoint tuple long before the ownership proof is reached. Never set this
     * in a real room.
     *
     * @internal
     */
    readonly forgePresenceOwnershipForPrototypeTests?: boolean;
}
interface ObservedPresence {
    readonly operationId: Uint8Array;
    readonly operation: AuthenticatedRoomOperationV1;
    readonly presence: PresenceV1;
}
export interface IdentityHelloOpenPolicyPrototypeOptions {
    readonly module: LibCrypto;
    readonly roomPqMode: RoomPqMode;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly policyHash: Uint8Array;
    readonly roomRoot: Uint8Array;
    readonly recipientHybridKemSecretKey: Uint8Array;
    readonly localPresenceOperationId: Uint8Array;
    readonly localStableEd25519PublicKey: Uint8Array;
    readonly remotePresence: ObservedPresence;
    readonly expectedPairEdgeId: Uint8Array;
    readonly candidate: ActivePairOperationCandidateSnapshotV1;
}
export interface IdentityHelloOpenPolicyPrototypeResultV1 {
    readonly bootstrapRoot: Uint8Array;
    readonly hello: PairIdentityHelloV1;
}
/**
 * Open one candidate `IDENTITY_HELLO` under the prototype's explicit OPEN
 * admission policy.
 *
 * `null` means "not this candidate" (routing tag, KEM, or AEAD mismatch) and
 * must be ignored. A throw means authenticated bytes failed the closed
 * identity gate and the caller must account it as a rejected pair attempt.
 *
 * The validator below is the same list `identityHelloOpen.ts:567-742` runs.
 * What it does NOT do is reserve pair-open budget, consume a one-use
 * reservation capability, resolve remote presence through a fenced historical
 * evidence view, or call `Admit()`: this prototype admits every capability
 * holder by construction and says so (see the module docblock).
 */
export declare const openIdentityHelloOpenPolicyPrototype: (options: IdentityHelloOpenPolicyPrototypeOptions) => Promise<IdentityHelloOpenPolicyPrototypeResultV1 | null>;
/**
 * One room, one local presence, one pair edge, driven entirely from the
 * operations a carrier hands back.
 *
 * The driver is asynchronous but not reentrant: `start()` and `ingest()` must
 * be awaited in sequence. Duplicate delivery is free — operations are keyed by
 * `OperationId` and each pair operation is handled at most once.
 */
export declare class PairDriver {
    readonly roomPolicy: RoomPolicyV4;
    private readonly module;
    private readonly capability;
    private readonly identity;
    private readonly publish;
    private readonly transport;
    private readonly clock;
    private readonly random;
    private readonly onPhase;
    private readonly forgePresenceOwnership;
    private initialization;
    private baseContext;
    private cachedContext;
    private cachedContextWindow;
    private roomContextIdBytes;
    private roomRootBytes;
    private policyHashBytes;
    private roomPqModeValue;
    private authorPublicKey;
    private authorSecretKey;
    private authorChainWindow;
    private authorSequence;
    private lastOwnOperationId;
    private stableCommitment;
    private receiverSecretKey;
    private localPresence;
    private remotePresence;
    private readonly knownOperations;
    private readonly ownOperationIds;
    private readonly handledPairOperationIds;
    private ledger;
    private rendezvousRole;
    private endpoints;
    private pairEdge;
    private helloRoot;
    private acceptRoot;
    private establishedRoot;
    private responseSecretKey;
    private helloResponsePublicKey;
    private helloOperationId;
    private acceptOperationId;
    private offerOperationId;
    private answerOperationId;
    private helloLogicalWindow;
    private confirmedTranscriptId;
    private peerStableKey;
    private offerWebRtcCandidateId;
    private localSdp;
    private remoteSdp;
    private phaseValue;
    private handoffFacts;
    constructor(options: PairDriverOptions);
    get phase(): PairDriverPhase;
    get handoff(): HandoffFacts | null;
    get roomContextId(): Uint8Array;
    /** RoomRoot: the carrier-envelope and HELLO PSK secret for this room. */
    get roomRoot(): Uint8Array;
    get policyHash(): Uint8Array;
    /** The cached room context rebound to one explicit reference window. */
    validationContextAt(referenceLogicalWindow: bigint): OperationValidationContext;
    /** Publish this endpoint's PRESENCE for the current logical window. */
    start(): Promise<void>;
    /**
     * Fold one batch of carrier-delivered operations into the room, then drive
     * whatever pair step that makes possible.
     */
    ingest(operations: readonly OuterValidatedIdentifiedOperationV1[]): Promise<void>;
    /**
     * Byte facts the browser harness greps its wire log for, so it can prove a
     * store never saw them.
     *
     * This deliberately exposes the room secret: `capabilityHex` is the room
     * capability itself, and the two SDP strings carry the DTLS fingerprints.
     * The audit is the only caller — the result must never be logged, persisted,
     * or sent anywhere.
     */
    auditSecrets(): {
        readonly capabilityHex: string;
        readonly roomContextIdHex: string;
        readonly stableKeyHex: string;
        readonly sdpLocal: string | null;
        readonly sdpRemote: string | null;
    };
    /** Wipe every secret this driver still owns. Idempotent. */
    destroy(): void;
    /**
     * Seal and publish one `IDENTITY_HELLO` toward the observed peer presence.
     *
     * `ingest` calls this once when the local presence is the rendezvous
     * initiator. It is exposed so a test can prove that a second, distinct HELLO
     * for the same authenticated slot is a pair fork.
     *
     * @internal
     */
    sendHello(): Promise<void>;
    private ensureInitialized;
    private initialize;
    private logicalWindow;
    private get roomPqMode();
    private isFailedEdge;
    private setPhase;
    private failEdge;
    /**
     * Allocate the next slot on this author's chain. Chains never cross a
     * logical window, so a new window restarts at sequence 0 with no
     * predecessor.
     */
    private nextAuthorFields;
    private recordOwnOperation;
    private identityBundle;
    private requireStableCommitment;
    private requireAuthorPublicKey;
    private requireAuthorSecretKey;
    private requireRemotePresence;
    private requireLocalPresence;
    private requireEndpoints;
    private requirePairEdge;
    /**
     * Pick the one other presence in the room and fix the rendezvous roles.
     *
     * The stable ownership proof cannot be checked here: the stable key is
     * deliberately absent from room-wide presence and only arrives inside the
     * identity flight, where the HELLO validator does verify it. Under the
     * prototype's OPEN policy every other presence is an acceptable peer.
     */
    private observePeer;
    /** Sign one identity plaintext over the exact outer binding. */
    private signIdentityPlaintext;
    private signPairStepOperation;
    /**
     * Route one candidate pair operation to the flight this endpoint expects.
     *
     * Returns false to defer: the operation stays unhandled so a later ingest
     * can retry once the missing predecessor exists.
     */
    private handlePairOperation;
    private handleIncomingHello;
    /** Seal the ACCEPT, promote the edge, persist the slot, then publish. */
    private sendAccept;
    private handleIncomingAccept;
    private validateAuthenticatedAccept;
    /** Derive `EstablishedPairRoot` and erase both bootstrap roots. */
    private promoteEstablishedRoot;
    private sendOffer;
    private handleIncomingOffer;
    private handleIncomingAnswer;
    private requirePeerStableKey;
    private prebindingFor;
    private slotAcceptanceCandidate;
    /**
     * Seal one established flight under `EstablishedPairRoot` and wrap it as the
     * `PAIR_STEP` operation the carrier publishes.
     */
    private sealEstablishedFlight;
    private signStableEdgeClaim;
    private stableEdgeClaimWindows;
    /**
     * Both endpoints recompute `StableEdgeId` from the two confirmed stable keys
     * and require byte equality, then verify the signature under the exact
     * authenticated claimant key over the exact lease interval.
     */
    private verifyStableEdgeClaim;
    private completeHandoff;
}
export {};
