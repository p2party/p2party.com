/**
 * Prototype delivery profile: the fixed per-window traffic geometry shared by
 * every client and both store servers in the server-blind rendezvous
 * prototype (design doc §4.2).
 *
 * `PROTOTYPE_DELIVERY_PROFILE_V0` is the one constant everything downstream
 * — the store server, the client adapter, and the scheduler — reads. Pinning
 * it here, next to the validator that checks it against the specification's
 * §4.3 arithmetic, means a profile that ships is a profile that has already
 * been proven geometrically self-consistent; nothing downstream re-derives or
 * re-checks that arithmetic.
 *
 * `withDeliveryWindowMs` exists because the prototype runs its local-stack
 * demo at a faster cadence than the spec's production numbers; scaling every
 * offset by the same ratio and re-validating is the only way to change the
 * window length without silently breaking one of the ordering inequalities.
 */
import type { PublicProfileGeometry } from "../publicWindow";
export interface AppendScheduleEntryV1 {
    readonly offsetMs: bigint;
    readonly role: "identity-bootstrap" | "safety-control" | "state-replication";
}
export interface DeliverySizeClassV1 {
    readonly id: number;
    readonly fixedCarrierObjectBytes: number;
    readonly operationPayloadClass: 0 | 1;
    readonly appendSchedule: readonly AppendScheduleEntryV1[];
    readonly publicChunksPerWindow: number;
}
export interface DeliveryProfileV1 {
    version: 1;
    carrierEnvelopeCodec: 1;
    publicStoreProtocol: 1;
    carrierAeadSuite: 1;
    admissionScheme: number;
    deliveryWindowMs: bigint;
    carrierRetentionWindows: number;
    maxFutureIngressWindows: number;
    roomSlotsPerClient: number;
    cohortAllocationsPerWindow: number;
    publicChunkObjectCount: number;
    maxScheduleSkewMs: bigint;
    tokenIssueOffsetMs: bigint;
    tokenIssueResponseBudgetMs: bigint;
    allocationRequestOffsetMs: bigint;
    allocationResponseBudgetMs: bigint;
    chunkFinalizationOffsetMs: bigint;
    publicReadLagWindows: 1;
    publicReadOffsetMs: bigint;
    maxConsecutiveMissedAppendOpportunities: number;
    sizeClasses: readonly DeliverySizeClassV1[];
    minMeasuredSharedCohort: number;
    maxAssuranceEvidenceAgeMs: bigint;
}
export declare const PROTOTYPE_STORE_PROTOCOL = "prototype-v0";
export declare const PROTOTYPE_ROUTE_PREFIX = "/p2party/prototype-v0";
export declare const PROTOTYPE_DESCRIPTOR_PATH = "/.well-known/p2party-store/prototype-v0";
export declare const PROTOTYPE_MEDIA_TYPE: (name: string) => string;
/**
 * The prototype's pinned delivery profile (design doc §4.2).
 *
 * Two size classes, one per `operationPayloadClass`: class 0 carries
 * identity-bootstrap traffic alongside the safety-control and
 * state-replication roles every class must schedule, and class 1 carries the
 * larger state-replication-heavy payloads. `publicChunksPerWindow` in each
 * class is the minimum satisfying `scheduledObjects <= chunkCapacity` —
 * see the third test in `profile.test.ts`, which recomputes it independently
 * rather than trusting the literal.
 */
export declare const PROTOTYPE_DELIVERY_PROFILE_V0: DeliveryProfileV1;
export declare class ProfileGeometryError extends Error {
    readonly name = "ProfileGeometryError";
    constructor(message: string);
}
/**
 * Every inequality from spec lines 5777-5825 ("For every size class, the
 * profile is valid only if: ..."), plus the preamble at 5770-5774 pinning
 * `sizeClasses` to exactly one class per `operationPayloadClass`. Throws
 * `ProfileGeometryError` on the first violation found; a caller that wants
 * every violation must fix and re-run.
 */
export declare const validateDeliveryProfileGeometry: (profile: DeliveryProfileV1) => void;
/** The size-class geometry a profile fixes, projected for the public-window
 * layer (`publicWindow.ts`), which never needs the full room-facing fields. */
export declare const profileGeometry: (profile: DeliveryProfileV1) => PublicProfileGeometry;
/** `CarrierSizeClassForPayloadClass(payloadClass)` (5772-5773): a total
 * function once the profile has passed `validateDeliveryProfileGeometry`. */
export declare const sizeClassForPayloadClass: (profile: DeliveryProfileV1, payloadClass: 0 | 1) => DeliverySizeClassV1;
/**
 * The exact wire length of one carrier object in this size class: the
 * canonical `CarrierEnvelopeV1` encoding of a zeroed envelope whose
 * ciphertext-and-tag body is the class's `fixedCarrierObjectBytes`. Building
 * the envelope literally and delegating to `encodeCarrierEnvelope` means this
 * never drifts from the wire codec, unlike a hand-maintained constant would.
 */
export declare const carrierObjectWireBytes: (profile: DeliveryProfileV1, sizeClassId: number, profileHash: Uint8Array) => number;
/**
 * Scale every schedule offset (and `maxAssuranceEvidenceAgeMs`) by
 * `deliveryWindowMs / profile.deliveryWindowMs` and re-validate.
 *
 * The prototype's local-stack demo runs the profile at a faster cadence than
 * the spec's production numbers; scaling every offset by the same ratio is
 * the only way to change the window length without silently breaking one of
 * the ordering inequalities checked above.
 */
export declare const withDeliveryWindowMs: (profile: DeliveryProfileV1, deliveryWindowMs: bigint) => DeliveryProfileV1;
