import type { Chunk, ReceiveChunk, NewChunk, NewChunkSelector, SendQueue, RatchetSession, IdentityDerivation, IdentityEd25519KeyMaterial, IdentityX25519 } from "./types";
export declare const getDBAddressBookEntry: (peerId?: string, peerPublicKey?: string) => Promise<import("./types").UsernamedPeer | undefined>;
export declare const getAllDBAddressBookEntries: () => Promise<import("./types").UsernamedPeer[]>;
export declare const setDBAddressBookEntry: (username: string, peerId: string, peerPublicKey: string) => Promise<undefined>;
export declare const deleteDBAddressBookEntry: (username?: string, peerId?: string, peerPublicKey?: string) => Promise<string>;
/**
 * Fails CLOSED. This is the sole admission gate on every connection path, and
 * an indeterminate answer must never be reported as "not blacklisted" — that
 * would let a storage fault silently readmit every blocked peer. The denial is
 * scoped to the one peer being checked, so a transient fault cannot lock the
 * whole room out.
 */
export declare const getDBPeerIsBlacklisted: (peerId?: string, peerPublicKey?: string) => Promise<boolean>;
export declare const getAllDBBlacklisted: () => Promise<import("./types").BlacklistedPeer[]>;
export declare const setDBPeerInBlacklist: (peerId: string, peerPublicKey: string) => Promise<undefined>;
export declare const deleteDBPeerFromBlacklist: (peerId?: string, peerPublicKey?: string) => Promise<undefined>;
export declare const getAllDBUniqueRooms: () => Promise<import("./types").UniqueRoom[]>;
export declare const setDBUniqueRoom: (roomUrl: string, roomId: string, roomPolicy: ArrayBuffer) => Promise<undefined>;
export declare const getDBMessageData: (merkleRootHex?: string, hashHex?: string) => Promise<import("./types").MessageData | undefined>;
export declare const getDBRoomMessageData: (roomId: string) => Promise<import("./types").MessageData[]>;
export declare const getDBRoomStats: (roomId: string) => Promise<import("./types").RoomStats>;
export declare const setDBRoomMessageData: (roomId: string, merkleRootHex: string, sha512Hex: string, fromPeerId: string, chunkSize: number, totalSize: number, messageType: number, // MessageType,
filename: string, channelLabel: string, timestamp: number, transferId?: string) => Promise<undefined>;
export declare const getDBChunk: (merkleRootHex: string, chunkIndex: number) => Promise<ArrayBuffer | undefined>;
export declare const existsDBChunk: (merkleRootHex: string, chunkIndex: number) => Promise<boolean>;
export declare const getDBNewChunk: (transferId: string, chunkIndex: number) => Promise<NewChunk | undefined>;
export declare const getDBNewChunkByReceipt: (merkleRootHex: string, receiptTokenHex: string) => Promise<NewChunk | undefined>;
export declare const existsDBNewChunk: (transferId: string, chunkIndex: number) => Promise<boolean>;
export declare const getDBSendQueue: (label: string, toPeerId: string) => Promise<SendQueue[]>;
export declare const getDBAllChunks: (merkleRootHex?: string, hashHex?: string) => Promise<Chunk[]>;
export declare const getDBAllChunkLeafHashes: (merkleRootHex: string) => Promise<import("./types").ChunkLeafHash[]>;
export declare const assembleToOPFS: (merkleRootHex: string, totalSize: number, filename: string, mimeType: string) => Promise<File | null>;
export declare const getDBAllChunksCount: (merkleRootHex?: string, hashHex?: string) => Promise<number>;
export declare const setDBChunk: (chunk: Chunk) => Promise<undefined>;
export declare const storeReceiveChunk: (chunk: ReceiveChunk) => Promise<import("./types").ReceiveChunkStoreResult>;
export declare const getReceiveFile: (merkleRootHex: string, totalSize: number, filename: string, mimeType: string) => Promise<File | null>;
export declare const closeReceiveFile: (merkleRootHex: string) => Promise<undefined>;
/**
 * Atomically retires one inbound transfer behind the same per-Merkle worker
 * lock used by storeReceiveChunk. This is the cancellation primitive: a chunk
 * write that was already in flight completes first and is then removed, while
 * later writes are stopped by the channel's AbortSignal.
 */
export declare const deleteReceiveTransfer: (merkleRootHex: string) => Promise<undefined>;
export declare const getDBAllNewChunks: (selector: NewChunkSelector) => Promise<NewChunk[]>;
export declare const getDBAllNewChunksCount: (transferId: string) => Promise<number>;
export declare const setDBNewChunk: (chunk: NewChunk) => Promise<undefined>;
export declare const setDBSendQueue: (item: SendQueue) => Promise<undefined>;
export declare const countDBSendQueue: (label: string, toPeerId: string) => Promise<number>;
export declare const deleteDBChunk: (hashHex: string, chunkIndex?: number) => Promise<undefined>;
export declare const deleteDBNewChunk: (selector: NewChunkSelector) => Promise<undefined>;
export declare const deleteDBMessageData: (merkleRootHex: string) => Promise<undefined>;
export declare const deleteDBUniqueRoom: (roomId: string) => Promise<undefined>;
export declare const deleteDB: () => Promise<undefined>;
export declare const deleteDBSendQueue: (label: string, toPeerId: string, position?: number) => Promise<undefined>;
export declare const getRatchetSession: (roomId: string, peerPublicKey: string) => Promise<RatchetSession | undefined>;
export declare const setRatchetSession: (session: RatchetSession) => Promise<undefined>;
export declare const deleteRatchetSession: (roomId: string, peerPublicKey: string) => Promise<undefined>;
export declare const getPinAttemptState: (roomId: string, peerIdentityEd25519: string) => Promise<import("./types").PinAttemptState | undefined>;
export declare const incrementPinAttemptState: (roomId: string, peerIdentityEd25519: string, now: number, maxImmediateAttempts: number, baseMs: number, maxMs: number) => Promise<import("./types").PinAttemptState>;
export declare const deletePinAttemptState: (roomId: string, peerIdentityEd25519?: string) => Promise<undefined>;
export declare const getIdentityX25519: () => Promise<IdentityX25519 | undefined>;
export declare const setIdentityX25519: (identity: IdentityX25519) => Promise<undefined>;
export declare const deleteIdentityX25519: () => Promise<undefined>;
export declare const getIdentityEd25519: () => Promise<import("./types").IdentityEd25519 | undefined>;
export declare const setIdentityEd25519: (identity: IdentityEd25519KeyMaterial) => Promise<bigint>;
export declare const deleteIdentityEd25519: () => Promise<undefined>;
export declare const getIdentityDerivation: () => Promise<IdentityDerivation | null>;
export declare const setIdentityDerivation: (derivation: IdentityDerivation) => Promise<undefined>;
export declare const deleteIdentityDerivation: () => Promise<undefined>;
