/**
 * Bounded rebuild budget for a transport that never negotiated.
 *
 * A protocol responder creates no data channel on a fresh transport, so if the
 * peer never dials it the transport sits in `new` with no description of any
 * kind and nothing watches it: the offer watchdog needs `have-local-offer`,
 * the rebind deadline needs a description, and ICE never runs. Tearing it down
 * and re-dialling makes the failure visible and lets a generation-aware peer
 * (see peerSocketGeneration) rebuild against the live session.
 *
 * Against a PRE-generation server the peer will not rebuild, so an uncapped
 * watchdog would churn every PENDING_OFFER_TIMEOUT_MS forever. This cap turns
 * that into three attempts and then a quiet, visibly-failed edge.
 */
export declare const MAX_UNNEGOTIATED_TRANSPORT_REBUILDS = 3;
export declare const recordUnnegotiatedTransportRebuild: (roomId: string, peerId: string) => number;
export declare const unnegotiatedTransportRebuilds: (roomId: string, peerId: string) => number;
export declare const clearUnnegotiatedTransportRebuilds: (roomId: string, peerId: string) => void;
export declare const mayRebuildUnnegotiatedTransport: (roomId: string, peerId: string) => boolean;
