import type { RatchetState, RatchetHeader } from "../cryptography/ratchet";
import type { LibCrypto } from "../cryptography/libcrypto";
/**
 * Per-message key-cache key. Keyed by `(dhPub, N)` — the pair that uniquely
 * identifies a ratchet message; every chunk of that message shares it. Exported
 * so the caller can evict a completed message's key deterministically.
 */
export declare const messageCacheKey: (dhPub: Uint8Array, N: number) => string;
/**
 * Seal ONE chunk under an already-derived per-message `messageKey` + `header`:
 * fresh random nonce, AEAD over `merkleRoot ‖ N ‖ PN`, framed as
 * `packChunkFrameHeader(header, nonce) ‖ ciphertext`. Does NOT touch the ratchet
 * (the caller stepped it ONCE via `ratchetEncrypt` for the whole message) and
 * does NOT wipe `messageKey` (the caller owns its lifecycle — it must stay live
 * across a big-file's streamed chunks AND across selective-retransmit rounds).
 *
 * This is the streaming/reconcile-friendly primitive the live send path uses: it
 * seals chunks one-at-a-time as they are read from IndexedDB, so a multi-GB
 * message is never materialised in RAM. A retransmit re-seals the same plaintext
 * under the SAME `messageKey` with a FRESH random nonce — cryptographically safe
 * (distinct 96-bit random nonces under one key) and decryptable by the receiver's
 * cached per-message key (a HIT on `(dhPub, N)`), so no frame-cache is needed.
 */
export declare const sealChunk: (messageKey: Uint8Array, header: RatchetHeader, chunk: Uint8Array, merkleRoot: Uint8Array, module: LibCrypto) => Uint8Array;
export interface DecryptedChunk {
    /** The DECRYPTED_LEN plaintext `metadata ‖ receiptLeaf ‖ chunk` written by the C
     *  receive, or `null` when the chunk was dropped (AEAD or Merkle failure). */
    decrypted: Uint8Array | null;
    /** True iff C returned 0 — AEAD **and** Merkle both passed. When false the caller
     *  drops the chunk (but still persists the ratchet if `stateAdvanced`). */
    ok: boolean;
    /** True iff this chunk stepped the ratchet (first-arriving chunk of a message
     *  whose AEAD authenticated). The caller persists `state` when true — even if
     *  `ok` is false, since the DH step is real once the AEAD authenticates. */
    stateAdvanced: boolean;
}
/**
 * RECEIVE one chunk frame: derive the per-message key off the ratchet (in TS —
 * the ratchet state is a TS object), then do ALL the crypto in ONE C call
 * (`receiveWithKey` → `_receive_message_with_key`: decrypt + leaf-hash + Merkle +
 * receipt, in place).
 *
 * The `cache` (caller-owned, keyed by `messageCacheKey(dhPub, N)`) holds the
 * per-message key. On a HIT — chunk 2..n, out-of-order, or a duplicate — the key
 * is reused WITHOUT touching the ratchet. On a MISS the key is derived under the
 * clone-rollback contract and cached.
 *
 * Clone-rollback (MANDATORY — `ratchetDecrypt` mutates BEFORE the AEAD
 * authenticates, so a replayed/old-chain header could otherwise fire a spurious
 * DH-step and desync the session):
 *   1. `clone = deserializeRatchet(serializeRatchet(state))`.
 *   2. `messageKey = ratchetDecrypt(clone, header)` — mutates the CLONE only.
 *   3. C decrypts+verifies. COMMIT (adopt the clone, cache the key) iff the AEAD
 *      authenticated (`code !== -2`); on `-2` DISCARD the clone — the live `state`
 *      is byte-for-byte untouched. `ok` (store-vs-drop) then follows `code === 0`.
 *
 * Cache lifecycle: the caller evicts a message's key (via `messageCacheKey`) when
 * the message completes (all leaves present) or on a TTL, so a peer can't pin keys
 * with never-completing messages.
 */
export declare const decryptMessageChunk: (state: RatchetState, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto) => DecryptedChunk;
