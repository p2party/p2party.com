import type { RatchetHeader } from "../cryptography/ratchet";
/** Total cleartext header length; ciphertext begins here. = 62 (the v3 MESSAGE_START). */
export declare const CHUNK_FRAME_HEADER_LEN: number;
/** Build the 62-byte cleartext chunk-frame header (ciphertext is appended by the caller). */
export declare const packChunkFrameHeader: (header: RatchetHeader, nonce: Uint8Array) => Uint8Array;
export interface ParsedChunkFrame {
    header: RatchetHeader;
    nonce: Uint8Array;
    ciphertext: Uint8Array;
}
/** Parse a v3 CHUNK frame into its ratchet header, nonce, and ciphertext (zero-copy views). */
export declare const parseChunkFrameHeader: (frame: Uint8Array) => ParsedChunkFrame;
