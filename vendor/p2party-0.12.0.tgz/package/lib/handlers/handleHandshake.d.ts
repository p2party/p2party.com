import type { LibCrypto } from "../cryptography/libcrypto";
import type { RatchetGateLease } from "./ratchetGate";
import type { RoomPqMode } from "../roomPolicy";
import type { IRTCPeerConnection, IRTCDataChannel } from "../api/webrtc/interfaces";
/**
 * Raw bytes of the `a=fingerprint:sha-256 XX:XX:...` line in an SDP blob.
 * Throws if no sha-256 fingerprint attribute is present, or if the one found
 * doesn't decode to exactly 32 bytes.
 */
export declare const parseFingerprintFromSdp: (sdp: string) => Uint8Array;
/**
 * Post-connect DTLS binding check (spec §5): the fingerprint declared in the
 * SDP (and bound into the CPace channel-input via buildChannelInput) must
 * equal the live certificate reported by getStats(). A disagreement means the
 * DTLS transport terminates on a different certificate than the one that was
 * authenticated by the handshake — i.e. a signaling server (or any on-path
 * attacker) swapped the SDP fingerprint/cert after the CPace transcript was
 * bound. This is the actual MITM tripwire, so it THROWS (never returns a
 * boolean, never logs-and-continues) — the caller must abort the channel.
 */
export declare const verifyDtlsFingerprints: (epc: IRTCPeerConnection) => Promise<void>;
/** Opaque owner of one concrete main-channel handshake attempt. */
export interface HandshakeLease {
    readonly token: symbol;
}
export declare const setHandshakeChannel: (roomId: string, peerId: string, channel: IRTCDataChannel | {
    send: (b: ArrayBuffer | Uint8Array) => void;
}, pqMode?: RoomPqMode, expectFinish?: boolean) => HandshakeLease;
export declare const clearHandshakeChannel: (roomId: string, peerId: string, reason?: Error, lease?: HandshakeLease) => boolean;
export declare const deliverHandshakeFrame: (roomId: string, peerId: string, payload: Uint8Array, lease: HandshakeLease) => boolean;
/**
 * Orchestrates the handshake on the persistent `main` channel (spec §5): verifies
 * the DTLS fingerprints (getStats vs SDP), runs the triple-confirmation core,
 * then — ONLY
 * on success — seeds + persists the (wrapped) ratchet, sets epc.ratchetState /
 * epc.session, and opens the per-peer gate. Any failure (fingerprint mismatch,
 * CPace/interactive-3DH error, key-confirmation mismatch, a bad/short frame,
 * a transport or
 * persistence error) rejects the gate and re-throws, having persisted NOTHING —
 * the caller tears the channel down.
 */
export declare const runHandshake: (epc: IRTCPeerConnection, roomId: string, mode: "pin" | "nopin", pqMode: RoomPqMode, pin: Uint8Array | null, channelInput: Uint8Array, module: LibCrypto, handshakeLease: HandshakeLease, gateLease: RatchetGateLease) => Promise<void>;
