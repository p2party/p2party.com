import type { RatchetSession } from "./types";
export declare const RATCHET_WRAP_VERSION = 1;
/**
 * Best-effort rollback/equivocation detection for one running client context.
 *
 * Callers pass an instance to `unwrapRatchetSession`; a successfully
 * authenticated record may advance `updatedAt`, but may not move backwards or
 * present different ciphertext at the same timestamp. `forget` is required
 * when an edge is intentionally deleted/re-established.
 *
 * This cannot detect replay of an older *complete* IndexedDB snapshot after a
 * full browser restart: WebCrypto/IndexedDB expose no trusted monotonic
 * counter. Durable cross-restart detection needs an independently protected
 * high-water head (or a remote/trusted anchor), atomically advanced with the
 * ratchet row. AES-GCM alone cannot provide that property.
 */
export declare class RatchetRollbackGuard {
    #private;
    acceptAuthenticated(s: RatchetSession): Promise<void>;
    /**
     * Advance the in-process high-water mark after, and only after, a local
     * wrapped row was durably stored. The record's canonical metadata and every
     * envelope shape/record ID are validated, but the locally produced
     * ciphertext is intentionally not decrypted.
     */
    rememberTrustedWrite(wrapped: RatchetSession): Promise<void>;
    forget(roomId: string, peerPublicKey: string): void;
    clear(): void;
}
export declare function getWrapKey(): Promise<CryptoKey>;
export declare function wrapSecret(key: CryptoKey, bytes: ArrayBuffer): Promise<ArrayBuffer>;
export declare function unwrapSecret(key: CryptoKey, blob: ArrayBuffer): Promise<ArrayBuffer>;
export declare function wrapRatchetSession(s: RatchetSession, key: CryptoKey): Promise<RatchetSession>;
export declare function unwrapRatchetSession(s: RatchetSession, key: CryptoKey, rollbackGuard?: RatchetRollbackGuard): Promise<RatchetSession>;
