import type { DBSchema, IDBPDatabase } from "idb";
import type { MessageData, Chunk, SendQueue, AddressBook, BlacklistedPeer, UniqueRoom, NewChunk, RatchetSession, StoredIdentityX25519, StoredIdentityEd25519, PinAttemptState } from "../types";
export declare const dbName = "p2party";
export declare const dbVersion = 18;
export interface RepoSchema extends DBSchema {
    addressBook: {
        value: AddressBook;
        key: [string];
        indexes: {
            peerId: string;
            peerPublicKey: string;
            username: string;
        };
    };
    blacklist: {
        value: BlacklistedPeer;
        key: [string];
        indexes: {
            peerId: string;
            peerPublicKey: string;
            username: string;
        };
    };
    uniqueRoom: {
        value: UniqueRoom;
        key: [string];
        indexes: {
            roomId: string;
            roomUrl: string;
        };
    };
    messageData: {
        value: MessageData;
        key: [number, string, string];
        indexes: {
            roomId: string;
            hash: string;
            merkleRoot: string;
            fromPeerId: string;
        };
    };
    chunks: {
        value: Chunk;
        key: [string, number];
        indexes: {
            merkleRoot: string;
            hash: string;
        };
    };
    newChunks: {
        value: NewChunk;
        key: [string, number];
        indexes: {
            transferId: string;
            hash: string;
            merkleRoot: string;
            receiptScope: [string, string];
        };
    };
    sendQueue: {
        value: SendQueue;
        key: [number, string, string];
        indexes: {
            labelPeer: string;
        };
    };
    ratchetSessions: {
        value: RatchetSession;
        key: [string, string];
        indexes: {
            peerId: string;
            peerPublicKey: string;
            roomId: string;
        };
    };
    meta: {
        value: CryptoKey | StoredIdentityX25519 | StoredIdentityEd25519 | PinAttemptState;
        key: string;
    };
}
export declare function getDB(): Promise<IDBPDatabase<RepoSchema>>;
