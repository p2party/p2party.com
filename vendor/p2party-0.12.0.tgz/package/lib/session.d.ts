import { type HandshakeTransport } from "./handlers/handshakeCore";
import type { RoomPqMode } from "./roomPolicy";
export type { HandshakeTransport };
export type { RoomPqMode } from "./roomPolicy";
export interface LocalSessionIdentity {
    ed25519PublicKey: Uint8Array;
    x25519PublicKey: Uint8Array;
    /** The X25519 identity secret used by interactive 3DH; never Ed25519. */
    x25519SecretKey: Uint8Array;
    x25519CrossSignature: Uint8Array;
}
export interface GeneratedSessionIdentity extends LocalSessionIdentity {
    ed25519SecretKey: Uint8Array;
}
export interface SessionChannelBinding {
    channelId: Uint8Array;
    localFingerprint: Uint8Array;
    remoteFingerprint: Uint8Array;
}
export interface SessionCryptoOptions {
    /**
     * Local/self-hosted libcrypto.wasm bytes. Supply this in Node/Bun or offline
     * deployments; when omitted the versioned p2party CDN loader is used.
     */
    wasmBinary?: ArrayBuffer | Uint8Array;
}
export type SessionAuth = {
    mode: "nopin";
    pin?: never;
} | {
    mode: "pin";
    pin: Uint8Array;
};
export type CreateSessionOptions = {
    transport: HandshakeTransport;
    role: "initiator" | "responder";
    identity: LocalSessionIdentity;
    /** Externally pinned (or explicitly TOFU-accepted) peer Ed25519 identity. */
    peerIdentityEd25519PublicKey: Uint8Array;
    channel: SessionChannelBinding;
    /** Exact suite chosen out-of-band for both peers; defaults to ML-KEM-768. */
    pqMode?: RoomPqMode;
    crypto?: SessionCryptoOptions;
} & SessionAuth;
export interface EncryptedSessionMessage {
    protocolVersion: 3;
    /** The message Merkle root; authenticated as AEAD additional data. */
    root: Uint8Array;
    /** Uniform protocol-v3 chunk frames. */
    frames: Uint8Array[];
}
export interface P2PartySession {
    readonly protocolVersion: 3;
    readonly pqMode: RoomPqMode;
    /** True for either role after a successful handshake; false after destroy. */
    readonly canEncrypt: boolean;
    encrypt(plaintext: Uint8Array): Promise<EncryptedSessionMessage>;
    decrypt(message: EncryptedSessionMessage): Promise<Uint8Array>;
    /**
     * Plaintext secret snapshot. Store only under authenticated encryption with
     * rollback protection; never send this blob to the peer.
     */
    serialize(): Promise<Uint8Array>;
    destroy(): Promise<void>;
}
export interface GenerateSessionIdentityOptions extends SessionCryptoOptions {
    ed25519KeyPair?: {
        publicKey: Uint8Array;
        secretKey: Uint8Array;
    };
}
export declare const generateSessionIdentity: (options?: GenerateSessionIdentityOptions) => Promise<GeneratedSessionIdentity>;
export declare const createSession: (options: CreateSessionOptions) => Promise<P2PartySession>;
export declare const restoreSession: (snapshot: Uint8Array, crypto?: SessionCryptoOptions) => Promise<P2PartySession>;
