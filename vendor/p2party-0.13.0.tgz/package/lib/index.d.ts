import { createSession, generateSessionIdentity, restoreSession } from "./session";
import { setWasmSourceUrl } from "./cryptography/wasmLoader";
import { WIRE_CHUNK_FRAME_LEN } from "./utils/constants";
import { DEFAULT_ROOM_POLICY_V1, MIN_COVER_CADENCE_MS, MAX_COVER_CADENCE_MS, MAX_COVER_LANES, MAX_COVER_FRAMES_PER_CELL, MIN_COVER_SLOT_MS, canonicalizeRoomPolicyV1, decodeRoomPolicyV1, encodeRoomPolicyV1, hashRoomPolicyV1, roomPoliciesEqualV1, validateRoomPolicyV1 } from "./roomPolicy";
import type { State } from "./store";
import type { Room, Peer, Channel, Message } from "./reducers/roomSlice";
import type { SignalingState } from "./reducers/signalingServerSlice";
import type { MimeType, FileExtension } from "./utils/messageTypes";
import type { WebSocketMessageRoomIdRequest, WebSocketMessageRoomIdResponse, WebSocketMessageChallengeRequest, WebSocketMessageChallengeResponse, WebSocketMessageDescriptionSend, WebSocketMessageDescriptionReceive, WebSocketMessageCandidateSend, WebSocketMessageCandidateReceive, WebSocketMessageError } from "./utils/interfaces";
import type { RoomData } from "./api/webrtc/interfaces";
import type { BlacklistedPeer, UsernamedPeer, UniqueRoom } from "./db/types";
import type { KeyPair } from "./reducers/keyPairSlice";
import type { RoomPolicyV1 } from "./roomPolicy";
import type { SendMessageResult } from "./handlers/handleSendMessage";
export interface ConnectRoomOptions {
    /**
     * Canonical public room policy. Omit on reconnect to preserve the room's
     * existing policy; a new room defaults to hybrid-PQ, no-PIN, immediate
     * delivery over the currently shipped signaling path.
     */
    policy?: RoomPolicyV1;
    /**
     * Required exactly when `policy.authMode` is `pin`. Copied into an in-memory
     * vault keyed by the local room URL; never enters Redux, storage, or logs.
     */
    pin?: Uint8Array;
}
/**
 * If no toChannel then broadcast the message everywhere to everyone.
 * If toChannel then broadcast to all peers with that channel.
 */
export interface MessageTransferHandle {
    readonly transferId: string;
    /**
     * Resolves only after every started peer send/reconciliation and cleanup
     * settles, preserving the ordered per-peer delivery outcomes.
     */
    readonly done: Promise<SendMessageResult | undefined>;
    /** Cancels exactly this logical send, even before hashing/WASM setup finishes. */
    cancel(): Promise<void>;
}
export declare const p2party: {
    store: import("@reduxjs/toolkit").EnhancedStore<{
        commonState: import("./reducers/commonSlice").CommonState;
        keyPair: KeyPair;
        rooms: Room[];
        signalingServer: SignalingState;
        signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        }, never, "signalingServerApi">;
        webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, SendMessageResult | undefined, "webrtcApi", undefined>;
            disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        }, never, "webrtcApi">;
    }, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
        dispatch: import("redux-thunk").ThunkDispatch<{
            commonState: import("./reducers/commonSlice").CommonState;
            keyPair: KeyPair;
            rooms: Room[];
            signalingServer: SignalingState;
            signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
                connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            }, never, "signalingServerApi">;
            webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
                connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, SendMessageResult | undefined, "webrtcApi", undefined>;
                disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            }, never, "webrtcApi">;
        }, undefined, import("redux").UnknownAction> & ((action: import("redux").Action<"listenerMiddleware/add">) => import("@reduxjs/toolkit").UnsubscribeListener);
    }>, import("redux").StoreEnhancer]>>;
    commonStateSelector: (state: State) => import("./reducers/commonSlice").CommonState;
    signalingServerSelector: (state: State) => SignalingState;
    roomSelector: (state: State) => Room[];
    keyPairSelector: (state: State) => KeyPair;
    connect: (roomUrl: string, signalingServerUrl?: string, rtcConfig?: RTCConfiguration, options?: ConnectRoomOptions) => Promise<void>;
    connectToSignalingServer: (roomUrl: string, signalingServerUrl?: string) => Promise<void>;
    disconnectFromSignalingServer: () => Promise<void>;
    disconnectFromRoom: (roomId: string, deleteMessages?: boolean) => Promise<void>;
    disconnectFromAllRooms: (deleteMessages?: boolean, exceptionRoomIds?: string[]) => Promise<void>;
    disconnectFromPeer: (peerId: string) => Promise<void>;
    allowConnectionRelay: (roomId: string, allowed?: boolean) => void;
    onlyAllowConnectionsFromAddressBook: (roomUrl: string, onlyAllow: boolean) => Promise<void>;
    addPeerToAddressBook: (username: string, peerId: string, peerPublicKey: string) => Promise<undefined>;
    getPeerAddressBookEntry: (peerId?: string, peerPublicKey?: string) => Promise<UsernamedPeer | undefined>;
    getAllPeersInAddressBook: () => Promise<UsernamedPeer[]>;
    getAllPeersInBlacklist: () => Promise<BlacklistedPeer[]>;
    deletePeerFromAddressBook: (username?: string, peerId?: string, peerPublicKey?: string) => Promise<void>;
    blacklistPeer: (peerId: string, peerPublicKey: string) => Promise<void>;
    getPeerIsBlacklisted: (peerId?: string, peerPublicKey?: string) => Promise<boolean>;
    removePeerFromBlacklist: (peerId?: string, peerPublicKey?: string) => Promise<undefined>;
    getAllExistingRooms: () => Promise<UniqueRoom[]>;
    sendMessage: (data: string | File, toChannel: string, roomId: string, percentageFilledChunk?: number, minChunks?: number, chunkSize?: number, metadataSchemaVersion?: number, transferId?: string) => MessageTransferHandle;
    readMessage: (merkleRootHex: string, hashHex?: string, materialize?: boolean) => Promise<{
        message: string | Blob;
        percentage: number;
        size: number;
        filename: string;
        mimeType: MimeType;
        extension: FileExtension;
        category: string;
        chunksReceivedTotal?: number;
        chunksReceivedReal?: number;
        retransmits?: number;
    }>;
    getSendChunksCount: (transferId: string) => Promise<number>;
    cancelMessage: (roomId: string, channelLabel: string, merkleRoot?: string | Uint8Array, hash?: string | Uint8Array, transferId?: string) => Promise<void>;
    createTransferId: () => string;
    deleteMessage: (roomId: string, merkleRoot?: string | Uint8Array, hash?: string | Uint8Array) => Promise<void>;
    purgeIdentity: () => Promise<void>;
    purgeRoom: (roomUrl: string) => Promise<void>;
    purge: () => Promise<void>;
    generateRandomRoomUrl: () => Promise<string>;
    generateRoomInvite: () => string;
    generateRoomCapability: () => Uint8Array;
    encodeRoomCapabilityBase64Url: (capability: Uint8Array) => string;
    decodeRoomCapabilityBase64Url: (encoded: string) => Uint8Array;
    decodeRoomCapability: (encoded: string) => Uint8Array;
    normalizeRoomCapability: (encoded: string) => string;
    encodeRoomInviteFragment: (capability: Uint8Array) => string;
    decodeRoomInviteFragment: (fragment: string) => Uint8Array;
    encodeRoomCapabilityWords: (capability: Uint8Array) => Promise<string>;
    decodeRoomCapabilityWords: (encoded: string) => Promise<Uint8Array>;
    ROOM_INVITE_WORDLIST_ID: string;
    sign: (message: Uint8Array, secretKey: Uint8Array, module?: import("./cryptography/libcrypto").LibCrypto) => Promise<Uint8Array>;
    verify: (message: Uint8Array, signature: Uint8Array, publicKey: Uint8Array, module?: import("./cryptography/libcrypto").LibCrypto) => Promise<boolean>;
    createSession: (options: import("./session").CreateSessionOptions) => Promise<import("./session").P2PartySession>;
    restoreSession: (snapshot: Uint8Array, crypto?: import("./session").SessionCryptoOptions) => Promise<import("./session").P2PartySession>;
    generateSessionIdentity: (options?: import("./session").GenerateSessionIdentityOptions) => Promise<import("./session").GeneratedSessionIdentity>;
    setWasmSourceUrl: (source: string | URL) => void;
    DEFAULT_ROOM_POLICY_V1: Readonly<RoomPolicyV1>;
    encodeRoomPolicyV1: (policy: RoomPolicyV1) => Uint8Array;
    decodeRoomPolicyV1: (encoded: Uint8Array) => RoomPolicyV1;
    hashRoomPolicyV1: (policy: RoomPolicyV1) => Promise<Uint8Array>;
    roomPoliciesEqualV1: (left: RoomPolicyV1, right: RoomPolicyV1) => boolean;
    generateKeyPair: (module?: import("./cryptography/libcrypto").LibCrypto) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    newKeyPair: (module?: import("./cryptography/libcrypto").LibCrypto) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    generateMnemonic: (strength?: 128 | 160 | 192 | 224 | 256 | 288 | 320 | 352 | 384 | 416 | 448 | 480 | 512) => Promise<string>;
    keyPairFromMnemonic: (mnemonic: string, password?: string) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    MIN_CHUNKS: number;
    MIN_CHUNK_SIZE: number;
    MAX_CHUNK_SIZE: number;
    WIRE_CHUNK_FRAME_LEN: number;
    MIN_COVER_CADENCE_MS: number;
    MAX_COVER_CADENCE_MS: number;
    MAX_COVER_LANES: number;
    MAX_COVER_FRAMES_PER_CELL: number;
    MIN_COVER_SLOT_MS: number;
    validateRoomPolicyV1: (policy: RoomPolicyV1) => void;
    MIN_PERCENTAGE_FILLED_CHUNK: number;
    MAX_PERCENTAGE_FILLED_CHUNK: number;
    ROOM_URL_LENGTH: number;
    MessageType: {
        Text: number;
        ImagePNG: number;
        ImageJPEG: number;
        ImageJPG: number;
        ImageGIF: number;
        ImageBMP: number;
        ImageTIFF: number;
        ImageSVG: number;
        ImageWEBP: number;
        ImageHEIC: number;
        DocumentPDF: number;
        DocumentDOC: number;
        DocumentDOCX: number;
        DocumentXLS: number;
        DocumentXLSX: number;
        DocumentPPT: number;
        DocumentPPTX: number;
        DocumentTXT: number;
        DocumentRTF: number;
        DocumentODT: number;
        AudioMP3: number;
        AudioWAV: number;
        AudioAAC: number;
        AudioFLAC: number;
        AudioOGG: number;
        AudioM4A: number;
        VideoMP4: number;
        VideoAVI: number;
        VideoMKV: number;
        VideoMOV: number;
        VideoWMV: number;
        VideoFLV: number;
        VideoWEBM: number;
        CompressedZIP: number;
        CompressedRAR: number;
        Compressed7Z: number;
        CompressedTAR: number;
        CompressedGZ: number;
        CodeHTML: number;
        CodeCSS: number;
        CodeJS: number;
        CodeJSX: number;
        CodeTS: number;
        CodeTSX: number;
        CodeJSON: number;
        CodeXML: number;
        CodePY: number;
        CodeJAVA: number;
        CodeC: number;
        CodeCPP: number;
        CodeCS: number;
        CodeRB: number;
        CodePHP: number;
        CodeSQL: number;
        EbookEPUB: number;
        EbookMOBI: number;
        EbookAZW: number;
        FontTTF: number;
        FontOTF: number;
        ImageICO: number;
        ExecutableEXE: number;
        ExecutableDMG: number;
        ExecutableAPK: number;
        Unknown: number;
    };
    MessageCategory: {
        Text: string;
        Image: string;
        Document: string;
        Audio: string;
        Video: string;
        Compressed: string;
        Code: string;
        Ebook: string;
        Font: string;
        Executable: string;
        Unknown: string;
    };
    VERSION: string;
};
declare global {
    interface Window {
        p2party: typeof p2party;
    }
}
export type { State, Room, Peer, Channel, Message, RoomData, MimeType, FileExtension, UsernamedPeer, BlacklistedPeer, UniqueRoom, SignalingState, KeyPair, RoomPolicyV1, WebSocketMessageRoomIdRequest, WebSocketMessageRoomIdResponse, WebSocketMessageChallengeRequest, WebSocketMessageChallengeResponse, WebSocketMessageDescriptionSend, WebSocketMessageDescriptionReceive, WebSocketMessageCandidateSend, WebSocketMessageCandidateReceive, WebSocketMessageError, };
export { createSession, restoreSession, generateSessionIdentity, setWasmSourceUrl, };
export { DEFAULT_ROOM_POLICY_V1, canonicalizeRoomPolicyV1, decodeRoomPolicyV1, encodeRoomPolicyV1, hashRoomPolicyV1, roomPoliciesEqualV1, };
export { MIN_COVER_CADENCE_MS, MAX_COVER_CADENCE_MS, MAX_COVER_LANES, MAX_COVER_FRAMES_PER_CELL, MIN_COVER_SLOT_MS, validateRoomPolicyV1, WIRE_CHUNK_FRAME_LEN, };
export type { RoomAuthMode, RoomCoverMode, RoomPqMode, RoomRendezvousMode, } from "./roomPolicy";
export type { CreateSessionOptions, EncryptedSessionMessage, GenerateSessionIdentityOptions, GeneratedSessionIdentity, HandshakeTransport, LocalSessionIdentity, P2PartySession, SessionChannelBinding, SessionCryptoOptions, } from "./session";
export default p2party;
