import type { State } from "../store";
import type { RoomPolicyV1 } from "../roomPolicy";
import type { CoverSchedulerStatus } from "../handlers/coverScheduler";
export interface Channel {
    label: string;
    peerIds: string[];
}
export interface Peer {
    peerId: string;
    peerPublicKey: string;
}
export interface Message {
    /** Sender-only random identity for one logical outbound transfer. */
    transferId?: string;
    merkleRootHex: string;
    sha512Hex: string;
    fromPeerId: string;
    filename: string;
    messageType: number;
    savedSize: number;
    totalSize: number;
    chunksCreated: number;
    totalChunks: number;
    channelLabel: string;
    timestamp: number;
    chunksReceivedTotal?: number;
    chunksReceivedReal?: number;
    retransmits?: number;
}
export interface IncrementMessageStatsArgs {
    roomId: string;
    merkleRootHex?: string;
    sha512Hex?: string;
    real?: boolean;
    retransmit?: boolean;
}
export interface SetRoomArgs {
    url: string;
    id: string;
    canBeConnectionRelay?: boolean;
    onlyConnectWithKnownPeers?: boolean;
    rtcConfig?: RTCConfiguration;
    /** Public/authenticated room settings only. PIN bytes never enter Redux. */
    policy?: RoomPolicyV1;
}
export interface SetRoomPolicyArgs {
    roomContext: string;
    policy: RoomPolicyV1;
}
export interface SetPeerArgs extends Peer {
    roomId: string;
}
export interface SetIceServersArgs {
    roomId: string;
    iceServers: RTCIceServer[];
}
export interface SetMessageArgs {
    roomId: string;
    transferId?: string;
    merkleRootHex: string;
    sha512Hex: string;
    chunkSize: number;
    totalSize: number;
    chunksCreated?: number;
    totalChunks?: number;
    timestamp?: number;
    fromPeerId: string;
    filename: string;
    messageType: number;
    channelLabel: string;
}
export interface SetMessageAllChunksArgs {
    roomId: string;
    transferId?: string;
    merkleRootHex: string;
    sha512Hex: string;
    fromPeerId: string;
    filename: string;
    messageType: number;
    totalSize: number;
    channelLabel: string;
    timestamp: number;
    alsoSendFinishedMessage?: boolean;
}
export interface SetMessageDeliveredSizeArgs {
    roomId: string;
    merkleRootHex: string;
    sha512Hex: string;
    fromPeerId: string;
    deliveredSize: number;
}
export interface SetChannelArgs {
    roomId: string;
    peerId: string;
    label: string;
}
export interface DeleteMessageArgs {
    roomId: string;
    transferId?: string;
    merkleRootHex?: string;
    hashHex?: string;
}
export interface DeleteChannelArgs {
    roomId?: string;
    peerId?: string;
    label?: string;
}
export interface SetCanOnlyConnectWithKnownPeers {
    roomId: string;
    onlyConnectWithKnownPeers: boolean;
}
export interface SetPeerCoverStatusArgs {
    roomId: string;
    peerId: string;
    status: CoverSchedulerStatus;
}
export interface Room extends SetRoomArgs {
    policy: RoomPolicyV1;
    connectingToPeers: boolean;
    connectedToPeers: boolean;
    canBeConnectionRelay: boolean;
    onlyConnectWithKnownAddresses: boolean;
    rtcConfig: RTCConfiguration;
    peers: Peer[];
    channels: Channel[];
    messages: Message[];
    /**
     * protocol-v4: live scheduled-cover status per authenticated peer edge
     * (peerId → status). Absent means no cover claim may ever be made for that
     * edge — only an explicit "active" from the runtime is a cover claim, so a
     * browser gap ("suspended") or teardown ("stopped") is always visible.
     */
    coverStatusByPeer?: Record<string, CoverSchedulerStatus>;
}
export declare const defaultRTCConfig: RTCConfiguration;
export declare const setRoom: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetRoomArgs, "rooms/setRoom">, setRoomPolicy: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetRoomPolicyArgs, "rooms/setRoomPolicy">, setConnectingToPeers: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    roomId: string;
    connectingToPeers: boolean;
}, "rooms/setConnectingToPeers">, setConnectedToPeers: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    roomId: string;
    connectedToPeers: boolean;
}, "rooms/setConnectedToPeers">, setConnectionRelay: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    roomId: string;
    canBeConnectionRelay: boolean;
}, "rooms/setConnectionRelay">, setOnlyConnectWithKnownPeers: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetCanOnlyConnectWithKnownPeers, "rooms/setOnlyConnectWithKnownPeers">, setPeer: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetPeerArgs, "rooms/setPeer">, setPeerCoverStatus: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetPeerCoverStatusArgs, "rooms/setPeerCoverStatus">, setChannel: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetChannelArgs, "rooms/setChannel">, setIceServers: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetIceServersArgs, "rooms/setIceServers">, setMessage: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetMessageArgs, "rooms/setMessage">, setMessageAllChunks: import("@reduxjs/toolkit").ActionCreatorWithPayload<SetMessageAllChunksArgs, "rooms/setMessageAllChunks">, incrementMessageStats: import("@reduxjs/toolkit").ActionCreatorWithPayload<IncrementMessageStatsArgs, "rooms/incrementMessageStats">, deletePeer: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    peerId: string;
    roomId?: string;
}, "rooms/deletePeer">, deleteChannel: import("@reduxjs/toolkit").ActionCreatorWithPayload<DeleteChannelArgs, "rooms/deleteChannel">, deleteMessage: import("@reduxjs/toolkit").ActionCreatorWithPayload<DeleteMessageArgs, "rooms/deleteMessage">, deleteRoom: import("@reduxjs/toolkit").ActionCreatorWithPayload<string, "rooms/deleteRoom">;
export declare const roomSelector: (state: State) => Room[];
declare const _default: import("redux").Reducer<Room[]>;
export default _default;
