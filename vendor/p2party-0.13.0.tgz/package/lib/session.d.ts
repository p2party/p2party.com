import { type HandshakeTransport } from "./handlers/handshakeCore";
import type { RoomPqMode } from "./roomPolicy";
export type { HandshakeTransport };
export type { RoomPqMode } from "./roomPolicy";
export interface LocalSessionIdentity {
    ed25519PublicKey: Uint8Array;
    x25519PublicKey: Uint8Array;
    /** The X25519 identity secret used by interactive 3DH; never Ed25519. */
    x25519SecretKey: Uint8Array;
    x25519CrossSignature: Uint8Array;
}
export interface GeneratedSessionIdentity extends LocalSessionIdentity {
    ed25519SecretKey: Uint8Array;
}
export interface SessionChannelBinding {
    channelId: Uint8Array;
    localFingerprint: Uint8Array;
    remoteFingerprint: Uint8Array;
}
export interface SessionCryptoOptions {
    /**
     * Local/self-hosted libcrypto.wasm bytes. Supply this in Node/Bun or offline
     * deployments; when omitted the versioned p2party CDN loader is used.
     */
    wasmBinary?: ArrayBuffer | Uint8Array;
}
export type SessionAuth = {
    mode: "nopin";
    pin?: never;
} | {
    mode: "pin";
    pin: Uint8Array;
};
export type CreateSessionOptions = {
    transport: HandshakeTransport;
    role: "initiator" | "responder";
    identity: LocalSessionIdentity;
    /** Externally pinned (or explicitly TOFU-accepted) peer Ed25519 identity. */
    peerIdentityEd25519PublicKey: Uint8Array;
    channel: SessionChannelBinding;
    /** Exact suite chosen out-of-band for both peers; defaults to ML-KEM-768. */
    pqMode?: RoomPqMode;
    crypto?: SessionCryptoOptions;
} & SessionAuth;
export interface EncryptedSessionMessage {
    protocolVersion: 4;
    /** The message Merkle root; authenticated as AEAD additional data. */
    root: Uint8Array;
    /** Uniform protocol-v3 chunk frames. */
    frames: Uint8Array[];
}
/**
 * One exact sealed sparse-PQ control cell to dispatch after the caller has
 * persisted the mutated session, plus whether a durable write is required
 * before sending (false for an exact duplicate response).
 */
export interface SessionControlOutput {
    readonly frame: Uint8Array | null;
    readonly requiresPersistBeforeSend: boolean;
}
export interface P2PartySession {
    readonly protocolVersion: 4;
    readonly pqMode: RoomPqMode;
    /** True for either role after a successful handshake; false after destroy. */
    readonly canEncrypt: boolean;
    /** Current authenticated PQ epoch; 0 before any healing exchange. */
    readonly pqEpoch: bigint;
    /** True while a sparse-PQ healing exchange blocks application traffic. */
    readonly healingInProgress: boolean;
    encrypt(plaintext: Uint8Array): Promise<EncryptedSessionMessage>;
    decrypt(message: EncryptedSessionMessage): Promise<Uint8Array>;
    /**
     * Store-free sparse-PQ healing for custom transports. Contract: after any of
     * these returns a frame, the caller MUST persist `serialize()` BEFORE
     * sending that frame, so a crash cannot fork the OFFER/ADVANCE/ACK sequence.
     *
     * `prepareHealing` starts a due local exchange (returns null when not due or
     * not this side's turn). `acceptControlFrame` processes an inbound OFFER,
     * ADVANCE, or ACK and returns the exact response to send. `pendingControl`
     * returns the exact frame to retransmit for a dropped flight.
     */
    prepareHealing(): Promise<SessionControlOutput>;
    acceptControlFrame(frame: Uint8Array): Promise<SessionControlOutput>;
    pendingControl(): Promise<Uint8Array | null>;
    /**
     * Plaintext secret snapshot (Double Ratchet + PQ machine/root/epoch/turn/
     * counters + active combined receive keys). Store only under authenticated
     * encryption with rollback protection; never send this blob to the peer.
     */
    serialize(): Promise<Uint8Array>;
    destroy(): Promise<void>;
}
export interface GenerateSessionIdentityOptions extends SessionCryptoOptions {
    ed25519KeyPair?: {
        publicKey: Uint8Array;
        secretKey: Uint8Array;
    };
}
export declare const generateSessionIdentity: (options?: GenerateSessionIdentityOptions) => Promise<GeneratedSessionIdentity>;
export declare const createSession: (options: CreateSessionOptions) => Promise<P2PartySession>;
export declare const restoreSession: (snapshot: Uint8Array, crypto?: SessionCryptoOptions) => Promise<P2PartySession>;
