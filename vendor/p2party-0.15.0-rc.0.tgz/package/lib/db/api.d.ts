import type { FileRemovalNotice, FileRemovalRetryScope, HeldFileProgressNotice, HeldFileSettledNotice, ReceiveDeleteGuard, RoomMessageLoadOptions } from "./types";
import type { OutboxLease, OutboxRequest, OutboxResponse } from "./outboxTypes";
import type { WorkerMessages, Chunk, ReceiveChunk, NewChunk, NewChunkSelector, SendQueue, RatchetSession, IdentityDerivation, IdentityEd25519KeyMaterial, IdentityX25519 } from "./types";
export declare const onHeldFileSettled: (listener: (notice: HeldFileSettledNotice) => void) => (() => void);
export declare const onVerificationProgress: (listener: (notice: HeldFileProgressNotice) => void) => (() => void);
/** Hear of each file a removal started by the SDK left on disk. */
export declare const onFileNotRemoved: (listener: (notice: FileRemovalNotice) => void) => (() => void);
/**
 * Announce a file a removal left on disk, unless a call of the application
 * answers for it or it was announced already.
 */
export declare const announceFileNotRemoved: (notice: FileRemovalNotice) => void;
/**
 * Run a call the application made to delete one file's message. Until `run`
 * settles, a refusal to remove that file, from whichever attempt inside the
 * call, is kept instead of being thrown or announced. The call's last attempt
 * decides: if that one was refused, the call rejects with it once, after
 * everything else in `run` was done.
 */
export declare const answeringForRemoval: <T>(merkleRootHex: string, run: () => Promise<T>) => Promise<T>;
/** The part of a Worker the database client uses. */
export interface DatabaseWorkerPort {
    postMessage(message: unknown, transfer: Transferable[]): void;
    onmessage: ((event: MessageEvent) => void) | null;
    onerror: ((event: ErrorEvent) => void) | null;
    onmessageerror: ((event: MessageEvent) => void) | null;
}
/**
 * The request/reply client over the database worker. A pending call is only
 * drained by a reply carrying its id, so anything that kills the worker (a
 * module-load failure, a structured-clone failure posting a large chunk, an
 * OOM) would otherwise leave every in-flight call unsettled forever. After the
 * worker fails, every pending and every later call rejects at once with
 * DatabaseWorkerError; the worker is not restarted (the application reloads).
 */
export declare const createDatabaseClient: (worker: DatabaseWorkerPort, bundled: boolean) => {
    call: (method: WorkerMessages["method"], args: readonly unknown[], transfer?: Transferable[]) => Promise<unknown>;
};
/**
 * Test seam: send every database call to `port` (an in-process worker) until
 * the returned function is called. Not part of the package's public exports.
 */
export declare const useDatabaseWorkerForTests: (port: DatabaseWorkerPort) => (() => void);
export declare const getDBAddressBookEntry: (peerId?: string, peerPublicKey?: string) => Promise<import("./types").UsernamedPeer | undefined>;
export declare const getAllDBAddressBookEntries: () => Promise<import("./types").UsernamedPeer[]>;
export declare const setDBAddressBookEntry: (username: string, peerId: string, peerPublicKey: string) => Promise<undefined>;
export declare const deleteDBAddressBookEntry: (username?: string, peerId?: string, peerPublicKey?: string) => Promise<string>;
/**
 * Fails CLOSED. This is the sole admission gate on every connection path, and
 * an indeterminate answer must never be reported as "not blacklisted" — that
 * would let a storage fault silently readmit every blocked peer. The denial is
 * scoped to the one peer being checked, so a transient fault cannot lock the
 * whole room out.
 */
export declare const getDBPeerIsBlacklisted: (peerId?: string, peerPublicKey?: string) => Promise<boolean>;
export declare const getAllDBBlacklisted: () => Promise<import("./types").BlacklistedPeer[]>;
export declare const setDBPeerInBlacklist: (peerId: string, peerPublicKey: string) => Promise<undefined>;
export declare const deleteDBPeerFromBlacklist: (peerId?: string, peerPublicKey?: string) => Promise<undefined>;
export declare const getAllDBUniqueRooms: () => Promise<import("./types").UniqueRoom[]>;
export declare const setDBUniqueRoom: (roomUrl: string, roomId: string, roomPolicy: ArrayBuffer) => Promise<undefined>;
export declare const getDBMessageData: (merkleRootHex?: string, hashHex?: string) => Promise<import("./types").MessageData | undefined>;
export declare const getDBRoomMessageData: (roomId: string, options?: RoomMessageLoadOptions) => Promise<import("./types").MessageData[]>;
export declare const getDBRoomStats: (roomId: string) => Promise<import("./types").RoomStats>;
export declare const setDBRoomMessageData: (roomId: string, merkleRootHex: string, sha512Hex: string, fromPeerId: string, chunkSize: number, totalSize: number, messageType: number, // MessageType,
filename: string, channelLabel: string, timestamp: number, transferId?: string) => Promise<undefined>;
export declare const getDBChunk: (merkleRootHex: string, chunkIndex: number) => Promise<ArrayBuffer | undefined>;
export declare const existsDBChunk: (merkleRootHex: string, chunkIndex: number) => Promise<boolean>;
export declare const getDBNewChunk: (transferId: string, chunkIndex: number) => Promise<NewChunk | undefined>;
export declare const getDBNewChunkByReceipt: (merkleRootHex: string, receiptTokenHex: string) => Promise<Pick<NewChunk, "transferId" | "merkleRoot" | "chunkIndex" | "receiptToken"> | undefined>;
export declare const existsDBNewChunk: (transferId: string, chunkIndex: number) => Promise<boolean>;
export declare const getDBSendQueue: (label: string, toPeerId: string) => Promise<SendQueue[]>;
export declare const getDBAllChunks: (merkleRootHex?: string, hashHex?: string) => Promise<Chunk[]>;
export declare const getDBAllChunkLeafHashes: (merkleRootHex: string) => Promise<import("./types").ChunkLeafHash[]>;
export declare const assembleToOPFS: (merkleRootHex: string, totalSize: number, filename: string, mimeType: string) => Promise<File | null>;
export declare const getDBAllChunksCount: (merkleRootHex?: string, hashHex?: string) => Promise<number>;
export declare const setDBChunk: (chunk: Chunk) => Promise<undefined>;
export declare const storeReceiveChunk: (chunk: ReceiveChunk) => Promise<import("./types").ReceiveChunkStored | import("./types").ReceiveChunkStoreFailure>;
export declare const verifyReceivedFile: (merkleRootHex: string, token: string, holder: string) => Promise<import("./types").ReceiveVerificationVerdict>;
export declare const settleReceivedFileVerification: (merkleRootHex: string, token: string, commit: boolean, holder: string) => Promise<import("./types").ReceiveVerificationOutcome>;
export declare const abortReceivedFileVerification: (merkleRootHex: string, token: string, holder: string) => Promise<undefined>;
export declare const getReceiveFile: (merkleRootHex: string, totalSize: number, filename: string, mimeType: string) => Promise<File | null>;
export declare const closeReceiveFile: (merkleRootHex: string) => Promise<undefined>;
/**
 * Atomically retires one inbound transfer behind the same per-Merkle worker
 * lock used by storeReceiveChunk. This is the cancellation primitive: a chunk
 * write that was already in flight completes first and is then removed, while
 * later writes are stopped by the channel's AbortSignal.
 */
export declare function deleteReceiveTransfer(merkleRootHex: string): Promise<void>;
export declare function deleteReceiveTransfer(merkleRootHex: string, guard: ReceiveDeleteGuard): Promise<boolean>;
/**
 * Try again to remove files an earlier delete left on disk. A scope that
 * names a room covers only what that room's deleted messages left: one
 * message's file (named by its Merkle root, transfer ID or hash), every file
 * of the room, or every file of a room that only its URL can still name.
 * (Leaving all rooms covers every room but the ones it excepts.) A file some
 * record owns, or that another room's records name, is not touched. Rejects
 * with StorageFailedError while the browser still refuses.
 */
export declare const retryFileRemovals: (scope: FileRemovalRetryScope) => Promise<void>;
export declare const getDBAllNewChunks: (selector: NewChunkSelector) => Promise<NewChunk[]>;
export declare const getDBAllNewChunksCount: (transferId: string) => Promise<number>;
/** With ownership, the worker receives the buffers and wipes its temporary
 * plaintext after the transaction. Other callers keep their buffers. */
export declare const setDBNewChunk: (chunk: NewChunk, lease?: OutboxLease, transferOwnership?: boolean) => Promise<undefined>;
export declare const setDBSendQueue: (item: SendQueue) => Promise<undefined>;
export declare const countDBSendQueue: (label: string, toPeerId: string) => Promise<number>;
export declare const deleteDBChunk: (hashHex: string, chunkIndex?: number) => Promise<undefined>;
export declare const deleteDBNewChunk: (selector: NewChunkSelector) => Promise<undefined>;
export declare const deleteDBUniqueRoom: (roomId: string) => Promise<string[]>;
export declare const deleteDB: () => Promise<undefined>;
export declare const deleteDBSendQueue: (label: string, toPeerId: string, position?: number) => Promise<undefined>;
export declare const getRatchetSession: (roomId: string, peerPublicKey: string) => Promise<RatchetSession | undefined>;
export declare const setRatchetSession: (session: RatchetSession) => Promise<undefined>;
export declare const deleteRatchetSession: (roomId: string, peerPublicKey: string) => Promise<undefined>;
export declare const getPinAttemptState: (roomId: string, peerIdentityEd25519: string) => Promise<import("./types").PinAttemptState | undefined>;
export declare const incrementPinAttemptState: (roomId: string, peerIdentityEd25519: string, now: number, maxImmediateAttempts: number, baseMs: number, maxMs: number) => Promise<import("./types").PinAttemptState>;
export declare const deletePinAttemptState: (roomId: string, peerIdentityEd25519?: string) => Promise<undefined>;
export declare const getIdentityX25519: () => Promise<IdentityX25519 | undefined>;
export declare const setIdentityX25519: (identity: IdentityX25519) => Promise<undefined>;
export declare const deleteIdentityX25519: () => Promise<undefined>;
export declare const getIdentityEd25519: () => Promise<import("./types").IdentityEd25519 | undefined>;
export declare const setIdentityEd25519: (identity: IdentityEd25519KeyMaterial) => Promise<bigint>;
export declare const deleteIdentityEd25519: () => Promise<undefined>;
export declare const getIdentityDerivation: () => Promise<IdentityDerivation | null>;
export declare const setIdentityDerivation: (derivation: IdentityDerivation) => Promise<undefined>;
export declare const deleteIdentityDerivation: () => Promise<undefined>;
export declare const outboxRequest: (request: OutboxRequest, transfer?: Transferable[]) => Promise<OutboxResponse>;
export declare const sweepStaleReceives: () => Promise<string[]>;
export declare const sweepStaleReceiveDetails: () => Promise<import("./types").ExpiredReceiveTransfer[]>;
