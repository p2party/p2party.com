import type { LibCrypto } from "../cryptography/libcrypto";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
import type { RatchetHeader, RatchetState } from "../cryptography/ratchet";
import type { DecryptedChunk } from "./messageChunkCrypto";
/**
 * Claim the stable persistence edge before a replacement handshake writes its
 * seed. The synchronous claim invalidates queued mutations from the old PC;
 * the edge-wide write lock ensures any already-running old write finishes
 * before the replacement seed is written last.
 */
export declare const claimRatchetPersistence: (epc: IRTCPeerConnection, roomId: string) => void;
/**
 * Retire a torn-down connection's claim on its edge's persisted ratchet row and
 * delete the row, so no wrapped key material of a dead generation stays on
 * disk. Called by the shared edge teardown (generation retire, explicit
 * disconnect, failed handshake, every other transport close).
 *
 * Only the connection that currently owns the edge's row deletes it. Once a
 * replacement has claimed the edge (`claimRatchetPersistence`), the row is the
 * replacement's, or is about to be, and a late teardown of its predecessor
 * leaves it alone.
 *
 * The decision is synchronous and so is the enqueue: ownership is revoked at
 * once, so every write this connection still has queued fails its owner check
 * and none it starts later can reclaim the edge, and the delete takes its place
 * in the per-edge lock now. It therefore runs after any write already queued
 * for the edge and before the seed of any replacement that claims the edge
 * afterwards.
 */
export declare const releaseRatchetPersistence: (epc: IRTCPeerConnection, roomId: string, remove?: RollbackInitialRatchetState) => Promise<void>;
export declare const persistRatchetState: (state: RatchetState, roomId: string, peerPublicKey: string, peerId: string, edgeCryptoState?: Uint8Array | null) => Promise<void>;
export declare const persistClaimedRatchetState: (epc: IRTCPeerConnection, state: RatchetState, roomId: string, edgeCryptoStateOverride?: () => Uint8Array) => Promise<void>;
export type PersistInitialRatchetState = (state: RatchetState, roomId: string, peerPublicKey: string, peerId: string, edgeCryptoState?: Uint8Array | null) => Promise<void>;
export type RollbackInitialRatchetState = (roomId: string, peerPublicKey: string) => Promise<void>;
/**
 * Atomically order the initial durable seed and its synchronous gate/RAM
 * activation under the stable-edge lock. If close/replacement settles the gate
 * while the worker write is in flight, delete that just-written seed before a
 * replacement is allowed to write. This prevents a never-established root from
 * being restored later.
 */
export declare const persistAndActivateClaimedRatchetState: (epc: IRTCPeerConnection, state: RatchetState, roomId: string, activate: () => void, persist?: PersistInitialRatchetState, rollback?: RollbackInitialRatchetState) => Promise<void>;
export type PersistRatchetState = typeof persistRatchetState;
export declare const withEdgeCryptoMutationLock: <T>(epc: IRTCPeerConnection, mutation: () => Promise<T>) => Promise<T>;
/**
 * TESTS ONLY. Lets `ratchetEncryptDurably` step this edge without an
 * installed PQ runtime; the step then returns a null PQ context, which only
 * `sealChunkClassicalOnlyForTests` accepts. Without this the step refuses
 * such an edge. tests/handlers/messageChunkCrypto.test.ts checks that no
 * production module calls it.
 */
export declare const allowClassicalOnlySendForTests: (epc: IRTCPeerConnection) => void;
/**
 * Advance the sending chain exactly once, durably, before its key/header can be
 * used to build a frame. The returned message key remains caller-owned, as is
 * the returned OWNED copy of the current PQ message context. Capturing the
 * context and counting the application message happen inside the same edge
 * transaction as the ratchet step, so a concurrent PQ healing transition
 * cannot interleave.
 *
 * A live edge always installs its PQ runtime together with its ratchet
 * (`persistAndActivateEdgeCrypto`), and every v4 message key is PQ-combined.
 * An edge with a ratchet but no PQ runtime therefore means that invariant
 * broke; the step rejects before touching the ratchet. The context is null
 * only for an edge a test opted in with `allowClassicalOnlySendForTests`.
 */
export declare const ratchetEncryptDurably: (epc: IRTCPeerConnection, roomId: string, module: LibCrypto, persist?: PersistRatchetState) => Promise<{
    messageKey: Uint8Array;
    header: RatchetHeader;
    pqContext: PqMessageKeyContext | null;
}>;
/**
 * TESTS ONLY. Lets this edge receive without an installed PQ runtime, under
 * raw classical ratchet keys (`decryptMessageChunkClassicalOnlyForTests`),
 * with the classical key kept in the persisted skipped map until retirement.
 * Without this, `decryptMessageChunkDurably` refuses such an edge.
 * tests/handlers/messageChunkCrypto.test.ts checks that no production module
 * calls it.
 */
export declare const allowClassicalOnlyReceiveForTests: (epc: IRTCPeerConnection) => void;
/**
 * Decrypt one inbound chunk with a staged state/cache. An authenticated ratchet
 * advance becomes visible only after its snapshot is durable; persistence
 * failure rejects without advancing live state, caching a key, or exposing the
 * decrypted bytes. Cache hits do not advance or persist the ratchet.
 *
 * A live edge always installs its PQ runtime together with its ratchet
 * (`persistAndActivateEdgeCrypto`), and every v4 message key is PQ-combined.
 * An edge with a ratchet but no PQ runtime therefore means that invariant
 * broke; the decrypt rejects before touching the ratchet rather than falling
 * back to the raw classical key.
 */
export declare const decryptMessageChunkDurably: (epc: IRTCPeerConnection, roomId: string, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto, persist?: PersistRatchetState) => Promise<DecryptedChunk>;
/**
 * Durably retire the active receive key after the atomic chunk manifest reports
 * completion, then erase the RAM cache copy. If persistence fails, both copies
 * remain usable for an idempotent retransmit/retry rather than diverging.
 */
export declare const forgetReceiveMessageKeyIfCurrentDurably: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, canRetire: (() => Promise<boolean>) | undefined, persist?: PersistRatchetState) => Promise<boolean>;
export declare const forgetReceiveMessageKeyDurably: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, persist?: PersistRatchetState) => Promise<void>;
export declare const persistRatchetSession: (epc: IRTCPeerConnection, roomId: string) => Promise<void>;
