import type { OutboxLease, OutboxManifest, OutboxReceipt, OutboxRequest, OutboxResponse } from "../db/outboxTypes";
export interface PendingMessage {
    transferId: string;
    roomId: string;
    channelLabel: string;
    filename: string;
    totalSize: number;
    totalChunks: number;
    merkleRootHex: string;
    createdAt: number;
    updatedAt: number;
    expiresAt: number;
    phase: "staging" | "pending" | "sending";
    remainingRecipients: Array<{
        peerId: string;
        publicKey: string;
    }>;
    lastError?: string;
    retryable: boolean;
    retryAfter: number;
}
export declare const pendingMessageView: (row: OutboxManifest) => PendingMessage;
export declare const persistOutboundReceipt: (receipt: OutboxReceipt) => Promise<boolean>;
export declare const persistOutboundCancellation: (receipt: Omit<OutboxReceipt, "chunkIndex" | "cancelled">) => Promise<boolean>;
export declare class OutboxOwnershipLostError extends Error {
    constructor();
}
/** Stop lease renewal synchronously on identity replacement / terminal signaling refusal. */
export declare const stopOutboxOwners: (_reason?: string, roomId?: string) => void;
export interface OutboxSession {
    lease: OutboxLease;
    signal: AbortSignal;
    finish(): void;
}
/** Local deadline prevents a suspended old tab sending before its renewal notices a fence. */
export declare const startOutboxSession: (lease: OutboxLease, roomId: string, leaseUntil: number, parentSignal: AbortSignal, stillAuthorized: () => boolean) => OutboxSession;
export declare const discardRoomOutbox: (roomId: string) => Promise<void>;
export declare const sweepTransferStorage: () => Promise<string[]>;
export declare const sweepTransferStorageDetails: (canSweep?: () => boolean) => Promise<import("../db/types").ExpiredReceiveTransfer[]>;
/** Exact IDs cancel synchronously; hash/root selectors validate ambiguity first. */
export declare const discardPendingSelection: (selection: {
    roomId: string;
    senderPublicKey: string;
    transferId?: string;
    merkleRootHex?: string;
    hashHex?: string;
}, abortLive: () => void, request?: (request: OutboxRequest) => Promise<OutboxResponse>) => Promise<void>;
