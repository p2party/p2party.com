/**
 * Call `listener` after every change to this edge's transfer state: a newly
 * acknowledged chunk, completion, cancellation, or a clear. It is a wake-up,
 * not a value: the listener reads the state it cares about. Returns the
 * unsubscribe, which a wait must call when it settles.
 */
export declare const onTransferProgress: (roomId: string, peerId: string, transferId: string, listener: () => void) => (() => void);
/**
 * Record that a frame for this transfer arrived from this peer. Called where
 * an authenticated receipt is first attributed to its transfer, before it is
 * checked against the have-set (a repeat changes nothing there).
 */
export declare const noteTransferActivity: (roomId: string, peerId: string, transferId: string) => void;
/** Call `listener` on every noteTransferActivity for this edge's transfer. */
export declare const onTransferActivity: (roomId: string, peerId: string, transferId: string, listener: () => void) => (() => void);
export declare const markChunkAcked: (roomId: string, peerId: string, transferId: string, chunkIndex: number) => boolean;
export declare const getAckedChunks: (roomId: string, peerId: string, transferId: string) => Set<number>;
/** Constant-time membership without allocating one Set copy per scheduled cell. */
export declare const hasChunkAcked: (roomId: string, peerId: string, transferId: string, chunkIndex: number) => boolean;
export declare const getAckedChunkCount: (roomId: string, peerId: string, transferId: string) => number;
export declare const markTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
export interface PeerTransferOutcome {
    readonly roomId: string;
    readonly peerId: string;
    readonly transferId: string;
    readonly ackedChunks: ReadonlySet<number>;
    readonly complete: boolean;
}
/** Accurate, defensive per-peer delivery state for UI/diagnostics consumers. */
export declare const getPeerTransferOutcome: (roomId: string, peerId: string, transferId: string) => PeerTransferOutcome;
export declare const isTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
/** A recipient's refusal is terminal only for this edge, never the whole send. */
export declare const markTransferCancelled: (roomId: string, peerId: string, transferId: string) => boolean;
export declare const isTransferCancelled: (roomId: string, peerId: string, transferId: string) => boolean;
export interface TransferAck {
    readonly peerId: string;
    /**
     * Distinct chunks this peer has receipted so far, counting decoys: a receipt
     * is emitted per inbound frame, and the padding is what makes every frame
     * indistinguishable, so excluding it would report a fraction of a denominator
     * that includes it.
     */
    readonly ackedChunks: number;
    readonly complete: boolean;
}
/**
 * Live outbound progress for one logical send, per peer.
 *
 * The sender already knows this -- every receipt lands in the have-set above --
 * but nothing outside this module could read it, so a UI could say "sending"
 * and then nothing at all until the transfer settled. On a large file that is
 * a progress bar's worth of silence.
 *
 * Derived from the same state selective retransmit uses, so it cannot drift
 * from what the sender actually believes was delivered. Read-only and
 * defensively copied; polling it never affects the transfer.
 */
export declare const getTransferAcks: (roomId: string, transferId: string) => TransferAck[];
export declare const clearTransfer: (roomId: string, peerId: string, transferId: string) => void;
/** The clock a transfer wait arms its timers on; injectable for tests. */
export interface TransferWaitClock {
    readonly now: () => number;
    readonly setTimeout: (callback: () => void, ms: number) => unknown;
    readonly clearTimeout: (handle: unknown) => void;
}
export declare const transferWaitClock: TransferWaitClock;
export interface CompletionWaitDependencies {
    readonly clock?: TransferWaitClock;
    /** How the wait is woken; `onTransferProgress` in production. */
    readonly subscribe?: typeof onTransferProgress;
}
/**
 * Wait up to timeoutMs for this edge's transfer to complete. Woken by the
 * final receipt (markTransferComplete), a refusal (markTransferCancelled) or
 * an abort, with a COMPLETION_WAIT_FALLBACK_MS re-check in case a wake-up is
 * lost. Resolves true only when complete and not aborted.
 *
 * It does not end early when the channel closes, as the 200 ms poll it
 * replaces did not: a final receipt already read off a closing channel is
 * still being persisted when `close` fires, and only lands in this state
 * after that.
 */
export declare const waitForCompletion: (roomId: string, peerId: string, transferId: string, timeoutMs: number, signal?: AbortSignal, dependencies?: CompletionWaitDependencies) => Promise<boolean>;
/**
 * The longest a sender waits for the final receipt of a fully acknowledged
 * transfer while its receiver keeps reporting: the file at
 * MIN_RECEIVER_VERIFY_BYTES_PER_SECOND, plus the silence bound.
 */
export declare const reportedCompletionCapMs: (totalSize: number, silenceMs: number) => number;
export interface ReportedCompletionOptions {
    /** End once this long has passed without any activity. */
    readonly silenceMs: number;
    /** End at the latest this long after the wait starts. */
    readonly capMs: number;
    /** Subscribe to the frames that show the receiver is still at work. */
    readonly onActivity: (wake: () => void) => () => void;
    /**
     * Subscribe to what can end the wait at once — the transfer's channel
     * closing, the edge being replaced. An event only wakes the wait: it ends
     * when `isInterrupted` holds, which is also read before the wait starts.
     */
    readonly onInterrupt?: (interrupt: () => void) => () => void;
    readonly isInterrupted?: () => boolean;
    /** While true, silence does not accrue (a suspended sender schedule). */
    readonly isHeld?: () => boolean;
    readonly signal?: AbortSignal;
    readonly clock?: TransferWaitClock;
    /** How the wait learns of completion; `onTransferProgress` in production. */
    readonly subscribe?: typeof onTransferProgress;
}
/** A timer delay a platform honours: a longer one fires at once. */
export declare const clampTimerDelayMs: (delayMs: number) => number;
/**
 * Run `callback` once `clock`'s timers have run for `delayMs`, however long
 * that is: a delay above MAX_TIMER_DELAY_MS is armed in clamped steps, each
 * re-armed for the remainder. The remainder is counted in the timers' own
 * time, never read off the wall clock, so a wall clock stepped backwards does
 * not hold the callback back. Returns the cancel.
 */
export declare const armTimer: (clock: TransferWaitClock, callback: () => void, delayMs: number) => (() => void);
/**
 * Wait for the final receipt of a transfer whose every chunk is acknowledged,
 * for as long as the receiver shows it is still at work.
 *
 * Each activity re-arms the silence bound. The wait ends on the final receipt
 * (true); a refusal, an abort or an interrupt, at once (false); `silenceMs`
 * without activity (false); or at the cap (false). It checks again at least
 * every REPORTED_COMPLETION_CHECK_MS, its timers armed through armTimer.
 *
 * A check is late when it runs more than REPORTED_COMPLETION_CHECK_MS after
 * its timer was due: the page ran nothing in between (it was frozen, asleep
 * or offline, or its timers are throttled). That time never counts as
 * silence: a late check restarts the silence clock, as every check does while
 * `isHeld` holds.
 *
 * The cap is fixed when the wait starts, `capMs` later on the clock, and moves
 * at most once: the first late check that finds it passed (a timer's, or a
 * receipt's) extends it to that check plus one silence bound, so a final
 * receipt queued behind the thaw can still arrive. Nothing else moves it, and
 * receipts after the cap never do.
 *
 * So on a page whose timers fire up to P after they are due, the wait ends no
 * later than one silence bound and two periods after the cap: the first check
 * at or past the cap runs within P of it and, if late, leaves one silence
 * bound, which a check sees within P of its end. With P at most
 * REPORTED_COMPLETION_CHECK_MS no check is late, and the wait ends within P of
 * the cap. On a page throttled to one wake-up every P above twice
 * REPORTED_COMPLETION_CHECK_MS (a hidden page, once a minute) every timer
 * check but the wait's first is late. That first one runs on time only within
 * twice REPORTED_COMPLETION_CHECK_MS of the wait's start, and a check a
 * receipt runs counts the receipt as activity, so with a silence bound longer
 * than that (every bound here is at least RECEIVER_SILENCE_LIMIT_MS) silence
 * never ends the wait: a receiver that goes silent there is detected only
 * through the cap, within one silence bound and two periods of it.
 */
export declare const waitForReportedCompletion: (roomId: string, peerId: string, transferId: string, options: ReportedCompletionOptions) => Promise<boolean>;
