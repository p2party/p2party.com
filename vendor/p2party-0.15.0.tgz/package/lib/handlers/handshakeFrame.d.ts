import type { RoomPqMode } from "../roomPolicy";
/**
 * Internal handshake sub-frame tags carried inside FRAME_TYPE_HANDSHAKE.
 * The tag byte is also the causal step number.
 */
export declare const HANDSHAKE_STEP: Readonly<{
    readonly HELLO: 1;
    readonly CONFIRM: 2;
    readonly FINISH: 3;
}>;
export type HandshakeStep = (typeof HANDSHAKE_STEP)[keyof typeof HANDSHAKE_STEP];
/** Exact handshake payload lengths, including the one-byte step tag. */
export declare const HANDSHAKE_PAYLOAD_LENGTHS: Readonly<{
    "hybrid-mlkem512": Readonly<Record<HandshakeStep, number>>;
    "hybrid-mlkem768": Readonly<Record<HandshakeStep, number>>;
    "hybrid-mlkem1024": Readonly<Record<HandshakeStep, number>>;
}>;
export declare const handshakePayloadLengthForStep: (step: HandshakeStep, pqMode?: RoomPqMode) => number;
/** Source-derived upper bound across every step and supported room PQ mode. */
export declare const MAX_HANDSHAKE_PAYLOAD_LENGTH: number;
/**
 * Fail-closed pre-auth framing check used before a payload enters a handshake
 * inbox. The crypto core repeats this check when parsing each flight.
 */
export declare const isHandshakePayloadForStep: (payload: Uint8Array, step: HandshakeStep, pqMode?: RoomPqMode) => boolean;
