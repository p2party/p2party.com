import { persistOutboundCancellation } from "./outbox";
import type { OutboxLease } from "../db/outboxTypes";
import { type PollClock } from "../utils/waitForOpen";
import { onTransferActivity } from "./reconcile";
import type { TransferWaitClock } from "./reconcile";
import type { IRTCDataChannel, IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { MerkleProofLevelsBuildOptions } from "../cryptography/merkle";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
import type { MessageChunkSealer } from "./messageChunkCrypto";
import type { NewChunk } from "../db/types";
import type { Metadata } from "../utils/metadata";
import type { RatchetHeader } from "../cryptography/ratchet";
import type { RatchetGateLease } from "./ratchetGate";
import type { ScheduledDeliveryWaitOptions } from "./coverTransfer";
import type { CoverSchedulerStatus } from "./coverScheduler";
import type { RoomPolicyV1 } from "../roomPolicy";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
export declare const SEND_RECEIPT_WINDOW: number;
export declare const SEND_WINDOW_STALL_MS = 10000;
export interface ReceiptWindowParams {
    readonly windowSize: number;
    readonly stallTimeoutMs: number;
    /** The longest the wait goes without re-checking on its own. */
    readonly fallbackMs: number;
    readonly isOpen: () => boolean;
    readonly inFlight: () => number;
    /**
     * Subscribe `wake` to what can end the wait — a receipt on this edge, the
     * channel leaving "open" — and return the unsubscribe.
     */
    readonly subscribe: (wake: () => void) => () => void;
    readonly signal?: AbortSignal;
    readonly clock?: TransferWaitClock;
}
/**
 * Resolve once in-flight drops below the window, the channel leaves "open",
 * or receipt progress stalls for stallTimeoutMs. Any receipt progress while
 * still over the window resets the stall clock. Throws only on transfer abort.
 *
 * Woken by `subscribe` (a receipt, a close) and by the abort signal; its one
 * timer fires only at the stall deadline or after fallbackMs without a
 * wake-up, never on a polling cadence.
 */
export declare const waitForReceiptWindow: (params: ReceiptWindowParams) => Promise<void>;
/** One edge's receipt count, and a way to be woken when it changes. */
export interface ReceiptProgress {
    readonly count: () => number;
    readonly subscribe: (wake: () => void) => () => void;
}
/** The receipts of one transfer edge, as reconcile records them. */
export declare const edgeReceiptProgress: (roomId: string, peerId: string, transferId: string) => ReceiptProgress;
/**
 * Where a sender's staged plaintext cells live: the durable `newChunks` store
 * the DB worker owns. Injectable so the read/write pattern of a send has a
 * focused unit test; production always uses the worker.
 */
export interface OutboundChunkStore {
    readonly get: (transferId: string, chunkIndex: number) => Promise<NewChunk | undefined>;
    readonly put: (chunk: NewChunk, lease?: OutboxLease) => Promise<void>;
}
export interface OutboundMessageParams {
    readonly transferId: string;
    readonly hashHex: string;
    readonly merkleRoot: Uint8Array;
    readonly totalChunks: number;
    /** The leaf hashes, totalChunks × 64 bytes, in chunk order. */
    readonly chunkHashes: Uint8Array;
    /** Hashes the tree's internal nodes when the proof levels are built. */
    readonly merkleModule: LibCrypto;
    readonly store?: OutboundChunkStore;
    /**
     * The clock the proof-level build's slices are timed on, and how it hands
     * the thread back between them. Production passes neither (performance.now,
     * a MessageChannel task); a test passes a counting clock.
     */
    readonly proofLevelBuild?: Pick<MerkleProofLevelsBuildOptions, "now" | "yieldToEventLoop">;
}
/** One staged cell, read once, with what its own metadata says it is. */
export interface StagedOutboundChunk {
    readonly index: number;
    readonly row: NewChunk;
    readonly metadataArray: Uint8Array;
    readonly metadata: Metadata;
    /** Real bytes, not padding. A decoy has chunkEnd − chunkStart > totalSize. */
    readonly real: boolean;
}
/**
 * Everything a sender knows about one logical message for as long as that
 * message is being delivered, shared by every peer's transfer of it.
 *
 * Its Merkle proof levels are built at most once — on the first cell whose
 * staged row has no proof yet — and serve every chunk, every retransmit round
 * and every peer in O(log N). The previous path called `getMerkleProof` per
 * chunk, which rebuilds the whole tree each time (about 51 ms at 19,270
 * leaves). A resume after a page reload builds them once from the leaves the
 * outbox claim returned, and only if some chunk still lacks a stored proof.
 *
 * The build targets PROOF_LEVEL_BUILD_SLICE_MS per slice, handing the
 * page back between them, so a cover wake-up due meanwhile is not held for
 * the build (about 2.5 µs a leaf). Every cell that needs a proof while it runs
 * awaits the same build; a scheduled slot whose cell is still waiting sends
 * its dummy, on time, and the chunk takes a later slot of its lane.
 *
 * It also remembers which cells a read showed to be decoys, so a retransmit
 * pass skips them without reading them again.
 *
 * `close()` drops both, and stops a build still running at its next slice.
 * `withOutboundMessage` owns that call; after it nothing is rebuilt.
 */
export declare class OutboundMessage {
    #private;
    readonly transferId: string;
    readonly hashHex: string;
    readonly merkleRoot: Uint8Array;
    readonly merkleRootHex: string;
    readonly totalChunks: number;
    constructor(params: OutboundMessageParams);
    get closed(): boolean;
    /**
     * Bytes the proof levels hold, built or being built; zero before the build
     * starts, once every cell carries its proof, and once a build stopped by
     * `close()` has reached its next slice.
     */
    get proofLevelBytes(): number;
    /** True once a read of this cell showed it is padding. */
    isKnownDecoy(index: number): boolean;
    /** The message's size in bytes, as its cells' metadata states it; 0 before any read. */
    get totalSize(): number;
    /**
     * True once every cell has been read and every real one is acknowledged:
     * the receiver holds the whole file. False while any cell's kind is unknown.
     */
    allRealsAcknowledged(isAcked: (index: number) => boolean): boolean;
    /** Read one staged cell from storage and check it belongs at `index`. */
    read(index: number, signal?: AbortSignal): Promise<StagedOutboundChunk | undefined>;
    /**
     * The DECRYPTED_LEN plaintext (metadata ‖ proof ‖ chunk) for one staged
     * cell. Its proof and scoped receipt token are persisted BEFORE the frame
     * can go on the wire: if quota/storage fails, propagating the error is the
     * only recoverable behaviour, because a sent frame whose resend source was
     * not committed can never take part in reconnect reconciliation.
     */
    cellPlaintext(staged: StagedOutboundChunk, outboxLease?: OutboxLease, signal?: AbortSignal): Promise<Uint8Array>;
    /**
     * Drop the proof levels and the decoy map, and stop a build still running:
     * it does no more work after its current slice, and drops what it built
     * then. Idempotent.
     */
    close(): void;
}
/**
 * Run one delivery of one message — every peer's transfer, immediate or
 * scheduled — against a single `OutboundMessage`, and close it however the
 * delivery ends: completion, the receiver's final receipt, a cancel, a torn
 * down edge, a left room. Each of those settles `deliver`.
 */
export declare const withOutboundMessage: <T>(params: OutboundMessageParams, deliver: (message: OutboundMessage) => Promise<T>) => Promise<T>;
/** The part of a data channel the send-buffer wait reads and listens to. */
export interface SendBufferChannel {
    readonly readyState: string;
    readonly bufferedAmount: number;
    bufferedAmountLowThreshold: number;
    addEventListener(type: string, listener: () => void): void;
    removeEventListener(type: string, listener: () => void): void;
}
export interface SendBufferTimers {
    readonly setTimeout: (callback: () => void, ms: number) => unknown;
    readonly clearTimeout: (handle: unknown) => void;
}
/**
 * Wait until `channel` can take another frame. Resolves true at once while
 * its buffer is below MAX_BUFFERED_AMOUNT; otherwise sets the low threshold
 * and waits for `bufferedamountlow`. Resolves false once the channel is no
 * longer open (the caller stops this pass, as the polling loop's caller did),
 * and rejects with the transfer's abort reason when `signal` aborts.
 *
 * The listeners are registered before the amount is re-checked, and a
 * SEND_BUFFER_FALLBACK_MS timer re-checks it after that, so a drain the event
 * did not report still ends the wait.
 */
export declare const waitForSendBuffer: (channel: SendBufferChannel, signal?: AbortSignal, timers?: SendBufferTimers) => Promise<boolean>;
/** The transfer's own channel, as the immediate-mode completion wait reads it. */
export interface TransferFrameSource {
    /** Only "closing" and "closed" end the wait; absent reads as open. */
    readonly readyState?: string;
    addEventListener(type: string, listener: () => void): void;
    removeEventListener(type: string, listener: () => void): void;
}
/**
 * Immediate mode, every chunk acknowledged: wait for the final receipt while
 * the receiver verifies the whole file. Any frame on the transfer's own
 * channel (a re-sent receipt) re-arms the RECEIVER_SILENCE_LIMIT_MS bound;
 * the wait is capped at reportedCompletionCapMs(totalSize). Only this peer
 * can send on that channel, and only about this transfer.
 *
 * The channel closing ends the wait at once: a close is the edge going away
 * or the receiver's cancel, and the caller handles it as it handles any close
 * (resume, or the cancel outcome).
 */
export declare const waitForVerifiedDelivery: (channel: TransferFrameSource, roomId: string, peerId: string, transferId: string, totalSize: number, options?: {
    readonly signal?: AbortSignal;
    readonly clock?: TransferWaitClock;
}) => Promise<boolean>;
/**
 * Scheduled mode, every chunk acknowledged: the same wait, re-armed by each
 * authenticated scheduled receipt for this transfer as coverEdge attributes
 * it (noteTransferActivity). `silenceMs` is the caller's: a scheduled receipt
 * can arrive only in a cover slot, so the bound is at least the schedule's
 * own delivery idle budget. `onInterrupt`/`isInterrupted` end it at once for
 * an edge that was replaced or torn down.
 */
export declare const waitForScheduledVerifiedDelivery: (roomId: string, peerId: string, transferId: string, totalSize: number, silenceMs: number, options?: {
    readonly onInterrupt?: (interrupt: () => void) => () => void;
    readonly isInterrupted?: () => boolean;
    readonly isHeld?: () => boolean;
    readonly signal?: AbortSignal;
    readonly clock?: TransferWaitClock;
    readonly subscribeActivity?: typeof onTransferActivity;
}) => Promise<boolean>;
/**
 * The wait between retransmit rounds of an immediate transfer. While a real
 * chunk is unacknowledged it is the round's fixed RETRANSMIT_TIMEOUT_MS wait;
 * once every chunk is acknowledged it is waitForVerifiedDelivery, and
 * `verifying` tells the caller there is nothing left to retransmit.
 */
export declare const waitForTransferConfirmation: (message: OutboundMessage, channel: TransferFrameSource, roomId: string, peerId: string, retries: number, signal?: AbortSignal, clock?: TransferWaitClock) => Promise<{
    readonly done: boolean;
    readonly verifying: boolean;
}>;
/**
 * One pass over a message's cells on one per-message channel, in a fresh
 * random order.
 *
 * Without `reconcileAcked` (the first pass) every cell, real and decoy, is
 * read once and sent once. With it (a retransmit or resume pass) only the real
 * cells the receiver has not acknowledged are sent, and a cell already known
 * to be acknowledged or a decoy is skipped before it is read.
 *
 * Exported only for a focused unit test of that read and proof pattern. It is
 * not part of the package's public root exports.
 */
export declare const sendChunks: (channel: IRTCDataChannel, sealer: MessageChunkSealer, message: OutboundMessage, signal?: AbortSignal, reconcileAcked?: Set<number>, receipts?: ReceiptProgress, outboxLease?: OutboxLease) => Promise<void>;
/**
 * Is this connection a transport a resumed transfer may open its per-message
 * channel on?
 *
 * `connectionState === "connected"` alone means DTLS is complete — it says
 * nothing about the main-channel handshake. Opening the per-message channel on
 * such a transport is what let the peer's replayed receipts arrive ahead of
 * THIS side's ratchet gate: the identity responder authenticates on SENDING
 * finish and replays immediately, while the initiator authenticates on
 * RECEIVING it, one IndexedDB persist later (C7). Requiring the gate to be
 * open, on this connection's own lease, removes that window at its source
 * instead of relying on the receiving guard to park the early frame.
 *
 * Not finding one is not fatal: the caller polls until its resume budget runs
 * out, which is exactly what it already did for a transport that had not
 * reconnected yet.
 */
export declare const isResumableAuthenticatedTransport: (candidate: IRTCPeerConnection, roomId: string, peerId: string) => boolean;
interface TransferCipher {
    epc: IRTCPeerConnection;
    /**
     * Gate lease of the ratchet generation `messageKey`/`header` were derived
     * from. An in-place re-bind (remoteTransportChange) keeps the
     * RTCPeerConnection and replaces this lease, so the epc identity alone does
     * NOT identify the crypto generation.
     */
    lease?: RatchetGateLease;
    messageKey: Uint8Array;
    header: RatchetHeader;
    /**
     * OWNED copy of the PQ message context captured in the same edge
     * transaction as the ratchet step (v4). Null only on runtime-free
     * bootstrap/test edges. Wiped with the message key.
     */
    pqContext?: PqMessageKeyContext | null;
}
/**
 * Stop a per-message transport without depending on its eventual `close`
 * event to release protocol accounting. This also covers cancellation while
 * the SCTP stream is still connecting and has not entered `dataChannels`.
 */
export declare const closeTransferChannel: (channel: IRTCDataChannel) => void;
/**
 * Own the one normal terminal close for a message-scoped channel. Receipt
 * handling only records authenticated completion; sendWithReconcile reaches
 * this boundary after its send/reconcile work settles.
 */
export declare const runWithTerminalChannelClose: <T>(currentChannel: () => IRTCDataChannel, operation: () => Promise<T>) => Promise<T>;
type WaitForRatchetGate = (roomId: string, peerId: string, signal?: AbortSignal) => Promise<void>;
type DurableRatchetStep = (epc: IRTCPeerConnection, roomId: string, module: LibCrypto) => Promise<{
    messageKey: Uint8Array;
    header: RatchetHeader;
    pqContext: PqMessageKeyContext | null;
}>;
/**
 * Bind an in-flight message to the active cryptographic transport.
 *
 * Reopening only its DataChannel on the same RTCPeerConnection AND the same
 * ratchet generation retains the session, so the per-message key/header remain
 * valid. Anything else — a replacement RTCPeerConnection, or the same one
 * re-bound in place onto a new remote DTLS certificate — performs a fresh
 * hybrid handshake and owns an unrelated ratchet. It must wait for that
 * generation's gate, advance its ratchet once and reseal the missing plaintext
 * chunks; replaying the old ciphertext/key/header cannot decrypt.
 *
 * The generation is identified by the gate lease, NOT by the connection: an
 * in-place re-bind keeps the very same epc while wiping its ratchet, PQ
 * runtime and message keys. Treating that as "same transport" would keep
 * sealing with a dead key and, worse, push frames onto an edge whose gate is
 * still closed — which the receiver can only reject as application data before
 * peer authentication, closing the channel and cascading into the edge.
 *
 * Exported only so the transport-identity and key-erasure contract has a focused
 * unit test. It is not part of the package's public root exports.
 */
export declare const bindTransferCipherToConnection: (transfer: TransferCipher, nextEpc: IRTCPeerConnection, roomId: string, module: LibCrypto, waitForGate?: WaitForRatchetGate, ratchetStep?: DurableRatchetStep, signal?: AbortSignal) => Promise<TransferCipher>;
/**
 * True iff a per-message channel closing is the PEER cancelling this transfer.
 *
 * Immediate mode has no CANCEL frame: one DataChannel is one logical message,
 * so its close IS the signal — but only when nothing on OUR side retired it.
 * Three things must hold: the RTCPeerConnection is still connected, it is
 * still the registered transport for this room/peer, and the ratchet
 * generation the transfer was sealed under is still the current one.
 *
 * That last test is what separates a remote cancel from a local retirement.
 * An in-place edge re-bind (remoteTransportChange) closes the generation's
 * message channels while KEEPING the connection connected and registered, so
 * the first two tests still pass; the gate lease it replaces is the only
 * evidence that the close was ours. Without it the sender abandons a perfectly
 * resumable transfer — and reports "cancelled by peer", which an application
 * may act on by deleting its outgoing message. Mirrors the receiver's
 * `authenticatedTransportStillAlive` test in handleOpenChannel.
 */
export declare const isAuthenticatedPeerCancel: (currentEpc: IRTCPeerConnection, peerConnections: IRTCPeerConnection[], roomId: string, peerId: string, transferGateLease: RatchetGateLease | undefined, currentChannel: IRTCDataChannel | undefined) => boolean;
/**
 * A resumed transfer failed to re-bind onto the transport it resumed on: is
 * another of its bounded resume attempts owed?
 *
 * The normal reason is that the transport was REPLACED before its gate could
 * open — an unauthenticated transport is granted at most one in-place re-bind
 * (decideRemoteTransportChangeResponse), and the replacement tears the old one
 * down, which rejects the gate every awaiter is sitting on. The peer is coming
 * back on the replacement, so giving up here would abandon a transfer that is
 * one attempt away from finishing.
 *
 * Two failures are terminal. A cancelled transfer resumes nothing. And a
 * gate-wait TIMEOUT means nothing replaced anything: the peer simply never
 * opened a handshake within the budget (a stale authenticated view), so
 * another attempt only buys another full budget of the same wait — the same
 * reason the send's first gate wait rethrows it.
 */
export declare const isResumableRebindFailure: (error: unknown, signal?: AbortSignal) => boolean;
export interface PeerSendTarget {
    peerId: string;
    epc?: IRTCPeerConnection;
}
export type PeerDeliveryOutcome = {
    peerId: string;
    status: "delivered";
} | {
    peerId: string;
    status: "failed";
    phase: "setup" | "transfer";
    reason: unknown;
} | {
    peerId: string;
    status: "skipped";
    reason: "not-connected" | "cover-unavailable" | "unauthenticated" | "cancelled";
};
export interface PeerSendFanoutResult {
    outcomes: PeerDeliveryOutcome[];
    startedTransfers: number;
}
type OpenPeerTransferChannel = (target: Required<PeerSendTarget>) => Promise<IRTCDataChannel>;
type StartPeerTransfer = (target: Required<PeerSendTarget>, channel: IRTCDataChannel) => Promise<void>;
/**
 * Set up every eligible room edge and settle every transfer that was started.
 *
 * Opening channels remains sequential so it cannot burst through the per-edge
 * channel budget. Transfer promises run concurrently, however, and are given a
 * rejection handler immediately. A later setup failure therefore becomes that
 * peer's outcome instead of unwinding past already-running sends and freeing
 * their shared `newChunks` staging records.
 */
export declare const runPeerSendFanout: (targets: readonly PeerSendTarget[], openChannel: OpenPeerTransferChannel, startTransfer: StartPeerTransfer, signal?: AbortSignal, onTransferStarted?: () => void) => Promise<PeerSendFanoutResult>;
export interface SendMessageResult extends PeerSendFanoutResult {
    transferId: string;
    merkleRootHex: string;
}
export declare class MessageDeliveryError extends AggregateError {
    readonly result: SendMessageResult;
    constructor(result: SendMessageResult, message: string);
}
/**
 * The sender's history is independent of remote delivery once splitToChunks
 * has committed its complete local copy. Network/setup failures may annotate
 * delivery status, but only an explicit local cancel removes that history.
 */
export declare const shouldDeleteLocalMessageAfterFailure: (localMessageCommitted: boolean, wireWorkStarted: boolean, explicitlyCancelled: boolean) => boolean;
/**
 * Test/fault-injection seams for `sendWithReconcile`, the same shape as
 * `ScheduledSendDependencies`. Production passes none of them.
 */
export interface ImmediateSendDependencies {
    readonly ratchetStep?: DurableRatchetStep;
    /** Remove an older runtime's ciphertext queue for this channel. */
    readonly deleteSendQueue?: (label: string, peerId: string) => Promise<void>;
    readonly persistCancellation?: typeof persistOutboundCancellation;
    /** How long a resume watches for the peer's replacement connection. */
    readonly resumeTimeoutMs?: number;
    /**
     * The clock of that resume watch and of its channel-open wait, apart from
     * the confirmation clock below; the browser's by default.
     */
    readonly resumeClock?: PollClock;
    /** The clock of the waits between retransmit rounds. */
    readonly clock?: TransferWaitClock;
}
/**
 * One peer's immediate-mode transfer of one message, as described above.
 * Exported only so its completion and close handling have focused tests. It is
 * not part of the package's public root exports.
 */
export declare const sendWithReconcile: (channel: IRTCDataChannel, api: BaseQueryApi, roomId: string, epc: IRTCPeerConnection, message: OutboundMessage, peerId: string, encryptionModule: LibCrypto, peerConnections: IRTCPeerConnection[], dataChannels: IRTCDataChannel[], signal?: AbortSignal, outboxLease?: OutboxLease, dependencies?: ImmediateSendDependencies) => Promise<void>;
export declare const makeScheduledSlotSealer: (message: OutboundMessage, chunkSealer: MessageChunkSealer, jobRetired: () => boolean, outboxLease?: OutboxLease, signal?: AbortSignal) => (chunkIndex: number) => Promise<Uint8Array | null>;
/**
 * Can this edge's cover runtime still admit a scheduled job?
 *
 * A scheduled job is dequeued only at a cycle open, and `CoverScheduler`
 * refuses to open one while suspended or stopped. Enqueuing into either and
 * then awaiting the schedule-derived delivery bound burns that whole budget —
 * 321 s on the shipped "5 min cycles" preset — for a job nothing was going to
 * send, and the whole send's result waits for every peer's outcome, so it
 * holds up the send for every peer in the room.
 *
 * "starting" and "degraded" both still open every subsequent cycle and both
 * still admit. Since C5 "degraded" is where a late or failed boundary lands,
 * so rejecting it here would turn one browser stall into a room that can never
 * send again — the same outcome, moved one layer up.
 */
export declare const coverRuntimeAdmitsScheduledJobs: (runtime: {
    readonly status: CoverSchedulerStatus;
} | undefined) => boolean;
/**
 * Test/fault-injection seams for `sendScheduled`. Production passes none of
 * them; they exist so the resume loop can be driven without a durable ratchet
 * write, a real gate, or a schedule-derived wall-clock wait. Same shape as
 * `bindTransferCipherToConnection`'s trailing defaults.
 */
export interface ScheduledSendDependencies {
    readonly waitForGate?: WaitForRatchetGate;
    readonly ratchetStep?: DurableRatchetStep;
    readonly waitForDelivery?: (options: ScheduledDeliveryWaitOptions, peerId: string) => Promise<boolean>;
    /** How long to watch for a replacement cover runtime before giving up (C8). */
    readonly resumeWaitMs?: number;
    /** The clock of the wait while the receiver verifies the file. */
    readonly clock?: TransferWaitClock;
    /** How that wait hears of receipts; `onTransferActivity` in production. */
    readonly subscribeActivity?: typeof onTransferActivity;
}
/**
 * Scheduled-cover send: instead of opening a per-message DataChannel and
 * bursting, step the ratchet once for the message and enqueue a lazy cover job
 * on each peer edge's cover runtime. The scheduler substitutes one chunk cell
 * per slot into the already-running cover lanes; the tail is dummy. Delivery is
 * confirmed by the receiver's terminal scheduled receipt (markTransferComplete).
 *
 * A send survives its edge being replaced. Every recovery path destroys the
 * cover runtime, which settles and deletes every job it holds and (since C3)
 * wipes the message key at that settlement; the replacement runtime starts
 * empty. So the retired job cannot be carried across — its key is already zero,
 * and even a live one belongs to a ratchet generation the peer has thrown away.
 * The send is instead RE-DERIVED on the replacement generation and re-offered,
 * exactly as `bindTransferCipherToConnection` does for immediate mode (C8).
 */
export declare const sendScheduled: (roomId: string, channelLabel: string, policy: RoomPolicyV1, targets: readonly PeerSendTarget[], message: OutboundMessage, encryptionModule: LibCrypto, signal?: AbortSignal, onTransferStarted?: () => void, 
/**
 * The room's LIVE connection array. A replacement RTCPeerConnection is a
 * different object, so `target.epc` is stale the moment the edge is rebuilt;
 * this is where the resume finds the transport that replaced it, exactly as
 * `resumeChannel` does on the immediate-mode path.
 */
peerConnections?: readonly IRTCPeerConnection[], dependencies?: ScheduledSendDependencies, outboxLease?: OutboxLease) => Promise<PeerSendFanoutResult>;
export declare const handleSendMessage: (data: string | File | undefined, api: BaseQueryApi, label: string, roomId: string, peerConnections: IRTCPeerConnection[], dataChannels: IRTCDataChannel[], encryptionModule: LibCrypto, merkleModule: LibCrypto, transferId: string, minChunks?: number, chunkSize?: number, percentageFilledChunk?: number, metadataSchemaVersion?: number) => Promise<SendMessageResult | undefined>;
export {};
