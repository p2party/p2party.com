import type { RatchetState, RatchetHeader } from "../cryptography/ratchet";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
/**
 * Per-message key-cache key. Production passes the parsed epoch explicitly and
 * gets an epoch-bound `(dhPub,N,epoch)` identity. Omitting the epoch preserves
 * the legacy low-level `dhPub:N` identity for raw/bootstrap tests only; this is
 * needed while those tests still round-trip keys through RatchetState.skipped,
 * whose historical serializer understands exactly that two-field shape.
 */
export declare const messageCacheKey: (dhPub: Uint8Array, N: number, pqEpoch?: bigint) => string;
/**
 * Seals the chunks of one logical message. The v4 combined key depends only
 * on the classical message key, the header and the PQ context, which every
 * chunk of a message shares, so it is derived once here, not once per chunk.
 */
export interface MessageChunkSealer {
    /** Seal one chunk under the message's combined key with a fresh nonce. */
    readonly seal: (chunk: Uint8Array, merkleRoot: Uint8Array) => Uint8Array;
    /** Zero the combined key. Idempotent; a later `seal` throws. */
    readonly wipe: () => void;
}
/**
 * Derive the combined key for one message: the send paths call this once per
 * ratchet step and seal every chunk, retransmit round included, through it.
 *
 * Every protocol-v4 message key is PQ-combined, so a missing context throws
 * instead of falling back to the raw classical ratchet key; the classical-only
 * path is `sealChunkClassicalOnlyForTests`, which production never calls.
 * An owned copy of `messageKey` is consumed, so the caller's classical key
 * stays live; the caller keeps owning and wiping it and the context.
 */
export declare const createMessageChunkSealer: (messageKey: Uint8Array, header: RatchetHeader, pqContext: PqMessageKeyContext | null, module: LibCrypto) => MessageChunkSealer;
/**
 * Seal ONE chunk under an already-derived classical `messageKey` + `header`
 * and the PQ context: derive the combined key, seal, wipe it. For a message
 * of several chunks, `createMessageChunkSealer` derives the key once instead.
 * The caller's classical key remains live. A retransmit re-seals the same
 * plaintext under the same key with a fresh random nonce, which the
 * receiver's cached per-message key opens.
 */
export declare const sealChunk: (messageKey: Uint8Array, header: RatchetHeader, chunk: Uint8Array, merkleRoot: Uint8Array, module: LibCrypto, pqContext: PqMessageKeyContext) => Uint8Array;
/**
 * TESTS ONLY. Seals under the raw classical ratchet key with no PQ combiner,
 * at wire epoch 0: a key an adversary who breaks X25519 can derive.
 * Production send paths seal through `createMessageChunkSealer` with a PQ
 * context. Only this module references it in src/;
 * tests/handlers/messageChunkCrypto.test.ts enforces that.
 */
export declare const sealChunkClassicalOnlyForTests: (messageKey: Uint8Array, header: RatchetHeader, chunk: Uint8Array, merkleRoot: Uint8Array, module: LibCrypto) => Uint8Array;
export interface DecryptedChunk {
    /** The DECRYPTED_LEN plaintext `metadata ‖ receiptLeaf ‖ chunk` written by the C
     *  receive, or `null` when the chunk was dropped (AEAD or Merkle failure). */
    decrypted: Uint8Array | null;
    /** True iff C returned 0 — AEAD **and** Merkle both passed. When false the caller
     *  drops the chunk (but still persists the ratchet if `stateAdvanced`). */
    ok: boolean;
    /** True iff this chunk stepped the ratchet (first-arriving chunk of a message
     *  whose AEAD authenticated). The caller persists `state` when true — even if
     *  `ok` is false, since the DH step is real once the AEAD authenticates. */
    stateAdvanced: boolean;
}
/**
 * Resolve an authenticated, currently acceptable PQ epoch. Returning null
 * rejects unknown/stale/future epochs before a Double-Ratchet clone is touched.
 */
export type PqMessageKeyContextResolver = (epoch: bigint) => PqMessageKeyContext | null;
/**
 * RECEIVE one chunk frame: derive the per-message key off the ratchet (in TS —
 * the ratchet state is a TS object), then do ALL the crypto in ONE C call
 * (`receiveWithKey` → `_receive_message_with_key`: decrypt + leaf-hash + Merkle +
 * receipt, in place).
 *
 * Every protocol-v4 message key is PQ-combined, so the resolver is required.
 * A call without one fails closed (`ok: false`, state untouched) instead of
 * falling back to the raw classical ratchet key; the classical-only path is
 * `decryptMessageChunkClassicalOnlyForTests`, which production never calls.
 *
 * The production `cache` is caller-owned and keyed by
 * `messageCacheKey(dhPub,N,pqEpoch)`. It stores already-combined active receive
 * keys separately from classical skipped keys. On a HIT the key is reused
 * without touching the ratchet. On a MISS, the resolver must authorize the
 * epoch before the classical key is derived on a clone and combined.
 *
 * Clone-rollback (MANDATORY — `ratchetDecrypt` mutates BEFORE the AEAD
 * authenticates, so a replayed/old-chain header could otherwise fire a spurious
 * DH-step and desync the session):
 *   1. `clone = deserializeRatchet(serializeRatchet(state))`.
 *   2. `messageKey = ratchetDecrypt(clone, header)` — mutates the CLONE only.
 *   3. C decrypts+verifies. COMMIT (adopt the clone, cache the key) iff the AEAD
 *      authenticated (`code !== -2`); on `-2` DISCARD the clone — the live `state`
 *      is byte-for-byte untouched. `ok` (store-vs-drop) then follows `code === 0`.
 *
 * Cache lifecycle: the caller evicts a message's key (via `messageCacheKey`) when
 * the message completes (all leaves present) or on a TTL, so a peer can't pin keys
 * with never-completing messages.
 */
export declare const decryptMessageChunk: (state: RatchetState, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto, pqContextResolver: PqMessageKeyContextResolver) => DecryptedChunk;
/**
 * TESTS ONLY. Decrypts under the raw classical ratchet key with no PQ
 * combiner, a key an adversary who breaks X25519 can derive. It accepts only
 * wire epoch 0 and uses the legacy two-field `dhPub:N` cache identity.
 * Production receive paths call `decryptMessageChunk` with a resolver. Outside
 * this module only ratchetPersist.ts references it, for an edge a test opted
 * in; tests/handlers/messageChunkCrypto.test.ts enforces that.
 */
export declare const decryptMessageChunkClassicalOnlyForTests: (state: RatchetState, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto) => DecryptedChunk;
