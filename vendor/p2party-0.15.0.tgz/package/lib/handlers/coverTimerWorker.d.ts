import type { CoverClock } from "./coverScheduler";
/** One request from the page to the timer worker. */
export type CoverTimerRequest = {
    readonly op: "arm";
    readonly id: number;
    readonly delayMs: number;
} | {
    readonly op: "cancel";
    readonly id: number;
} | {
    readonly op: "ping";
    readonly id: number;
};
/** What the worker posts back: a handle is due, or a ping's answer. */
export interface CoverTimerReply {
    readonly op: "fire" | "pong";
    readonly id: number;
}
/**
 * The worker, as source text. It is loaded from a Blob URL exactly as the
 * database worker is, so a page that admits that worker (`worker-src blob:`)
 * needs nothing new. It keeps no state but its own timer handles.
 */
export declare const COVER_TIMER_WORKER_SOURCE = "\"use strict\";\nconst timers = new Map();\nself.onmessage = (event) => {\n  const message = event.data;\n  if (message === null || typeof message !== \"object\") return;\n  if (!Number.isSafeInteger(message.id)) return;\n  if (message.op === \"arm\" && Number.isFinite(message.delayMs)) {\n    const previous = timers.get(message.id);\n    if (previous !== undefined) clearTimeout(previous);\n    timers.set(\n      message.id,\n      setTimeout(() => {\n        timers.delete(message.id);\n        self.postMessage({ op: \"fire\", id: message.id });\n      }, Math.max(0, message.delayMs)),\n    );\n  } else if (message.op === \"cancel\") {\n    const handle = timers.get(message.id);\n    if (handle !== undefined) {\n      clearTimeout(handle);\n      timers.delete(message.id);\n    }\n  } else if (message.op === \"ping\") {\n    self.postMessage({ op: \"pong\", id: message.id });\n  }\n};\n";
/** The surface of a dedicated Worker the host uses. */
export interface CoverTimerWorkerPort {
    onmessage: ((event: {
        readonly data: unknown;
    }) => void) | null;
    onerror: ((event: unknown) => void) | null;
    onmessageerror: ((event: unknown) => void) | null;
    postMessage(message: CoverTimerRequest): void;
    terminate(): void;
}
/** Where a host reads time and sets page timers, and how it makes a worker. */
export interface CoverTimerEnvironment {
    readonly now: () => number;
    readonly setTimeout: (callback: () => void, delayMs: number) => unknown;
    readonly clearTimeout: (handle: unknown) => void;
    /** Absent means no worker can exist here: page timers for good. */
    readonly createWorker?: () => CoverTimerWorkerPort;
    /**
     * True on a browser page, where being on page timers for good is reported
     * with console.warn. Elsewhere it goes to the debug log only.
     */
    readonly browserPage: boolean;
}
/** A CoverClock served by the page's shared timer host. */
export interface CoverTimerClock extends CoverClock {
    /** What drives this clock's wake-ups now. */
    readonly source: "worker" | "page";
    /** Cancel this clock's wake-ups and release the shared worker. */
    destroy(): void;
}
/** The browser's environment: one object per page, so one host per page. */
export declare const browserCoverTimerEnvironment: () => CoverTimerEnvironment;
/**
 * A CoverClock whose wake-ups come from the page's shared timer worker,
 * falling back to page timers where none can run. One per CoverRuntime;
 * destroy it with the runtime.
 */
export declare const createCoverTimerClock: (env?: CoverTimerEnvironment) => CoverTimerClock;
/**
 * What drives this page's scheduled-cover wake-ups now: its timer worker,
 * page timers (no worker can run, or it is being replaced), or nothing (no
 * scheduled-cover edge is open).
 */
export declare const getCoverTimerSource: (env?: CoverTimerEnvironment) => "worker" | "page" | "none";
/** Wake-ups the environment's host still holds (tests). */
export declare const pendingCoverTimerWakeUps: (env: CoverTimerEnvironment) => number;
