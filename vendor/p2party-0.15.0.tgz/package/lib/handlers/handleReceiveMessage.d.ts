import { abortReceivedFileVerification, getDBMessageData, onVerificationProgress, settleReceivedFileVerification, verifyReceivedFile } from "../db/api";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { ReceiveChunk, ReceiveChunkStoreFailure, ReceiveChunkStoreResult, ReceiveStorageFailure, ReceiveVerificationOutcome, ReceiveVerificationVerdict } from "../db/types";
import type { PersistRatchetState } from "./ratchetPersist";
export interface ReceiveMessageResult {
    date: Date;
    chunkSize: number;
    chunkIndex: number;
    receivedFullSize: boolean;
    fromPeerPublicKey?: string;
    chunkAlreadyExists: boolean;
    totalSize: number;
    messageType: number;
    filename: string;
    /** 64-byte root/index/leaf-bound receipt token (legacy field name). */
    chunkHash: Uint8Array;
    messageHash: Uint8Array;
    /**
     * Set when this chunk would complete a file: it is held, and the file must
     * be verified (verifyHeldFile, then settleHeldFile) before it is complete.
     */
    verification?: string;
}
type ReceiveChunkStore = (chunk: ReceiveChunk) => Promise<ReceiveChunkStoreResult>;
export interface ReceiveMessageDependencies {
    /** Test/fault-injection seam; production uses the ratchet worker database. */
    persistRatchetState?: PersistRatchetState;
    /** Test/fault-injection seam; production uses the receive-chunk worker. */
    storeReceiveChunk?: ReceiveChunkStore;
    /** Test seams for whole-file verification; production uses the worker. */
    closeReceiveFile?: (merkleRootHex: string) => Promise<void>;
    verifyReceivedFile?: typeof verifyReceivedFile;
    settleReceivedFileVerification?: typeof settleReceivedFileVerification;
    abortReceivedFileVerification?: typeof abortReceivedFileVerification;
    /** Test seam for the worker's verification progress reports. */
    onVerificationProgress?: typeof onVerificationProgress;
}
/**
 * A received chunk this device could not store. The chunk was not
 * acknowledged: its sender sees no receipt for it and will retransmit or give
 * up, so the transfer stays incomplete until storage is available again.
 */
export interface ReceiveStorageError {
    /**
     * - `insufficient-quota`: the transfer is larger than the estimated free
     *   storage and was refused before anything was written.
     * - `quota-exceeded`: the browser refused a write for lack of space.
     * - `storage-failed`: any other storage fault.
     * - `integrity`: the file's last chunk arrived, but the stored bytes do not
     *   hash to the whole-file hash its message carries. The file's chunks were
     *   dropped and reading it throws ReceiveIntegrityError.
     * - `not-removed`: a removal the SDK started itself (a peer's cancel, the
     *   expiry of a stale receive, the drop after a failed verification, a
     *   `deleteMessage` action dispatched to the store, `blacklistPeer`, or the
     *   retry when the SDK starts) deleted the message's records, but the
     *   browser refused to remove its file from the origin private file system
     *   and the bytes are still there. `cause` is what the browser threw. The
     *   SDK tries again when it next starts. Reported once per file;
     *   `chunkIndex` is -1, and `roomId`, `fromPeerId`, `filename` and
     *   `totalSize` are empty or 0 when no record of the message is left. (A
     *   call the application makes to delete rejects with StorageFailedError
     *   instead and raises no event.)
     */
    readonly code: ReceiveStorageFailure;
    readonly roomId: string;
    readonly fromPeerId: string;
    readonly merkleRootHex: string;
    readonly filename: string;
    readonly totalSize: number;
    readonly chunkIndex: number;
    /** `insufficient-quota` only: the bytes the transfer needs. */
    readonly requiredBytes?: number;
    /** `insufficient-quota` only: the estimated free bytes. */
    readonly availableBytes?: number;
    /** `not-removed` only: the browser's error, with its name and message. */
    readonly cause?: Error;
}
/**
 * Call `listener` when a received chunk cannot be stored, or a received file
 * cannot be removed. Returns an unsubscribe function. Listener errors are
 * caught and logged. The first listener is also given, right after it
 * subscribes, the `not-removed` reports raised before any listener existed.
 */
export declare const onReceiveStorageError: (listener: (error: ReceiveStorageError) => void) => (() => void);
/** What names a received transfer in a ReceiveStorageError. */
export type ReceivedChunkContext = Pick<ReceiveChunk, "roomId" | "fromPeerId" | "merkleRoot" | "filename" | "totalSize" | "chunkIndex">;
export declare const reportReceiveStorageError: (chunk: ReceivedChunkContext, failure: ReceiveChunkStoreFailure, cause?: Error) => void;
/**
 * Thrown when reading a received file whose stored bytes did not match the
 * whole-file hash its message carries. Its chunks were dropped, so it stays
 * unreadable until its sender sends the whole file again.
 */
export declare class ReceiveIntegrityError extends Error {
    readonly code: "integrity";
    readonly merkleRootHex: string;
    constructor(merkleRootHex: string);
}
/**
 * Throw ReceiveIntegrityError if this received file failed whole-file
 * verification. A completed file was verified when it completed, so callers
 * need this only for a file that is not complete.
 */
export declare const assertReceivedFileIntact: (merkleRootHex: string, readProgress?: typeof getDBMessageData) => Promise<void>;
/**
 * Worker storage is the durability boundary for a receipt. A failed write must
 * look exactly like a decoy/drop to the caller, and the owned real-byte copy is
 * erased after postMessage has cloned it (or after an injected failure).
 */
export declare const storeReceiveChunkFailClosed: (chunk: Omit<ReceiveChunk, "data">, realChunk: Uint8Array, store?: ReceiveChunkStore) => Promise<ReceiveChunkStoreResult | null>;
export declare const handleReceiveMessage: (frame: Uint8Array, roomId: string, channelLabel: string, epc: IRTCPeerConnection, merkleRoot: Uint8Array, module: LibCrypto, signal?: AbortSignal, dependencies?: ReceiveMessageDependencies) => Promise<ReceiveMessageResult>;
/**
 * Hash a received file held pending verification (a result with
 * `verification`). Call it outside the edge's receive lock: the worker reads
 * the file once and keeps serving other requests meanwhile. If `signal`
 * aborts once the edge is no longer current (teardown, room leave), the
 * hashing stops at its next read and the verdict is "aborted".
 */
export declare const verifyHeldFile: (merkleRootHex: string, token: string, holder: string, signal: AbortSignal | undefined, edgeIsCurrent: () => boolean, dependencies?: ReceiveMessageDependencies) => Promise<ReceiveVerificationVerdict>;
/**
 * Commit a verification's verdict under the edge's receive lock, or decline
 * it (`commit` false: the edge is gone), which leaves the file to be verified
 * again by the next copy of its last chunk. Reports an integrity failure, or a
 * storage fault while reading the file, through onReceiveStorageError.
 */
export declare const settleHeldFile: (context: ReceivedChunkContext, token: string, holder: string, verdict: ReceiveVerificationVerdict, commit: boolean, dependencies?: ReceiveMessageDependencies) => Promise<ReceiveVerificationOutcome>;
export {};
