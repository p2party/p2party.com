import type { Peer, PeerSignalingPresence } from "../reducers/roomSlice";
import type { PeerDepartureReason, RoomPeer } from "../utils/interfaces";
export interface SelfPeerIdentity {
    peerId: string;
    publicKey: string;
}
/** Validate the whole snapshot before replacing prior membership. */
export declare const parsePeerRosterSnapshot: (peers: readonly RoomPeer[], self: SelfPeerIdentity) => Peer[];
/**
 * Server `peers` messages are accepted-peer deltas, not room snapshots.
 * Preserve prior members and upsert only canonical, non-conflicting additions.
 * Peer removal belongs to transport teardown and to a `peerLeft` report for a
 * member this client holds no connected edge to (planPeerDeparture).
 */
export declare const mergePeerRosterDelta: (current: readonly Peer[], delta: readonly RoomPeer[], self: SelfPeerIdentity) => Peer[];
/** A `peerLeft` frame's fields, once each one is well formed. */
export interface PeerDepartureReport {
    roomId: string;
    peerId: string;
    reason: PeerDepartureReason;
    /** The departed socket's generation, a UUIDv4. */
    socketGeneration: string;
}
/** Validate a server `peerLeft` frame; undefined for anything malformed. */
export declare const parsePeerLeft: (message: unknown) => PeerDepartureReport | undefined;
/** The parts of a room the presence rules read; a superset of the reducer's. */
export interface PresenceRoom {
    readonly peers: readonly {
        readonly peerId: string;
    }[];
    readonly knownPeers?: readonly {
        readonly peerId: string;
    }[];
    readonly peerPresence?: Readonly<Record<string, PeerSignalingPresence | undefined>>;
}
/** A member this client tracks: on the roster or in the last snapshot. */
export declare const isRoomMember: (room: PresenceRoom, peerId: string) => boolean;
/**
 * What a `peerLeft` report may change.
 *
 * The signaling server is not trusted and cannot authenticate this report to
 * the members' WebRTC edges, so it is a hint and never closes a connected
 * edge:
 *
 * - "ignore": the report names this client, a peer this client does not
 *   track, or a socket generation other than the one the server last named
 *   for that peer (a report about an earlier session, delivered after the
 *   peer came back on a new socket).
 * - "remove": "left" with no connected edge. The member is dropped, which
 *   ends its reconcile retries; the caller cancels any negotiation still in
 *   progress.
 * - "mark": "left" with a connected edge, or "offline". The edge and
 *   everything on it stay. The mark keeps the member out of reconcile
 *   retries; a "left" member is dropped when that edge closes (deletePeer).
 */
export type PeerDepartureVerdict = "ignore" | "remove" | "mark";
export declare const planPeerDeparture: (room: PresenceRoom, report: Pick<PeerDepartureReport, "peerId" | "reason" | "socketGeneration">, selfPeerId: string, edgeConnected: boolean) => PeerDepartureVerdict;
/**
 * How much a server frame naming a member says about its presence.
 *
 * - "session": the frame comes from the member's live socket — a `peers`
 *   delta (it accepted an introduction), a `peerConnection` introduction (it
 *   asked for peers), or a `connection` (it is dialling).
 * - "membership": a `peers` snapshot entry. A snapshot lists offline members
 *   too, so it says the peer is a member, not that it is online.
 */
export type PeerPresenceEvidence = "session" | "membership";
/**
 * The presence a server frame naming a member leaves behind.
 *
 * Any frame naming the member withdraws a "left" report: it is a member
 * again. An "offline" report is withdrawn by a frame naming another socket
 * generation, or by a session frame that names none; a frame naming the
 * generation that went offline is older than the report and changes nothing,
 * and a snapshot entry without a generation is no evidence the member is
 * online. A canonical generation the frame names is recorded either way.
 */
export declare const notedPeerPresence: (current: PeerSignalingPresence | undefined, socketGeneration: unknown, evidence: PeerPresenceEvidence) => PeerSignalingPresence;
