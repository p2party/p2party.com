import { type CoverClock, type CoverJob, type CoverJobInterruption, type CoverJobProgress, type CoverJobResult, type CoverSchedule, type CoverScheduler, type CoverSchedulerStatus, type CoverStatusChange } from "./coverScheduler";
import { type CoverCellContent } from "../cryptography/coverCell";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { CoverTimerEnvironment } from "./coverTimerWorker";
/** The transport surface a cover lane needs from an RTCDataChannel. */
export interface CoverLaneChannel {
    readonly label: string;
    readonly readyState: RTCDataChannelState | string;
    readonly bufferedAmount: number;
    send(data: ArrayBuffer): void;
    close(): void;
}
export interface CoverRuntimeOptions {
    readonly epc: IRTCPeerConnection;
    readonly roomId: string;
    readonly module: LibCrypto;
    readonly amInitiator: boolean;
    /** Authenticated room policy values (already validated by roomPolicy). */
    readonly schedule: Omit<CoverSchedule, "phaseOffsetMs">;
    /** Authenticated canonical room-policy hash: the shared phase source. */
    readonly policyHash: Uint8Array;
    /** Constant-shape name element shared by real and dummy lane labels. */
    readonly laneLabelName: string;
    /** Open one outbound lane; the caller owns RTCDataChannel construction. */
    readonly openLaneChannel: (label: string) => CoverLaneChannel;
    readonly onStatusChange?: (change: CoverStatusChange) => void;
    readonly onJobResult?: (result: CoverJobResult) => void;
    readonly onJobInterrupted?: (interruption: CoverJobInterruption) => void;
    /** Durable PQ epoch changed; senders may re-derive retired real producers. */
    readonly onKeyEpochChanged?: () => void;
    /**
     * Real-timer drift tolerance. Defaults to just under one slot spacing so a
     * healthy browser's setTimeout jitter does not suspend cover; a larger slip
     * still degrades. Deterministic (fake-clock) tests pass 0.
     */
    readonly maxTimerDriftMs?: number;
    /** Authenticated remote CANCEL for one transfer root (lowercase hex). */
    readonly onRemoteCancel?: (merkleRootHex: string) => void;
    /** Authenticated scheduled receipt token scoped to its transfer root. */
    readonly onScheduledReceipt?: (merkleRootHex: string, token: Uint8Array) => void;
    readonly onScheduledChunkReceipts?: (merkleRootHex: string, tokens: readonly Uint8Array[]) => void;
    /**
     * A clock to drive the schedule with, owned by the caller (deterministic
     * tests). Without one the runtime creates its own timer-worker clock
     * (coverTimerWorker) and destroys it with itself.
     */
    readonly clock?: CoverClock;
    /** Where that own clock gets time, page timers and its worker (tests). */
    readonly timerEnvironment?: CoverTimerEnvironment;
}
/**
 * True while the page is hidden: the condition under which a scheduled send's
 * delivery idle budget is held (scheduledCoverIsSuspended). False outside a
 * browser.
 */
export declare const isPageHidden: () => boolean;
/**
 * Every peer derives the identical absolute phase from the authenticated
 * policy hash, so all edges of the room share one cycle grid without any
 * negotiation message.
 */
export declare const deriveCoverPhaseOffsetMs: (policyHash: Uint8Array, coverCadenceMs: number) => number;
export declare class CoverRuntime {
    #private;
    constructor(options: CoverRuntimeOptions);
    /** Total cells one lane emits over a full cycle: F × D. */
    cellsPerLanePerCycle(): number;
    /**
     * Fire a one-shot callback when the given job settles (completed, cancelled,
     * or failed). Used to re-arm a long control backlog across cycles.
     */
    onJobSettled(jobId: string, callback: () => void): void;
    /** A constant-shape lane label with a fresh random root (dummy/control). */
    randomLaneLabel(): string;
    /** starting | active | degraded | suspended | stopped */
    get status(): CoverSchedulerStatus;
    start(): void;
    stop(): void;
    /**
     * Stop for good. The runtime's clock is released and every pending wake-up
     * of it dropped, including the boundary close a stop() pins: the edge
     * teardown that destroys a runtime closes its lanes itself. The page's
     * shared timer worker is terminated when the last clock using it goes. A
     * cell already produced for the next slot is zeroed (CoverScheduler.stop).
     */
    destroy(): void;
    /** Which source drives the schedule's wake-ups: the timer worker or the page. */
    get timerSource(): "worker" | "page";
    /** A browser-imposed gap: close at the boundary, never claim the gap. */
    suspend(reason: string): void;
    /** Resume begins at a strictly future cycle boundary; gaps stay gaps. */
    resume(): void;
    enqueue(job: CoverJob): void;
    cancel(jobId: string): ReturnType<CoverScheduler["cancel"]>;
    complete(jobId: string): void;
    getQueuedJobIds(): readonly string[];
    hasPendingRealJobs(): boolean;
    /** Called only after the new epoch is durable and adopted. */
    onPqEpochChanged(): void;
    /**
     * Live scheduler progress for one job, or undefined once it has settled.
     * Deliberately NOT `#assertLive()`-guarded: a delivery wait polls this and
     * must keep answering (with "gone") after the edge is destroyed rather than
     * throwing into the sender's loop.
     */
    getJobProgress(jobId: string): CoverJobProgress | undefined;
    /**
     * Seal one authenticated non-dummy cover cell (CANCEL or scheduled receipt)
     * for substitution into an already-scheduled slot.
     */
    sealCoverContent(content: CoverCellContent): Uint8Array;
    /**
     * Authenticate one inbound FRAME_TYPE_COVER cell. Dummy cells vanish;
     * CANCEL/receipt dispatch to their hooks bound to the transfer root. An
     * unauthentic, replayed, or wrong-epoch cell is dropped (returns false) —
     * cover lanes may legitimately race an epoch transition by one flight.
     */
    processInboundCoverCell(frame: Uint8Array): boolean;
    /**
     * A dummy lane advertises a plausible same-shape label: the identical name
     * element with a fresh random 64-byte "Merkle root". Labels are visible to
     * the authenticated peer only — never to the signaling server or a network
     * observer — so shape (not secrecy) is the requirement.
     */
    makeDummyLaneLabel(): Promise<string>;
}
