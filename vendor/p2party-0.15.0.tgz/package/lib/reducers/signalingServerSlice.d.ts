import type { PayloadAction } from "@reduxjs/toolkit";
export interface SignalingState {
    isEstablishingConnection: boolean;
    isConnected: boolean;
    isVerified: boolean;
    serverUrl: string;
    refusal?: "version-mismatch";
}
export declare const signalingServerActions: import("@reduxjs/toolkit").CaseReducerActions<{
    startConnecting: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
        refusal?: "version-mismatch" | undefined;
    }, action: PayloadAction<string | undefined>) => void;
    connectionEstablished: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
        refusal?: "version-mismatch" | undefined;
    }) => void;
    connectionVerified: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
        refusal?: "version-mismatch" | undefined;
    }) => void;
    disconnect: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
        refusal?: "version-mismatch" | undefined;
    }, action: PayloadAction<"version-mismatch" | undefined>) => void;
}, "signalingServer">;
export declare const signalingServerSelector: (state: {
    readonly signalingServer: SignalingState;
}) => SignalingState;
declare const _default: import("redux").Reducer<SignalingState>;
export default _default;
