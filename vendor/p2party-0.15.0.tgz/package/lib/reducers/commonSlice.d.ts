export interface CommonState {
    currentRoomUrl: string;
}
export declare const setCurrentRoomUrl: import("@reduxjs/toolkit").ActionCreatorWithPayload<string, "commonState/setCurrentRoomUrl">;
export declare const commonStateSelector: (state: {
    readonly commonState: CommonState;
}) => CommonState;
declare const _default: import("redux").Reducer<CommonState>;
export default _default;
