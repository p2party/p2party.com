/**
 * A received chunk refused for what it claims (bounds, layout, metadata,
 * ownership, cancellation fence), as opposed to a storage fault. The worker
 * rethrows these unchanged; anything else thrown while storing is reported as
 * a typed storage failure.
 */
export declare class ReceiveChunkRejectedError extends Error {
}
/**
 * Running summary of the distinct chunks held for one received transfer. It is
 * kept on the transfer's messageData row and rewritten in the same transaction
 * as every chunk insert, so a new chunk is validated against it in constant
 * time instead of by re-reading every chunk record already held.
 *
 * Rows written by 0.14.10 have no manifest; it is rebuilt once from the chunk
 * records (`buildReceiveManifest`) and persisted with the next insert.
 */
export interface ReceiveManifest {
    version: 1;
    /** Number of distinct chunk indices held. */
    count: number;
    /**
     * Sum of their real lengths. It must equal the row's savedSize: a row
     * rewritten by code that does not maintain the manifest (0.14.10 drops the
     * field, but a stale copy must never be trusted) is rebuilt instead.
     */
    savedSize: number;
    /** Real bytes in every chunk but the last; 0 while not yet determined. */
    uniformSize: number;
    /** The one chunk held while uniformSize is undetermined. */
    pendingIndex?: number;
    pendingRealLen?: number;
}
export interface ReceiveProgress {
    savedSize: number;
    complete: boolean;
}
export declare const EMPTY_RECEIVE_MANIFEST: ReceiveManifest;
/**
 * Full validation of a set of held chunk records, and the manifest that
 * describes them. This is the layout check 0.14.10 ran on every chunk; it now
 * runs only to rebuild a missing or stale manifest.
 */
export declare const buildReceiveManifest: (records: ReadonlyArray<{
    chunkIndex: number;
    realLen?: number;
}>, totalSize: number) => ReceiveManifest;
/**
 * The manifest after adding one chunk index not yet held. Throws
 * ReceiveChunkRejectedError exactly when `buildReceiveManifest` over the held
 * records plus this one would; constant time and no record reads.
 *
 * The chunk's own bounds (safe integers, realLen <= CHUNK_LEN and <= totalSize,
 * chunkIndex < totalSize) are the caller's entry check.
 */
export declare const advanceReceiveManifest: (manifest: ReceiveManifest, totalSize: number, chunkIndex: number, realLen: number) => ReceiveManifest;
/**
 * Distinct-byte progress for a manifest. Every held chunk conforms to the
 * canonical layout, so holding all expected indices and holding totalSize
 * bytes are the same fact; a manifest where they disagree is refused.
 */
export declare const receiveProgress: (manifest: ReceiveManifest, totalSize: number) => ReceiveProgress;
/**
 * True when `value` is a well-formed manifest that matches the row it was read
 * from. Anything else (absent on a 0.14.10 row, malformed, or out of step with
 * savedSize) is rebuilt from the chunk records rather than trusted.
 */
export declare const isCurrentReceiveManifest: (value: unknown, savedSize: number, totalSize: number) => value is ReceiveManifest;
