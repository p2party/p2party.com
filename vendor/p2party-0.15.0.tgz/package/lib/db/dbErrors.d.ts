/** The database cannot serve requests at all. */
export declare class DatabaseUnavailableError extends Error {
}
/** The database worker stopped: it failed, or one of its replies was unreadable. */
export declare class DatabaseWorkerError extends DatabaseUnavailableError {
    constructor(message: string);
}
/**
 * A Merkle root or whole-file hash passed to `deleteMessage` or
 * `cancelMessage` is not in a form the SDK accepts: the 128 lower-case
 * hexadecimal characters the SDK reports it as, or the 64 bytes those
 * encode. Nothing was looked up or changed. `argument` says which one.
 */
export declare class InvalidMessageHashError extends Error {
    readonly argument: "merkleRoot" | "hash";
    readonly code = "invalid-message-hash";
    constructor(argument: "merkleRoot" | "hash");
}
export declare class InvalidTransferIdError extends Error {
    readonly code = "invalid-transfer-id";
    constructor();
}
export declare class MissingMessageIdentifierError extends Error {
    readonly code = "missing-message-identifier";
    constructor();
}
export declare const DATABASE_UPGRADE_BLOCKED = "database-upgrade-blocked";
/**
 * This version's database upgrade is blocked by another open tab of this site
 * running an older version, which keeps its connection open. Close the other
 * tabs of this site and reload.
 */
export declare class DatabaseUpgradeBlockedError extends DatabaseUnavailableError {
    readonly code = "database-upgrade-blocked";
    constructor();
}
export declare const STORAGE_FAILED = "storage-failed";
/** One received file a removal left on disk. */
export interface FileRemovalFailure {
    /**
     * The file: its message's Merkle root in hex, which is also its name in the
     * SDK's directory of the origin private file system. Empty when the failure
     * is the directory's (it could not be listed or removed).
     */
    readonly merkleRootHex: string;
    /** What the browser threw, with its own `name` and `message`. */
    readonly error: Error;
}
/**
 * A removal left a received file on disk: the browser refused to remove it.
 * - `failures` lists every file that is still there, each with the browser's
 *   error for it (an `Error` with the `name` and `message` the browser
 *   threw).
 * - `cause` is the browser's error itself when the call was for one message
 *   (deleteMessage, cancelMessage). For a call that covers several messages
 *   or steps (disconnectFromRoom, disconnectFromAllRooms, purgeRoom, purge)
 *   it is what those steps threw, usually an AggregateError; each file's own
 *   error is in `failures`.
 * Both hold on the page for an error raised in the database worker. An
 * error's class, cause and fields do not survive the worker boundary, so the
 * worker sends each file's root and the name and message of the browser's
 * error as data (SerializedStorageFailure) and the client rebuilds them. The
 * rebuilt errors are plain `Error`s carrying that name and message, not the
 * browser's own DOMException objects.
 */
export declare class StorageFailedError extends Error {
    readonly code = "storage-failed";
    readonly failures: readonly FileRemovalFailure[];
    constructor(message: string, options?: {
        cause?: unknown;
        failures?: readonly FileRemovalFailure[];
    });
}
/** A browser error as it crosses the worker boundary: its name and message. */
export interface SerializedError {
    readonly name: string;
    readonly message: string;
}
/** A StorageFailedError as the worker posts it to its client. */
export interface SerializedStorageFailure {
    readonly message: string;
    readonly cause?: SerializedError;
    readonly failures: ReadonlyArray<{
        readonly merkleRootHex: string;
    } & SerializedError>;
}
export declare const serializeError: (error: unknown) => SerializedError;
/** An Error carrying the name and message of the one that was thrown. */
export declare const rebuildError: ({ name, message }: SerializedError) => Error;
export declare const serializeStorageFailure: (error: StorageFailedError) => SerializedStorageFailure;
export declare const rebuildStorageFailure: (detail: SerializedStorageFailure) => StorageFailedError;
/** A StorageFailedError for the files a removal left on disk. */
export declare const filesNotRemoved: (failures: readonly FileRemovalFailure[], what?: string) => StorageFailedError;
/**
 * One typed error for a call whose work included removing received files: a
 * StorageFailedError when any part of `error` is a storage failure (the
 * original as `cause`; in `failures`, every file any part names), else
 * `error`.
 */
export declare const asStorageFailure: (error: unknown, message: string) => unknown;
