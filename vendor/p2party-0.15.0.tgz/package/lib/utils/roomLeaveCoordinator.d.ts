import type { WebSocketMessageLeaveRoomRequest, WebSocketMessageRoomLeftResponse } from "./interfaces";
export declare const ROOM_LEAVE_ACK_TIMEOUT_MS = 2000;
export declare const MAX_PENDING_ROOM_LEAVES = 256;
export type RemoteRoomRevocationFailure = "no-current-socket" | "send-failed" | "ack-timeout" | "socket-closed" | "socket-replaced" | "ingress-rejected";
/**
 * Local room state and transports are already terminal when this is surfaced.
 * It says only that authoritative unlinking at the rendezvous server was not
 * confirmed; callers may safely forget the local room while reporting that
 * narrower remote uncertainty.
 */
export declare class RemoteRoomRevocationUnconfirmedError extends Error {
    readonly roomUrl: string;
    readonly roomLeaveId: string;
    readonly reason: RemoteRoomRevocationFailure;
    constructor(roomUrl: string, roomLeaveId: string, reason: RemoteRoomRevocationFailure, detail?: string);
}
type SendRoomLeave = (request: WebSocketMessageLeaveRoomRequest) => void | Promise<unknown>;
export declare const buildRoomLeaveRequest: (fromPeerId: string, roomUrl: string, roomLeaveId?: string) => WebSocketMessageLeaveRoomRequest;
export interface RequestRoomLeaveOptions {
    readonly timeoutMs?: number;
    readonly roomLeaveId?: string;
}
/**
 * Install correlation before sending, so even a synchronous in-memory server
 * acknowledgement cannot outrun the waiter.
 */
export declare const requestRoomLeaveAcknowledgement: (fromPeerId: string, roomUrl: string, socketToken: object, send: SendRoomLeave, options?: RequestRoomLeaveOptions) => Promise<void>;
export declare const hasExactRoomLeftShape: (message: WebSocketMessageRoomLeftResponse) => boolean;
/** Parse only the tiny exact ack shape used by the socket fast path. */
export declare const parseRoomLeftAcknowledgement: (data: unknown) => WebSocketMessageRoomLeftResponse | null;
/**
 * Settle only the exact socket+room+nonce waiter. The acknowledgement has no
 * reducer side effect, so a duplicate or late frame cannot resurrect a room.
 */
export declare const acknowledgeRoomLeft: (message: WebSocketMessageRoomLeftResponse, socketToken: object) => boolean;
export declare const cancelRoomLeavesForSocket: (socketToken: object, reason: Exclude<RemoteRoomRevocationFailure, "no-current-socket" | "send-failed" | "ack-timeout">) => number;
export declare const pendingRoomLeaveCount: () => number;
export {};
