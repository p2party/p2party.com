export declare class SignalingVersionMismatchError extends Error {
    constructor();
}
export declare const isSignalingVersionRefusal: (code: number, reason: string) => boolean;
/**
 * The signaling version is a fail-closed compatibility check, not a suite
 * negotiation mechanism. Missing, malformed, older, and newer values all fail.
 */
export declare const isProtocolVersionCompatible: (peerProtocolVersion?: number) => boolean;
