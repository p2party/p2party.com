/** The clock a poll reads and sleeps on; the browser's by default. */
export interface PollClock {
    readonly now: () => number;
    readonly setTimeout: (callback: () => void, ms: number) => unknown;
    readonly clearTimeout: (handle: unknown) => void;
}
export declare const realPollClock: PollClock;
/** Sleep `ms` on `clock`, or until `signal` aborts, whichever comes first. */
export declare const sleepUnlessAborted: (ms: number, signal?: AbortSignal, clock?: PollClock) => Promise<void>;
export declare const waitForOpen: (dc: {
    readyState: string;
}, timeoutMs?: number, pollMs?: number, signal?: AbortSignal, clock?: PollClock) => Promise<boolean>;
