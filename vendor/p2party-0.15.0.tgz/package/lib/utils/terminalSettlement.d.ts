export type TerminalSettlementStep = () => void | Promise<void>;
/**
 * Run every fail-closed teardown step in order, even when an earlier storage or
 * transport cleanup fails. The caller receives all failures only after the
 * local terminal state has been attempted everywhere.
 */
export declare const runTerminalSettlement: (message: string, steps: readonly TerminalSettlementStep[]) => Promise<void>;
export interface IdentityPurgeSettlement {
    readonly disconnectSignaling: TerminalSettlementStep;
    readonly clearRoomPins: TerminalSettlementStep;
    readonly resetIdentity: TerminalSettlementStep;
    /**
     * Close every authenticated WebRTC transport before awaiting either identity
     * deletion. A slow or failed database worker must never leave a live channel
     * able to receive under already-reset identity state.
     */
    readonly teardownRooms: TerminalSettlementStep;
    readonly deleteIdentityX25519: TerminalSettlementStep;
    readonly deleteIdentityEd25519: TerminalSettlementStep;
    /**
     * The non-secret record of how the purged identity was created. It describes
     * a key that no longer exists, so leaving it behind would let the next
     * identity inherit a stale claim about whether it can be backed up.
     */
    readonly deleteIdentityDerivation: TerminalSettlementStep;
}
/**
 * SSOT for identity-purge ordering. The X25519 wrapper is still removed before
 * the Ed25519 identity that authenticates it, but transport termination comes
 * first and every step settles even when another one fails.
 */
export declare const runIdentityPurgeSettlement: (steps: IdentityPurgeSettlement) => Promise<void>;
export interface RoomPurgeSettlement {
    /**
     * Tombstoning happens before this orchestrator. Close local RTC first; this
     * step is awaited before any network revocation attempt begins.
     */
    readonly closeLocalTransport: TerminalSettlementStep;
    /**
     * Starts immediately after local transport termination and may remain
     * pending while durable local cleanup proceeds.
     */
    readonly startRemoteRevocation: () => Promise<void>;
    readonly deleteLocalData: TerminalSettlementStep;
    readonly clearPinAttempts: TerminalSettlementStep;
}
/**
 * SSOT for a single-room purge completion boundary. Every local terminal step
 * settles even on storage/network failure; a lone typed remote-revocation
 * error is rethrown directly so callers can narrow it without unpacking an
 * AggregateError.
 */
export declare const runRoomPurgeSettlement: (steps: RoomPurgeSettlement) => Promise<void>;
