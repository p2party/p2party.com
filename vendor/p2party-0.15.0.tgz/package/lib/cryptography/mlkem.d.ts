import type { LibCrypto } from "./libcrypto";
export type MlKemParameterSet = 512 | 768 | 1024;
export declare const ML_KEM_512_PUBLIC_KEY_BYTES = 800;
export declare const ML_KEM_512_SECRET_KEY_BYTES = 1632;
export declare const ML_KEM_512_CIPHERTEXT_BYTES = 768;
export declare const ML_KEM_768_PUBLIC_KEY_BYTES = 1184;
export declare const ML_KEM_768_SECRET_KEY_BYTES = 2400;
export declare const ML_KEM_768_CIPHERTEXT_BYTES = 1088;
export declare const ML_KEM_1024_PUBLIC_KEY_BYTES = 1568;
export declare const ML_KEM_1024_SECRET_KEY_BYTES = 3168;
export declare const ML_KEM_1024_CIPHERTEXT_BYTES = 1568;
export declare const ML_KEM_SHARED_SECRET_BYTES = 32;
export declare const ML_KEM_KEYPAIR_RANDOM_BYTES = 64;
export declare const ML_KEM_ENCAPS_RANDOM_BYTES = 32;
type MlKemKeyPairExport<P extends MlKemParameterSet> = `_mlkem${P}_keypair`;
type MlKemEncapsExport<P extends MlKemParameterSet> = `_mlkem${P}_encaps`;
type MlKemDecapsExport<P extends MlKemParameterSet> = `_mlkem${P}_decaps`;
/**
 * Complete runtime description of one FIPS 203 parameter set.
 *
 * The sizes are carried with the selected suite so callers cannot
 * accidentally validate an ML-KEM-512 key with ML-KEM-768 constants.
 */
export interface MlKemSuiteDescriptor<P extends MlKemParameterSet = MlKemParameterSet> {
    readonly parameterSet: P;
    readonly standardName: `ML-KEM-${P}`;
    readonly publicKeyBytes: number;
    readonly secretKeyBytes: number;
    readonly ciphertextBytes: number;
    readonly sharedSecretBytes: typeof ML_KEM_SHARED_SECRET_BYTES;
    readonly keyPairRandomBytes: typeof ML_KEM_KEYPAIR_RANDOM_BYTES;
    readonly encapsRandomBytes: typeof ML_KEM_ENCAPS_RANDOM_BYTES;
    readonly wasmExports: {
        readonly keypair: MlKemKeyPairExport<P>;
        readonly encaps: MlKemEncapsExport<P>;
        readonly decaps: MlKemDecapsExport<P>;
    };
}
export declare const ML_KEM_512_SUITE: Readonly<MlKemSuiteDescriptor<512>>;
export declare const ML_KEM_768_SUITE: Readonly<MlKemSuiteDescriptor<768>>;
export declare const ML_KEM_1024_SUITE: Readonly<MlKemSuiteDescriptor<1024>>;
export declare const ML_KEM_SUITES: Readonly<{
    512: Readonly<MlKemSuiteDescriptor<512>>;
    768: Readonly<MlKemSuiteDescriptor<768>>;
    1024: Readonly<MlKemSuiteDescriptor<1024>>;
}>;
export declare const getMlKemSuite: <P extends MlKemParameterSet>(parameterSet: P) => Readonly<MlKemSuiteDescriptor<P>>;
/**
 * FIPS 203 Section 7.2 modulus check for one encoded encapsulation key.
 *
 * Each three-byte group in the encoded polynomial vector contains two
 * little-endian 12-bit coefficients, both of which must be below q=3329.
 * The final 32-byte public seed is unrestricted. This pure check is shared by
 * every composed KEM so canonical ML-KEM public-key encoding has one SSOT.
 */
export declare const mlKemPublicKeyHasCanonicalEncoding: (publicKey: unknown, parameterSet: MlKemParameterSet) => boolean;
type MlKemKeyPairFunction = (publicKey: number, secretKey: number, coins64: number) => number;
type MlKemEncapsFunction = (ciphertext: number, sharedSecret: number, publicKey: number, coins32: number) => number;
type MlKemDecapsFunction = (sharedSecret: number, ciphertext: number, secretKey: number) => number;
/**
 * The deterministic ABI exported by the pinned, portable mlkem-native build.
 * JavaScript supplies all entropy; the WASM has no second RNG path.
 */
export interface MlKemModule extends LibCrypto {
    _mlkem512_keypair: MlKemKeyPairFunction;
    _mlkem512_encaps: MlKemEncapsFunction;
    _mlkem512_decaps: MlKemDecapsFunction;
    _mlkem768_keypair: MlKemKeyPairFunction;
    _mlkem768_encaps: MlKemEncapsFunction;
    _mlkem768_decaps: MlKemDecapsFunction;
    _mlkem1024_keypair: MlKemKeyPairFunction;
    _mlkem1024_encaps: MlKemEncapsFunction;
    _mlkem1024_decaps: MlKemDecapsFunction;
}
/** Compatibility type for protocol-v3 code while suite negotiation lands. */
export type MlKem768Module = LibCrypto & Pick<MlKemModule, "_mlkem768_keypair" | "_mlkem768_encaps" | "_mlkem768_decaps">;
export interface MlKemKeyPair {
    /** A copy suitable for transport or serialization. This is not secret. */
    readonly publicKey: Uint8Array;
    /**
     * Plaintext secret key bytes suitable for encrypted serialization.
     * Call destroy() as soon as the key is no longer needed.
     */
    readonly secretKey: Uint8Array;
    readonly destroyed: boolean;
    /** Idempotently wipes this object's secretKey bytes. */
    destroy(): void;
}
export interface MlKemEncapsulation {
    /** A copy suitable for transport or serialization. This is not secret. */
    readonly ciphertext: Uint8Array;
    /** Plaintext shared-secret bytes. Mix into a KDF, then call destroy(). */
    readonly sharedSecret: Uint8Array;
    readonly destroyed: boolean;
    /** Idempotently wipes this object's sharedSecret bytes. */
    destroy(): void;
}
export interface MlKemDecapsulation {
    /** Plaintext shared-secret bytes. Mix into a KDF, then call destroy(). */
    readonly sharedSecret: Uint8Array;
    readonly destroyed: boolean;
    /** Idempotently wipes this object's sharedSecret bytes. */
    destroy(): void;
}
/**
 * Async-compatible ML-KEM API. The WASM calls are synchronous, but promises
 * allow a worker-backed implementation without changing protocol state
 * machines.
 */
export interface MlKemBackend<P extends MlKemParameterSet = MlKemParameterSet> {
    readonly suite: Readonly<MlKemSuiteDescriptor<P>>;
    generateKeyPair(): Promise<MlKemKeyPair>;
    encapsulate(publicKey: Uint8Array): Promise<MlKemEncapsulation>;
    decapsulate(ciphertext: Uint8Array, secretKey: Uint8Array): Promise<MlKemDecapsulation>;
}
/**
 * Real-WASM ML-KEM backend with the explicit deterministic inputs required by
 * composed, version-pinned KEMs. The ordinary backend remains the narrower
 * seam used by protocol state machines and test doubles.
 */
export interface DeterministicMlKemBackend<P extends MlKemParameterSet = MlKemParameterSet> extends MlKemBackend<P> {
    /**
     * FIPS 203 KeyGen_internal with the caller-supplied 64-byte d || z seed.
     * The seed is borrowed; this method snapshots but never wipes caller bytes.
     */
    deriveKeyPair(seed: Uint8Array): Promise<MlKemKeyPair>;
    /**
     * FIPS 203 Encaps_internal with caller-supplied 32-byte randomness.
     * Inputs are borrowed; this method snapshots but never wipes caller bytes.
     */
    encapsulateDeterministically(publicKey: Uint8Array, randomness: Uint8Array): Promise<MlKemEncapsulation>;
}
/** Compatibility aliases for the currently shipped ML-KEM-768 handshake. */
export type MlKem768KeyPair = MlKemKeyPair;
export type MlKem768Encapsulation = MlKemEncapsulation;
export type MlKem768Decapsulation = MlKemDecapsulation;
export type MlKem768Backend = MlKemBackend<768>;
export declare const createMlKemBackend: <P extends MlKemParameterSet>(module: LibCrypto, suite: Readonly<MlKemSuiteDescriptor<P>>) => DeterministicMlKemBackend<P>;
/**
 * Temporary compatibility factory for the protocol-v3 ML-KEM-768 wire suite.
 */
export declare const createMlKem768Backend: (module: LibCrypto) => MlKem768Backend;
export {};
