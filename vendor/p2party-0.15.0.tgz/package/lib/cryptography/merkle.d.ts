import type { LibCrypto } from "./libcrypto";
/**
 * @function
 * Returns the Merkle root of a tree.
 *
 * @param treeHashes: The tree, hashed.
 * @returns Promise<Uint8Array>
 */
export declare const getMerkleRoot: (treeHashes: Uint8Array, module?: LibCrypto) => Promise<Uint8Array>;
/**
 * @function
 * getMerkleProof
 *
 * @description
 * Returns the Merkle proof of an element of a tree.
 * Can be used as a receipt of a transaction etc.
 *
 * @param {Uint8Array[]} treeHashes: The tree.
 * @param {Uint8Array} elementHash: The element.
 *
 * @returns {Promise<Uint8Array>}: The Merkle proof.
 */
export declare const getMerkleProof: (treeHashes: Uint8Array, elementHash: Uint8Array, module?: LibCrypto, proofFixedLen?: number) => Promise<Uint8Array>;
/**
 * Every level of one Merkle tree, built once, so the proof of any leaf is a
 * walk of at most ⌈log2 N⌉ sibling copies. `getMerkleProof` rebuilds the
 * whole tree in WASM for every call, which a sender pays once per chunk.
 */
export interface MerkleProofLevels {
    readonly leafCount: number;
    /**
     * Bytes held above the caller's leaves: about N × 64 for N leaves. Zero once
     * released.
     */
    readonly byteLength: number;
    /**
     * The proof of the leaf at `index`, framed exactly as `getMerkleProof`
     * frames it (with `proofFixedLen`: u32 BE length ‖ proof ‖ random padding).
     * For a tree of distinct leaves the bytes equal `getMerkleProof(tree,
     * leafHash)`. With duplicate leaves `getMerkleProof` proves the FIRST equal
     * leaf, and this proves the one at `index`; both verify against the root.
     * Throws when `leafHash` is not the leaf at `index`.
     */
    proof(index: number, leafHash: Uint8Array, proofFixedLen?: number): Uint8Array;
    /** A copy of the root, equal to `getMerkleRoot` over the same leaves. */
    root(): Uint8Array;
    /** Drop every level. Idempotent; a later `proof` or `root` throws. */
    release(): void;
}
/** How a proof-level build shares the thread it runs on. */
export interface MerkleProofLevelsBuildOptions {
    /**
     * The target duration of a slice, in ms of `now`.
     * Defaults to PROOF_LEVEL_BUILD_SLICE_MS.
     */
    readonly sliceMs?: number;
    /** The clock slices are timed on. Defaults to `performance.now`. */
    readonly now?: () => number;
    /**
     * Hands the thread back between slices. The default posts one task for
     * the next runnable build across all messages on the page.
     */
    readonly yieldToEventLoop?: () => Promise<void>;
    /** Stops the build at its next slice; it then rejects with the reason. */
    readonly signal?: AbortSignal;
}
/** A proof-level build that is running, or has ended. */
export interface MerkleProofLevelsBuild {
    /** The levels, or the build's error, or the stop signal's reason. */
    readonly done: Promise<MerkleProofLevels>;
    /**
     * Bytes the levels built so far hold above the leaves. Zero once the build
     * has ended: when it succeeds the levels it settles with hold them; when it
     * fails or is stopped they are dropped, at the slice it stops in.
     */
    readonly byteLength: number;
}
/**
 * Build every level of the tree over `treeHashes` (the domain-separated leaf
 * hashes) with merkle.c's rules: an internal node is SHA-512(0x01 ‖ left ‖
 * right), computed by the module's libsodium SHA-512, and a lone odd node is
 * promoted unchanged. That is N − 1 node hashes, once.
 *
 * A slice targets `sliceMs` using the average hash cost so far, with a
 * separate cap on hashes even when the clock does not advance. A single
 * slow hash, allocation, or browser scheduling delay can overrun the target.
 *
 * Level 0 is `treeHashes` itself, not a copy: the caller must not modify it
 * while the levels are live.
 */
export declare const startMerkleProofLevelsBuild: (treeHashes: Uint8Array, module: LibCrypto, options?: MerkleProofLevelsBuildOptions) => MerkleProofLevelsBuild;
/** `startMerkleProofLevelsBuild`, for a caller that only needs the levels. */
export declare const buildMerkleProofLevels: (treeHashes: Uint8Array, module: LibCrypto, options?: MerkleProofLevelsBuildOptions) => Promise<MerkleProofLevels>;
/**
 * @function
 * Calculates the Merkle root from the element hash and its Merkle proof.
 *
 * @param hash: The hash of the base element in question.
 * @param proof: The first element is the first leave that was added for the calculation etc. The last
 * byte is either 0 or 1, indicating whether it is to the left or to the right in the tree.
 *
 * @returns The Merkle root
 */
export declare const getMerkleRootFromProof: (item: Uint8Array, proof: Uint8Array) => Promise<Uint8Array>;
/**
 * Verifies that the hash was indeed included in the calculation of the Merkle root.
 * @param hash: The hash of the base element in question.
 * @param root: The Merkle root.
 * @param proof: The first element is the first leave that was added for the calculation etc. The last
 * byte is either 0 or 1, indicating whether it is to the left or to the right in the tree.
 */
export declare const verifyMerkleProof: (item: Uint8Array, root: Uint8Array, proof: Uint8Array, module?: LibCrypto) => Promise<boolean>;
