/**
 * Point the browser root at a self-hosted copy of this release's exact WASM:
 * an https: URL, a URL on the page's own origin whatever its scheme, or a
 * plain http: URL on a loopback host. data:, blob:, javascript: and file:
 * URLs are refused. The build-pinned SHA-384 is still enforced. Configure
 * once, before connect() or any other operation first loads cryptography.
 */
export declare const setWasmSourceUrl: (source: string | URL) => void;
export declare const wasmLoader: (wasmMemory: WebAssembly.Memory) => Promise<import("./libcrypto").LibCrypto>;
