import type { LibCrypto } from "./libcrypto";
/**
 * The result of a mnemonic check, shaped for a form field: `reason` is a
 * displayable sentence naming the first problem found, and is absent when the
 * phrase is usable.
 */
export interface MnemonicValidation {
    ok: boolean;
    reason?: string;
}
/**
 * The canonical form of a recovery phrase, and part of the derivation
 * contract: NFKD, then any run of whitespace collapsed to a single space,
 * trimmed, lowercased.
 *
 * A phrase is transcribed by a human from paper, a password manager or a
 * screenshot, so it arrives with a trailing newline, a double space, a soft
 * wrap, or a capital first letter from a keyboard's autocapitalisation. All of
 * those used to be rejected outright by the wordlist lookup. Normalising them
 * away here means `"  Adapt  patrol "` and `"adapt patrol"` are the same
 * phrase everywhere: for validation, and for the argon2id input that produces
 * the seed. Every phrase that derived a key before this normalisation existed
 * was already in canonical form, so no backup changes what it restores.
 */
export declare const normalizeMnemonic: (mnemonic: string) => string;
/**
 * Derive an argon2id seed from a passphrase.
 *
 * This is the low-level KDF: it applies NFKD only, because an arbitrary
 * passphrase is not a mnemonic and must not be lowercased. Callers that hash a
 * recovery phrase pass it through `normalizeMnemonic` first, as
 * `keyPairFromMnemonic` does.
 *
 * @param mnemonic - Passphrase to stretch
 * @param salt - Optional salt; a random one is generated when omitted
 * @param module - Optional preloaded WASM module, otherwise one is loaded
 * @returns The argon2id seed. The caller owns it and should wipe it.
 */
export declare const argon2: (mnemonic: string, salt?: Uint8Array, module?: LibCrypto) => Promise<Uint8Array>;
/**
 * Generates a sequence of words chosen from a prespecified wordlist
 * that represents a random seed that
 * can be translated later into a cryptographic keypair.
 * With a strength of 128 bits of entropy you get 12 words.
 * In every additional step you get 3 more words. The maximum is
 * set to 512 bits of entropy, or 48 words!
 *
 * @param strength - Entropy bits
 * @returns The mnemonic from the wordlist.
 *
 */
export declare const generateMnemonic: (strength?: 128 | 160 | 192 | 224 | 256 | 288 | 320 | 352 | 384 | 416 | 448 | 480 | 512) => Promise<string>;
export declare const mnemonicToEntropy: (mnemonic: string) => Promise<boolean>;
export declare const validateMnemonic: (mnemonic: string) => Promise<boolean>;
/**
 * Everything about a recovery phrase that can be checked without hashing:
 * word count and membership of the wordlist. Synchronous, so a form can call
 * it on every keystroke and tell the user which word they mistyped.
 *
 * The checksum is deliberately not checked here — SHA-512 is only available
 * asynchronously through Web Crypto. Use `validateMnemonicPhrase` (or
 * `validateMnemonic`) once the phrase is structurally complete.
 *
 * @param words - The phrase as typed; normalisation is applied for you
 * @returns `{ ok }`, plus a displayable `reason` for the first problem found
 */
export declare const validateMnemonicWords: (words: string) => MnemonicValidation;
/**
 * The full check: `validateMnemonicWords` plus the checksum, reported in the
 * same shape so a form can show one message wherever the phrase went wrong.
 *
 * @param words - The phrase as typed; normalisation is applied for you
 * @returns `{ ok }`, plus a displayable `reason` when the phrase is unusable
 */
export declare const validateMnemonicPhrase: (words: string) => Promise<MnemonicValidation>;
/**
 * Generates an Ed25519 key pair from the provided mnemonic.
 * Optionally, you can strenthen the generation with a password.
 * The mnemonic is converted into a seed through the use of argon2id.
 * The password is used as a salt for argon2id.
 * From the generated seed we extract the key pair.
 *
 * The phrase is normalised first (see `normalizeMnemonic`), so how it was
 * typed does not change the identity it restores. Nothing here is persisted:
 * the seed, the salt and the encoded password are wiped before returning, and
 * the phrase itself stays the caller's to forget.
 *
 * @param mnemonic - Sequence of words from the predefined wordlist
 * @param password - Optional salt for the seed derivation
 * @param module - Optional preloaded WASM module, otherwise one is loaded
 * @returns An Ed25519 key pair
 */
export declare const keyPairFromMnemonic: (mnemonic: string, password?: string, module?: LibCrypto) => Promise<import("./interfaces").SignKeyPair>;
