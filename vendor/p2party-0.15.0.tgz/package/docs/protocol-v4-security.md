# Protocol-v4 security boundary

This document states what p2party 0.14's code path does, what observers still
learn, and which adjacent mechanisms are not production properties. It is a
developer threat-model summary, not an independent audit or a formal proof.

Protocol v4 is a clean wire break. Missing, malformed, older, and mismatched
wire versions fail closed; there is no legacy cryptographic fallback.

## What establishes a peer edge

There are three different acknowledgements in the system:

1. An `RTCDataChannel` becoming `open` means the DTLS/SCTP transport and that
   channel are ready. An in-band channel may have completed its DCEP OPEN/ACK,
   but this is not p2party identity or key confirmation.
2. The protocol-v4 handshake runs over the open main channel. After HELLO,
   responder CONFIRM, initiator CONFIRM, and responder FINISH, the peers have
   authenticated the same hybrid root and initial ratchet keys.
3. Immediate 65-byte receipts on authenticated message channels, or encrypted
   scheduled control cells, acknowledge chunks and transfer completion. They
   are delivery/reconciliation signals, not handshake establishment.

An open data channel therefore is necessary transport readiness, not an
established p2party crypto session.

The handshake combines:

- interactive 3DH proving possession of fresh ephemeral X25519 keys and
  dedicated long-term X25519 identity keys;
- Ed25519-pinned identities cross-signing those X25519 identity keys with a
  domain-separated transcript;
- one room-fixed ML-KEM-512, ML-KEM-768, or ML-KEM-1024 shared secret;
- draft-21 CPace in PIN rooms; and
- HKDF/HMAC transcript binding and three chained key-confirmation flights.

The authenticated channel input binds the channel identifier, initiator and
responder Ed25519 identities, ordered endpoint fingerprints, and exact ML-KEM
suite tag. The room policy is fixed before traffic; a suite/mode mismatch
poisons the transcript instead of negotiating or falling back.

The initiator returns established only after receiving and verifying FINISH.
The responder returns after successfully sending FINISH. Losing that final
flight can leave the responder complete while the initiator waits and
eventually fails. That is an availability/common-knowledge limit of the final
message, not evidence that an attacker learned the root key.

## Post-handshake message protection

Every authenticated peer edge owns independent Double Ratchet state. Either
role may send first, and simultaneous first sends are tested. Each logical
message consumes one message-key step; its chunks share the authenticated
ratchet header and use fresh nonces. Failed authentication rolls back the
candidate receive state, and skipped-key storage is bounded.

Each chunk frame is exactly 65,490 bytes:

```text
type(1) || DH public key(32) || N(8) || PN(8) || PQ epoch(8) ||
nonce(12) || encrypted fixed plaintext cell(65,405) || AEAD tag(16)
```

The AEAD additional data is 121 bytes: the transfer's 64-byte Merkle root
followed by the first 57 bytes of the clear header (type, DH public key, N, PN
and PQ epoch). The fresh random 12-byte nonce, which completes the 69-byte
clear header, is not part of the additional data; it is the AEAD nonce, so a
changed nonce fails the tag check. The PQ epoch is an unsigned 64-bit counter
— widened from v3's single byte so the sparse post-quantum healing epoch
cannot wrap.

The fixed frame geometry absorbs the ratchet and AEAD overhead into the cell
budget. Random padding and decoy slots can hide the exact payload length within
one transfer's chosen number of frames. Immediate receipts have a distinct
65-byte geometry and immediate pause/cancel controls are 66 bytes. Scheduled
receipt batches, terminal receipts and CANCELs occupy existing 65,490-byte
cover slots. Handshake flights are suite- and step-dependent.

Per-message channels give each transfer an independent lifecycle for
cancellation, bounded channel accounting, receipts, selective retransmission,
and reconnect resume. Channel isolation is a UX and reliability property; it
does not make timing or channel count invisible.

### Durable selective resume and cancellation

A chunk acknowledgement becomes live only after its per-recipient outbox
update commits. Receipt acceptance binds room, peer ID, peer public key,
random transfer ID, Merkle root and original chunk index. Scheduled cells
add direction, PQ epoch, AEAD and counter replay checks; their terminal token
must equal the transfer root. Stale asynchronous storage responses cannot
advance a replacement owner's live state. Recipient refusal is persisted
separately from completion and stops only that recipient's retry.

Scheduled chunk receipts use a separate encrypted subtype with up to 64 tokens
per root. Existing subtype 3 remains terminal-only: older clients interpreted
any token in that subtype as completion. Older protocol-v4 clients drop the
new subtype and retain terminal-only scheduled delivery, including full replay
when necessary. Selective scheduled resume therefore requires supporting peers.

Have-set membership is O(1) in memory and does not allocate a set copy per
scheduled slot. A resume scans indices once, sends missing real chunks and
may send one completion probe. Storage lookup costs, initial file preparation
and scanning remain; this is not a claim of sublinear total file processing.
Batching and selective resume reduce real work within the existing schedule,
whose observable cell count remains fixed.

Immediate resume uses the channel protocol `p2party-resume-v1` and a capability
echo to distinguish pause from explicit cancellation. Type-6 controls are
authenticated by the concrete DTLS/SCTP channel and current identity gate,
with an exact-root check; they do not have a separate application AEAD.
Legacy peers retain close-as-cancel behavior. A fresh immediate attempt
rebuilds its have-set from paced receiver receipts instead of assuming a
legacy receiver retained its partial. Remote cancellation drains pending
writes, then atomically checks room, sender and incomplete status before
deleting receiver data; completed files and sender self-copies are preserved.

### Sparse-PQ healing during scheduled sends

Local healing waits for queued or admitted real jobs, message channels,
derive-to-enqueue reservations and queued receive work to drain. An atomic
application reservation closes the race between deriving a message key and
admitting its scheduled producer. Dummy cover does not block healing.

An incoming exchange blocks new admission and drains reservations, then
persists its new epoch before adopting it. Epoch adoption invalidates old-key
real producers on the same scheduler and wakes bounded sender recovery.
Recovery requires an actual epoch advance when reusing that runtime and
re-derives the missing chunks. If sealing was already in flight, its retired
cell is wiped and the slot remains dummy; pending explicit CANCEL is resealed
under the new epoch. Lane timing continues throughout this transition.
Persistence failure leaves the prior live epoch unchanged for exact retry.

## Guarantees, assuming authenticated peer keys

With a correctly pinned peer Ed25519 identity, uncompromised endpoints, matching
room configuration, and successful confirmation, the implementation is
designed to provide:

- mutual possession authentication for the cross-signed X25519 identities;
- optional shared-PIN authentication in addition to identity authentication;
- a hybrid initial root dependent on both classical 3DH and the selected
  ML-KEM exchange;
- transcript binding to roles, identities, endpoint fingerprints, policy
  suite, KEM fields, and initial ratchet public keys;
- confidentiality and integrity for message cells;
- forward evolution, and post-compromise recovery from later uncompromised
  X25519 DH ratchet turns against an adversary that cannot break X25519.
  Against one that can, recovery comes only from the next completed sparse
  ML-KEM healing exchange, so between exchanges it is classical only. An
  exchange becomes due, on the side whose turn it is to offer, after 64
  application messages or 24 hours; in the store-free session API it runs
  only when the integrator calls `prepareHealing()`;
- tamper rejection for every message cell;
- replay rejection in the WebRTC transfer path and in the store-free session
  API. In the transfer path a repeated chunk is deduplicated in storage while
  its message key is live, and cannot be decrypted once the key is retired.
  The session API's `decrypt()` opens each message at most once: a repeat
  raises `SessionReplayError` while the message's chain is the current
  receiving chain or one of the 256 most recently superseded ones, and fails
  authentication after that; and
- bounded out-of-order key retention and bounded per-edge transfer resources.

These are implementation claims, not a claim of equivalence to Signal's PQXDH
proofs or to a standardized X-Wing combiner. p2party's handshake is interactive,
includes transport and optional CPace binding, and uses its own explicitly
domain-separated combiner. The code has not completed an independent
third-party cryptographic audit or a ProVerif/CryptoVerif analysis.

## Observable metadata

Encryption does not hide all communication metadata.

The signaling operator can observe the following metadata.

- the stable room locator and membership;
- peer identifiers and presented public identity keys;
- signaling timing, SDP, ICE candidates, IP/network information, and TURN use;
- room joins, leaves, and connection attempts; and
- any fallback/relay metadata explicitly sent through server-controlled paths.

A network observer can still estimate connection timing, endpoints where
WebRTC exposes them, packet volume, transfer duration, and traffic bursts. An
endpoint peer necessarily learns plaintexts it decrypts, peer identity, message
ordering, and transfer activity.

Room members learn from the signaling server when another member leaves a
room and when its last signaling socket closes (`peerLeft`, see below). Much
of this was already visible on request: any member can ask for a membership
snapshot at any time, a member absent from it has left, and the snapshot
names a member's socket generation exactly when the answering server process
holds that member's current socket, so on a one-process server a missing
generation means the member is offline. What `peerLeft` adds is a real-time
push, unrequested, of those transitions to every online member of every room
an identity is in, whether or not it holds an edge to that identity, within
the server's delivery time; on a server with several processes it also
reports an offline member whose socket was on another process, which a
snapshot could not show. `p2party-server` bounds the pushes (at most six
offline closes per identity per minute per process, and a frame budget per
source address) and does not announce the rest. With the introductions a
returning member already causes, room-mates can record the start and end of
each of a member's signaling sessions. The frame carries the room UUID, the
member's peer id and a socket generation that introductions and deltas
already show to room-mates; it carries no address and no key.

Fixed chunk cells hide exact plaintext length only within the frame-count
bucket and chosen decoy allocation. With immediate delivery, observers still
see when a message starts, how many cells/channels are active, when receipts
flow, and when a transfer ends. Fixed cells without a room-wide schedule are
not continuous cover traffic.

The SDK keeps the 256-bit capability locally. Join and leave requests carry
`roomLocator`, the lowercase hex SHA-512 digest of the 64-character canonical
capability string encoded as UTF-8. A room can be linked across visits by
this digest. Roster requests omit local PIN and policy failure lists.

## Signaling and TURN correctness boundary

Signaling v5 uses peer protocol v4 for end-to-end connections.

- A room response is accepted only for the exact current socket, room
  locator, and UUIDv4 request. A delayed response cannot configure another
  room.
- Caller ICE configuration and signaling-managed TURN credentials are separate
  inputs. Managed credentials carry an absolute expiry, are applied to every
  live room edge before an ICE restart, refresh proactively, and are removed or
  failed closed when they expire.
- `purgeRoom()` tears down local transports and durable state before waiting
  for a correlated server acknowledgement. The stable room locator identifies
  the membership even if the server has yet to send the room UUID. The server
  unlinks the authenticated peer before acknowledging. An
  offline or non-acknowledging server produces
  `RemoteRoomRevocationUnconfirmedError`; it is never reported as confirmed.
- Signaling ingress, room rosters, live mesh edges, pending ICE, and channel
  registries have explicit client-side bounds. Those bounds limit one client's
  exposure; they are not server-side Sybil resistance or a global availability
  proof.
- The server reports departures with a `peerLeft` frame:
  `{ type: "peerLeft", roomId, peerId, reason: "left" | "offline",
socketGeneration, protocolVersion: 5 }`. `"left"` means the member sent
  `leaveRoom`; `"offline"` means its last signaling socket closed, and the
  server sends one frame per room the identity is in. `socketGeneration` names
  the socket that left or closed. The client cannot verify the report, and a
  hostile or compromised signaling server is inside this project's threat
  model, so the report is a hint (`handleWebSocketMessage.ts`,
  `peerRosterDelta.ts`): it never closes a connected edge (an
  `RTCPeerConnection` in `connected` or `disconnected`). For `"left"` with no
  connected edge the client drops the member and abandons a negotiation still
  in progress; with a connected edge it keeps the edge and drops the member
  when that edge closes. For `"offline"` it keeps the edge and the member, and
  makes no reconcile retry or targeted roster request for that member until a
  server frame names it again. A `peers` delta, a `peerConnection`
  introduction or a `connection` from the member withdraws either report; a
  `peers` snapshot, which lists offline members too, withdraws a `"left"`
  report, and an `"offline"` one only when it shows the member on another
  socket generation. A report naming another generation than the one the
  server last named for that member is about an earlier session and changes
  nothing, which is what keeps a departure delivered after the member's quick
  return from removing it; a report naming this client, an untracked peer or
  an unknown room is refused like a malformed frame. A false report gives the
  server no power it lacked: it could already decline to introduce a member or
  to relay a negotiation that has not connected. What a false report can do is
  make this client stop retrying a member whose edge later drops; the other
  member's own retries still reach it through the server.

The relay sees source addresses, allocations, timing and byte counts. Its
TURN REST username contains a Unix expiry and a 22-character opaque
base64url tag. The client checks that the username prefix matches the
expiry and that it lies within the allowed lifetime. The issuing signaling server can associate
an issued credential with the socket that requested it.

The first client frame carries its public Ed25519 identity key and a signature
over the UTF-8 string `p2party-signaling-auth-v2`, a zero byte, the lowercase
WebSocket host (including any nondefault port), a zero byte and the server's
32-byte nonce. The server checks this against its configured host. The
WebSocket upgrade URL omits the public key. The signaling operator still
sees identities, room membership, SDP and ICE, and it controls availability.

## Shipped, implemented core, and research

| Status                    | Exact boundary in 0.14                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Shipped public path       | Full WebRTC room mesh; protocol-v4 hybrid 3DH + exact room-fixed ML-KEM-512/768/1024 bootstrap; optional CPace PIN rooms; chained triple confirmation; per-edge Double Ratchet; fixed message cells and in-transfer decoys; per-message channels; authenticated receipts, cancellation, selective retransmission, reconnect resume; compact/fragment/word invites; store-free `createSession()`/`restoreSession()` API. |
| Shipped, newer            | Sparse post-quantum healing (OFFER/ADVANCE/ACK epoch exchange) with persist-before-dispatch and application traffic blocked while an epoch is in flight. Room-wide scheduled timing cover: policy-pinned cadence, lanes, and frames per cell, emitted whether or not data is queued.                                                                                                                                    |
| Research/design direction | Opaque/server-blind rendezvous and blind meeting points; a private BitTorrent-compatible swarm extension; multi-device/group-state designs beyond independent pairwise mesh edges; and machine-checked formal analysis comparable in scope to PQXDH work.                                                                                                                                                               |

Scheduled cover is a room-wide property: it hides _when_ a peer has something
to say only for as long as every edge in the room keeps emitting on the
schedule. It does not hide room membership from the signaling operator, and it
does not apply to rooms whose policy selects immediate delivery.

## Deployment obligations

Applications using `p2party/session` own several security-critical jobs:

- authenticate or explicitly TOFU-pin peer Ed25519 keys;
- bind the session to a real transport context and route handshake frames
  without cross-session confusion;
- keep long-term Ed25519/X25519 secrets in protected storage;
- encrypt snapshots at rest and enforce rollback protection;
- wipe caller-owned PIN, identity-secret, WASM scratch, and snapshot buffers
  when their lifecycle ends;
- enforce timeouts, message-size/resource limits, and abuse controls; and
- update JavaScript and its exact release-matched WASM together.

For browser-mesh setup and artifact behavior, see
[Getting started](getting-started.md). For the standalone transport and
snapshot contract, see [Store-free session API](session-api.md).
