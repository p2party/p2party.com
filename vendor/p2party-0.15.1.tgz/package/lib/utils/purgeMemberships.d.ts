export interface PurgeMembershipResult {
    /** Local room IDs, or the public locator while an ID is still pending. */
    unacknowledgedRoomIds: string[];
    /** False if the saved-room list could not be read before the deadline. */
    roomInventoryComplete: boolean;
}
interface SavedMembership {
    roomId: string;
    roomUrl: string;
    signalingServerUrl?: string;
    membershipPublicKey?: string;
}
/** Start all correlated leaves while the old socket and key still own them.
 * Older saved rooms do not identify their server, so only an active join
 * can establish their authority. Never send a locator to a guessed server.
 */
export declare const leaveMembershipsForPurge: (activeRooms: readonly {
    id: string;
    url: string;
    signalingActive?: boolean;
}[], serverUrl: string, publicKey: string, readSavedRooms: () => Promise<readonly SavedMembership[]>, leave: (url: string, remainingMs: number) => Promise<void>, timeoutMs?: number) => Promise<PurgeMembershipResult>;
export {};
