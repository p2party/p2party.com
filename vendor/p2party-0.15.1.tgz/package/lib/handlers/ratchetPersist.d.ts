import type { LibCrypto } from "../cryptography/libcrypto";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { PqMessageKeyContext } from "../cryptography/pqMessageKey";
import type { RatchetHeader, RatchetState } from "../cryptography/ratchet";
import type { DecryptedChunk } from "./messageChunkCrypto";
/** Claim this authenticated identity edge for its new transport generation. */
export declare const claimRatchetGeneration: (epc: IRTCPeerConnection, roomId: string) => void;
/** Revocation is synchronous so queued work cannot reactivate a retired edge. */
export declare const releaseRatchetGeneration: (epc: IRTCPeerConnection, roomId: string) => void;
export declare const assertCurrentRatchetGeneration: (epc: IRTCPeerConnection, roomId: string) => void;
/** Optional instrumentation for testing staged transitions. */
export type RatchetTransitionHook = (state: RatchetState, roomId: string, peerPublicKey: string, peerId: string, edgeCryptoState?: Uint8Array | null) => Promise<void>;
export declare const withEdgeCryptoMutationLock: <T>(epc: IRTCPeerConnection, mutation: () => Promise<T>) => Promise<T>;
/**
 * TESTS ONLY. Lets `advanceSendingRatchet` step this edge without an
 * installed PQ runtime; the step then returns a null PQ context, which only
 * `sealChunkClassicalOnlyForTests` accepts. Without this the step refuses
 * such an edge. tests/handlers/messageChunkCrypto.test.ts checks that no
 * production module calls it.
 */
export declare const allowClassicalOnlySendForTests: (epc: IRTCPeerConnection) => void;
/**
 * Advance the sending chain exactly once before its key/header can be
 * used to build a frame. The returned message key remains caller-owned, as is
 * the returned OWNED copy of the current PQ message context. Capturing the
 * context and counting the application message happen inside the same edge
 * transaction as the ratchet step, so a concurrent PQ healing transition
 * cannot interleave.
 *
 * A live edge always installs its PQ runtime together with its ratchet
 * (`activateEdgeCrypto`), and every v4 message key is PQ-combined.
 * An edge with a ratchet but no PQ runtime therefore means that invariant
 * broke; the step rejects before touching the ratchet. The context is null
 * only for an edge a test opted in with `allowClassicalOnlySendForTests`.
 */
export declare const advanceSendingRatchet: (epc: IRTCPeerConnection, roomId: string, module: LibCrypto, beforeCommit?: RatchetTransitionHook) => Promise<{
    messageKey: Uint8Array;
    header: RatchetHeader;
    pqContext: PqMessageKeyContext | null;
}>;
/**
 * TESTS ONLY. Lets this edge receive without an installed PQ runtime, under
 * raw classical ratchet keys (`decryptMessageChunkClassicalOnlyForTests`),
 * with the classical key kept in the skipped map until retirement.
 * Without this, `decryptChunkWithLiveRatchet` refuses such an edge.
 * tests/handlers/messageChunkCrypto.test.ts checks that no production module
 * calls it.
 */
export declare const allowClassicalOnlyReceiveForTests: (epc: IRTCPeerConnection) => void;
/**
 * Decrypt one inbound chunk with a staged state/cache. An authenticated ratchet
 * advance is adopted before exposing decrypted bytes. A cache hit reuses the
 * message key held by this live generation.
 *
 * A live edge always installs its PQ runtime together with its ratchet
 * (`activateEdgeCrypto`), and every v4 message key is PQ-combined.
 * An edge with a ratchet but no PQ runtime therefore means that invariant
 * broke; the decrypt rejects before touching the ratchet rather than falling
 * back to the raw classical key.
 */
export declare const decryptChunkWithLiveRatchet: (epc: IRTCPeerConnection, roomId: string, frame: Uint8Array, cache: Map<string, Uint8Array>, merkleRoot: Uint8Array, module: LibCrypto, beforeCommit?: RatchetTransitionHook) => Promise<DecryptedChunk>;
/**
 * Erase the active receive key when the atomic chunk manifest is complete.
 */
export declare const forgetReceiveMessageKeyIfCurrent: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, canRetire: (() => Promise<boolean>) | undefined, beforeCommit?: RatchetTransitionHook) => Promise<boolean>;
export declare const forgetReceiveMessageKey: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, beforeCommit?: RatchetTransitionHook) => Promise<void>;
