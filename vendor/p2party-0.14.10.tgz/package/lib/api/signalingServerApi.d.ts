import { type RequestRoomLeaveOptions } from "../utils/roomLeaveCoordinator";
import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { WebSocketMessageCandidateSend, WebSocketMessageDescriptionSend, WebSocketMessageChallengeResponse, WebSocketMessageRoomIdRequest, WebSocketMessagePeersRequest, WebSocketMessageConnectionResponse, WebSocketMessagePongResponse, WebSocketMessageLeaveRoomRequest, WebSocketPeerConnectionParams, WebSocketMessagePeerConnectionRequest } from "../utils/interfaces";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
export interface WebSocketParams {
    signalingServerUrl: string;
}
export interface WebSocketMessage {
    content: WebSocketMessagePongResponse | WebSocketMessageCandidateSend | WebSocketMessageDescriptionSend | WebSocketMessageChallengeResponse | WebSocketMessageRoomIdRequest | WebSocketMessageLeaveRoomRequest | WebSocketMessagePeersRequest | WebSocketMessageConnectionResponse | WebSocketMessagePeerConnectionRequest;
}
/**
 * The host the reconnect controller reads Redux state from and dispatches
 * through. Bound on every connect attempt; the tests rebind it directly. It is
 * NOT the store import, so this module keeps its existing dependency edges.
 */
type SignalingReconnectHost = {
    dispatch: (action: unknown) => unknown;
    getState: () => unknown;
};
export declare const setSignalingReconnectHost: (host: SignalingReconnectHost | null) => void;
/**
 * Record how a socket ended, so the reconnect ladder can refuse a close the
 * server means as final. `selfInitiated` is what keeps the SDK's own protective
 * closes out of the policy: `onOverflow` closes with 1008 when this tab's
 * ingress backlog is exceeded, and local overload is exactly what bounded
 * backoff is for.
 */
export declare const noteSignalingSocketClose: (close: Readonly<{
    code: number;
    selfInitiated: boolean;
}>) => void;
/**
 * A ladder rung is a floor, never shortened, and at most 25 % longer. Without
 * this every client a server restart disconnected walks the identical
 * 1/2/4/8 s ladder and re-handshakes in lockstep, which is the same stampede
 * the restart caused. The spread lives here rather than in the controller
 * because the controller's ladder is exact by contract and its tests assert
 * exact delays; the scheduler this module injects is the seam that perturbs it.
 */
export declare const signalingReconnectDelayWithJitter: (delayMs: number) => number;
/**
 * C4: a socket close that carries no browser wake event is otherwise terminal.
 * `settleClosedSocket` detects; this reconnects. Shared by the close handler,
 * the error handler and the heartbeat watchdog, so a peer whose socket died
 * while its edges stayed authenticated is found again within 1-30 s instead of
 * never.
 */
export declare const signalingReconnect: import("../utils/signalingReconnectController").SignalingReconnectController;
type CurrentSocketApi = Pick<BaseQueryApi, "dispatch" | "getState">;
/**
 * Send a correlated leave on the exact authenticated socket and wait for its
 * exact acknowledgement. The caller must make local room transport terminal
 * before invoking this network-only boundary.
 */
export declare const requestCurrentSocketRoomLeave: (api: CurrentSocketApi, roomUrl: string, options?: RequestRoomLeaveOptions) => Promise<void>;
declare const signalingServerApi: import("@reduxjs/toolkit/query").Api<BaseQueryFn<WebSocketParams, undefined>, {
    connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, BaseQueryFn<WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
    disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, BaseQueryFn<WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
    sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<WebSocketMessage, BaseQueryFn<WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
    connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<WebSocketPeerConnectionParams, BaseQueryFn<WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
}, "signalingServerApi", never, typeof import("@reduxjs/toolkit/query").coreModuleName>;
/** Queue one room request or reject immediately when RTK reports no send. */
export declare const sendRoomRequestMessage: (api: Pick<BaseQueryApi, "dispatch">, request: WebSocketMessageRoomIdRequest) => Promise<void>;
export default signalingServerApi;
