import type { PayloadAction } from "@reduxjs/toolkit";
export interface SignalingState {
    isEstablishingConnection: boolean;
    isConnected: boolean;
    isVerified: boolean;
    serverUrl: string;
}
export declare const signalingServerActions: import("@reduxjs/toolkit").CaseReducerActions<{
    startConnecting: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
    }, action: PayloadAction<string | undefined>) => void;
    connectionEstablished: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
    }) => void;
    connectionVerified: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
    }) => void;
    disconnect: (state: {
        isEstablishingConnection: boolean;
        isConnected: boolean;
        isVerified: boolean;
        serverUrl: string;
    }) => void;
}, "signalingServer">;
export declare const signalingServerSelector: (state: {
    readonly signalingServer: SignalingState;
}) => SignalingState;
declare const _default: import("redux").Reducer<SignalingState>;
export default _default;
