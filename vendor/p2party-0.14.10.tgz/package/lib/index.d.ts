import type { PendingMessage } from "./handlers/outbox";
export type { PendingMessage } from "./handlers/outbox";
import { createSession, generateSessionIdentity, restoreSession } from "./session";
import { validateMnemonic, validateMnemonicWords } from "./cryptography/mnemonic";
import { setWasmSourceUrl } from "./cryptography/wasmLoader";
import { setDebugLogging } from "./utils/debug";
import { WIRE_CHUNK_FRAME_LEN } from "./utils/constants";
import { DEFAULT_ROOM_POLICY_V1, MIN_COVER_CADENCE_MS, MAX_COVER_CADENCE_MS, MAX_COVER_LANES, MAX_COVER_FRAMES_PER_CELL, MIN_COVER_SLOT_MS, canonicalizeRoomPolicyV1, decodeRoomPolicyV1, encodeRoomPolicyV1, hashRoomPolicyV1, roomPoliciesEqualV1, validateRoomPolicyV1 } from "./roomPolicy";
import { InvalidRecoveryPhraseError } from "./utils/identityRestore";
import { RemoteRoomRevocationUnconfirmedError } from "./utils/roomLeaveCoordinator";
import type { State as InternalState } from "./store";
import type { Room, Peer, Channel, Message } from "./reducers/roomSlice";
import type { SignalingState } from "./reducers/signalingServerSlice";
import type { MimeType, FileExtension } from "./utils/messageTypes";
import type { WebSocketMessageRoomIdRequest, WebSocketMessageRoomIdResponse, WebSocketMessageChallengeRequest, WebSocketMessageChallengeResponse, WebSocketMessageDescriptionSend, WebSocketMessageDescriptionReceive, WebSocketMessageCandidateSend, WebSocketMessageCandidateReceive, WebSocketMessageLeaveRoomRequest, WebSocketMessageRoomLeftResponse, WebSocketMessageError } from "./utils/interfaces";
import type { RoomData } from "./api/webrtc/interfaces";
import type { BlacklistedPeer, IdentityDerivation, UsernamedPeer, UniqueRoom, RoomStats } from "./db/types";
import type { CreatedRecoverableIdentity, CreateRecoverableIdentityOptions, RestoredIdentity } from "./utils/identityRestore";
import type { KeyPair } from "./reducers/keyPairSlice";
import type { RoomPolicyV1 } from "./roomPolicy";
import type { SendMessageResult } from "./handlers/handleSendMessage";
import { MessageDeliveryError } from "./handlers/handleSendMessage";
/** Public projection; reducer state keeps its additional fields normalized. */
type State = Omit<InternalState, "rooms"> & {
    rooms: Room[];
};
export interface ConnectRoomOptions {
    /**
     * Canonical public room policy. Omit on reconnect to preserve the room's
     * existing policy; a new room defaults to hybrid-PQ, no-PIN, immediate
     * delivery over the currently shipped signaling path.
     */
    policy?: RoomPolicyV1;
    /**
     * Required exactly when `policy.authMode` is `pin`. Copied into an in-memory
     * vault keyed by the local room URL; never enters Redux, storage, or logs.
     */
    pin?: Uint8Array;
}
export interface WaitForRoomOptions {
    /** Reject if the signaling service has not assigned an id in this long. */
    timeoutMs?: number;
    /** Cancel the wait, e.g. because the user navigated away. */
    signal?: AbortSignal;
}
/**
 * Resolve once the signaling service has assigned this room its id.
 *
 * `connect()` returns as soon as the join has been *started*; the id arrives
 * later, on a `roomId` frame. Without this, every caller has to hand-roll the
 * same store subscription — a mutable `unsubscribe` binding, an `inspect()`
 * that must also be called once synchronously in case the room is already
 * there, and no timeout — which is a lot of ceremony to learn one string.
 *
 * Resolves immediately when the room is already known.
 */
declare const waitForRoom: (roomUrl: string, options?: WaitForRoomOptions) => Promise<Room>;
/**
 * Join a room and resolve once it has an id, in one call.
 *
 * This is `connect()` followed by `waitForRoom()`, which is what essentially
 * every browser caller wants:
 *
 * ```ts
 * const invite = p2party.generateRoomInvite();
 * const room = await p2party.joinRoom(invite);
 * console.log("joined", room.id);
 * ```
 */
declare const joinRoom: (roomUrl: string, signalingServerUrl?: string, rtcConfig?: RTCConfiguration, options?: ConnectRoomOptions & WaitForRoomOptions) => Promise<Room>;
export interface WaitForPeersOptions extends WaitForRoomOptions {
    /** Resolve once this many peers have completed the handshake. Default 1. */
    count?: number;
}
/**
 * Resolve once `count` peers in the room have finished authenticating.
 *
 * A room having an id says nothing about whether anyone can receive a message:
 * `sendMessage` to a room with no authenticated peer rejects. Callers were
 * writing their own store subscription and peer-count poll to bridge that gap.
 */
declare const waitForPeers: (roomId: string, options?: WaitForPeersOptions) => Promise<Peer[]>;
export interface InboundMessage {
    readonly roomId: string;
    readonly fromPeerId: string;
    readonly merkleRootHex: string;
    readonly filename: string;
    readonly size: number;
    /** Text for a text message; a Blob for a completed file. */
    readonly message: string | Blob;
}
/**
 * Call `handler` once for each message that finishes arriving in a room.
 *
 * Without this, every application reimplements the same loop: subscribe to the
 * store, diff the room's `messages` array against what it saw last time, skip
 * anything still in flight, and call `readMessage` to decode. Returns an
 * unsubscribe function.
 *
 * Handler errors are caught and logged rather than allowed to escape into the
 * store's notify loop, where they would break unrelated subscribers.
 */
declare const onMessage: (roomId: string, handler: (message: InboundMessage) => void) => (() => void);
/**
 * If no toChannel then broadcast the message everywhere to everyone.
 * If toChannel then broadcast to all peers with that channel.
 */
export interface MessageTransferHandle {
    readonly transferId: string;
    /**
     * Settles only after every started peer send/reconciliation and cleanup
     * finishes, preserving the ordered per-peer delivery outcomes.
     *
     * This promise REJECTS when no peer took delivery — for example every edge
     * failed, or the transfer was cancelled. The rejection is a
     * {@link MessageDeliveryError}, whose `result.outcomes` carries the same
     * per-peer detail a resolved value would have, and whose `errors` holds the
     * underlying per-peer failures. Always attach a catch:
     *
     * ```ts
     * const handle = p2party.sendMessage(data, "chat", roomId);
     * try {
     *   const result = await handle.done;
     * } catch (error) {
     *   if (error instanceof p2party.MessageDeliveryError)
     *     console.table(error.result.outcomes);
     * }
     * ```
     */
    readonly done: Promise<SendMessageResult | undefined>;
    /** Cancels exactly this logical send, even before hashing/WASM setup finishes. */
    cancel(): Promise<void>;
}
/**
 * Adopt the identity a recovery phrase encodes, in place of the current one.
 *
 * An invalid phrase rejects with `InvalidRecoveryPhraseError` before anything
 * is disconnected, so a typo costs nothing. Only a phrase that derives a key
 * opens the exclusive boundary: signaling is disconnected, every room's WebRTC
 * transport is brought to a terminal state, the cross-signed X25519 identity is
 * deleted (the next connection regenerates and re-signs it), the Ed25519 key is
 * persisted, and the identity is adopted in memory last.
 *
 * Rooms, messages, the address book and cached room PINs are all kept. Peers
 * see a new identity key for this device, exactly as they would after a purge,
 * so the address book will report an identity change.
 *
 * Signaling is left disconnected: call `connect(roomUrl)` afterwards to come
 * back online under the restored identity.
 *
 * @param mnemonic - The recovery phrase, in any transcription
 * @param password - The passphrase the identity was created with, if any
 * @returns The restored Ed25519 public key, hex-encoded
 */
declare const restoreIdentityFromMnemonic: (mnemonic: string, password?: string) => Promise<RestoredIdentity>;
/**
 * Replace the current identity with a freshly generated, recoverable one and
 * return the phrase that restores it.
 *
 * The phrase is shown once and stored nowhere: it is the only backup, and a
 * caller that drops it before the user has written it down has lost it. A
 * `password` is folded into the derivation and is equally unrecoverable — the
 * phrase alone will not restore the identity without it.
 *
 * As with `restoreIdentityFromMnemonic`, signaling is left disconnected; call
 * `connect(roomUrl)` afterwards.
 *
 * @param options - Entropy bits (128 gives 12 words, 256 gives 24) and an
 *   optional passphrase
 * @returns The recovery phrase and the Ed25519 public key it now derives
 */
declare const createRecoverableIdentity: (options?: CreateRecoverableIdentityOptions) => Promise<CreatedRecoverableIdentity>;
/** What the current account key is, and whether a phrase can reproduce it. */
export interface IdentityBackupStatus {
    publicKey: string;
    derivation: IdentityDerivation | null;
}
/**
 * Whether the identity in use can be backed up at all.
 *
 * `derivation` is "mnemonic" only for an identity that was created from a
 * recovery phrase; a "random" one cannot be exported, and the only way to get a
 * recoverable identity is `createRecoverableIdentity`, which replaces it. It is
 * null when no identity is stored yet, and also when the stored flag no longer
 * describes the stored key — an unreadable provenance hint must never be
 * reported as "this can be backed up".
 *
 * @returns The current Ed25519 public key (empty when there is none) and how it
 *   came into being
 */
declare const getIdentityBackupStatus: () => Promise<IdentityBackupStatus>;
export declare const p2party: {
    store: import("@reduxjs/toolkit").EnhancedStore<{
        commonState: import("./reducers/commonSlice").CommonState;
        keyPair: KeyPair;
        rooms: import("./reducers/roomSlice").ManagedRoom[];
        signalingServer: SignalingState;
        signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
        }, never, "signalingServerApi">;
        webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
            connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            applyRoomConfiguration: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCApplyRoomConfigurationParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, SendMessageResult | undefined, "webrtcApi", undefined>;
            disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
        }, never, "webrtcApi">;
    }, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
        dispatch: import("redux-thunk").ThunkDispatch<{
            commonState: import("./reducers/commonSlice").CommonState;
            keyPair: KeyPair;
            rooms: import("./reducers/roomSlice").ManagedRoom[];
            signalingServer: SignalingState;
            signalingServerApi: import("@reduxjs/toolkit/query").CombinedState<{
                connectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<string, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                disconnectWebSocket: import("@reduxjs/toolkit/query").MutationDefinition<undefined, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/signalingServerApi").WebSocketMessage, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
                connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./utils/interfaces").WebSocketPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/signalingServerApi").WebSocketParams, undefined>, never, undefined, "signalingServerApi", undefined>;
            }, never, "signalingServerApi">;
            webrtcApi: import("@reduxjs/toolkit/query").CombinedState<{
                connectWithPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCPeerConnectionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                setDescription: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetDescriptionParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                setCandidate: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSetCandidateParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                applyRoomConfiguration: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCApplyRoomConfigurationParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                openChannel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCOpenChannelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                sendMessage: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCSendMessageParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, SendMessageResult | undefined, "webrtcApi", undefined>;
                disconnect: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromRoom: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromRoomParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromAllRooms: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromAllRoomsParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromPeer: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
                disconnectFromPeerChannelLabel: import("@reduxjs/toolkit/query").MutationDefinition<import("./api/webrtc/interfaces").RTCDisconnectFromPeerChannelLabelParams, import("@reduxjs/toolkit/query").BaseQueryFn<import("./api/webrtc/baseQuery").RTCPeerConnectionParamsExtend, undefined>, never, undefined, "webrtcApi", undefined>;
            }, never, "webrtcApi">;
        }, undefined, import("redux").UnknownAction> & ((action: import("redux").Action<"listenerMiddleware/add">) => import("@reduxjs/toolkit").UnsubscribeListener);
    }>, import("redux").StoreEnhancer]>>;
    commonStateSelector: (state: {
        readonly commonState: import("./reducers/commonSlice").CommonState;
    }) => import("./reducers/commonSlice").CommonState;
    signalingServerSelector: (state: {
        readonly signalingServer: SignalingState;
    }) => SignalingState;
    roomSelector: <TRoom extends Room>(state: {
        readonly rooms: TRoom[];
    }) => TRoom[];
    keyPairSelector: (state: {
        readonly keyPair: KeyPair;
    }) => KeyPair;
    connect: (roomUrl: string, signalingServerUrl?: string, rtcConfig?: RTCConfiguration, options?: ConnectRoomOptions) => Promise<void>;
    connectToSignalingServer: (roomUrl: string, signalingServerUrl?: string) => Promise<void>;
    disconnectFromSignalingServer: () => Promise<void>;
    disconnectFromRoom: (roomId: string, deleteMessages?: boolean) => Promise<void>;
    disconnectFromAllRooms: (deleteMessages?: boolean, exceptionRoomIds?: string[]) => Promise<void>;
    disconnectFromPeer: (peerId: string) => Promise<void>;
    allowConnectionRelay: (roomId: string, allowed?: boolean) => void;
    onlyAllowConnectionsFromAddressBook: (roomUrl: string, onlyAllow: boolean) => Promise<void>;
    addPeerToAddressBook: (username: string, peerId: string, peerPublicKey: string) => Promise<undefined>;
    getPeerAddressBookEntry: (peerId?: string, peerPublicKey?: string) => Promise<UsernamedPeer | undefined>;
    getAllPeersInAddressBook: () => Promise<UsernamedPeer[]>;
    getAllPeersInBlacklist: () => Promise<BlacklistedPeer[]>;
    deletePeerFromAddressBook: (username?: string, peerId?: string, peerPublicKey?: string) => Promise<void>;
    blacklistPeer: (peerId: string, peerPublicKey: string) => Promise<void>;
    getPeerIsBlacklisted: (peerId?: string, peerPublicKey?: string) => Promise<boolean>;
    removePeerFromBlacklist: (peerId?: string, peerPublicKey?: string) => Promise<undefined>;
    getAllExistingRooms: () => Promise<UniqueRoom[]>;
    getRoomStats: (roomId: string) => Promise<RoomStats>;
    sendMessage: (data: string | File, toChannel: string, roomId: string, percentageFilledChunk?: number, minChunks?: number, chunkSize?: number, metadataSchemaVersion?: number, transferId?: string) => MessageTransferHandle;
    listPendingMessages: (roomId?: string) => Promise<PendingMessage[]>;
    resumePendingMessages: (roomId: string) => Promise<SendMessageResult[]>;
    cancelPendingMessage: (roomId: string, transferId: string) => Promise<void>;
    readMessage: (merkleRootHex: string, hashHex?: string, materialize?: boolean) => Promise<{
        message: string | Blob;
        percentage: number;
        size: number;
        filename: string;
        mimeType: MimeType;
        extension: FileExtension;
        category: string;
        chunksReceivedTotal?: number;
        chunksReceivedReal?: number;
        retransmits?: number;
    }>;
    getTransferAcks: (roomId: string, transferId: string) => import(".").TransferAck[];
    getSendChunksCount: (transferId: string) => Promise<number>;
    cancelMessage: (roomId: string, channelLabel: string, merkleRoot?: string | Uint8Array, hash?: string | Uint8Array, transferId?: string) => Promise<void>;
    createTransferId: () => string;
    deleteMessage: (roomId: string, merkleRoot?: string | Uint8Array, hash?: string | Uint8Array) => Promise<void>;
    purgeIdentity: () => Promise<void>;
    purgeRoom: (roomUrl: string) => Promise<void>;
    purge: () => Promise<void>;
    generateRandomRoomUrl: () => Promise<string>;
    generateRoomInvite: () => string;
    generateRoomCapability: () => Uint8Array;
    encodeRoomCapabilityBase64Url: (capability: Uint8Array) => string;
    decodeRoomCapabilityBase64Url: (encoded: string) => Uint8Array;
    decodeRoomCapability: (encoded: string) => Uint8Array;
    normalizeRoomCapability: (encoded: string) => string;
    encodeRoomInviteFragment: (capability: Uint8Array) => string;
    decodeRoomInviteFragment: (fragment: string) => Uint8Array;
    encodeRoomCapabilityWords: (capability: Uint8Array) => Promise<string>;
    decodeRoomCapabilityWords: (encoded: string) => Promise<Uint8Array>;
    ROOM_INVITE_WORDLIST_ID: string;
    sign: (message: Uint8Array, secretKey: Uint8Array, module?: import("./cryptography/libcrypto").LibCrypto) => Promise<Uint8Array>;
    verify: (message: Uint8Array, signature: Uint8Array, publicKey: Uint8Array, module?: import("./cryptography/libcrypto").LibCrypto) => Promise<boolean>;
    createSession: (options: import("./session").CreateSessionOptions) => Promise<import("./session").P2PartySession>;
    restoreSession: (snapshot: Uint8Array, crypto?: import("./session").SessionCryptoOptions) => Promise<import("./session").P2PartySession>;
    generateSessionIdentity: (options?: import("./session").GenerateSessionIdentityOptions) => Promise<import("./session").GeneratedSessionIdentity>;
    setWasmSourceUrl: (source: string | URL) => void;
    DEFAULT_ROOM_POLICY_V1: Readonly<RoomPolicyV1>;
    encodeRoomPolicyV1: (policy: RoomPolicyV1) => Uint8Array;
    decodeRoomPolicyV1: (encoded: Uint8Array) => RoomPolicyV1;
    hashRoomPolicyV1: (policy: RoomPolicyV1) => Promise<Uint8Array>;
    roomPoliciesEqualV1: (left: RoomPolicyV1, right: RoomPolicyV1) => boolean;
    generateKeyPair: (module?: import("./cryptography/libcrypto").LibCrypto) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    newKeyPair: (module?: import("./cryptography/libcrypto").LibCrypto) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    generateMnemonic: (strength?: 128 | 160 | 192 | 224 | 256 | 288 | 320 | 352 | 384 | 416 | 448 | 480 | 512) => Promise<string>;
    keyPairFromMnemonic: (mnemonic: string, password?: string, module?: import("./cryptography/libcrypto").LibCrypto) => Promise<import("./cryptography/interfaces").SignKeyPair>;
    validateMnemonic: (mnemonic: string) => Promise<boolean>;
    validateMnemonicWords: (words: string) => import(".").MnemonicValidation;
    createRecoverableIdentity: (options?: CreateRecoverableIdentityOptions) => Promise<CreatedRecoverableIdentity>;
    restoreIdentityFromMnemonic: (mnemonic: string, password?: string) => Promise<RestoredIdentity>;
    getIdentityBackupStatus: () => Promise<IdentityBackupStatus>;
    InvalidRecoveryPhraseError: typeof InvalidRecoveryPhraseError;
    MIN_CHUNKS: number;
    MIN_CHUNK_SIZE: number;
    MAX_CHUNK_SIZE: number;
    WIRE_CHUNK_FRAME_LEN: number;
    MIN_COVER_CADENCE_MS: number;
    MAX_COVER_CADENCE_MS: number;
    MAX_COVER_LANES: number;
    MAX_COVER_FRAMES_PER_CELL: number;
    MIN_COVER_SLOT_MS: number;
    validateRoomPolicyV1: (policy: RoomPolicyV1) => void;
    MessageDeliveryError: typeof MessageDeliveryError;
    RemoteRoomRevocationUnconfirmedError: typeof RemoteRoomRevocationUnconfirmedError;
    joinRoom: (roomUrl: string, signalingServerUrl?: string, rtcConfig?: RTCConfiguration, options?: ConnectRoomOptions & WaitForRoomOptions) => Promise<Room>;
    waitForRoom: (roomUrl: string, options?: WaitForRoomOptions) => Promise<Room>;
    waitForPeers: (roomId: string, options?: WaitForPeersOptions) => Promise<Peer[]>;
    onMessage: (roomId: string, handler: (message: InboundMessage) => void) => (() => void);
    setDebugLogging: (value: boolean) => void;
    MIN_PERCENTAGE_FILLED_CHUNK: number;
    MAX_PERCENTAGE_FILLED_CHUNK: number;
    ROOM_URL_LENGTH: number;
    MessageType: {
        Text: number;
        ImagePNG: number;
        ImageJPEG: number;
        ImageJPG: number;
        ImageGIF: number;
        ImageBMP: number;
        ImageTIFF: number;
        ImageSVG: number;
        ImageWEBP: number;
        ImageHEIC: number;
        DocumentPDF: number;
        DocumentDOC: number;
        DocumentDOCX: number;
        DocumentXLS: number;
        DocumentXLSX: number;
        DocumentPPT: number;
        DocumentPPTX: number;
        DocumentTXT: number;
        DocumentRTF: number;
        DocumentODT: number;
        AudioMP3: number;
        AudioWAV: number;
        AudioAAC: number;
        AudioFLAC: number;
        AudioOGG: number;
        AudioM4A: number;
        VideoMP4: number;
        VideoAVI: number;
        VideoMKV: number;
        VideoMOV: number;
        VideoWMV: number;
        VideoFLV: number;
        VideoWEBM: number;
        CompressedZIP: number;
        CompressedRAR: number;
        Compressed7Z: number;
        CompressedTAR: number;
        CompressedGZ: number;
        CodeHTML: number;
        CodeCSS: number;
        CodeJS: number;
        CodeJSX: number;
        CodeTS: number;
        CodeTSX: number;
        CodeJSON: number;
        CodeXML: number;
        CodePY: number;
        CodeJAVA: number;
        CodeC: number;
        CodeCPP: number;
        CodeCS: number;
        CodeRB: number;
        CodePHP: number;
        CodeSQL: number;
        EbookEPUB: number;
        EbookMOBI: number;
        EbookAZW: number;
        FontTTF: number;
        FontOTF: number;
        ImageICO: number;
        ExecutableEXE: number;
        ExecutableDMG: number;
        ExecutableAPK: number;
        Unknown: number;
    };
    MessageCategory: {
        Text: string;
        Image: string;
        Document: string;
        Audio: string;
        Video: string;
        Compressed: string;
        Code: string;
        Ebook: string;
        Font: string;
        Executable: string;
        Unknown: string;
    };
    VERSION: string;
};
declare global {
    interface Window {
        p2party: typeof p2party;
    }
}
export type { State, Room, Peer, Channel, Message, RoomData, MimeType, FileExtension, UsernamedPeer, BlacklistedPeer, UniqueRoom, RoomStats, SignalingState, KeyPair, RoomPolicyV1, IdentityDerivation, WebSocketMessageRoomIdRequest, WebSocketMessageRoomIdResponse, WebSocketMessageChallengeRequest, WebSocketMessageChallengeResponse, WebSocketMessageDescriptionSend, WebSocketMessageDescriptionReceive, WebSocketMessageCandidateSend, WebSocketMessageCandidateReceive, WebSocketMessageLeaveRoomRequest, WebSocketMessageRoomLeftResponse, WebSocketMessageError, };
export { createSession, restoreSession, generateSessionIdentity, setWasmSourceUrl, MessageDeliveryError, RemoteRoomRevocationUnconfirmedError, createRecoverableIdentity, restoreIdentityFromMnemonic, getIdentityBackupStatus, validateMnemonic, validateMnemonicWords, InvalidRecoveryPhraseError, joinRoom, waitForRoom, waitForPeers, onMessage, setDebugLogging, };
export { DEFAULT_ROOM_POLICY_V1, canonicalizeRoomPolicyV1, decodeRoomPolicyV1, encodeRoomPolicyV1, hashRoomPolicyV1, roomPoliciesEqualV1, };
export { MIN_COVER_CADENCE_MS, MAX_COVER_CADENCE_MS, MAX_COVER_LANES, MAX_COVER_FRAMES_PER_CELL, MIN_COVER_SLOT_MS, validateRoomPolicyV1, WIRE_CHUNK_FRAME_LEN, };
export type { TransferAck } from "./handlers/reconcile";
export type { MnemonicValidation } from "./cryptography/mnemonic";
export type { CreatedRecoverableIdentity, CreateRecoverableIdentityOptions, RestoredIdentity, } from "./utils/identityRestore";
export type { RoomAuthMode, RoomCoverMode, RoomPqMode, RoomRendezvousMode, } from "./roomPolicy";
export type { CreateSessionOptions, EncryptedSessionMessage, GenerateSessionIdentityOptions, GeneratedSessionIdentity, HandshakeTransport, LocalSessionIdentity, P2PartySession, SessionChannelBinding, SessionCryptoOptions, } from "./session";
export default p2party;
