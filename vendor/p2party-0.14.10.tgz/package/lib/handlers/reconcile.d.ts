export declare const markChunkAcked: (roomId: string, peerId: string, transferId: string, chunkIndex: number) => boolean;
export declare const getAckedChunks: (roomId: string, peerId: string, transferId: string) => Set<number>;
/** Constant-time membership without allocating one Set copy per scheduled cell. */
export declare const hasChunkAcked: (roomId: string, peerId: string, transferId: string, chunkIndex: number) => boolean;
export declare const getAckedChunkCount: (roomId: string, peerId: string, transferId: string) => number;
export declare const markTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
export interface PeerTransferOutcome {
    readonly roomId: string;
    readonly peerId: string;
    readonly transferId: string;
    readonly ackedChunks: ReadonlySet<number>;
    readonly complete: boolean;
}
/** Accurate, defensive per-peer delivery state for UI/diagnostics consumers. */
export declare const getPeerTransferOutcome: (roomId: string, peerId: string, transferId: string) => PeerTransferOutcome;
export declare const isTransferComplete: (roomId: string, peerId: string, transferId: string) => boolean;
/** A recipient's refusal is terminal only for this edge, never the whole send. */
export declare const markTransferCancelled: (roomId: string, peerId: string, transferId: string) => boolean;
export declare const isTransferCancelled: (roomId: string, peerId: string, transferId: string) => boolean;
export interface TransferAck {
    readonly peerId: string;
    /**
     * Distinct chunks this peer has receipted so far, counting decoys: a receipt
     * is emitted per inbound frame, and the padding is what makes every frame
     * indistinguishable, so excluding it would report a fraction of a denominator
     * that includes it.
     */
    readonly ackedChunks: number;
    readonly complete: boolean;
}
/**
 * Live outbound progress for one logical send, per peer.
 *
 * The sender already knows this -- every receipt lands in the have-set above --
 * but nothing outside this module could read it, so a UI could say "sending"
 * and then nothing at all until the transfer settled. On a large file that is
 * a progress bar's worth of silence.
 *
 * Derived from the same state selective retransmit uses, so it cannot drift
 * from what the sender actually believes was delivered. Read-only and
 * defensively copied; polling it never affects the transfer.
 */
export declare const getTransferAcks: (roomId: string, transferId: string) => TransferAck[];
export declare const clearTransfer: (roomId: string, peerId: string, transferId: string) => void;
export declare const waitForCompletion: (roomId: string, peerId: string, transferId: string, timeoutMs: number, signal?: AbortSignal) => Promise<boolean>;
