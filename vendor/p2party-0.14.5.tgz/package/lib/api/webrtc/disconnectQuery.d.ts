import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCPeerConnection, RTCDisconnectParams, DisconnectPeerTransport } from "./interfaces";
export interface RTCDisconnectParamsExtension extends RTCDisconnectParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
    disconnectPeer: DisconnectPeerTransport;
}
declare const webrtcDisconnectQuery: BaseQueryFn<RTCDisconnectParamsExtension, undefined>;
export default webrtcDisconnectQuery;
