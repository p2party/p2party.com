type IceRestartTarget = Pick<RTCPeerConnection, "connectionState" | "signalingState" | "restartIce"> & {
    ensureFreshIceConfiguration?: () => Promise<boolean | void>;
};
export type IceCandidateRepairResult = "restarted" | "disconnected";
/**
 * Repair a candidate-add failure without ever calling restartIce() after
 * teardown. Active PCs restart in place; closed PCs, or PCs whose restart
 * throws because they closed concurrently, take the room-scoped disconnect
 * path instead.
 */
export declare const repairIceTransportAfterCandidateFailure: (target: IceRestartTarget, disconnect: () => void | Promise<void>) => Promise<IceCandidateRepairResult>;
export {};
