import type { MessageData } from "../../db/types";
export interface DeleteRoomDataDependencies {
    readonly getMessages: (roomId: string) => Promise<MessageData[]>;
    readonly deleteRoomRecord: (roomId: string) => Promise<void>;
    readonly deleteReceive: (merkleRootHex: string) => Promise<void>;
    readonly deleteOutgoing: (merkleRootHex: string) => Promise<void>;
}
/**
 * Await every durable room-data deletion and report only after all reachable
 * records were attempted. `removeLocalMessage` is reducer-only; no background
 * listener owns storage completion after this function returns.
 */
export declare const deleteRoomDataTerminal: (roomId: string, removeLocalMessage: (merkleRootHex: string) => void, dependencies?: DeleteRoomDataDependencies) => Promise<void>;
