/** The slice of an RTCPeerConnection that proves the transport is gone. */
export type PcOperationTarget = Pick<RTCPeerConnection, "signalingState" | "connectionState">;
export interface AwaitPcOperationOptions {
    /** How often the transport is inspected while the operation is in flight. */
    readonly pollMs?: number;
    /** Wall-clock budget after which the operation is abandoned. */
    readonly maxMs?: number;
    /** Named in the timeout warning so a stuck operation is identifiable. */
    readonly name?: string;
}
export declare const isPcOperationTargetClosed: (epc: PcOperationTarget) => boolean;
/**
 * Await one RTCPeerConnection operation without ever waiting forever on it.
 *
 * Closing an RTCPeerConnection aborts every operation in flight on it, and the
 * specification aborts them *without settling* their promises — while close()
 * itself fires no `connectionstatechange`. An `await pc.addIceCandidate(...)`
 * or `await pc.setRemoteDescription(...)` on a connection that closes
 * underneath it therefore never returns. In this codebase those awaits run
 * inside the (room, peer) negotiation mutex, which is entered from the socket's
 * strictly serial ingress queue: one such await strands the edge's mutex
 * forever AND stops every later signaling frame on that socket, so a peer's
 * re-introductions go unanswered indefinitely.
 *
 * The returned promise settles three ways:
 * - the operation's own result (or rejection, rethrown for the caller's
 *   existing error handling),
 * - `"closed"` as soon as a poll observes the transport closed — the operation
 *   is abandoned, since nothing it could still do matters,
 * - `"timeout"` once the budget expires, which callers treat exactly like a
 *   failure of that operation.
 *
 * An abandoned operation's later rejection is consumed here, so walking away
 * from it can never surface as an unhandled rejection.
 */
export declare const awaitPcOperation: <T>(epc: PcOperationTarget, operation: Promise<T>, { pollMs, maxMs, name, }?: AwaitPcOperationOptions) => Promise<T | "closed" | "timeout">;
