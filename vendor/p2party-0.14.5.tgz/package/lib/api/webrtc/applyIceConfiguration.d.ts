import type { IRTCPeerConnection } from "./interfaces";
/**
 * Apply the room's current effective ICE servers to every live transport.
 *
 * getConfiguration() preserves construction-time WebRTC options that browsers
 * do not allow setConfiguration() to change. Only the refreshable ICE list is
 * replaced.
 */
export declare const applyRoomIceConfiguration: (peerConnections: readonly IRTCPeerConnection[], roomId: string, rtcConfig: RTCConfiguration, restartIceAfterApply?: boolean, failurePolicy?: "rollback" | "close") => number;
