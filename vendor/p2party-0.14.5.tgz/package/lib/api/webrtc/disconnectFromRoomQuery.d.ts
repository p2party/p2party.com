import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCPeerConnection, RTCDisconnectFromRoomParams, DisconnectPeerTransport } from "./interfaces";
export interface RTCDisconnectFromRoomParamsExtension extends RTCDisconnectFromRoomParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
    disconnectPeer: DisconnectPeerTransport;
}
declare const webrtcDisconnectRoomQuery: BaseQueryFn<RTCDisconnectFromRoomParamsExtension, undefined>;
export default webrtcDisconnectRoomQuery;
