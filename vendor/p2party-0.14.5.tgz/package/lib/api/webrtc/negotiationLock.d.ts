import { AsyncMutex } from "../../utils/mutex";
export declare const getRoomPeerMutex: (roomId: string, peerId: string) => AsyncMutex;
/**
 * Forget a terminal edge only after its current owner and queued signaling
 * operations drain. Deleting a locked mutex would permit a second instance to
 * enter the same critical section concurrently.
 */
export declare const releaseRoomPeerMutex: (roomId: string, peerId: string) => void;
/**
 * Serialize one negotiation operation and release its registry key once every
 * queued owner drains. This must wrap nonterminal frames too: otherwise valid
 * unknown-peer SDP/ICE identifiers can grow the mutex registry forever.
 */
export declare const runRoomPeerExclusive: <T>(roomId: string, peerId: string, operation: () => Promise<T>) => Promise<T>;
/** Narrow test visibility without exposing the mutable registry. */
export declare const hasRoomPeerMutex: (roomId: string, peerId: string) => boolean;
/** Narrow test visibility without exposing the mutable registry. */
export declare const roomPeerMutexCount: () => number;
export declare const getRoomIdentityMutex: (roomId: string, peerPublicKey: string) => AsyncMutex;
export declare const releaseRoomIdentityMutex: (roomId: string, peerPublicKey: string) => void;
/**
 * Serializes caller configuration mutation and a room-response live sweep +
 * Redux publication with the final configuration read, construction, and
 * registry insertion of a new PC. The key is the stable room URL, including
 * while the room is still awaiting its server-assigned id.
 */
export declare const getRoomIceConfigurationMutex: (roomUrl: string) => AsyncMutex;
export declare const releaseRoomIceConfigurationMutex: (roomUrl: string) => void;
/** Narrow test visibility without exposing the mutable registry. */
export declare const hasRoomIceConfigurationMutex: (roomUrl: string) => boolean;
/**
 * Server-assigned room ids are globally unique, so validation, live apply, and
 * publication of assignments must be one global transaction. Room responses
 * are rare; serializing them is simpler and safer than multi-key lock ordering.
 */
export declare const runRoomResponseCommitExclusive: <T>(operation: () => Promise<T>) => Promise<T>;
