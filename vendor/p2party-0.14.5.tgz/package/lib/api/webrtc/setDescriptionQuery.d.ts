import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { RTCSetDescriptionParams, IRTCPeerConnection, IRTCIceCandidate, IRTCDataChannel, DisconnectPeerTransport } from "./interfaces";
export interface RTCSetDescriptionParamsExtension extends RTCSetDescriptionParams {
    peerConnections: IRTCPeerConnection[];
    iceCandidates: IRTCIceCandidate[];
    dataChannels: IRTCDataChannel[];
    /**
     * Tears one room/peer transport down through the same path as a transport
     * failure (disconnectFromPeer). Injected, like the bulk teardown queries
     * do, so this module needs no import of the API that registers it and a
     * test can bind the real query to its own transport registry.
     */
    disconnectPeer: DisconnectPeerTransport;
}
declare const webrtcSetDescriptionQuery: BaseQueryFn<RTCSetDescriptionParamsExtension, undefined>;
export default webrtcSetDescriptionQuery;
