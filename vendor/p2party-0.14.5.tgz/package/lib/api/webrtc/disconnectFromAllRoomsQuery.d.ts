import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import type { IRTCDataChannel, IRTCPeerConnection, RTCDisconnectFromAllRoomsParams, DisconnectPeerTransport } from "./interfaces";
export interface RTCDisconnectFromAllRoomsParamsExtension extends RTCDisconnectFromAllRoomsParams {
    peerConnections: IRTCPeerConnection[];
    dataChannels: IRTCDataChannel[];
    disconnectPeer: DisconnectPeerTransport;
}
declare const webrtcDisconnectAllRoomsQuery: BaseQueryFn<RTCDisconnectFromAllRoomsParamsExtension, undefined>;
export default webrtcDisconnectAllRoomsQuery;
