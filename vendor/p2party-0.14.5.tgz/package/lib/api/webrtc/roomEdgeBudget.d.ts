import type { Peer } from "../../reducers/roomSlice";
import type { IRTCPeerConnection } from "./interfaces";
/**
 * Enforce one cumulative edge budget across Redux roster state and concrete
 * transports, including PCs inserted while their WASM initialization awaits.
 *
 * Callers run this under the stable room-configuration mutex immediately
 * before registry insertion, making concurrent identities observe each other.
 */
export declare const assertRoomEdgeBudget: (roomId: string, peers: readonly Peer[], peerConnections: readonly IRTCPeerConnection[], candidatePublicKey: string) => void;
