/**
 * Main-realm ownership boundary for the persisted Ed25519 identity.
 *
 * The database worker only wraps bytes and allocates revisions. Seed
 * derivation stays here so it uses the application's one configured
 * cryptography/WASM source.
 */
import type { IdentityEd25519, IdentityEd25519KeyMaterial } from "./types";
type IdentityWriter = (identity: IdentityEd25519KeyMaterial, transfer: Transferable[]) => Promise<unknown> | unknown;
export declare const wipeUnclaimedWorkerSecret: (value: unknown) => void;
export declare const readIdentityEd25519AtClientBoundary: (read: () => Promise<unknown>) => Promise<IdentityEd25519 | undefined>;
export declare const writeIdentityEd25519AtClientBoundary: (identity: IdentityEd25519KeyMaterial, write: IdentityWriter) => Promise<bigint>;
export {};
