/**
 * Constants-only SSOT for the fixed pair-bootstrap HPKE suite.
 *
 * Keeping this separate from the executable HPKE adapter lets schemas and the
 * blind-rendezvous suite registry consume the exact wire geometry without
 * importing WASM-backed cryptographic code.
 */
export declare const HPKE_MLKEM768_X25519_KEM_ID = 25722;
export declare const HPKE_HKDF_SHA256_KDF_ID = 1;
export declare const HPKE_CHACHA20POLY1305_AEAD_ID = 3;
export declare const HPKE_MODE_BASE = 0;
export declare const HPKE_MODE_PSK = 1;
export declare const HPKE_HASH_BYTES = 32;
export declare const HPKE_KEY_BYTES = 32;
export declare const HPKE_NONCE_BYTES = 12;
export declare const HPKE_TAG_BYTES = 16;
export declare const HPKE_PAIR_PSK_BYTES = 32;
export declare const HPKE_PAIR_PSK_ID_BYTES = 32;
export declare const HPKE_MAX_EXPORT_BYTES: number;
export declare const HPKE_MAX_APPLICATION_CONTEXT_BYTES = 65535;
export declare const HPKE_MLKEM768_X25519_SUITE: Readonly<{
    readonly specification: Readonly<{
        kem: "draft-ietf-hpke-pq-05";
        kemKeyDerivation: "draft-ietf-hpke-hpke-03";
        keySchedule: "RFC 9180";
    }>;
    readonly kemId: 25722;
    readonly kdfId: 1;
    readonly aeadId: 3;
    readonly publicKeyBytes: 1216;
    readonly secretKeyBytes: 32;
    readonly encapsulatedKeyBytes: 1120;
    readonly sharedSecretBytes: 32;
    readonly keyBytes: 32;
    readonly nonceBytes: 12;
    readonly tagBytes: 16;
    readonly pskBytes: 32;
    readonly pskIdBytes: 32;
}>;
