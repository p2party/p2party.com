import type { LibCrypto } from "./libcrypto";
export interface X25519KeyPair {
    publicKey: Uint8Array;
    secretKey: Uint8Array;
}
/**
 * The peer-supplied u-coordinate produced the prohibited all-zero X25519
 * shared secret (for example, a low-order point).
 *
 * This is distinct from allocation/module failures so protocol receivers can
 * classify attacker-controlled invalid KEM input as a closed no-match without
 * hiding cryptographic infrastructure faults.
 */
export declare class X25519RejectedPublicPointError extends Error {
    readonly name = "X25519RejectedPublicPointError";
    constructor();
}
export declare const x25519Keypair: (module: LibCrypto) => X25519KeyPair;
/**
 * Async, optional-module wrapper over `x25519Keypair`, mirroring `ed25519.newKeyPair`:
 * self-loads a LibCrypto module (sizing its own fixed 2 MiB heap) when none is passed,
 * so identity-generation call sites can mint the dedicated X25519 identity keypair the
 * same way they call `newKeyPair()`. The keypair is random (`_x25519_keypair` draws its
 * own entropy); `x25519Keypair` copies the secret out and zero-frees the wasm scratch.
 */
export declare const newX25519KeyPair: (module?: LibCrypto) => Promise<X25519KeyPair>;
export declare const x25519Dh: (secretKey: Uint8Array, publicKey: Uint8Array, module: LibCrypto) => Uint8Array;
/**
 * Derive an X25519 public key by scalar-multiplying the RFC 7748 u=9 base
 * point. The canonical base point stays module-owned so callers cannot mutate
 * protocol input shared by later derivations.
 */
export declare const x25519PublicFromSecret: (secretKey: Uint8Array, module: LibCrypto) => Uint8Array;
