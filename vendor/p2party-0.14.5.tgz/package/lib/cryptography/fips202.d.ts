import type { LibCrypto } from "./libcrypto";
export declare const SHA3_256_BYTES = 32;
/**
 * The one-shot bound proved by the pinned mlkem-native FIPS 202 backend.
 *
 * WASM uses a 32-bit size_t, so this is `(SIZE_MAX >> 12)` from mlkem768.h.
 */
export declare const FIPS202_MAX_BUFFER_BYTES = 1048575;
export declare const shake256: (input: Uint8Array, outputLength: number, module: LibCrypto) => Uint8Array;
export declare const sha3_256: (input: Uint8Array, module: LibCrypto) => Uint8Array;
