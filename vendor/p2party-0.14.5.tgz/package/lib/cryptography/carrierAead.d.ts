import type { LibCrypto } from "./libcrypto";
/**
 * XChaCha20-Poly1305 as required by the blind-rendezvous delivery profile's
 * `carrierAeadSuite = 1` (`draft-irtf-cfrg-xchacha-03`).
 *
 * The construction comes from the pinned libsodium build. The reusable
 * XChaCha adapter owns the hardened WASM boundary; this compatibility wrapper
 * preserves the established carrier call shape and errors. Application code
 * implements no cryptography, which is what SEC-002 and SEC-019 require.
 */
export declare class CarrierAeadError extends Error {
    readonly name = "CarrierAeadError";
    constructor(message: string);
}
export declare const xchacha20poly1305Seal: (key: Uint8Array, nonce: Uint8Array, associatedData: Uint8Array, plaintext: Uint8Array, module: LibCrypto) => Uint8Array;
/**
 * Returns null on authentication failure.
 *
 * libsodium verifies the tag in constant time and writes no plaintext when it
 * fails, so a caller can treat null as "not for this room" — which is exactly
 * how a dummy object reads — without having to scrub a partial buffer.
 */
export declare const xchacha20poly1305Open: (key: Uint8Array, nonce: Uint8Array, associatedData: Uint8Array, ciphertextAndTag: Uint8Array, module: LibCrypto) => Uint8Array | null;
