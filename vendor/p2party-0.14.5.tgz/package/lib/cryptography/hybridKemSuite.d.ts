/**
 * Frozen wire geometry for the pair-bootstrap KEM.
 *
 * This constants-only module is the SSOT shared by the crypto implementation
 * and blind-rendezvous schemas. Changing any value requires a new suite ID.
 */
export declare const MLKEM768_X25519_SEED_BYTES = 32;
export declare const MLKEM768_X25519_PUBLIC_KEY_BYTES = 1216;
export declare const MLKEM768_X25519_SECRET_KEY_BYTES = 32;
export declare const MLKEM768_X25519_CIPHERTEXT_BYTES = 1120;
export declare const MLKEM768_X25519_SHARED_SECRET_BYTES = 32;
export declare const MLKEM768_X25519_RANDOM_BYTES = 64;
export declare const MLKEM768_X25519_SUITE: Readonly<{
    readonly standardName: "MLKEM768-X25519";
    readonly specification: "draft-irtf-cfrg-concrete-hybrid-kems-04";
    readonly seedBytes: 32;
    readonly publicKeyBytes: 1216;
    readonly secretKeyBytes: 32;
    readonly ciphertextBytes: 1120;
    readonly sharedSecretBytes: 32;
    readonly randomnessBytes: 64;
}>;
