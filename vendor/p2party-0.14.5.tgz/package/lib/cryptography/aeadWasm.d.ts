import type { LibCrypto } from "./libcrypto";
export declare const WASM_AEAD_MAX_BYTES = 2147483647;
type AeadPrimitive = (module: LibCrypto, output: number, input: number, inputLength: number, key: number, nonce: number, associatedData: number, associatedDataLength: number) => number;
export interface WasmAeadSuite {
    readonly name: string;
    readonly keyBytes: number;
    readonly nonceBytes: number;
    readonly tagBytes: number;
    readonly encrypt: AeadPrimitive;
    readonly decrypt: AeadPrimitive;
}
export declare class WasmAeadError extends Error {
    readonly name = "WasmAeadError";
}
export declare const maxAeadPlaintextBytes: (suite: WasmAeadSuite) => number;
export declare const sealWasmAead: (suite: WasmAeadSuite, module: LibCrypto, key: Uint8Array, nonce: Uint8Array, plaintext: Uint8Array, associatedData: Uint8Array) => Uint8Array;
export declare const openWasmAead: (suite: WasmAeadSuite, module: LibCrypto, key: Uint8Array, nonce: Uint8Array, ciphertextAndTag: Uint8Array, associatedData: Uint8Array) => Uint8Array | null;
export {};
