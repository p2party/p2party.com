import type { MlKem768X25519KeyPair } from "./hybridKem";
import type { LibCrypto } from "./libcrypto";
export { HPKE_CHACHA20POLY1305_AEAD_ID, HPKE_HASH_BYTES, HPKE_HKDF_SHA256_KDF_ID, HPKE_KEY_BYTES, HPKE_MAX_APPLICATION_CONTEXT_BYTES, HPKE_MAX_EXPORT_BYTES, HPKE_MLKEM768_X25519_KEM_ID, HPKE_MLKEM768_X25519_SUITE, HPKE_MODE_BASE, HPKE_MODE_PSK, HPKE_NONCE_BYTES, HPKE_PAIR_PSK_BYTES, HPKE_PAIR_PSK_ID_BYTES, HPKE_TAG_BYTES, } from "./hpkeSuite";
export interface HpkeContext {
    readonly sequence: bigint;
    readonly destroyed: boolean;
    /**
     * RFC 9180 Export. It does not consume a nonce and has no replay protection.
     */
    exportSecret(exporterContext: Uint8Array, length: number): Promise<Uint8Array>;
    /** Idempotently wipe the AEAD and exporter state. */
    destroy(): void;
}
export interface HpkeSenderContext extends HpkeContext {
    readonly role: "sender";
    seal(associatedData: Uint8Array, plaintext: Uint8Array): Uint8Array;
}
export interface HpkeRecipientContext extends HpkeContext {
    readonly role: "recipient";
    /**
     * Return null on authentication failure. A failed Open does not advance the
     * sequence number.
     */
    open(associatedData: Uint8Array, ciphertextAndTag: Uint8Array): Uint8Array | null;
}
export interface HpkePskSenderSetup {
    readonly encapsulatedKey: Uint8Array;
    readonly context: HpkeSenderContext;
}
export interface HpkePskSenderOptions {
    readonly module: LibCrypto;
    readonly recipientPublicKey: Uint8Array;
    readonly info: Uint8Array;
    /** Pair suite 1 requires the exact 32-byte RoomRoot or HelloRoot. */
    readonly psk: Uint8Array;
    /** Pair suite 1 requires the exact 32-byte transcript-derived PSK ID. */
    readonly pskId: Uint8Array;
}
export interface HpkePskRecipientOptions {
    readonly module: LibCrypto;
    readonly encapsulatedKey: Uint8Array;
    readonly recipientSecretKey: Uint8Array;
    readonly info: Uint8Array;
    readonly psk: Uint8Array;
    readonly pskId: Uint8Array;
}
/** RFC 9180 SetupPSKS for the fixed pair-bootstrap suite. */
export declare const setupHpkePskSender: (options: HpkePskSenderOptions) => Promise<HpkePskSenderSetup>;
/**
 * Deterministic SetupPSKS hook for pinned vectors only.
 *
 * Reusing or predicting its 64-byte randomness destroys KEM security. Normal
 * protocol code must call setupHpkePskSender(), which obtains fresh CSPRNG
 * bytes internally.
 *
 * @internal
 */
export declare const setupHpkePskSenderDeterministically: (options: HpkePskSenderOptions & {
    readonly encapsulationRandomness: Uint8Array;
}) => Promise<HpkePskSenderSetup>;
/** RFC 9180 SetupPSKR for the fixed pair-bootstrap suite. */
export declare const setupHpkePskRecipient: (options: HpkePskRecipientOptions) => Promise<HpkeRecipientContext>;
/**
 * Generate a production recipient key pair using the hybrid KEM's CSPRNG path.
 */
export declare const generateHpkeRecipientKeyPair: (module: LibCrypto) => Promise<MlKem768X25519KeyPair>;
/**
 * HPKE KEM DeriveKeyPair mapping used by the official conformance vectors.
 * The pair profile restricts IKM to one exact 32-byte seed.
 */
export declare const deriveHpkeRecipientKeyPair: (ikm: Uint8Array, module: LibCrypto) => Promise<MlKem768X25519KeyPair>;
/**
 * Base-mode deterministic setup exists solely to verify the official
 * draft-ietf-hpke-pq vector for this exact KEM/KDF/AEAD tuple. Pair protocol
 * code must never use base mode.
 *
 * @internal
 */
export declare const setupHpkeBaseSenderForConformance: (options: {
    readonly module: LibCrypto;
    readonly recipientPublicKey: Uint8Array;
    readonly info: Uint8Array;
    readonly encapsulationRandomness: Uint8Array;
}) => Promise<HpkePskSenderSetup>;
