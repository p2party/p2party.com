/**
 * Internal, owned Ed25519 secret-key capture shared by trusted local
 * persistence and custody boundaries.
 *
 * This module deliberately exposes no process-local capability and no signing
 * operation. Callers must keep the returned material behind their own trusted
 * boundary and wipe it when that ownership ends.
 */
import type { LibCrypto } from "./libcrypto";
export interface OwnedEd25519KeyMaterial {
    readonly secretKey: Uint8Array;
    readonly publicKey: Uint8Array;
}
export interface CaptureConsistentEd25519KeyMaterialOptions {
    readonly module?: LibCrypto;
    readonly secretKey: Uint8Array;
    readonly inputLabel: string;
    /** Optional synchronous validation after secret capture and before await. */
    readonly validateBeforeDerivation?: () => void;
    readonly rejectInconsistentSecretKey: () => never;
}
/**
 * Own a 64-byte Ed25519 secret before the first await and verify its public
 * suffix by deriving the key pair from its seed.
 */
export declare const captureConsistentEd25519KeyMaterial: (options: CaptureConsistentEd25519KeyMaterialOptions) => Promise<OwnedEd25519KeyMaterial>;
export declare const wipeOwnedEd25519KeyMaterial: (material: OwnedEd25519KeyMaterial) => void;
