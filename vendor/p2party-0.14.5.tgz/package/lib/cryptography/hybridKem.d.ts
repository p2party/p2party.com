import { MLKEM768_X25519_SUITE } from "./hybridKemSuite";
import type { LibCrypto } from "./libcrypto";
import type { MlKemDecapsulation, MlKemEncapsulation, MlKemKeyPair } from "./mlkem";
export { MLKEM768_X25519_CIPHERTEXT_BYTES, MLKEM768_X25519_PUBLIC_KEY_BYTES, MLKEM768_X25519_RANDOM_BYTES, MLKEM768_X25519_SEED_BYTES, MLKEM768_X25519_SECRET_KEY_BYTES, MLKEM768_X25519_SHARED_SECRET_BYTES, MLKEM768_X25519_SUITE, } from "./hybridKemSuite";
export type MlKem768X25519KeyPair = MlKemKeyPair;
export type MlKem768X25519Encapsulation = MlKemEncapsulation;
export type MlKem768X25519Decapsulation = MlKemDecapsulation;
/**
 * A correctly framed peer ciphertext is not a valid ciphertext for this
 * hybrid KEM. Infrastructure and local-key failures use their original errors.
 */
export declare class HybridKemInvalidCiphertextError extends Error {
    readonly name = "HybridKemInvalidCiphertextError";
    constructor();
}
/**
 * A correctly framed hybrid encapsulation key failed FIPS 203's ML-KEM
 * modulus check or X25519 low-order-point validation.
 */
export declare class HybridKemInvalidPublicKeyError extends Error {
    readonly name = "HybridKemInvalidPublicKeyError";
    constructor();
}
/**
 * Validate one suite-1 hybrid encapsulation key without performing a second
 * ML-KEM encapsulation.
 *
 * FIPS 203 encodes two 12-bit ML-KEM coefficients in each three-byte group;
 * every coefficient must be below q=3329. The final 32 ML-KEM bytes are rho
 * and are unrestricted. X25519 validity is the library's ordinary
 * all-zero-shared-secret rejection. Public inputs need no constant-time scan.
 */
export declare const validateMlKem768X25519PublicKey: (publicKey: Uint8Array, module: LibCrypto) => void;
export interface MlKem768X25519Backend {
    readonly suite: typeof MLKEM768_X25519_SUITE;
    generateKeyPair(): Promise<MlKem768X25519KeyPair>;
    deriveKeyPair(seed: Uint8Array): Promise<MlKem768X25519KeyPair>;
    encapsulate(publicKey: Uint8Array): Promise<MlKem768X25519Encapsulation>;
    encapsulateDeterministically(publicKey: Uint8Array, randomness: Uint8Array): Promise<MlKem768X25519Encapsulation>;
    decapsulate(ciphertext: Uint8Array, secretKey: Uint8Array): Promise<MlKem768X25519Decapsulation>;
}
export declare const createMlKem768X25519Backend: (module: LibCrypto) => MlKem768X25519Backend;
