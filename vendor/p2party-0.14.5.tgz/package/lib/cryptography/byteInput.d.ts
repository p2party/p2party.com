export interface ByteInputConstraints {
    readonly exactLength?: number;
    readonly maximumLength?: number;
}
/**
 * Take an ordinary, owned snapshot of borrowed bytes before a WASM boundary.
 *
 * Typed-array intrinsics are used deliberately: a Proxy can pass `instanceof`
 * while lying about its length, and a real view can shadow `length`, iteration,
 * or species properties. None of those surfaces influence this copy.
 */
export declare const snapshotByteInput: (value: unknown, label: string, constraints?: ByteInputConstraints) => Uint8Array;
