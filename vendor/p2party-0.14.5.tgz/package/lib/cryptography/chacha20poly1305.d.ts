import type { LibCrypto } from "./libcrypto";
export declare const CHACHA20POLY1305_MAX_WASM_BYTES = 2147483647;
export declare const CHACHA20POLY1305_MAX_PLAINTEXT_BYTES: number;
/** Seal to RFC 8439 `ciphertext || 16-byte Poly1305 tag`. */
export declare const chacha20Poly1305Seal: (module: LibCrypto, key: Uint8Array, nonce: Uint8Array, plaintext: Uint8Array, associatedData: Uint8Array) => Uint8Array;
/** Open RFC 8439 `ciphertext || tag`, returning null on authentication failure. */
export declare const chacha20Poly1305Open: (module: LibCrypto, key: Uint8Array, nonce: Uint8Array, ciphertextAndTag: Uint8Array, associatedData: Uint8Array) => Uint8Array | null;
