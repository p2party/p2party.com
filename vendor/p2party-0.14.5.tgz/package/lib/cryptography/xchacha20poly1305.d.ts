import type { LibCrypto } from "./libcrypto";
export declare const XCHACHA20POLY1305_MAX_WASM_BYTES = 2147483647;
export declare const XCHACHA20POLY1305_MAX_PLAINTEXT_BYTES: number;
/** Seal to XChaCha20-Poly1305 `ciphertext || 16-byte tag`. */
export declare const xchacha20Poly1305Seal: (module: LibCrypto, key: Uint8Array, nonce: Uint8Array, plaintext: Uint8Array, associatedData: Uint8Array) => Uint8Array;
/** Open `ciphertext || tag`, returning null on authentication failure. */
export declare const xchacha20Poly1305Open: (module: LibCrypto, key: Uint8Array, nonce: Uint8Array, ciphertextAndTag: Uint8Array, associatedData: Uint8Array) => Uint8Array | null;
