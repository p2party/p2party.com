/**
 * Shared WebCrypto SHA-256, HMAC-SHA-256, and RFC 5869 HKDF-SHA-256.
 *
 * Every public function snapshots caller-owned bytes synchronously. Callers may
 * therefore mutate or transfer their buffers as soon as the function returns
 * its promise without changing the in-flight operation.
 */
/** SHA-256 over a synchronous snapshot of `input`. */
export declare const sha256: (input: Uint8Array) => Promise<Uint8Array>;
/** HMAC-SHA-256 over synchronous snapshots of `key` and `message`. */
export declare const hmacSha256: (key: Uint8Array, message: Uint8Array) => Promise<Uint8Array>;
/** RFC 5869 HKDF-Extract with SHA-256. */
export declare const hkdfSha256Extract: (salt: Uint8Array, ikm: Uint8Array) => Promise<Uint8Array>;
/**
 * RFC 5869 HKDF-Expand with SHA-256.
 *
 * This API requires a standards-conforming PRK of at least 32 bytes and a
 * nonempty output no longer than RFC 5869's 255-block upper bound.
 */
export declare const hkdfSha256Expand: (prk: Uint8Array, info: Uint8Array, length: number) => Promise<Uint8Array>;
