export declare const RATCHET_GATE_WAIT_TIMEOUT_MESSAGE = "Peer is not authenticated on this transport: the handshake did not complete within the wait budget";
export declare const isRatchetGateWaitTimeout: (error: unknown) => boolean;
/**
 * Await the per-(room, peer) ratchet gate with a wall-clock budget.
 *
 * The gate itself is unbounded by design (it is the "handshake succeeded"
 * signal), but a send must not wait on it forever: after an edge re-dial the
 * remote may hold a stale authenticated view and never open a fresh `main`,
 * so its handshake never starts and the gate never settles. The transfer
 * abort signal still wins first; a gate that opens or rejects on its own
 * clears the timer and settles with its own outcome.
 */
export declare const waitForRatchetGate: (roomId: string, peerId: string, signal?: AbortSignal, timeoutMs?: number) => Promise<void>;
