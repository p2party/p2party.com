import type { AppliedRoomResponse } from "../utils/roomRequestCoordinator";
import type { WebSocketMessageRoomIdRequest } from "../utils/interfaces";
export interface RoomRequestApi {
    getState: () => unknown;
}
export type SendRoomRequest = (request: WebSocketMessageRoomIdRequest) => Promise<unknown>;
export declare const MAX_ROOM_REQUEST_ATTEMPTS = 4;
export declare const ROOM_REQUEST_RETRY_BASE_MS = 250;
export declare const MAX_ROOM_REQUEST_RETRY_MS = 2000;
export interface RoomRequestRetryOptions {
    lifecycleEpoch?: number;
    maxAttempts?: number;
    retryBaseMs?: number;
    maxRetryMs?: number;
}
export interface ActiveRoomRequestOptions extends RoomRequestRetryOptions {
    concurrency?: number;
}
export declare const ACTIVE_ROOM_REQUEST_CONCURRENCY = 16;
/**
 * The one SDK path that emits a room request.
 *
 * It binds every request to a fresh wire nonce through the coordinator and
 * refuses to issue room traffic before the current socket proves identity.
 */
export declare const requestRoomFromSignaling: (api: RoomRequestApi, roomUrl: string, sendRoomRequest: SendRoomRequest) => Promise<AppliedRoomResponse>;
/** Retry one room independently while it remains in this socket lifecycle. */
export declare const requestRoomFromSignalingWithRetry: (api: RoomRequestApi, roomUrl: string, sendRoomRequest: SendRoomRequest, options?: RoomRequestRetryOptions) => Promise<AppliedRoomResponse>;
/** Refresh every retained active room after a fresh socket proof. */
export declare const requestAllActiveRooms: (api: RoomRequestApi, sendRoomRequest: SendRoomRequest, options?: ActiveRoomRequestOptions) => Promise<void>;
