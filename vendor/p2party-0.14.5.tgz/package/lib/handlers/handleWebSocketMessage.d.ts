import type { BaseQueryApi } from "@reduxjs/toolkit/query";
declare const handleWebSocketMessage: (event: MessageEvent, ws: WebSocket, api: BaseQueryApi, isCurrentSocket?: () => boolean, onHeartbeat?: () => void) => Promise<void>;
export default handleWebSocketMessage;
