import { applyRoomResponse } from "../reducers/roomSlice";
import type { ManagedRoom } from "../reducers/roomSlice";
import type { TurnCredentials } from "../utils/interfaces";
import type { PendingRoomResponseClaim } from "../utils/roomRequestCoordinator";
export interface RoomResponseCorrelation {
    readonly roomUrl: string;
    readonly roomRequestId: string;
}
/**
 * Read only the correlation tuple. No pending request is consumed until this
 * tuple has been proven to be the exact current wire nonce.
 */
export declare const parseRoomResponseCorrelation: (value: unknown) => RoomResponseCorrelation | null;
export type RoomResponsePlan = {
    accepted: true;
    action: ReturnType<typeof applyRoomResponse>;
    roomId: string;
    roomUrl: string;
    roomRequestId: string;
    requestGeneration: number;
    expiresAtUnixSeconds: number | null;
    nextRtcConfig: RTCConfiguration;
} | {
    accepted: false;
    reason: "malformed-room-response" | "malformed-turn-credentials" | "unknown-room" | "room-id-reassignment" | "room-id-collision" | "stale-room-response";
};
/**
 * Validate one wire-correlated response and derive its single Redux commit.
 *
 * Room identity and the signaling-owned TURN bundle change in one reducer
 * action. No observer can see a new room ID paired with old credentials.
 */
export declare const planRoomResponse: (value: unknown, rooms: readonly ManagedRoom[], claim: PendingRoomResponseClaim, expectedPublicKey: string, nowMs?: number) => RoomResponsePlan;
export type AcceptedRoomResponsePlan = Extract<RoomResponsePlan, {
    accepted: true;
}>;
export interface AuthoritativeRoomResponseState {
    id: string;
    roomResponseGeneration: number;
    rtcConfig: RTCConfiguration;
    signalingTurnCredentials: TurnCredentials | null;
    signalingActive: boolean;
}
/** True only when an expiry reducer just removed this exact live generation. */
export declare const isExactExpiredTurnGeneration: (room: AuthoritativeRoomResponseState | undefined, plan: Pick<AcceptedRoomResponsePlan, "roomId" | "requestGeneration">) => room is AuthoritativeRoomResponseState;
/**
 * Apply live browser configuration before publishing the Redux generation.
 *
 * If setConfiguration() rejects, the old state and old refresh timer remain
 * authoritative and retryable. Publishing first could orphan the new expiry
 * with no timer while live PCs still used the old credential.
 */
export declare const commitRoomResponsePlan: (plan: AcceptedRoomResponsePlan, applyLiveConfiguration: (roomId: string, rtcConfig: RTCConfiguration, failurePolicy: "rollback" | "close") => Promise<void>, canPublish: () => boolean, publish: () => boolean, readRoom: (roomUrl: string) => AuthoritativeRoomResponseState | undefined, rollbackPublishedState?: (previous: AuthoritativeRoomResponseState) => void) => Promise<boolean>;
