/**
 * The scheduler may overlap four policy-maximal cycle generations while close
 * events drain. Keep the receiver at that same derived geometry even when an
 * authenticated peer opens lanes outside the agreed schedule.
 */
export declare const MAX_COVER_CHANNELS_PER_EDGE: number;
export declare const registerCoverChannel: <T>(coverChannels: Set<T>, channel: T) => void;
export interface CloseObservableChannel extends EventTarget {
    readonly readyState: string;
}
/**
 * Remove exactly one concrete lane from both registries. Labels repeat every
 * cover cycle, so label-based removal can evict a replacement and leak the
 * channel that actually closed.
 */
export declare const unregisterCoverChannel: <T>(coverChannels: Set<T> | undefined, openChannels: T[], channel: T) => void;
/**
 * Register the lane and its exact close cleanup as one synchronous operation,
 * before callers perform any await. Returns the idempotent cleanup closure for
 * parse failures and higher-level teardown.
 */
export declare const registerCoverChannelUntilClose: <T extends CloseObservableChannel>(coverChannels: Set<T>, channel: T, openChannels?: T[]) => (() => void);
