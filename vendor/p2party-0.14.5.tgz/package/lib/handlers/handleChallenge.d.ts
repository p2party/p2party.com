import type { MiddlewareAPI } from "@reduxjs/toolkit";
import type { KeyPair } from "../reducers/keyPairSlice";
import type { WebSocketMessageChallengeResponse } from "../utils/interfaces";
export declare const handleChallenge: (keyPair: KeyPair, peerId: string, challenge: string, store: MiddlewareAPI, isCurrentSocket?: () => boolean) => Promise<WebSocketMessageChallengeResponse | null>;
