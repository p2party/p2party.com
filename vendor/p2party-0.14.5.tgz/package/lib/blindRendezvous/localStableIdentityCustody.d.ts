/**
 * Process-local custody for one persisted stable Ed25519 identity key.
 *
 * Trusted key storage constructs this handle from the secret key and its
 * non-reused record revision. The public key is derived rather than accepted
 * from the caller, so later receiver-key custody cannot bind an unrelated
 * public identity. This internal module is absent from the package barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
declare const localStableIdentityCustodyBrand: unique symbol;
/** Opaque live custody for one exact persisted stable identity key record. */
export interface LocalStableIdentityCustodyV1 {
    readonly [localStableIdentityCustodyBrand]: true;
}
export interface CreateLocalStableIdentityCustodyOptionsV1 {
    readonly module: LibCrypto;
    readonly stableEd25519SecretKey: Uint8Array;
    readonly localIdentityKeyRecordRevision: bigint;
}
export interface LocalStableIdentityCustodySnapshotV1 {
    readonly version: 1;
    readonly localStableEd25519PublicKey: Uint8Array;
    readonly localIdentityKeyRecordRevision: bigint;
}
export declare class LocalStableIdentityCustodyError extends Error {
    readonly name = "LocalStableIdentityCustodyError";
    constructor(message: string);
}
/**
 * Copy one stable secret and derive its public identity before minting custody.
 *
 * All caller-controlled values are captured before the first await. Mutating
 * or wiping the caller's secret after invocation therefore cannot change the
 * key held by the returned capability.
 */
export declare const createLocalStableIdentityCustodyV1: (options: CreateLocalStableIdentityCustodyOptionsV1) => Promise<LocalStableIdentityCustodyV1>;
/** Return a fresh non-secret projection and assert that custody is still live. */
export declare const snapshotLocalStableIdentityCustodyV1: (custody: LocalStableIdentityCustodyV1) => LocalStableIdentityCustodySnapshotV1;
/**
 * Wipe stable identity custody after its persisted key record is retired.
 *
 * Destruction is idempotent for a genuine handle. Dependent receiver custody
 * retains the exact handle and therefore fails closed after this transition.
 */
export declare const destroyLocalStableIdentityCustodyV1: (custody: LocalStableIdentityCustodyV1) => void;
export {};
