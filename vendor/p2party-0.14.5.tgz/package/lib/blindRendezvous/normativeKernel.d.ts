/**
 * Blind-rendezvous registry shape validators, intentionally absent from the
 * package's public barrel.
 *
 * This module validates the logical shape of the kernel manifest, claim
 * registry, claim evaluations, and formal-obligation records so separate tools
 * cannot accept different registry shapes. It deliberately evaluates no claim
 * and exposes no positive-wording authorizer.
 *
 * Every field table and closed enumeration below is now imported from
 * `projections.ts`, which derives them from the canonical binary schema. The
 * schema is the SSOT for bytes, widths, ordering, and bounds; this module owns
 * only the cross-record reference, ordering, and acyclicity rules that a
 * per-value encoding cannot express.
 *
 * The schema itself is still PROPOSED, not frozen: acquiring real protocol
 * hashes additionally requires the Phase-0 freeze, deterministic vectors, and
 * the module-8 resolver/evaluator.
 */
export type Bytes32 = Uint8Array;
export type Uint16 = number;
export type KernelModuleIdV1 = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
export type KernelEntrypointIdV1 = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
export interface KernelEntrypointV1 {
    entrypointId: KernelEntrypointIdV1;
    inputSchemaHash: Bytes32;
    outputSchemaHash: Bytes32;
    normativeSourceHash: Bytes32;
}
export interface ExecutableRendezvousKernelModuleV1 {
    moduleId: KernelModuleIdV1;
    entrypoints: readonly KernelEntrypointV1[];
    executableArtifactHash: Bytes32;
    normativeSourceTreeHash: Bytes32;
    canonicalVectorSetHash: Bytes32;
}
export interface ExecutableRendezvousKernelManifestV1 {
    version: 1;
    canonicalBinarySchemaHash: Bytes32;
    modules: readonly ExecutableRendezvousKernelModuleV1[];
}
export interface BlindRendezvousImplementationBuildManifestV1 {
    version: 1;
    releaseRegistryHash: Bytes32;
    implementationArtifactSetDigest: Bytes32;
    executableModuleArtifactHashes: readonly Bytes32[];
    productionSchedulerArtifactHash: Bytes32;
    canonicalTraceSetDigest: Bytes32;
}
export type ClaimEvaluationStateV1 = "not-implemented" | "not-evaluated" | "unknown" | "expired" | "failed" | "satisfied";
export type ClaimScopeKindV1 = "release" | "deployment" | "room" | "carrier-instance" | "edge" | "r2-conformance-record";
export interface ClaimAssumptionV1 {
    assumptionId: Uint16;
    kind: "cryptographic" | "protocol" | "deployment" | "environmental";
    canonicalStatement: string;
    verification: {
        kind: "declared-foundational";
    } | {
        kind: "evidence-verified";
        verifierEntrypointId: KernelEntrypointIdV1;
    };
}
export interface ClaimEvidenceKindV1 {
    evidenceKindId: Uint16;
    canonicalSchemaHash: Bytes32;
    verifierEntrypointId: KernelEntrypointIdV1;
}
export interface ClaimWordingByStateV1 {
    notImplemented: Uint16;
    notEvaluated: Uint16;
    unknown: Uint16;
    expired: Uint16;
    failed: Uint16;
    satisfied: Uint16;
}
export interface ClaimDefinitionV1 {
    claimId: Uint16;
    scopeKind: ClaimScopeKindV1;
    scopeSchemaHash: Bytes32;
    predicateEntrypointId: KernelEntrypointIdV1;
    assumptionIds: readonly Uint16[];
    requiredEvidenceKindIds: readonly Uint16[];
    prerequisiteClaimIds: readonly Uint16[];
    requiredFormalObligationIds: readonly Uint16[];
    wordingIdByState: ClaimWordingByStateV1;
    forbiddenWordingIds: readonly Uint16[];
}
export interface ClaimRegistryV1 {
    version: 1;
    assumptions: readonly ClaimAssumptionV1[];
    evidenceKinds: readonly ClaimEvidenceKindV1[];
    claims: readonly ClaimDefinitionV1[];
    wordingCatalogHash: Bytes32;
}
export interface ClaimWordingCatalogV1 {
    version: 1;
    wording: readonly {
        claimId: Uint16;
        wordingId: Uint16;
        state: ClaimEvaluationStateV1;
        canonicalText: string;
    }[];
    reasons: readonly {
        reasonId: Uint16;
        canonicalText: string;
    }[];
}
export interface ClaimEvidenceBindingV1 {
    evidenceKindId: Uint16;
    evidenceId: Bytes32;
}
export interface ClaimPrerequisiteBindingV1 {
    claimId: Uint16;
    evaluationDigest: Bytes32;
}
export interface ClaimFormalResultBindingV1 {
    obligationId: Uint16;
    resultDigest: Bytes32;
}
export type ClaimAssumptionBindingV1 = {
    assumptionId: Uint16;
    kind: "declared-foundational";
} | {
    assumptionId: Uint16;
    kind: "evidence-verified";
    evidenceId: Bytes32;
};
export interface ClaimEvaluationDatasetV1 {
    version: 1;
    releaseRegistryHash: Bytes32;
    claimRegistryHash: Bytes32;
    claimId: Uint16;
    canonicalScope: Uint8Array;
    assumptionBindings: readonly ClaimAssumptionBindingV1[];
    evidenceBindings: readonly ClaimEvidenceBindingV1[];
    prerequisiteBindings: readonly ClaimPrerequisiteBindingV1[];
    formalResultBindings: readonly ClaimFormalResultBindingV1[];
    evidenceSaturated: boolean;
    firstSaturatedEvidenceId: Bytes32 | null;
}
export interface ClaimEvaluationInputV1 {
    releaseRegistryHash: Bytes32;
    claimRegistryHash: Bytes32;
    claimId: Uint16;
    scopeDigest: Bytes32;
    evaluatedAtMs: bigint;
    evaluationClockUncertaintyMs: bigint;
    implementationPresent: boolean;
    evaluationDatasetDigest: Bytes32;
}
export interface ClaimEvaluationV1 {
    version: 1;
    input: ClaimEvaluationInputV1;
    state: ClaimEvaluationStateV1;
    reasonIds: readonly Uint16[];
    selectedWordingId: Uint16;
    validThroughMs: bigint | null;
}
export interface CurrentClaimEvaluationRegistryRootsV1 {
    releaseRegistryHash: Bytes32;
    claimRegistryHash: Bytes32;
}
export type FormalObligationKindV1 = "algebraic" | "safety" | "liveness-refinement" | "computational-game";
export interface FormalObligationV1 {
    obligationId: Uint16;
    kind: FormalObligationKindV1;
    modelSourceHash: Bytes32;
    propertySourceHash: Bytes32;
    abstractionMapHash: Bytes32;
    toolchainLockHash: Bytes32;
    proofScopeSchemaHash: Bytes32;
    scopeCoverageEntrypointId: KernelEntrypointIdV1;
    assumptionIds: readonly Uint16[];
}
export interface FormalObligationRegistryV1 {
    version: 1;
    obligations: readonly FormalObligationV1[];
}
export interface FormalProofScopeArtifactV1 {
    version: 1;
    obligationId: Uint16;
    canonicalScope: Uint8Array;
}
export interface FormalProofResultV1 {
    version: 1;
    releaseRegistryHash: Bytes32;
    formalObligationRegistryHash: Bytes32;
    obligationId: Uint16;
    modelSourceHash: Bytes32;
    propertySourceHash: Bytes32;
    assumptionSetHash: Bytes32;
    abstractionMapHash: Bytes32;
    toolchainLockHash: Bytes32;
    proofScopeDigest: Bytes32;
    implementationArtifactSetDigest: Bytes32;
    canonicalTraceSetDigest: Bytes32;
    schedulerWorkloadDigest: Bytes32;
    result: "proved-within-scope" | "counterexample" | "inconclusive";
    proofArtifactDigest: Bytes32;
    counterexampleTraceDigest: Bytes32 | null;
}
export interface FormalProofValidationContextV1 {
    releaseRegistryHash: Bytes32;
    formalObligationRegistryHash: Bytes32;
    expectedAssumptionSetHash: Bytes32;
}
export declare const validateExecutableRendezvousKernelManifestV1: (manifest: ExecutableRendezvousKernelManifestV1) => void;
export declare const validateClaimRegistryV1: (registry: ClaimRegistryV1) => void;
export declare const validateFormalObligationRegistryV1: (registry: FormalObligationRegistryV1) => void;
export declare const validateNormativeRegistriesV1: (manifest: ExecutableRendezvousKernelManifestV1, claimRegistry: ClaimRegistryV1, formalRegistry: FormalObligationRegistryV1) => void;
/**
 * Checks the v0.4 structural publication set. This is not cryptographic
 * release conformance until a caller verifies canonically derived roots.
 */
export declare const validateV04ReleaseConformanceShapeV1: (manifest: ExecutableRendezvousKernelManifestV1, claimRegistry: ClaimRegistryV1, formalRegistry: FormalObligationRegistryV1) => void;
/**
 * Validates artifact shape and its binding to caller-supplied current roots.
 * It deliberately does not verify evidence, run the predicate, or authorize
 * claim wording.
 */
export declare const validateClaimEvaluationShapeV1: (evaluation: ClaimEvaluationV1, definition: ClaimDefinitionV1, currentRoots: CurrentClaimEvaluationRegistryRootsV1) => void;
export declare const validateFormalProofResultV1: (result: FormalProofResultV1, obligation: FormalObligationV1, validationContext: FormalProofValidationContextV1) => void;
