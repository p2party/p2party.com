/**
 * Canonical retained evidence for one authenticated IDENTITY_HELLO.
 *
 * The bundle is intentionally pair-subject scoped: it binds the exact
 * historical Core selector and the remote/local endpoint PRESENCE operations,
 * including the complete author prefixes that made those operations eligible.
 * It is not a claim that every unrelated roster fact is duplicated here.
 */
import type { PairAuthorChainPrefixEvidenceV1 } from "./coreReduce";
import type { RoomPolicyV4 } from "./roomPolicyV4";
export interface IdentityHelloHistoricalPresenceEvidenceV1 {
    readonly exactPresenceOperationBytes: Uint8Array;
    readonly presenceOperationId: Uint8Array;
    readonly retainThroughLogicalWindow: bigint;
    readonly authorChainPrefix: readonly PairAuthorChainPrefixEvidenceV1[];
}
export interface IdentityHelloHistoricalEvidenceBundleV1 {
    readonly version: 1;
    readonly exactCoreStateBytes: Uint8Array;
    /** Remote HELLO author first, local responder second. */
    readonly endpointPresenceEvidence: readonly [
        IdentityHelloHistoricalPresenceEvidenceV1,
        IdentityHelloHistoricalPresenceEvidenceV1
    ];
}
export interface ExpectedIdentityHelloHistoricalEvidenceV1 {
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly exactCoreStateBytes: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
}
export declare class IdentityHelloHistoricalEvidenceError extends Error {
    readonly name = "IdentityHelloHistoricalEvidenceError";
    constructor(message: string);
}
/**
 * Encode and deeply own a bundle assembled from genuine CoreReduce evidence.
 *
 * Cryptographic operation IDs and author-chain continuity are rechecked by
 * `decodeAndVerifyIdentityHelloHistoricalEvidenceBundleV1` at the durable
 * admission boundary.
 */
export declare const encodeIdentityHelloHistoricalEvidenceBundleV1: (value: IdentityHelloHistoricalEvidenceBundleV1) => Uint8Array;
/**
 * Canonical-decode and revalidate the complete persisted pair-subject bundle.
 *
 * Exact comparison with the authenticated claim remains mandatory before this
 * call. This verifier then independently checks the selector, endpoint order,
 * operation IDs, contiguous author prefixes, room binding, PRESENCE kind, and
 * exact protocol-derived retention horizons.
 */
export declare const decodeAndVerifyIdentityHelloHistoricalEvidenceBundleV1: (exactBytes: Uint8Array, expected: ExpectedIdentityHelloHistoricalEvidenceV1) => Promise<IdentityHelloHistoricalEvidenceBundleV1>;
