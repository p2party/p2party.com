/**
 * Internal, pure Section 4.8 admission-policy semantics.
 *
 * This module deliberately does not implement `Admit()`, trusted snapshot or
 * custody capture, provenance brands, pair opening/binding, effectful
 * persistence, outbound-intent atomicity, or the pre-SDP runtime gate. Its
 * canonical codecs only preserve already-validated structural values; decoding
 * bytes does not make a lease trusted or current. Structural inputs are useful
 * only after a future trusted constructor has obtained the same facts
 * atomically. Nothing here may turn a caller-supplied authority availability
 * bit, digest, or revocation list into trusted state.
 *
 * The helpers do own the deterministic policy order and lease arithmetic once
 * those facts are available. This file is not exported from the package barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { CoreFaultV1, CoreRevocationFloorV1 } from "./coreReduce";
import type { AdmissionGrantV1 } from "./operationPayload";
import type { RoomPolicyV4 } from "./roomPolicyV4";
export type CanonicalBytes32SetV1 = readonly Uint8Array[];
export interface FrontendRoomControlsV1 {
    readonly version: 1;
    readonly policyGeneration: bigint;
    readonly onlyConnectWithKnownPeers: boolean;
    readonly allowedStableIdentityKeys: CanonicalBytes32SetV1;
    readonly deniedStableIdentityKeys: CanonicalBytes32SetV1;
    readonly deniedRoomIdentityCommitments: CanonicalBytes32SetV1;
}
export interface AuthorityWindowFaultV1 {
    readonly logicalWindow: bigint;
    readonly proofOperationIds: readonly Uint8Array[];
}
/**
 * Structural policy projection only. A future private authority-view
 * constructor must derive this from a branded atomic snapshot. This interface
 * and its digest field do not establish provenance.
 */
export interface AuthorityAdmissionPolicyViewV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly stableIdentityCommitment: Uint8Array;
    readonly referenceWindow: bigint;
    readonly status: "available" | "unavailable";
    readonly revocationFacts: readonly CoreRevocationFloorV1[];
    readonly authorityAdmissionStateDigest: Uint8Array;
}
export interface PairAttemptLeaseV1 {
    readonly version: 1;
    readonly helloOperationId: Uint8Array;
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly attemptMode: "planner" | "explicit";
    readonly helloLogicalWindow: bigint;
    readonly validThroughLogicalWindow: bigint;
}
export interface BootstrapAdmissionDecisionLeaseV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly stableEd25519PublicKey: Uint8Array;
    readonly stableIdentityCommitment: Uint8Array;
    readonly grantId: Uint8Array | null;
    readonly grantGeneration: bigint | null;
    readonly localPolicyGeneration: bigint;
    readonly authorityAdmissionStateDigest: Uint8Array | null;
    readonly admittedPresenceOperationId: Uint8Array;
    readonly admittedIdentityOperationId: Uint8Array;
    readonly decidedAtLogicalWindow: bigint;
    readonly validThroughLogicalWindow: bigint;
}
export interface StableEdgeAdmissionLeaseV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly stableEdgeId: Uint8Array;
    readonly confirmedPairTranscriptId: Uint8Array;
    readonly rendezvousChannelId: Uint8Array;
    readonly v4WireBinding: Uint8Array;
    readonly remoteStableEd25519PublicKey: Uint8Array;
    readonly remoteStableIdentityCommitment: Uint8Array;
    readonly grantId: Uint8Array | null;
    readonly grantGeneration: bigint | null;
    readonly localPolicyGeneration: bigint;
    readonly authorityAdmissionStateDigest: Uint8Array | null;
    readonly decidedAtLogicalWindow: bigint;
    readonly validThroughLogicalWindow: bigint | null;
}
export type AdmissionAllowReason = "open" | "address-book" | "authority-grant";
export type AdmissionDenyReason = "blacklisted" | "not-in-address-book" | "missing-grant" | "invalid-grant" | "revoked" | "policy-unavailable";
export interface AllowedPeerAdmissionPolicyV1 {
    readonly result: "allow";
    readonly reason: AdmissionAllowReason;
    readonly localPolicyGeneration: bigint;
    readonly grantId: Uint8Array | null;
    readonly grantGeneration: bigint | null;
    readonly authorityAdmissionStateDigest: Uint8Array | null;
    readonly grantValidThroughLogicalWindow: bigint | null;
}
export interface DeniedPeerAdmissionPolicyV1 {
    readonly result: "deny";
    readonly reason: AdmissionDenyReason;
}
export type PeerAdmissionPolicyDecisionV1 = AllowedPeerAdmissionPolicyV1 | DeniedPeerAdmissionPolicyV1;
export type PairAdmissionDecision = {
    readonly result: "allow";
    readonly reason: AdmissionAllowReason;
    readonly bootstrapLease: BootstrapAdmissionDecisionLeaseV1;
    readonly pairAttemptLease: PairAttemptLeaseV1;
} | DeniedPeerAdmissionPolicyV1;
export type StableEdgeAdmissionDecision = {
    readonly result: "allow";
    readonly reason: AdmissionAllowReason;
    readonly lease: StableEdgeAdmissionLeaseV1;
} | DeniedPeerAdmissionPolicyV1;
/**
 * Unbranded facts consumed by the semantic policy helper. Production code must
 * obtain the corresponding values from `TrustedAdmissionSnapshotV1`; this type
 * is intentionally not named or presented as that trusted snapshot.
 */
export interface PeerAdmissionPolicySemanticInputV1 {
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly referenceWindow: bigint;
    readonly frontendControls: FrontendRoomControlsV1 | null;
    readonly authorityView: AuthorityAdmissionPolicyViewV1 | null;
    readonly stableEd25519PublicKey: Uint8Array;
    readonly stableIdentityCommitment: Uint8Array;
    readonly optionalGrant: AdmissionGrantV1 | null;
    readonly grantCarriedAtLogicalWindow: bigint | null;
}
export interface BootstrapAdmissionLeaseSemanticInputV1 {
    readonly policy: AllowedPeerAdmissionPolicyV1;
    readonly roomContextId: Uint8Array;
    readonly stableEd25519PublicKey: Uint8Array;
    readonly stableIdentityCommitment: Uint8Array;
    readonly admittedPresenceOperationId: Uint8Array;
    readonly admittedIdentityOperationId: Uint8Array;
    readonly admittedIdentityOperationLogicalWindow: bigint;
    readonly admittedIdentityOperationValidThroughLogicalWindow: bigint;
    readonly admittedPresenceEvidenceRetainThroughLogicalWindow: bigint;
    readonly basePairAttemptLease: PairAttemptLeaseV1;
    readonly referenceWindow: bigint;
}
export interface StableEdgeAdmissionLeaseSemanticInputV1 {
    readonly policy: AllowedPeerAdmissionPolicyV1;
    readonly roomContextId: Uint8Array;
    readonly stableEdgeId: Uint8Array;
    readonly confirmedPairTranscriptId: Uint8Array;
    readonly rendezvousChannelId: Uint8Array;
    readonly v4WireBinding: Uint8Array;
    readonly remoteStableEd25519PublicKey: Uint8Array;
    readonly remoteStableIdentityCommitment: Uint8Array;
    readonly referenceWindow: bigint;
}
export declare class AdmissionPolicySemanticError extends Error {
    readonly name = "AdmissionPolicySemanticError";
    constructor(message: string);
}
export declare const validateAndCopyFrontendRoomControlsV1: (value: unknown) => FrontendRoomControlsV1;
/** Canonical bytes for one already-local frontend policy snapshot. */
export declare const encodeFrontendRoomControlsV1: (value: unknown) => Uint8Array;
/**
 * Restore an owned structural snapshot. This does not establish frontend
 * provenance or make the policy generation current.
 */
export declare const decodeFrontendRoomControlsV1: (bytes: Uint8Array) => FrontendRoomControlsV1;
/** Membership over an already validated canonical byte set. */
export declare const canonicalBytes32SetHas: (values: CanonicalBytes32SetV1, candidate: Uint8Array) => boolean;
/**
 * `ApplicableRevocationFacts(commitment, referenceWindow)` from Section 4.8.
 * Input order and exact duplicate delivery do not affect the result.
 */
export declare const selectApplicableRevocationFacts: (facts: readonly CoreRevocationFloorV1[], stableIdentityCommitment: Uint8Array, referenceWindow: bigint) => readonly CoreRevocationFloorV1[];
export declare const authorityFaultValidThrough: (roomPolicy: RoomPolicyV4, faultWindow: bigint) => bigint;
export interface BlockingAuthorityWindowFaultSelectionV1 {
    readonly blockingAuthorityWindowFaults: readonly AuthorityWindowFaultV1[];
    readonly unavailableThroughLogicalWindow: bigint | null;
}
/**
 * Select every still-blocking pinned-authority author-window fault. Custody
 * saturation is intentionally absent; the future trusted view constructor must
 * combine this selection with its protected custody projection.
 */
export declare const selectBlockingAuthorityWindowFaults: (faults: readonly CoreFaultV1[], roomPolicy: RoomPolicyV4, referenceWindow: bigint) => BlockingAuthorityWindowFaultSelectionV1;
export declare const authorityGenerationAllowed: (generation: bigint, authorityView: Pick<AuthorityAdmissionPolicyViewV1, "status" | "revocationFacts">) => boolean;
/**
 * The one semantic policy order shared by future bootstrap and stable-edge
 * wrappers. It intentionally does not verify trusted snapshot/view provenance.
 */
export declare const evaluatePeerAdmissionPolicySemantics: (input: PeerAdmissionPolicySemanticInputV1, module?: LibCrypto) => Promise<PeerAdmissionPolicyDecisionV1>;
export declare const validateAndCopyPairAttemptLeaseV1: (value: unknown) => PairAttemptLeaseV1;
/** Canonical durable bytes for one structurally valid pair-attempt lease. */
export declare const encodePairAttemptLeaseV1: (value: unknown) => Uint8Array;
/**
 * Restore an owned structural pair-attempt lease. Callers must still bind it
 * to the fresh trusted pair state before treating it as authority to act.
 */
export declare const decodePairAttemptLeaseV1: (bytes: Uint8Array) => PairAttemptLeaseV1;
export declare const validateAndCopyBootstrapAdmissionDecisionLeaseV1: (value: unknown) => BootstrapAdmissionDecisionLeaseV1;
/** Canonical durable bytes for one bootstrap admission decision lease. */
export declare const encodeBootstrapAdmissionDecisionLeaseV1: (value: unknown) => Uint8Array;
/**
 * Restore an owned structural bootstrap lease. The decoded record is not a
 * trusted admission decision until its bindings and freshness are rechecked.
 */
export declare const decodeBootstrapAdmissionDecisionLeaseV1: (bytes: Uint8Array) => BootstrapAdmissionDecisionLeaseV1;
export declare const validateAndCopyAllowedPeerAdmissionPolicyV1: (value: unknown) => AllowedPeerAdmissionPolicyV1;
/**
 * Narrow the authenticated base pair-attempt horizon by the admitted grant,
 * then construct both immutable bootstrap leases. A future trusted wrapper
 * must verify every pair/presence coordinate before calling this semantic
 * helper and must persist only this returned pair-attempt lease.
 */
export declare const constructBootstrapAdmissionDecisionLease: (input: BootstrapAdmissionLeaseSemanticInputV1) => PairAdmissionDecision;
/**
 * Construct only the stable-edge lease/result after a future branded stable
 * context and fresh trusted snapshot have passed the shared policy helper.
 */
export declare const constructStableEdgeAdmissionLease: (input: StableEdgeAdmissionLeaseSemanticInputV1) => StableEdgeAdmissionDecision;
