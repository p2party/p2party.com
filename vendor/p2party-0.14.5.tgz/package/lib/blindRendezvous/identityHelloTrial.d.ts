/**
 * Provenance-checked local custody and receiver trial for identity HELLO.
 *
 * Expensive local ownership and hybrid-key verification happen exactly once
 * when trusted room/key storage creates `LocalHelloReceiverCustodyV1`.
 * Per-candidate `ExpectedIdentityHelloTrialV1` construction is synchronous,
 * bounded, and cryptography-free. A later durable budget reservation binds
 * the exact opaque candidate and trial objects. The opener can additionally
 * assert the custody identity sealed inside that trial before it invokes the
 * explicitly internal one-use secret transfer below.
 *
 * This module deliberately does not reserve work, run HPKE, authorize a peer,
 * mutate a pair ledger, or publish a response. It is absent from the package
 * barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { ActivePairOperationCandidateSnapshotV1, ActivePairOperationCandidateV1, VerifiedHistoricalPairPresenceEvidenceV1, VerifiedHistoricalPairPresenceSnapshotV1 } from "./coreReduce";
import type { ReservedIdentityHelloOpenV1 } from "./pairOpenReservation";
import type { RoomPolicyV4 } from "./roomPolicyV4";
import type { LocalStableIdentityCustodyV1 } from "./localStableIdentityCustody";
declare const localHelloReceiverCustodyBrand: unique symbol;
declare const historicalIdentityHelloEvidenceViewBrand: unique symbol;
declare const expectedIdentityHelloTrialBrand: unique symbol;
/**
 * Opaque room-specific custody for one local presence receiver key.
 *
 * The current constructor is an interim trusted local-storage boundary:
 * `receiverKeyRecordRevision` and `roomRoot` have no independent storage
 * provenance yet. Stable identity ownership is already sealed by an exact
 * `LocalStableIdentityCustodyV1` handle. The future atomic room/key adapter
 * must be the sole caller. None of these values become per-trial inputs.
 */
export interface LocalHelloReceiverCustodyV1 {
    readonly [localHelloReceiverCustodyBrand]: true;
}
/**
 * Opaque bounded endpoint-evidence lookup for one exact HELLO-time Core view.
 *
 * It is not admission or topology authority. The trusted caller supplies the
 * locally selected subset; the later planner/explicit-state fence decides
 * whether an authenticated endpoint may receive a response.
 */
export interface HistoricalIdentityHelloEvidenceViewV1 {
    readonly [historicalIdentityHelloEvidenceViewBrand]: true;
}
/** Opaque, process-local, one-use candidate trial. */
export interface ExpectedIdentityHelloTrialV1 {
    readonly [expectedIdentityHelloTrialBrand]: true;
}
export interface CreateLocalHelloReceiverCustodyOptionsV1 {
    readonly module: LibCrypto;
    readonly localPresenceEvidence: VerifiedHistoricalPairPresenceEvidenceV1;
    /** Suite-1 MLKEM768-X25519 deterministic receiver seed. */
    readonly recipientHybridKemSecretSeed: Uint8Array;
    /** Exact room-specific HPKE PSK derived by trusted initialized-room state. */
    readonly roomRoot: Uint8Array;
    readonly localStableIdentityCustody: LocalStableIdentityCustodyV1;
    readonly receiverKeyRecordRevision: bigint;
}
export interface LocalHelloReceiverCustodySnapshotV1 {
    readonly version: 1;
    readonly localPresenceOperationId: Uint8Array;
    readonly exactPresenceOperationBytes: Uint8Array;
    readonly sourceEvidenceCoreStateBytes: Uint8Array;
    readonly sourceEvidenceLogicalWindow: bigint;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly advertisedReceiverHybridKemPublicKey: Uint8Array;
    readonly receiverKeyValidThroughLogicalWindow: bigint;
    readonly receiverEvidenceRetainThroughLogicalWindow: bigint;
    readonly localStableEd25519PublicKey: Uint8Array;
    readonly localIdentityKeyRecordRevision: bigint;
    readonly receiverKeyRecordRevision: bigint;
}
export interface CreateHistoricalIdentityHelloEvidenceViewOptionsV1 {
    /**
     * A nonempty bounded subset of observed PRESENCE evidence from one genuine
     * HELLO-time Core result. Production supplies the Project-selected subset
     * needed by local receiver trials, never the whole raw overcapacity roster.
     */
    readonly historicalPresenceEvidence: readonly VerifiedHistoricalPairPresenceEvidenceV1[];
}
/**
 * Compact, deeply owned metadata for one bounded historical evidence view.
 *
 * Presence operation IDs are sufficient for deterministic membership and
 * lookup. Exact operation/prefix snapshots are resolved one at a time only
 * after a durable pair-open reservation has been consumed.
 */
export interface HistoricalIdentityHelloEvidenceViewSnapshotV1 {
    readonly version: 1;
    readonly exactCoreStateBytes: Uint8Array;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly helloLogicalWindow: bigint;
    readonly minimumRetainThroughLogicalWindow: bigint;
    readonly presenceOperationIds: readonly Uint8Array[];
}
export interface CreateExpectedIdentityHelloTrialOptionsV1 {
    readonly activeCandidate: ActivePairOperationCandidateV1;
    readonly receiverCustody: LocalHelloReceiverCustodyV1;
    readonly historicalEvidenceView: HistoricalIdentityHelloEvidenceViewV1;
    readonly trialOrdinal: number;
}
/**
 * Deeply owned non-secret view for durable reservation/CAS binding.
 *
 * `exactCoreStateBytes` is the current active-operation fence.
 * `exactEvidenceCoreStateBytes` is the potentially older, exact HELLO-window
 * presence-proof fence. They intentionally need not be equal.
 */
export interface ExpectedIdentityHelloTrialSnapshotV1 {
    readonly version: 1;
    readonly activeOperationId: Uint8Array;
    readonly exactCoreStateBytes: Uint8Array;
    readonly exactEvidenceCoreStateBytes: Uint8Array;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly helloLogicalWindow: bigint;
    readonly localPresenceOperationId: Uint8Array;
    readonly advertisedReceiverHybridKemPublicKey: Uint8Array;
    readonly receiverKeyValidThroughLogicalWindow: bigint;
    readonly receiverEvidenceRetainThroughLogicalWindow: bigint;
    readonly trialOrdinal: number;
    readonly receiverKeyRecordRevision: bigint;
    readonly localIdentityKeyRecordRevision: bigint;
    readonly activeCandidate: ActivePairOperationCandidateSnapshotV1;
    readonly receiverCustody: LocalHelloReceiverCustodySnapshotV1;
    readonly localPresenceEvidence: VerifiedHistoricalPairPresenceSnapshotV1;
    readonly historicalEvidenceView: HistoricalIdentityHelloEvidenceViewSnapshotV1;
}
/**
 * Small private-to-the-pair-kernel projection used before work is charged.
 *
 * It contains no decoded room roster, presence operation, author prefix,
 * receiver secret, RoomRoot, or caller-controlled coordinate.
 *
 * @internal
 */
export interface ExpectedIdentityHelloTrialReservationProjectionV1 {
    readonly version: 1;
    readonly activeOperationId: Uint8Array;
    readonly exactCurrentCoreStateBytes: Uint8Array;
    readonly exactEvidenceCoreStateBytes: Uint8Array;
    readonly roomContextId: Uint8Array;
    readonly localPresenceOperationId: Uint8Array;
    readonly receiverKeyRecordRevision: bigint;
    readonly capturedReferenceWindow: bigint;
    readonly completeEnvelopeBytes: number;
}
/**
 * Internal one-use transfer returned only after consuming a genuine durable
 * reservation.
 *
 * Both returned secrets are fresh owned copies and MUST be wiped by the
 * consumer in a `finally` block. The reusable custody master remains live
 * until explicitly destroyed because concurrent HELLO trials may need it.
 *
 * @internal
 */
export interface ConsumedExpectedIdentityHelloTrialV1 {
    readonly snapshot: ExpectedIdentityHelloTrialSnapshotV1;
    readonly activeCandidate: ActivePairOperationCandidateV1;
    readonly receiverCustody: LocalHelloReceiverCustodyV1;
    readonly localPresenceEvidence: VerifiedHistoricalPairPresenceEvidenceV1;
    /**
     * Exact-ID lookup over the bounded fenced view. This function exists only
     * after the durable reservation is consumed; it returns an opaque genuine
     * evidence handle, never a caller-assembled structural proof.
     */
    readonly resolveHistoricalPresenceEvidence: (presenceOperationId: Uint8Array) => VerifiedHistoricalPairPresenceEvidenceV1 | null;
    readonly recipientHybridKemSecretSeed: Uint8Array;
    readonly roomRoot: Uint8Array;
}
export declare class IdentityHelloTrialError extends Error {
    readonly name = "IdentityHelloTrialError";
    constructor(message: string);
}
/**
 * Capture one bounded exact-Core evidence subset.
 *
 * The O(selected-member-count) provenance work and canonical Core decode
 * happen once here. Every later receiver-key trial reuses the opaque result
 * and performs no raw-roster walk. A view may omit an otherwise valid Core
 * presence because Project did not select it; a HELLO naming an omitted
 * endpoint is deferred and can never bypass later planner/admission fences.
 */
export declare const createHistoricalIdentityHelloEvidenceViewV1: (options: CreateHistoricalIdentityHelloEvidenceViewOptionsV1) => Promise<HistoricalIdentityHelloEvidenceViewV1>;
/** Return fresh compact metadata, never per-presence operation snapshots. */
export declare const snapshotHistoricalIdentityHelloEvidenceViewV1: (view: HistoricalIdentityHelloEvidenceViewV1) => HistoricalIdentityHelloEvidenceViewSnapshotV1;
/**
 * Create reusable local receiver custody.
 *
 * All caller bytes and execution dependencies are captured before the first
 * await. Expensive verification occurs here once per persisted key record,
 * never once per attacker-supplied PAIR_STEP.
 */
export declare const createLocalHelloReceiverCustodyV1: (options: CreateLocalHelloReceiverCustodyOptionsV1) => Promise<LocalHelloReceiverCustodyV1>;
/** Return a fresh non-secret custody projection. */
export declare const snapshotLocalHelloReceiverCustodyV1: (custody: LocalHelloReceiverCustodyV1) => LocalHelloReceiverCustodySnapshotV1;
/**
 * Create one cheap expected trial from already-verified local custody.
 *
 * This function is intentionally synchronous and performs no signature, KEM,
 * KDF, AEAD, or storage work.
 */
export declare const createExpectedIdentityHelloTrialV1: (options: CreateExpectedIdentityHelloTrialOptionsV1) => ExpectedIdentityHelloTrialV1;
/** Return a fresh, independently owned, non-secret trial snapshot. */
export declare const snapshotExpectedIdentityHelloTrialV1: (trial: ExpectedIdentityHelloTrialV1) => ExpectedIdentityHelloTrialSnapshotV1;
/**
 * Return the only pre-budget projection used by reservation.
 *
 * All fields were captured once when the trial was constructed. In
 * particular, this function performs no Core decode, roster walk, evidence
 * snapshot, operation decode, signature work, KEM work, or secret copy.
 *
 * @internal
 */
export declare const snapshotExpectedIdentityHelloTrialReservationProjectionV1: (trial: ExpectedIdentityHelloTrialV1, activeCandidate: ActivePairOperationCandidateV1) => ExpectedIdentityHelloTrialReservationProjectionV1;
/**
 * Recheck all opaque dependencies without materializing structural data.
 *
 * @internal
 */
export declare const assertExpectedIdentityHelloTrialReservationLivenessV1: (trial: ExpectedIdentityHelloTrialV1, activeCandidate: ActivePairOperationCandidateV1) => void;
/**
 * Bind reservation to the exact opaque active-candidate object.
 *
 * Custody is deliberately not a reservation input: its identity is sealed
 * inside the trial, so the reservation caller cannot substitute one.
 *
 * @internal
 */
export declare const assertExpectedIdentityHelloTrialCandidateBindingV1: (trial: ExpectedIdentityHelloTrialV1, activeCandidate: ActivePairOperationCandidateV1) => void;
/**
 * Bind the future opener to the exact opaque candidate and custody objects.
 *
 * Matching structural bytes are insufficient.
 *
 * @internal
 */
export declare const assertExpectedIdentityHelloTrialBindingsV1: (trial: ExpectedIdentityHelloTrialV1, activeCandidate: ActivePairOperationCandidateV1, receiverCustody: LocalHelloReceiverCustodyV1) => void;
/**
 * Consume one genuine committed reservation, then transfer trial secrets.
 *
 * The reservation capability is deleted before this function can copy either
 * secret. Its privately bound candidate must be the exact candidate sealed
 * inside the trial; no caller-supplied candidate participates in this check.
 *
 * This explicit import creates a narrow cycle with `pairOpenReservation.ts`.
 * Neither module performs top-level work, so the cycle contains bindings only.
 *
 * @internal
 */
export declare const consumeReservedExpectedIdentityHelloTrialForPairOpenV1: (capability: ReservedIdentityHelloOpenV1, trial: ExpectedIdentityHelloTrialV1) => ConsumedExpectedIdentityHelloTrialV1;
/** Invalidate one unused trial. Idempotent for a genuine handle. */
export declare const destroyExpectedIdentityHelloTrialV1: (trial: ExpectedIdentityHelloTrialV1) => void;
/**
 * Invalidate one reusable historical evidence view.
 *
 * Destruction is idempotent for a genuine handle. Any dependent unconsumed
 * trial subsequently fails closed at reservation or consumption.
 */
export declare const destroyHistoricalIdentityHelloEvidenceViewV1: (view: HistoricalIdentityHelloEvidenceViewV1) => void;
/**
 * Wipe reusable receiver custody after its key record is retired.
 *
 * Destruction is idempotent for a genuine handle.
 */
export declare const destroyLocalHelloReceiverCustodyV1: (custody: LocalHelloReceiverCustodyV1) => void;
export {};
