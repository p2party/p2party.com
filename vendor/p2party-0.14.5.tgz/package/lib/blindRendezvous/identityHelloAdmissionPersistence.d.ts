/**
 * Exact persistence contract for HELLO-responder admission.
 *
 * This module is deliberately declarative. It defines the one atomic capture,
 * fixed compare-and-swap fence order, and closed write masks that a concrete
 * store adapter must implement. It does not expose an executable claim-to-CAS
 * path: only the trusted admission/response orchestrator may eventually build
 * a mutation from canonical rows and spend its opaque prepared handle.
 *
 * The adapter's read result is untrusted until
 * `validateAndCopyIdentityHelloAdmissionExactCaptureRowsV1` accepts it. This
 * source-internal module is absent from the package barrel.
 */
/** Exact absence is a fence and is never represented by empty bytes. */
export type ExactIdentityHelloAdmissionRowV1 = {
    readonly kind: "absent";
} | {
    readonly kind: "present";
    readonly exactBytes: Uint8Array;
};
/** Revisioned key custody uses a non-reused u64 revision to prevent ABA. */
export type ExactIdentityHelloAdmissionRevisionV1 = {
    readonly kind: "absent";
} | {
    readonly kind: "present";
    readonly recordRevision: bigint;
};
/**
 * Lookup coordinates derived only from a genuine authenticated HELLO claim.
 * Applications and adapters may not select any of these values.
 */
export interface IdentityHelloAdmissionReadLocatorV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly helloOperationId: Uint8Array;
    readonly pairEdgeId: Uint8Array;
    readonly localPresenceOperationId: Uint8Array;
    readonly exactHistoricalEvidenceCoreStateBytes: Uint8Array;
}
/**
 * Complete read result from one atomic read-only transaction.
 *
 * `historicalEvidence` is the canonical pair-subject evidence bundle selected
 * by the exact HELLO-time Core bytes: that exact Core row plus the remote and
 * local endpoint PRESENCE operations and their required author prefixes.
 */
export interface IdentityHelloAdmissionExactCaptureRowsV1 {
    readonly initializedRoom: ExactIdentityHelloAdmissionRowV1;
    readonly currentCore: ExactIdentityHelloAdmissionRowV1;
    readonly historicalEvidence: ExactIdentityHelloAdmissionRowV1;
    readonly receiverKey: ExactIdentityHelloAdmissionRevisionV1;
    readonly localPresenceOwnership: ExactIdentityHelloAdmissionRowV1;
    readonly frontendControls: ExactIdentityHelloAdmissionRowV1;
    readonly authorityCustody: ExactIdentityHelloAdmissionRowV1;
    readonly plannerAndExplicitState: ExactIdentityHelloAdmissionRowV1;
    readonly localIdentityKey: ExactIdentityHelloAdmissionRevisionV1;
    readonly localAuthorHead: ExactIdentityHelloAdmissionRowV1;
    readonly pairLedger: ExactIdentityHelloAdmissionRowV1;
    readonly provisionalPair: ExactIdentityHelloAdmissionRowV1;
    readonly identityBootstrapOutbox: ExactIdentityHelloAdmissionRowV1;
    readonly resourceState: ExactIdentityHelloAdmissionRowV1;
}
/** Normative first-conflict order for the admission transaction. */
export declare const IDENTITY_HELLO_ADMISSION_CAS_FENCE_ORDER_V1: readonly ["initialized-room", "current-core", "historical-evidence", "receiver-key", "local-presence-ownership", "frontend-controls", "authority-custody", "planner-and-explicit-state", "local-identity-key", "local-author-head", "pair-ledger", "provisional-pair", "identity-bootstrap-outbox", "resource-state"];
export type IdentityHelloAdmissionCasConflictFenceV1 = (typeof IDENTITY_HELLO_ADMISSION_CAS_FENCE_ORDER_V1)[number];
/**
 * Closed effects for the four legal persistence transitions.
 *
 * Every effect carries one complete next-state projection instead of a
 * per-variant partial write mask. This is deliberately repetitive at runtime
 * but singular in the type system: an added mutable row cannot be forgotten
 * by fork cancellation, denial, or replay reauthorization.
 *
 * These are an adapter contract, not caller input. The trusted transition
 * must construct every row from canonical codecs. `accept-new` additionally
 * proves that one ACCEPT operation ID binds the author head, pair ledger,
 * provisional pair, outbox, and resource reservation.
 */
export interface PreparedIdentityHelloAdmissionMutationV1 {
    readonly kind: "accept-new" | "record-denial" | "requeue-replay" | "record-fork";
    readonly nextRows: IdentityHelloAdmissionCommittedRowsV1;
}
export interface IdentityHelloAdmissionCasRequestV1 {
    readonly locator: IdentityHelloAdmissionReadLocatorV1;
    readonly expected: IdentityHelloAdmissionExactCaptureRowsV1;
    readonly mutation: PreparedIdentityHelloAdmissionMutationV1;
}
/** Complete mutable-row echo after a successful durable commit. */
export interface IdentityHelloAdmissionCommittedRowsV1 {
    readonly plannerAndExplicitState: ExactIdentityHelloAdmissionRowV1;
    readonly localAuthorHead: ExactIdentityHelloAdmissionRowV1;
    readonly pairLedger: ExactIdentityHelloAdmissionRowV1;
    readonly provisionalPair: ExactIdentityHelloAdmissionRowV1;
    readonly identityBootstrapOutbox: ExactIdentityHelloAdmissionRowV1;
    readonly resourceState: ExactIdentityHelloAdmissionRowV1;
}
export type IdentityHelloAdmissionPortCasResultV1 = {
    readonly status: "committed";
    readonly committedRows: IdentityHelloAdmissionCommittedRowsV1;
} | {
    readonly status: "conflict";
    readonly fence: IdentityHelloAdmissionCasConflictFenceV1;
};
/**
 * Minimal byte-store port.
 *
 * `readExactCapture` performs one read-only transaction over every named row,
 * owns all returned bytes, and resolves only from `transaction.oncomplete`.
 *
 * `compareAndSwap` performs one read-write transaction, compares exact bytes,
 * exact absence, and non-reused revisions in the normative order, applies the
 * closed mutation only if every fence matches, and resolves only from
 * `transaction.oncomplete`. It performs no crypto and awaits no promise while
 * the IndexedDB transaction is live.
 */
export interface IdentityHelloAdmissionPersistencePortV1 {
    readExactCapture(locator: IdentityHelloAdmissionReadLocatorV1): Promise<IdentityHelloAdmissionExactCaptureRowsV1>;
    compareAndSwap(request: IdentityHelloAdmissionCasRequestV1): Promise<IdentityHelloAdmissionPortCasResultV1>;
}
export declare class IdentityHelloAdmissionPersistenceError extends Error {
    readonly name = "IdentityHelloAdmissionPersistenceError";
    constructor(message: string);
}
/**
 * Deeply own and structurally validate one complete adapter capture.
 *
 * This is only the byte/absence/revision boundary. The trusted admission
 * orchestrator must canonical-decode and correlate every required row before
 * it can mint any subsequent opaque capability.
 *
 * @internal
 */
export declare const validateAndCopyIdentityHelloAdmissionExactCaptureRowsV1: (value: unknown) => IdentityHelloAdmissionExactCaptureRowsV1;
