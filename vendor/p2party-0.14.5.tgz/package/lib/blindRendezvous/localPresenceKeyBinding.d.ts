/**
 * Process-local custody for a room/window author epoch and a verified binding
 * from one exact local PRESENCE to its live local key records.
 *
 * `VerifiedLocalPresenceKeyBindingV1` is intentionally only a per-presence key
 * binding. It proves neither a complete/non-omitted local-presence set nor a
 * current Core view, and it grants no topology, admission, lease, persistence,
 * publication, or signaling authority. This internal module is absent from the
 * package barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { VerifiedHistoricalPairPresenceEvidenceV1 } from "./coreReduce";
import type { LocalHelloReceiverCustodyV1 } from "./identityHelloTrial";
import type { OperationValidationContext } from "./operation";
import type { RoomPolicyV4 } from "./roomPolicyV4";
declare const localAuthorEpochCustodyBrand: unique symbol;
declare const verifiedLocalPresenceKeyBindingBrand: unique symbol;
/**
 * Opaque live custody for one exact room/window author epoch key record.
 *
 * This capability is runtime-distinct from stable-identity custody. Possessing
 * either handle can never be substituted for the other, even by a type cast.
 */
export interface LocalAuthorEpochCustodyV1 {
    readonly [localAuthorEpochCustodyBrand]: true;
}
export interface CreateLocalAuthorEpochCustodyOptionsV1 {
    readonly module: LibCrypto;
    readonly authorEpochEd25519SecretKey: Uint8Array;
    /** Non-reused revision of the persisted author-epoch key record. */
    readonly authorEpochKeyRecordRevision: bigint;
    readonly roomContextId: Uint8Array;
    readonly logicalWindow: bigint;
}
export interface LocalAuthorEpochCustodySnapshotV1 {
    readonly version: 1;
    readonly authorEpochEd25519PublicKey: Uint8Array;
    readonly authorEpochKeyRecordRevision: bigint;
    readonly roomContextId: Uint8Array;
    readonly logicalWindow: bigint;
}
/**
 * Opaque proof that one genuine retained local PRESENCE matches live local
 * stable-identity, receiver-key, and author-epoch custody.
 *
 * The handle is not a roster/set ownership proof. In particular, it says
 * nothing about omitted presences, a current Core snapshot, or authorization.
 */
export interface VerifiedLocalPresenceKeyBindingV1 {
    readonly [verifiedLocalPresenceKeyBindingBrand]: true;
}
export interface CreateVerifiedLocalPresenceKeyBindingOptionsV1 {
    readonly localPresenceEvidence: VerifiedHistoricalPairPresenceEvidenceV1;
    readonly receiverCustody: LocalHelloReceiverCustodyV1;
    readonly authorEpochCustody: LocalAuthorEpochCustodyV1;
    readonly initializedRoom: OperationValidationContext;
}
export interface VerifiedLocalPresenceKeyBindingSnapshotV1 {
    readonly version: 1;
    readonly localPresenceOperationId: Uint8Array;
    readonly exactPresenceOperationBytes: Uint8Array;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly presenceLogicalWindow: bigint;
    readonly provedAtLogicalWindow: bigint;
    readonly authorEpochEd25519PublicKey: Uint8Array;
    readonly authorEpochKeyRecordRevision: bigint;
    readonly advertisedReceiverHybridKemPublicKey: Uint8Array;
    readonly receiverKeyValidThroughLogicalWindow: bigint;
    readonly receiverKeyRecordRevision: bigint;
    readonly localStableEd25519PublicKey: Uint8Array;
    readonly localIdentityKeyRecordRevision: bigint;
}
export declare class LocalPresenceKeyBindingError extends Error {
    readonly name = "LocalPresenceKeyBindingError";
    constructor(message: string);
}
/**
 * Capture and validate one room/window author secret before minting custody.
 */
export declare const createLocalAuthorEpochCustodyV1: (options: CreateLocalAuthorEpochCustodyOptionsV1) => Promise<LocalAuthorEpochCustodyV1>;
/** Return a fresh non-secret projection and assert that custody is live. */
export declare const snapshotLocalAuthorEpochCustodyV1: (custody: LocalAuthorEpochCustodyV1) => LocalAuthorEpochCustodySnapshotV1;
/**
 * Wipe author-epoch custody after the corresponding local key record retires.
 *
 * Destruction is idempotent for a genuine handle. It neither owns nor retires
 * the historical receiver or stable-identity custody used by a binding.
 */
export declare const destroyLocalAuthorEpochCustodyV1: (custody: LocalAuthorEpochCustodyV1) => void;
/**
 * Verify one exact local PRESENCE/key relation and mint an empty opaque handle.
 *
 * Every caller-controlled byte is captured through genuine handles before the
 * ownership-signature await. The exact handles are then re-read, so retiring a
 * nested author, receiver, or stable key during verification fails closed.
 */
export declare const createVerifiedLocalPresenceKeyBindingV1: (options: CreateVerifiedLocalPresenceKeyBindingOptionsV1) => Promise<VerifiedLocalPresenceKeyBindingV1>;
/** Return fresh non-secret facts while every retained handle remains live. */
export declare const snapshotVerifiedLocalPresenceKeyBindingV1: (binding: VerifiedLocalPresenceKeyBindingV1) => VerifiedLocalPresenceKeyBindingSnapshotV1;
/**
 * Invalidate one binding without dereferencing its nested custody handles.
 *
 * This remains safe and idempotent after author, receiver, or stable custody
 * has already been retired and wiped.
 */
export declare const destroyVerifiedLocalPresenceKeyBindingV1: (binding: VerifiedLocalPresenceKeyBindingV1) => void;
export {};
