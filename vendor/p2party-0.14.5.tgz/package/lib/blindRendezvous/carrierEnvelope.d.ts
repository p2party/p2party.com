/**
 * Carrier-separated envelope framing (Section 4.5).
 *
 * The same logical operation is wrapped independently for every carrier
 * context, with carrier-domain-separated keys and nonce material, so two
 * stores never receive byte-identical ciphertext or a common object
 * identifier. A client deduplicates the rewrapped copies by the private
 * `OperationId` after decryption — an identifier a store never sees.
 *
 * ## The sealing primitive
 *
 * `carrierAeadSuite = 1` is the frozen XChaCha20-Poly1305 construction from
 * `draft-irtf-cfrg-xchacha-03` with a 32-byte key, 24-byte nonce, and 16-byte
 * tag. `createCarrierAeadProvider` binds it from the pinned libsodium build.
 *
 * The AEAD stays an injected provider rather than a direct import for two
 * reasons: a caller must supply an initialized WASM module anyway, and a build
 * that lacks the export fails closed with a typed error instead of silently
 * sealing under some other construction. Substituting a different AEAD, or
 * composing XChaCha20 in TypeScript, remains forbidden by SEC-002 and SEC-019.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { CarrierEnvelopeCoordinates } from "./derivations";
export declare const CARRIER_ENVELOPE_VERSION = 1;
export declare const CARRIER_AEAD_SUITE_1_KEY_BYTES = 32;
export declare const CARRIER_AEAD_SUITE_1_NONCE_BYTES = 24;
export declare const CARRIER_AEAD_SUITE_1_TAG_BYTES = 16;
export interface CarrierEnvelopeV1 {
    version: 1;
    deliveryProfileHash: Uint8Array;
    ingressWindow: bigint;
    sizeClass: number;
    carrierContextId: Uint8Array;
    nonce: Uint8Array;
    ciphertextAndTag: Uint8Array;
}
export interface CarrierPlaintextV1 {
    /** Exact canonical signed operation bytes, identical across carriers. */
    operationBytes: Uint8Array;
    /** Fills this profile's carrier size class. */
    carrierPadding: Uint8Array;
}
/**
 * The exact AEAD required by `carrierAeadSuite = 1`.
 *
 * An implementation must be XChaCha20-Poly1305 with the stated key, nonce, and
 * tag sizes. `open` returns null — never a partial or unauthenticated
 * plaintext — on any tag, length, or associated-data failure.
 */
export interface CarrierAeadProvider {
    readonly suite: 1;
    seal(key: Uint8Array, nonce: Uint8Array, associatedData: Uint8Array, plaintext: Uint8Array): Promise<Uint8Array>;
    open(key: Uint8Array, nonce: Uint8Array, associatedData: Uint8Array, ciphertextAndTag: Uint8Array): Promise<Uint8Array | null>;
}
export declare class CarrierAeadUnavailableError extends Error {
    readonly name = "CarrierAeadUnavailableError";
    readonly code = "carrier-aead-suite-1-unavailable";
    readonly suite = 1;
    constructor();
}
export declare class CarrierEnvelopeError extends Error {
    readonly name = "CarrierEnvelopeError";
    constructor(message: string);
}
/**
 * The conforming `carrierAeadSuite = 1` provider, bound to an initialized
 * cryptography module.
 */
export declare const createCarrierAeadProvider: (module: LibCrypto) => CarrierAeadProvider;
/**
 * Build the canonical carrier plaintext, padded to the profile's size class.
 *
 * Padding is what makes real and dummy objects the same length; a caller that
 * skipped it would publish a length that varies with the operation.
 */
export declare const buildCarrierPlaintext: (operationBytes: Uint8Array, fixedCarrierObjectBytes: number) => CarrierPlaintextV1;
/**
 * Seal one operation for one carrier context.
 *
 * The nonce is sampled by the caller per `(OperationId, profile, context,
 * ingressWindow, sizeClass)` wrap slot and persisted with the envelope before
 * first publication, so an exact retry resends the same bytes rather than
 * re-encrypting under a fresh nonce.
 */
export declare const sealCarrierEnvelope: (roomRootBytes: Uint8Array, coordinates: CarrierEnvelopeCoordinates, nonce: Uint8Array, plaintext: CarrierPlaintextV1, provider: CarrierAeadProvider | null) => Promise<CarrierEnvelopeV1>;
/**
 * Open an envelope, returning null when it is not for this room.
 *
 * A dummy is indistinguishable from a real object at this layer by
 * construction: it has the same public header and body length and simply fails
 * authentication, so the caller must treat null as "not mine", never as
 * evidence of a fault.
 */
export declare const openCarrierEnvelope: (roomRootBytes: Uint8Array, envelope: CarrierEnvelopeV1, provider: CarrierAeadProvider | null) => Promise<CarrierPlaintextV1 | null>;
/** The exact canonical encoding of an envelope, as published to a carrier. */
export declare const encodeCarrierEnvelope: (envelope: CarrierEnvelopeV1) => Uint8Array;
export declare const decodeCarrierEnvelope: (encoded: Uint8Array) => CarrierEnvelopeV1;
/** `CarrierObjectId`, meaningful only inside one carrier context. */
export declare const deriveCarrierObjectId: (envelope: CarrierEnvelopeV1) => Promise<Uint8Array>;
/**
 * Two envelopes of the same operation for different carrier contexts must not
 * share ciphertext or object identifier. Exposed so the carrier-separation
 * requirement is testable rather than assumed.
 */
export declare const envelopesAreCarrierSeparated: (left: CarrierEnvelopeV1, right: CarrierEnvelopeV1) => boolean;
