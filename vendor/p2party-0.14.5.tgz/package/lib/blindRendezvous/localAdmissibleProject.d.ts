/**
 * Pure local-admissible projection semantics.
 *
 * This module computes the diagnostic `LocalAdmissibleStateV1` from complete,
 * deeply owned inputs. It deliberately does not mint topology, reservation,
 * admission, persistence, or publication authority. The effectful HELLO path
 * must later wrap this kernel behind an opaque handle tied by object identity
 * to one genuine `TrustedAdmissionSnapshotV1` and its exact planner/CAS row.
 *
 * Authority-mode projection remains unavailable until the protected
 * non-omission custody constructor is implemented. There is no fallback to
 * address-book or open eligibility.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { FrontendRoomControlsV1 } from "./admissionPolicy";
import type { CoreRoomStateV1 } from "./coreReduce";
import type { PlannerAndExplicitStateV1 } from "./plannerState";
import type { RoomPolicyV4 } from "./roomPolicyV4";
export type LocalPresenceEligibilityV1 = "open" | "local-address-book-proved" | "authority-permit-proved";
export interface LocalAdmissiblePeerV1 {
    readonly localPeerId: string;
    readonly presenceOperationId: Uint8Array;
    readonly stableIdentityCommitment: Uint8Array;
    readonly rank: Uint8Array;
    readonly eligibility: LocalPresenceEligibilityV1;
    readonly desiredEdge: boolean;
}
export interface LocalAdmissibleStateV1 {
    readonly version: 1;
    readonly referenceWindow: bigint;
    readonly coreOperationsDigest: Uint8Array;
    readonly localPresenceOperationId: Uint8Array | null;
    readonly localPresenceRank: Uint8Array | null;
    readonly peers: readonly LocalAdmissiblePeerV1[];
    readonly requestedExplicitPeerIds: readonly string[];
}
export type LocalAdmissibleProjectStatusV1 = "ready" | "policy-unavailable" | "projection-resource-overcapacity" | "no-unambiguous-local-presence";
export type LocalAdmissiblePlannerStatusV1 = "ready" | "unavailable" | "full-mesh-overcapacity";
/**
 * Structural inputs for the pure semantic kernel.
 *
 * `maxPairLedgerEntriesPerRoom` is needed only to validate the captured
 * planner row. A future trusted wrapper pins it from the room resource policy;
 * accepting this structural object does not establish that provenance.
 */
export interface LocalAdmissibleProjectSemanticInputV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly referenceWindow: bigint;
    readonly coreRoomState: CoreRoomStateV1;
    readonly frontendControls: FrontendRoomControlsV1 | null;
    /**
     * Structural premise only. The trusted wrapper must replace this with a
     * process-local brand that binds every exact owned Core fact and OperationId
     * to one of these stable keys, a verified stable-ownership signature, and
     * current local author, identity, and receiver-key custody.
     */
    readonly localPresenceOwnership: {
        readonly version: 1;
        readonly localPresenceOperationIds: readonly Uint8Array[];
        readonly localStableIdentityKeys: readonly Uint8Array[];
    };
    readonly plannerAndExplicitState: PlannerAndExplicitStateV1;
    readonly maxRetainedValidOperationsPerRoom: number;
    readonly maxPairLedgerEntriesPerRoom: number;
}
export interface LocalAdmissibleProjectSemanticResultV1 {
    readonly version: 1;
    readonly projectionStatus: LocalAdmissibleProjectStatusV1;
    readonly plannerStatus: LocalAdmissiblePlannerStatusV1;
    readonly observedRosterHash: Uint8Array;
    readonly state: LocalAdmissibleStateV1;
    /**
     * SSOT for the two distinct attempt origins. `state.peers[].desiredEdge` is
     * only their UI-friendly OR and must never be used to enforce attemptMode.
     */
    readonly topologySelections: readonly LocalTopologySelectionFactV1[];
}
export interface LocalTopologySelectionFactV1 {
    readonly presenceOperationId: Uint8Array;
    readonly plannerSelected: boolean;
    /**
     * Local outbound intent only. An incoming signed `attemptMode="explicit"`
     * does not require this bit; it requires the separately captured receiver
     * `allowOnDemandEdges` gate.
     */
    readonly locallyRequestedExplicit: boolean;
}
export declare class LocalAdmissibleProjectError extends Error {
    readonly name = "LocalAdmissibleProjectError";
    constructor(message: string);
}
/**
 * Evaluate the local Project rules over one owned structural snapshot.
 *
 * The return value is a diagnostic fact only. It is intentionally cloneable
 * and therefore MUST NOT be accepted by a topology or admission transition as
 * proof that a peer was selected.
 */
export declare const evaluateLocalAdmissibleProjectionSemanticsV1: (inputValue: unknown, module?: LibCrypto) => Promise<LocalAdmissibleProjectSemanticResultV1>;
