/**
 * HELLO-responder admission preparation boundary.
 *
 * A service factory captures the initialized room and one storage port.
 * Per-HELLO callers supply only a genuine one-use authenticated claim; they
 * cannot assemble trusted rows, policy views, admission decisions, or lease
 * coordinates. An allow remains an opaque pre-topology policy result with
 * private HelloRoot custody. It is not a prepared persistence mutation or send
 * authority: planner/replay/resource checks, exact response construction,
 * compare-and-swap persistence, and publication remain later transitions.
 *
 * This source-internal module is intentionally absent from the package barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { AdmissionAllowReason } from "./admissionPolicy";
import type { IdentityHelloAdmissionClaimV1 } from "./identityHelloOpen";
import type { OperationValidationContext } from "./operation";
import type { RoomPolicyV4 } from "./roomPolicyV4";
import type { IdentityHelloAdmissionPersistencePortV1 } from "./identityHelloAdmissionPersistence";
declare const preparedIdentityHelloAdmissionBrand: unique symbol;
/**
 * Opaque policy allow before topology, replay/fork, key, and resource checks.
 * Its private state owns the claim and exact capture; spreading, persistence,
 * or a type assertion cannot reproduce its process-local provenance.
 */
export interface PreparedIdentityHelloAdmissionV1 {
    readonly [preparedIdentityHelloAdmissionBrand]: true;
}
export interface InitializedRoomAdmissionFenceV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
}
export interface LocalPresenceOwnershipV1 {
    readonly version: 1;
    readonly localPresenceOperationIds: readonly Uint8Array[];
    readonly localStableIdentityKeys: readonly Uint8Array[];
}
export type AuthorityCustodyProjectionV1 = {
    readonly version: 1;
    readonly status: "complete";
    readonly authorityCustodyStateDigest: Uint8Array;
    readonly firstSaturatedRequiredWorkId: null;
} | {
    readonly version: 1;
    readonly status: "saturated";
    readonly authorityCustodyStateDigest: Uint8Array;
    readonly firstSaturatedRequiredWorkId: Uint8Array;
};
export type IdentityHelloAdmissionCapturePortV1 = Pick<IdentityHelloAdmissionPersistencePortV1, "readExactCapture">;
export type PrepareIdentityHelloAdmissionResultV1 = {
    readonly kind: "prepared";
    readonly value: PreparedIdentityHelloAdmissionV1;
} | {
    readonly kind: "denied";
    readonly reason: "blacklisted" | "not-in-address-book" | "missing-grant" | "invalid-grant" | "revoked" | "policy-unavailable";
} | {
    readonly kind: "stale";
    readonly reason: "initialized-room-changed" | "core-changed" | "historical-evidence-changed" | "receiver-key-changed" | "local-identity-key-changed" | "local-presence-ownership-changed";
};
export interface IdentityHelloAdmissionPreparationServiceV1 {
    prepareIdentityHelloAdmission(claim: IdentityHelloAdmissionClaimV1): Promise<PrepareIdentityHelloAdmissionResultV1>;
}
export interface PreparedIdentityHelloAdmissionSnapshotV1 {
    readonly version: 1;
    readonly stage: "policy-allowed-pre-topology";
    /** Cloneable diagnostic only; never accepted back as authority. */
    readonly reason: AdmissionAllowReason;
}
export declare const encodeInitializedRoomAdmissionFenceV1: (initializedRoom: OperationValidationContext) => Uint8Array;
export declare const encodeLocalPresenceOwnershipV1: (value: LocalPresenceOwnershipV1) => Uint8Array;
export declare const encodeAuthorityCustodyProjectionV1: (value: AuthorityCustodyProjectionV1) => Uint8Array;
/**
 * Capture one storage adapter and initialized-room provenance boundary.
 *
 * A test may supply an in-memory port; production must construct this service
 * only inside the trusted room worker with its concrete transaction adapter.
 * Per-attempt callers cannot replace the port, initialized room, or crypto
 * module.
 */
export declare const createIdentityHelloAdmissionPreparationServiceV1: (port: IdentityHelloAdmissionCapturePortV1, initializedRoom: OperationValidationContext, module?: LibCrypto) => IdentityHelloAdmissionPreparationServiceV1;
/**
 * Non-secret diagnostic/test projection. It conveys no HelloRoot, response,
 * outbox, CAS capability, or permission to publish.
 */
export declare const snapshotPreparedIdentityHelloAdmissionV1: (value: PreparedIdentityHelloAdmissionV1) => PreparedIdentityHelloAdmissionSnapshotV1;
/** Wipe private HELLO-root custody. Idempotent for a genuine handle. */
export declare const destroyPreparedIdentityHelloAdmissionV1: (value: PreparedIdentityHelloAdmissionV1) => void;
export {};
