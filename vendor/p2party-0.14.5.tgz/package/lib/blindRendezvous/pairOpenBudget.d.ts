/**
 * Pure durable pair-open work-budget reducer.
 *
 * The effectful transaction layer derives one charge from a genuine active
 * PAIR_STEP, calls this reducer, compare-and-swaps the returned row together
 * with the exact Core/pair-state revisions, and only then mints a one-use
 * cryptographic trial capability. This module deliberately cannot authorize
 * crypto work by itself.
 */
export interface PairOpenBudgetCoordinateV1 {
    readonly localRoomId: string;
    readonly localPresenceOperationId: Uint8Array;
    readonly budgetLogicalWindow: bigint;
}
export interface PairOpenBudgetSnapshotV1 {
    readonly version: 1;
    readonly coordinate: PairOpenBudgetCoordinateV1;
    readonly budgetRevision: bigint;
    readonly reservedTrialCount: number;
    readonly reservedEnvelopeBytes: bigint;
    readonly saturated: boolean;
}
/**
 * Higher layers derive this from an opaque active-operation handle. In
 * particular, `completeEnvelopeBytes` is the exact validated fixed payload
 * length and is never a transport- or caller-reported estimate.
 */
export interface PairOpenBudgetChargeV1 {
    readonly localRoomId: string;
    readonly localPresenceOperationId: Uint8Array;
    readonly capturedReferenceWindow: bigint;
    readonly completeEnvelopeBytes: number;
}
export interface PairOpenBudgetLimitsV1 {
    readonly maxPairOpenTrialsPerPresenceWindow: number;
    readonly maxPairOpenBytesPerPresenceWindow: number;
}
export type PairOpenBudgetTransitionV1 = {
    readonly result: "prepared";
    /** Must be durably committed before any cryptographic work begins. */
    readonly next: PairOpenBudgetSnapshotV1;
} | {
    readonly result: "saturated";
    /**
     * Non-null on the first saturation (or a new-window reset) and must be
     * committed. Null means the persisted row was already sticky-saturated.
     */
    readonly next: PairOpenBudgetSnapshotV1 | null;
};
export declare class PairOpenBudgetError extends Error {
    readonly name = "PairOpenBudgetError";
    constructor(message: string);
}
/**
 * Apply one actual expensive-trial charge.
 *
 * Equal/older captured windows reuse the durable counters. Only a strictly
 * newer captured Core reference window resets them, and reset plus charge is
 * represented by one replacement row. Repeating crypto work repeats charge.
 */
export declare const reducePairOpenBudgetV1: (previousValue: PairOpenBudgetSnapshotV1 | null, chargeValue: PairOpenBudgetChargeV1, limitsValue: PairOpenBudgetLimitsV1) => PairOpenBudgetTransitionV1;
/** Strictly own and validate one row read from durable storage. */
export declare const validatePairOpenBudgetSnapshotV1: (value: unknown) => PairOpenBudgetSnapshotV1;
/** Canonical durable bytes after complete structural and reachability checks. */
export declare const encodePairOpenBudgetSnapshotV1: (value: unknown) => Uint8Array;
/** Strictly restore and own one canonical durable budget row. */
export declare const decodePairOpenBudgetSnapshotV1: (bytes: Uint8Array) => PairOpenBudgetSnapshotV1;
