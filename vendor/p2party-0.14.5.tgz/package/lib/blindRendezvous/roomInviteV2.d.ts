/**
 * Version-safe invitation parsing.
 *
 * REQ-001 keeps the user-facing flow identical — one capability, one `/r`
 * link, one QR code — while making the rendezvous version explicit in the
 * fragment. Every deployed form (compact, `v1.`, 24-word, legacy hex) keeps its
 * legacy-signaling meaning forever; blind rendezvous uses `v2.`.
 *
 * The two versions must never be silently interchangeable in either
 * direction: an old client rejects `v2.` as unsupported rather than joining a
 * different room, and a new client executes `v1.` only through the separately
 * installed legacy-signaling adapter.
 *
 * This module deliberately does not parse whole URLs. The page extracts
 * `location.hash` and passes the fragment in, exactly as today.
 */
import type { RoomPolicyV4 } from "./roomPolicyV4";
export declare const BLIND_ROOM_INVITE_VERSION = 2;
export declare const BLIND_ROOM_INVITE_PREFIX = "v2.";
/**
 * Bound on the canonical policy carried by a policy-bearing v2 fragment.
 *
 * Status: PROPOSED. The release registry freezes the final value together with
 * the binary policy codec; this bound only has to be large enough for a valid
 * `RoomPolicyV4` and small enough to keep a shared link scannable as a QR code.
 */
export declare const MAX_INVITE_POLICY_BYTES = 512;
export type LegacyRoomInviteV1 = {
    version: 1;
    capability: Uint8Array;
};
export type BlindRoomInviteV2 = {
    version: 2;
    form: "default";
    capability: Uint8Array;
} | {
    version: 2;
    form: "room-policy";
    capability: Uint8Array;
    roomPolicy: RoomPolicyV4;
};
export type ParsedRoomInvite = LegacyRoomInviteV1 | BlindRoomInviteV2;
export declare class RoomInviteParseError extends Error {
    readonly name = "RoomInviteParseError";
    constructor(message: string);
}
/**
 * Thrown when a v1 invitation is executed in a build without the optional
 * legacy-signaling adapter. It is raised before any adapter or network work
 * and before capability or identity disclosure, and it never maps v1 to v2.
 */
export declare class LegacySignalingAdapterUnavailableError extends Error {
    readonly name = "LegacySignalingAdapterUnavailableError";
    readonly code = "legacy-signaling-adapter-unavailable";
    readonly inviteVersion = 1;
    constructor();
}
/**
 * Thrown when the legacy-named `signalingServerUrl` option is supplied with a
 * v2 invitation but no exact trusted alias maps it to a signed store
 * descriptor. Failing here is deliberate: silently ignoring the value or
 * substituting the default store would send the user somewhere they did not
 * ask for.
 */
export declare class BlindStoreAliasResolutionError extends Error {
    readonly name = "BlindStoreAliasResolutionError";
    readonly code = "blind-store-alias-unmapped";
    readonly option = "signalingServerUrl";
    constructor();
}
/**
 * Parse a fragment into a closed versioned result, preserving the version.
 *
 * A leading `#` is accepted here and only here; it is not part of the
 * canonical invitation.
 */
export declare const parseRoomInvite: (fragment: string) => ParsedRoomInvite;
/** The capability-only default fragment: `v2.<43-character-base64url>`. */
export declare const encodeBlindRoomInviteV2Default: (capability: Uint8Array) => string;
/**
 * The policy-bearing fragment used by the advanced-room flow, so a PIN, PQ, or
 * cover choice survives sharing without appearing in an HTTP query.
 */
export declare const encodeBlindRoomInviteV2WithPolicy: (capability: Uint8Array, roomPolicy: RoomPolicyV4) => string;
/**
 * The room policy an invitation resolves to.
 *
 * A bare v2 invitation resolves to the frozen default rather than to whatever
 * the current application default happens to be; a policy-bearing invitation
 * resolves to its exact decoded policy with no defaults merged in.
 */
export declare const resolveInviteRoomPolicy: (invite: BlindRoomInviteV2) => RoomPolicyV4;
