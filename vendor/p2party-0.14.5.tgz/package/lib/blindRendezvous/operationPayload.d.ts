/**
 * Closed non-pair operation payload codecs and intrinsic validation.
 *
 * The schema descriptors in `schemas.ts` are the byte SSOT. This module adds
 * only rules that cannot be expressed by field widths alone: room/policy
 * binding, interval containment, semantic-slot derivation, and signatures.
 *
 * A LEAVE's same-author/live-presence dependency is intentionally completed
 * by `CoreReduce`, after the referenced operation is available. Rejecting a
 * missing dependency here would make acceptance depend on carrier arrival
 * order. Stable presence ownership is likewise verified only when a trusted
 * local address-book key or the pair-private stable key is available.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { AuthenticatedRoomOperationV1 } from "./operation";
import type { CorePresenceFactV1 } from "./coreReduce";
import type { RoomPolicyV4 } from "./roomPolicyV4";
import type { StoreDescriptorV1, StoreRouteV1 } from "./storeDescriptor";
export interface AdmissionGrantV1 {
    version: 1;
    roomContextId: Uint8Array;
    stableEd25519PublicKey: Uint8Array;
    generation: bigint;
    issuedAtLogicalWindow: bigint;
    notBeforeLogicalWindow: bigint;
    notAfterLogicalWindow: bigint;
    authoritySignature: Uint8Array;
}
export interface AdmissionRevokeV1 {
    version: 1;
    roomContextId: Uint8Array;
    stableIdentityCommitment: Uint8Array;
    minimumAcceptedGeneration: bigint;
    effectiveLogicalWindow: bigint;
    expiresAfterLogicalWindow: bigint;
    authoritySignature: Uint8Array;
}
export interface PresenceCoreV1 {
    version: 1;
    stableIdentityCommitment: Uint8Array;
    rendezvousHybridKemPublicKey: Uint8Array;
    receiverKeyValidThroughLogicalWindow: bigint;
    presenceNonce: Uint8Array;
    validThroughLogicalWindow: bigint;
}
export interface PresencePermitV1 {
    version: 1;
    roomContextId: Uint8Array;
    presenceProofTranscriptHash: Uint8Array;
    permitSerial: Uint8Array;
    generation: bigint;
    issuedAtLogicalWindow: bigint;
    notBeforeLogicalWindow: bigint;
    notAfterLogicalWindow: bigint;
    authoritySignature: Uint8Array;
}
export interface PresenceV1 {
    core: PresenceCoreV1;
    stableOwnershipSignature: Uint8Array;
    authorityPermit: PresencePermitV1 | null;
}
export interface LeaveV1 {
    version: 1;
    presenceOperationId: Uint8Array;
    effectiveLogicalWindow: bigint;
}
export interface StoreHintOperationV1 {
    version: 1;
    descriptor: StoreDescriptorV1;
    routes: readonly StoreRouteV1[];
    hintExpiresAfterLogicalWindow: bigint;
}
export type DecodedNonPairOperationPayloadV1 = {
    readonly kind: "PRESENCE";
    readonly value: PresenceV1;
} | {
    readonly kind: "LEAVE";
    readonly value: LeaveV1;
} | {
    readonly kind: "STORE_HINT";
    readonly value: StoreHintOperationV1;
} | {
    readonly kind: "ADMISSION_REVOKE";
    readonly value: AdmissionRevokeV1;
};
export interface NonPairPayloadValidationContext {
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
}
export interface AdmissionGrantValidationContext extends NonPairPayloadValidationContext {
    /** Logical window of the HELLO or ACCEPT carrying this grant. */
    readonly carriedAtLogicalWindow: bigint;
    readonly referenceWindow: bigint;
}
export declare class OperationPayloadValidationError extends Error {
    readonly name = "OperationPayloadValidationError";
    constructor(message: string);
}
export declare const encodeAdmissionGrantV1: (value: AdmissionGrantV1) => Uint8Array;
export declare const decodeAdmissionGrantV1: (bytes: Uint8Array) => AdmissionGrantV1;
export declare const encodeAdmissionRevokeV1: (value: AdmissionRevokeV1) => Uint8Array;
export declare const decodeAdmissionRevokeV1: (bytes: Uint8Array) => AdmissionRevokeV1;
export declare const encodePresenceV1: (value: PresenceV1) => Uint8Array;
export declare const decodePresenceV1: (bytes: Uint8Array) => PresenceV1;
export declare const encodeLeaveV1: (value: LeaveV1) => Uint8Array;
export declare const decodeLeaveV1: (bytes: Uint8Array) => LeaveV1;
export declare const encodeStoreHintOperationV1: (value: StoreHintOperationV1) => Uint8Array;
export declare const decodeStoreHintOperationV1: (bytes: Uint8Array) => StoreHintOperationV1;
/**
 * Validate a pair-private admission grant at the one decision snapshot.
 *
 * This does not apply frontend allow/deny policy or a revocation floor. Those
 * belong to the sole admission kernel after it has captured its trusted
 * snapshot; this function proves only the grant's canonical authority facts.
 */
export declare const validateAdmissionGrantV1: (grant: AdmissionGrantV1, context: AdmissionGrantValidationContext, module?: LibCrypto) => Promise<void>;
/**
 * Verify the stable ownership proof once a trusted local lookup or pair flight
 * supplies the exact stable public key. The key is deliberately absent from
 * room-wide presence, so core validation cannot call this function itself.
 */
export declare const validatePresenceOwnershipV1: (operation: AuthenticatedRoomOperationV1, presence: PresenceV1, stableEd25519PublicKey: Uint8Array, context: NonPairPayloadValidationContext, module?: LibCrypto) => Promise<void>;
/**
 * Verify ownership directly from a trusted Core presence fact.
 *
 * Core already authenticated the outer operation and preserved every field
 * used by the ownership transcript. This avoids fabricating an incomplete
 * `AuthenticatedRoomOperationV1` merely to perform a local address-book
 * lookup. The function proves only the signature/commitment relation; the
 * caller must still obtain the fact from a genuine current or retained Core
 * projection before treating it as admission evidence.
 */
export declare const validateCorePresenceFactOwnershipV1: (fact: CorePresenceFactV1, stableEd25519PublicKey: Uint8Array, context: NonPairPayloadValidationContext, module?: LibCrypto) => Promise<void>;
export declare const decodeAndValidateNonPairOperationPayload: (operation: AuthenticatedRoomOperationV1, context: NonPairPayloadValidationContext, module?: LibCrypto) => Promise<DecodedNonPairOperationPayloadV1>;
