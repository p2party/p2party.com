/**
 * Canonical binary schema: the single source of truth for blind-rendezvous
 * wire bytes.
 *
 * Section 4 of the L2/L3 blind-rendezvous specification writes `Canonical(x)`
 * for "the unique encoding in the companion binary-schema artifact". This
 * module is that artifact's executable form. It owns field order, integer
 * widths, enum values, collection ordering, and bounds, so no other module may
 * hand-roll a second encoding of the same value.
 *
 * Status: PROPOSED, NOT FROZEN. Phase 0 of the delivery roadmap freezes these
 * widths and publishes deterministic vectors under one release-registry hash.
 * Until that freeze and its external review, no hash derived from this module
 * may be published as a v0.4 release artifact, and no interoperability claim
 * follows from two implementations agreeing with it.
 *
 * The codec is descriptor-driven rather than hand-written per type. A
 * descriptor is the SSOT: encoders, decoders, key tables, and bound checks are
 * all derived from it, which is what makes the generated projections in
 * `projections.ts` mechanically checkable instead of hand-maintained.
 */
export type Bytes32 = Uint8Array;
/** Maximum entries in any bounded collection with a 16-bit count prefix. */
export declare const MAX_U16_COLLECTION_ENTRIES = 65535;
/** Bound on any canonical NFC text field, in UTF-8 bytes. */
export declare const MAX_CANONICAL_TEXT_BYTES = 4096;
/** Bound on a single canonically encoded value, in bytes. */
export declare const MAX_CANONICAL_ENCODING_BYTES: number;
export declare class CanonicalSchemaError extends Error {
    readonly name = "CanonicalSchemaError";
    readonly path: string;
    constructor(path: string, message: string);
}
export interface FieldDescriptor {
    readonly name: string;
    readonly type: TypeDescriptor;
}
export type TypeDescriptor = {
    readonly kind: "u8";
} | {
    readonly kind: "u16";
} | {
    readonly kind: "u32";
} | {
    readonly kind: "u64";
} | {
    readonly kind: "bool";
} | {
    readonly kind: "fixedBytes";
    readonly length: number;
} | {
    readonly kind: "varBytes";
    readonly maxLength: number;
} | {
    readonly kind: "text";
    readonly maxBytes: number;
} | {
    readonly kind: "enum";
    readonly name: string;
    readonly values: readonly string[];
} | {
    readonly kind: "array";
    readonly item: TypeDescriptor;
    readonly maxEntries: number;
    readonly ordering: "sorted-unique" | "sequence";
} | {
    readonly kind: "optional";
    readonly value: TypeDescriptor;
} | {
    readonly kind: "record";
    readonly name: string;
    readonly fields: readonly FieldDescriptor[];
} | {
    readonly kind: "union";
    readonly name: string;
    readonly discriminant: string;
    readonly variants: readonly {
        readonly tag: string;
        readonly type: TypeDescriptor;
    }[];
};
export declare const u8: TypeDescriptor;
export declare const u16: TypeDescriptor;
export declare const u32: TypeDescriptor;
export declare const u64: TypeDescriptor;
export declare const bool: TypeDescriptor;
export declare const fixedBytes: (length: number) => TypeDescriptor;
export declare const bytes32: TypeDescriptor;
export declare const bytes64: TypeDescriptor;
export declare const varBytes: (maxLength: number) => TypeDescriptor;
export declare const text: (maxBytes?: number) => TypeDescriptor;
export declare const enumOf: (name: string, values: readonly string[]) => TypeDescriptor;
export declare const array: (item: TypeDescriptor, maxEntries: number, ordering?: "sorted-unique" | "sequence") => TypeDescriptor;
export declare const optional: (value: TypeDescriptor) => TypeDescriptor;
export declare const record: (name: string, fields: readonly FieldDescriptor[]) => TypeDescriptor;
export declare const union: (name: string, discriminant: string, variants: readonly {
    readonly tag: string;
    readonly type: TypeDescriptor;
}[]) => TypeDescriptor;
export declare const bytesEqual: (left: Uint8Array, right: Uint8Array) => boolean;
/** The unique canonical encoding of `value` under `descriptor`. */
export declare const encodeCanonical: (descriptor: TypeDescriptor, value: unknown, path?: string) => Uint8Array;
/**
 * Decode exactly one canonical value. Trailing bytes, non-minimal encodings,
 * unknown enum/union tags, unsorted collections, and out-of-bound lengths are
 * rejected rather than repaired.
 */
export declare const decodeCanonical: (descriptor: TypeDescriptor, bytes: Uint8Array, path?: string) => unknown;
/**
 * Decode, then prove the result re-encodes to the exact input bytes. Callers
 * at a security boundary use this so a value that decodes but is not the
 * unique encoding of itself can never be accepted.
 */
export declare const decodeCanonicalStrict: (descriptor: TypeDescriptor, bytes: Uint8Array, path?: string) => unknown;
export declare const descriptorName: (descriptor: TypeDescriptor) => string;
/**
 * The exact field-name projection of a record descriptor, in wire order.
 *
 * Section 1.4 makes generated projections mandatory: a hand-maintained key
 * table that disagrees with the schema is a release failure. Consumers import
 * this instead of restating field names.
 */
export declare const recordFieldNames: (descriptor: TypeDescriptor) => readonly string[];
/**
 * The complete field list of a record descriptor.
 *
 * A signed wire type is its body plus a signature, so it reuses the body's
 * fields rather than restating them — the signature transcript is exactly the
 * body encoding, and a divergence between the two lists would be silent.
 */
export declare const recordFields: (descriptor: TypeDescriptor) => readonly FieldDescriptor[];
/** The descriptor of one named field of a record descriptor. */
export declare const recordFieldType: (descriptor: TypeDescriptor, fieldName: string) => TypeDescriptor;
/** The descriptor of one named variant of a union descriptor. */
export declare const unionVariantType: (descriptor: TypeDescriptor, tag: string) => TypeDescriptor;
/** The exact enum-value projection, in wire-byte order. */
export declare const enumValues: (descriptor: TypeDescriptor) => readonly string[];
/** The wire byte assigned to one enum member. */
export declare const enumByte: (descriptor: TypeDescriptor, value: string) => number;
