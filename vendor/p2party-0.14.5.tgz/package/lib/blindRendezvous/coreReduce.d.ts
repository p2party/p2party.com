/**
 * Deterministic outer-layer reduction (Section 4.7).
 *
 * `Merge` is set union and `CoreReduce` is a pure function of the validated
 * operation set, the immutable room policy, and an explicit reference window.
 * It reads no arrival timestamp, server identity, fetch order, frontend
 * allow/deny state, planner preference, wall clock, "first response" state,
 * pair secret, or inner pair validity — that exclusion list is the whole
 * reason two honest clients with the same delivered set derive byte-identical
 * state no matter which carrier delivered what, in which order.
 *
 * The reducer consumes only process-private results of the validation ingress.
 * It integrates payload facts only after arrival-independent author
 * fork/quota classification, then applies semantic-slot/dependency rules and
 * emits the exact CoreRoomStateV1 projections. Frontend admission, route
 * activation, planner preference, and pair plaintext remain outside this
 * room-wide state.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { AuthenticatedRoomOperationV1, OperationValidationContext } from "./operation";
import type { PresenceV1 } from "./operationPayload";
import type { PairStepEnvelopeV1 } from "./pairStepEnvelope";
import type { RoomPolicyV4 } from "./roomPolicyV4";
import type { StoreDescriptorV1, StoreRouteV1 } from "./storeDescriptor";
declare const outerValidatedIdentifiedOperationBrand: unique symbol;
declare const activePairOperationCandidateBrand: unique symbol;
/**
 * Process-local proof that one exact PAIR_STEP was active in one genuine
 * CoreReduce result. It intentionally exposes no structural fields.
 */
export interface ActivePairOperationCandidateV1 {
    readonly [activePairOperationCandidateBrand]: true;
}
export interface PairAuthorChainPrefixEvidenceV1 {
    readonly operationId: Uint8Array;
    readonly exactOperationBytes: Uint8Array;
}
export interface ActivePairOperationCandidateSnapshotV1 {
    readonly exactOperationBytes: Uint8Array;
    readonly operationId: Uint8Array;
    readonly operation: AuthenticatedRoomOperationV1;
    readonly envelope: PairStepEnvelopeV1;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly referenceWindow: bigint;
    readonly evidenceValidThroughWindow: bigint;
    readonly exactCoreStateBytes: Uint8Array;
    readonly authorChainPrefix: readonly PairAuthorChainPrefixEvidenceV1[];
}
declare const verifiedHistoricalPairPresenceBrand: unique symbol;
/**
 * Process-local proof that one exact signed PRESENCE was an observed roster
 * fact in a genuine CoreReduce result. Generic author-prefix evidence cannot
 * instantiate this capability.
 */
export interface VerifiedHistoricalPairPresenceEvidenceV1 {
    readonly [verifiedHistoricalPairPresenceBrand]: true;
}
/** Exact durable record defined by Section 4.9. */
export interface HistoricalPairPresenceEvidenceV1 {
    readonly exactPresenceOperationBytes: Uint8Array;
    readonly presenceOperationId: Uint8Array;
    readonly retainThroughLogicalWindow: bigint;
}
export interface VerifiedHistoricalPairPresenceSnapshotV1 extends HistoricalPairPresenceEvidenceV1 {
    readonly operation: AuthenticatedRoomOperationV1;
    readonly presence: PresenceV1;
    readonly provedAtLogicalWindow: bigint;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    readonly exactCoreStateBytes: Uint8Array;
    readonly authorChainPrefix: readonly PairAuthorChainPrefixEvidenceV1[];
}
/** One outer-authenticated candidate together with its private candidate ID. */
export interface OuterValidatedIdentifiedOperationV1 {
    readonly [outerValidatedIdentifiedOperationBrand]: true;
    readonly operationId: Uint8Array;
    readonly operation: AuthenticatedRoomOperationV1;
}
/**
 * The sole ingress from untrusted decoded bytes into the reducer domain.
 *
 * The caller-owned object is canonically snapshotted before the first await;
 * all validation and ID derivation use that private copy. OperationId is
 * derived only after complete outer validation, including PAIR_STEP slot
 * binding and the author signature. Non-pair nested signature work is
 * deliberately deferred until CoreReduce has classified author quota/forks.
 * The returned provenance brand is process-local and never persisted.
 */
export declare const validateAndIdentifyOperationCandidate: (operation: AuthenticatedRoomOperationV1, context: OperationValidationContext, module?: LibCrypto) => Promise<OuterValidatedIdentifiedOperationV1>;
/**
 * Capture one active, provenance-checked PAIR_STEP ingress.
 *
 * This is the only bridge from room-wide outer validation into pair opening.
 * It requires both the candidate and the room state to be live results of
 * their private validation/reduction entrypoints and rechecks their canonical
 * bytes on every call. Persisted bytes must therefore pass validation and
 * CoreReduce again after restart; a merely outer-valid future, forked,
 * overquota, expired, or dependency-inert candidate cannot spend pair-open
 * work or reach admission.
 *
 * The returned value is an opaque process-local capability. Pair-kernel code
 * accepts that capability, never a caller-assembled snapshot or prebinding.
 */
export declare const captureActivePairOperationCandidate: (candidate: OuterValidatedIdentifiedOperationV1, roomState: CoreRoomStateV1) => Promise<ActivePairOperationCandidateV1>;
/**
 * Take an owned pair-kernel snapshot from a genuine active-operation handle.
 *
 * The returned bytes are data, not provenance: downstream state machines must
 * continue accepting the opaque `ActivePairOperationCandidateV1` and call this
 * accessor themselves. Exact Core bytes are included for the later durable
 * compare-and-swap that prevents an asynchronous open from committing against
 * a superseded room view.
 */
export declare const snapshotActivePairOperationCandidate: (candidate: ActivePairOperationCandidateV1) => ActivePairOperationCandidateSnapshotV1;
/**
 * Capture one current roster fact for bounded pair-private use after that
 * presence leaves the live roster.
 *
 * Restore repeats operation validation and CoreReduce at the exact HELLO
 * logical window before calling this constructor. That equality is
 * load-bearing: a capability captured before an effective LEAVE cannot prove
 * a HELLO created at or after the leave. Exact signed bytes alone, a decoded
 * CoreRoomState, or generic author-prefix evidence are insufficient.
 */
export declare const captureHistoricalPairPresenceEvidence: (candidate: OuterValidatedIdentifiedOperationV1, roomState: CoreRoomStateV1, helloLogicalWindow: bigint) => Promise<VerifiedHistoricalPairPresenceEvidenceV1>;
/**
 * Return owned bytes from a genuine historical-presence capability.
 *
 * Downstream admission code accepts the opaque capability and calls this
 * accessor itself. The structural result is suitable for persistence only; it
 * cannot be passed back as proof after restart without validation and
 * CoreReduce reconstructing a new capability.
 */
export declare const snapshotHistoricalPairPresenceEvidence: (evidence: VerifiedHistoricalPairPresenceEvidenceV1) => VerifiedHistoricalPairPresenceSnapshotV1;
export type CoreFaultV1 = {
    readonly kind: "author-fork-or-overquota";
    readonly authorEpochEd25519Key: Uint8Array;
    readonly logicalWindow: bigint;
    readonly proofOperationIds: readonly Uint8Array[];
} | {
    readonly kind: "presence-or-leave-fork";
    readonly semanticSlot: Uint8Array;
    readonly proofOperationIds: readonly Uint8Array[];
} | {
    readonly kind: "store-generation-fork";
    readonly storeId: Uint8Array;
    readonly descriptorGeneration: bigint;
    readonly descriptorHashes: readonly [Uint8Array, Uint8Array];
};
export interface CorePresenceFactV1 {
    readonly presenceOperationId: Uint8Array;
    readonly authorEpochEd25519Key: Uint8Array;
    readonly logicalWindow: bigint;
    readonly presence: PresenceV1;
}
export interface CoreStoreFactV1 {
    readonly storeId: Uint8Array;
    readonly descriptorGeneration: bigint;
    readonly descriptorHash: Uint8Array;
    readonly sourceOperationId: Uint8Array;
    readonly descriptor: StoreDescriptorV1;
    readonly routes: readonly StoreRouteV1[];
    readonly hintValidThroughLogicalWindow: bigint;
}
export interface CoreRevocationFloorV1 {
    readonly stableIdentityCommitment: Uint8Array;
    readonly minimumAcceptedGeneration: bigint;
    readonly effectiveLogicalWindow: bigint;
    readonly validThroughLogicalWindow: bigint;
    readonly revokeOperationId: Uint8Array;
}
export interface CoreRoomStateV1 {
    readonly version: 1;
    readonly referenceWindow: bigint;
    readonly roomCapacityState: "within-policy" | "overcapacity";
    readonly activeOperationIds: readonly Uint8Array[];
    readonly observedPresences: readonly CorePresenceFactV1[];
    readonly effectiveLeaveOperationIds: readonly Uint8Array[];
    readonly storeCatalogFacts: readonly CoreStoreFactV1[];
    readonly revocationFloors: readonly CoreRevocationFloorV1[];
    readonly activePairOuterOperationIds: readonly Uint8Array[];
    readonly faults: readonly CoreFaultV1[];
    readonly operationsDigest: Uint8Array;
}
/** The unique canonical encoding of a reduced room state. */
export declare const encodeCoreRoomStateV1: (state: CoreRoomStateV1) => Promise<Uint8Array>;
/** Strictly decode one canonical reduced room state. */
export declare const decodeCoreRoomStateV1: (bytes: Uint8Array) => Promise<CoreRoomStateV1>;
export declare const mergeOperationCandidateSets: (left: readonly OuterValidatedIdentifiedOperationV1[], right: readonly OuterValidatedIdentifiedOperationV1[]) => OuterValidatedIdentifiedOperationV1[];
/**
 * Exact deterministic `CoreReduce`.
 *
 * Every decision is a function of privately snapshotted operation bytes and
 * one immutable room context/reference window. Fork and overquota
 * classification precedes payload reduction and is arrival-independent.
 */
export declare const coreReduce: (operations: readonly OuterValidatedIdentifiedOperationV1[], context: OperationValidationContext, module?: LibCrypto) => Promise<CoreRoomStateV1>;
export {};
