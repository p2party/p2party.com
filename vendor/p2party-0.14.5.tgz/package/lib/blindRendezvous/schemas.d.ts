/**
 * Canonical descriptors for the blind-rendezvous wire objects.
 *
 * These descriptors are the schema SSOT named in Section 1.4: they own field
 * order, integer widths, enum bytes, collection ordering, and bounds. Every
 * other module derives its encoder, decoder, key table, and bound check from
 * here rather than restating them.
 *
 * Field order below follows the specification's declaration order in Sections
 * 4.0 through 4.5. A TypeScript interface may list the same fields in a
 * different order for readability; interface order is not wire order.
 *
 * Status: PROPOSED, NOT FROZEN. Integer widths are this artifact's proposal
 * for the Phase-0 freeze, not published v0.4 release bytes.
 */
import type { TypeDescriptor } from "./canonicalSchema";
/** Section 4.4 operation payload classes: exact signed inner byte counts. */
export declare const OPERATION_PAYLOAD_CLASS_BYTES: Readonly<Record<0 | 1, number>>;
export declare const MAX_OPERATION_PAYLOAD_BYTES: number;
/** Absolute profile bound for one carried signed room operation. */
export declare const MAX_CARRIED_ROOM_OPERATION_BYTES_V1: number;
/** Section 4.11 suite-1 bootstrap KEM ciphertext width. */
export declare const PAIR_BOOTSTRAP_KEM_CIPHERTEXT_BYTES_V1: 1120;
/** Sections 4.9/4.11 suite-1 ML-KEM-768 + X25519 public-key width. */
export declare const RENDEZVOUS_HYBRID_KEM_PUBLIC_KEY_BYTES_V1: 1216;
/** Section 4.11: every currently defined pair step has zero or one dependency. */
export declare const MAX_PAIR_DEPENDENCIES_V1 = 1;
/**
 * The largest unique pair-padding suffix.
 *
 * An established class-1 plaintext is minimal only when its empty-padding
 * encoding is at least 4,018 bytes. Its target is 69,553 bytes, so the largest
 * possible canonical suffix is 69,553 - 4,018 = 65,535 bytes.
 */
export declare const MAX_PAIR_PADDING_BYTES_V1 = 65535;
/** Section 4.12 permits one through three transport candidates. */
export declare const MAX_PAIR_TRANSPORT_CANDIDATES_V1 = 3;
export declare const MAX_PAIR_WEBRTC_SDP_BYTES_V1 = 32768;
export declare const MAX_PAIR_LOCAL_CANDIDATE_BYTES_V1 = 2048;
/** Section 4.2 bounds one encrypted store hint to 255 exact routes. */
export declare const MAX_STORE_HINT_ROUTES_V1 = 255;
/** Section 4.8 bounds each frontend-owned canonical identity set. */
export declare const MAX_FRONTEND_ROOM_CONTROL_SET_ENTRIES_V1 = 65535;
/**
 * Leaves one 16-bit collection slot for the canonical quota+1 physical proof.
 */
export declare const MAX_OPERATIONS_PER_AUTHOR_WINDOW_V1 = 65534;
/** Section 4.0 closes the kernel at 8 modules and 9 entrypoints. */
export declare const KERNEL_MODULE_IDS: readonly [1, 2, 3, 4, 5, 6, 7, 8];
export declare const KERNEL_ENTRYPOINT_IDS: readonly [1, 2, 3, 4, 5, 6, 7, 8, 9];
/**
 * Section 4.0: modules 1..5 own entrypoints 1..5; module 6 owns the delivery
 * scheduler (6) and `R2Conforms` (7); module 7 owns the eventual pair-control
 * transition (8); module 8 owns claim evaluation (9).
 */
export declare const KERNEL_ENTRYPOINT_IDS_BY_MODULE: Readonly<Record<(typeof KERNEL_MODULE_IDS)[number], readonly number[]>>;
/** Section 4.0: a v0.4 release must carry FPO-001 through FPO-006. */
export declare const V04_REQUIRED_FORMAL_OBLIGATION_IDS: readonly [1, 2, 3, 4, 5, 6];
export declare const roomProtocolLimitsV1Schema: TypeDescriptor;
export declare const admissionFloorV4Schema: TypeDescriptor;
export declare const roomPolicyV4Schema: TypeDescriptor;
export declare const appendScheduleRoleV1Schema: TypeDescriptor;
export declare const appendScheduleEntryV1Schema: TypeDescriptor;
export declare const deliverySizeClassV1Schema: TypeDescriptor;
export declare const deliveryProfileV1Schema: TypeDescriptor;
export declare const operationKindV1Schema: TypeDescriptor;
export declare const operationLifetimeV1Schema: TypeDescriptor;
export declare const authenticatedRoomOperationUnsignedV1Schema: TypeDescriptor;
export declare const authenticatedRoomOperationV1Schema: TypeDescriptor;
export declare const pairBootstrapHeaderV1Schema: TypeDescriptor;
export declare const pairStepEnvelopeV1Schema: TypeDescriptor;
export declare const carrierEnvelopeV1Schema: TypeDescriptor;
export declare const carrierPlaintextV1Schema: TypeDescriptor;
/** The sorted duplicate-free operation-ID projection hashed by
 * `operationsDigest` and by the R2 required-operation digest. */
export declare const operationIdSetSchema: TypeDescriptor;
export declare const kernelEntrypointV1Schema: TypeDescriptor;
export declare const executableRendezvousKernelModuleV1Schema: TypeDescriptor;
export declare const executableRendezvousKernelManifestV1Schema: TypeDescriptor;
export declare const blindRendezvousImplementationBuildManifestV1Schema: TypeDescriptor;
export declare const claimEvaluationStateV1Schema: TypeDescriptor;
export declare const claimScopeKindV1Schema: TypeDescriptor;
export declare const claimAssumptionKindV1Schema: TypeDescriptor;
export declare const claimAssumptionVerificationV1Schema: TypeDescriptor;
export declare const claimAssumptionV1Schema: TypeDescriptor;
export declare const claimEvidenceKindV1Schema: TypeDescriptor;
export declare const claimWordingByStateV1Schema: TypeDescriptor;
export declare const claimDefinitionV1Schema: TypeDescriptor;
export declare const claimRegistryV1Schema: TypeDescriptor;
export declare const claimWordingEntryV1Schema: TypeDescriptor;
export declare const claimReasonEntryV1Schema: TypeDescriptor;
export declare const claimWordingCatalogV1Schema: TypeDescriptor;
export declare const claimEvidenceBindingV1Schema: TypeDescriptor;
export declare const claimPrerequisiteBindingV1Schema: TypeDescriptor;
export declare const claimFormalResultBindingV1Schema: TypeDescriptor;
export declare const claimAssumptionBindingV1Schema: TypeDescriptor;
export declare const claimEvaluationDatasetV1Schema: TypeDescriptor;
export declare const claimEvaluationInputV1Schema: TypeDescriptor;
export declare const claimEvaluationV1Schema: TypeDescriptor;
export declare const formalObligationKindV1Schema: TypeDescriptor;
export declare const formalObligationV1Schema: TypeDescriptor;
export declare const formalObligationRegistryV1Schema: TypeDescriptor;
export declare const formalProofScopeArtifactV1Schema: TypeDescriptor;
export declare const formalProofResultKindV1Schema: TypeDescriptor;
export declare const formalProofResultV1Schema: TypeDescriptor;
/** The resolved assumption sequence hashed by `FormalAssumptionSetHash`. */
export declare const resolvedAssumptionSetSchema: TypeDescriptor;
/** The normalized source-tree projection hashed by `KernelSourceTreeHash`. */
export declare const kernelSourceTreeEntrySchema: TypeDescriptor;
export declare const kernelSourceTreeSchema: TypeDescriptor;
/** The per-entrypoint projection hashed by `KernelModuleSemanticsHash`. */
export declare const kernelModuleSemanticsEntrySchema: TypeDescriptor;
export declare const kernelModuleSemanticsSchema: TypeDescriptor;
/** No room-derived value appears here: every room in a profile shares it. */
export declare const publicBucketV1Schema: TypeDescriptor;
export declare const publicChunkBodyV1Schema: TypeDescriptor;
export declare const publicChunkV1Schema: TypeDescriptor;
export declare const publicStoreCheckpointBodyV1Schema: TypeDescriptor;
export declare const publicStoreCheckpointV1Schema: TypeDescriptor;
export declare const publicCheckpointChunkLeafV1Schema: TypeDescriptor;
export declare const publicCheckpointChunkInclusionProofV1Schema: TypeDescriptor;
export declare const storeCheckpointChainStartV1Schema: TypeDescriptor;
export declare const storeDescriptorUnsignedV1Schema: TypeDescriptor;
export declare const storeDescriptorV1Schema: TypeDescriptor;
export declare const storeRouteUnsignedV1Schema: TypeDescriptor;
export declare const storeRouteV1Schema: TypeDescriptor;
export declare const canonicalBytes32SetV1Schema: TypeDescriptor;
export declare const initializedRoomAdmissionFenceV1Schema: TypeDescriptor;
export declare const localPresenceOwnershipV1Schema: TypeDescriptor;
export declare const authorityCustodyStatusV1Schema: TypeDescriptor;
export declare const authorityCustodyProjectionV1Schema: TypeDescriptor;
export declare const frontendRoomControlsV1Schema: TypeDescriptor;
export declare const bootstrapAdmissionDecisionLeaseV1Schema: TypeDescriptor;
export declare const admissionGrantUnsignedV1Schema: TypeDescriptor;
export declare const admissionGrantV1Schema: TypeDescriptor;
export declare const pairStepKindV1Schema: TypeDescriptor;
export declare const pairAttemptModeV1Schema: TypeDescriptor;
export declare const pairAttemptLeaseV1Schema: TypeDescriptor;
export declare const pairBootstrapRecipientKindV1Schema: TypeDescriptor;
export declare const pairTransportCandidateKindV1Schema: TypeDescriptor;
export declare const stableIdentityBundleV1Schema: TypeDescriptor;
export declare const pairIdentityHelloUnsignedV1Schema: TypeDescriptor;
export declare const pairIdentityHelloV1Schema: TypeDescriptor;
export declare const pairIdentityAcceptUnsignedV1Schema: TypeDescriptor;
export declare const pairIdentityAcceptV1Schema: TypeDescriptor;
export declare const stableEdgeAttemptClaimUnsignedV1Schema: TypeDescriptor;
export declare const stableEdgeAttemptClaimV1Schema: TypeDescriptor;
export declare const pairTransportCandidateV1Schema: TypeDescriptor;
export declare const pairTransportOfferV1Schema: TypeDescriptor;
export declare const pairTransportAnswerV1Schema: TypeDescriptor;
export declare const quiesceProposeV1Schema: TypeDescriptor;
export declare const quiesceAckV1Schema: TypeDescriptor;
export declare const healCompleteV1Schema: TypeDescriptor;
export declare const pairCheckpointV1Schema: TypeDescriptor;
export declare const pairStepBodyV1Schema: TypeDescriptor;
export declare const pairPlaintextV1Schema: TypeDescriptor;
export declare const pairIdentityUnsignedProjectionV1Schema: TypeDescriptor;
export declare const pairOuterPrebindingV1Schema: TypeDescriptor;
export declare const pairOuterBindingV1Schema: TypeDescriptor;
export declare const pairFlightSlotV1Schema: TypeDescriptor;
export declare const pairBootstrapRecipientBindingV1Schema: TypeDescriptor;
export declare const pairBootstrapInfoV1Schema: TypeDescriptor;
export declare const pairAcceptedSlotCoordinateV1Schema: TypeDescriptor;
export declare const pairAuthorChainPrefixEvidenceV1Schema: TypeDescriptor;
export declare const identityHelloHistoricalPresenceEvidenceV1Schema: TypeDescriptor;
/**
 * Exact pair-subject evidence retained for one authenticated IDENTITY_HELLO.
 *
 * Endpoint order is protocol-visible: remote HELLO author first, local
 * responder second. The semantic codec requires exactly two entries.
 */
export declare const identityHelloHistoricalEvidenceBundleV1Schema: TypeDescriptor;
/**
 * Canonical post-authentication input. Its descriptor is shared by the live
 * transition and durable entry so neither path can drift in field order or
 * bounds.
 */
export declare const pairSlotAcceptanceCandidateV1Schema: TypeDescriptor;
export declare const pairAcceptedSlotEntryV1Schema: TypeDescriptor;
export declare const pairAcceptedSlotLedgerSnapshotV1Schema: TypeDescriptor;
export declare const pairOpenBudgetCoordinateV1Schema: TypeDescriptor;
export declare const pairOpenBudgetChargeV1Schema: TypeDescriptor;
export declare const pairOpenBudgetSnapshotV1Schema: TypeDescriptor;
export declare const admissionRevokeUnsignedV1Schema: TypeDescriptor;
export declare const admissionRevokeV1Schema: TypeDescriptor;
export declare const presenceCoreV1Schema: TypeDescriptor;
export declare const presencePermitUnsignedV1Schema: TypeDescriptor;
export declare const presencePermitV1Schema: TypeDescriptor;
export declare const presenceV1Schema: TypeDescriptor;
/**
 * Canonical input to `PresenceProofTranscriptHash`.
 *
 * The declaration order is protocol-visible. Keeping it in the schema SSOT
 * prevents an implementation from silently reordering the outer bindings.
 */
export declare const presenceProofTranscriptV1Schema: TypeDescriptor;
export declare const leaveV1Schema: TypeDescriptor;
export declare const storeHintOperationV1Schema: TypeDescriptor;
export declare const corePresenceFactV1Schema: TypeDescriptor;
export declare const coreStoreFactV1Schema: TypeDescriptor;
export declare const coreRevocationFloorV1Schema: TypeDescriptor;
export declare const authorityWindowFaultV1Schema: TypeDescriptor;
export declare const authorityAdmissionStatusV1Schema: TypeDescriptor;
/**
 * Exact canonical tuple hashed by AuthorityAdmissionStateDigest. It excludes
 * the reference window, whole-Core digest, custody digest source material,
 * and unrelated authority facts by construction.
 */
export declare const authorityAdmissionStateDigestInputV1Schema: TypeDescriptor;
/**
 * Variant order is the canonical fault order and therefore protocol-visible.
 * Reducer sorting derives its order from this descriptor.
 */
export declare const coreFaultV1Schema: TypeDescriptor;
export declare const roomCapacityStateV1Schema: TypeDescriptor;
export declare const coreRoomStateV1Schema: TypeDescriptor;
export declare const connectionPlannerModeV1Schema: TypeDescriptor;
export declare const connectionPlannerPolicyV1Schema: TypeDescriptor;
export declare const provisionalTopologyEdgeV1Schema: TypeDescriptor;
export declare const activeStableTopologyEdgeV1Schema: TypeDescriptor;
export declare const plannerAndExplicitStateV1Schema: TypeDescriptor;
