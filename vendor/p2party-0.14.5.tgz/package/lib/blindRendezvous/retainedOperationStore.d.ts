/**
 * Exact local persistence boundary for retained blind-rendezvous operations.
 *
 * This is a local storage schema, not a wire format and not part of the
 * normative release registry. It preserves the exact canonical operation
 * bytes needed by the existing operation validator and CoreReduce after a
 * restart; it deliberately performs neither of those protocol validations.
 *
 * One immutable content row stores each exact operation once per room. A
 * per-room/window manifest names the complete sorted unique room-wide row set
 * visible at that historical decision boundary and fences its physical
 * count/bytes. This intentionally simple representation makes omission and
 * overcapacity explicit. A later database adapter may change its physical
 * layout without changing this source-internal contract.
 */
export type RetainedOperationManifestCompletenessV1 = "complete" | "incomplete-overcapacity";
/**
 * Canonical local manifest for one room/window historical replay fence.
 *
 * `operationIds` names the complete room-wide unique retained-operation set,
 * not an endpoint subset and not a decoded Core projection. Therefore the
 * byte total charges a shared content row once regardless of how many window
 * manifests reference it.
 */
export interface RetainedOperationWindowManifestV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly referenceWindow: bigint;
    readonly retainThroughLogicalWindow: bigint;
    readonly completeness: RetainedOperationManifestCompletenessV1;
    readonly operationIds: readonly Uint8Array[];
    readonly retainedOperationCount: number;
    readonly retainedOperationBytes: bigint;
    readonly maxRetainedValidOperationsPerRoom: number;
    readonly maxRetainedValidOperationBytesPerRoom: bigint;
    /** The first unique row rejected at the public capacity boundary. */
    readonly firstRejectedOperationId: Uint8Array | null;
}
/**
 * Immutable content-addressed row. Room membership is supplied only by the
 * trusted outer-validation/store transition; this module can prove the
 * OperationId/bytes relation but cannot infer RoomContextId from an operation.
 */
export interface RetainedOperationContentRowV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly operationId: Uint8Array;
    readonly exactOperationBytes: Uint8Array;
}
export interface RetainedOperationWindowLocatorV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly referenceWindow: bigint;
}
/** Exact absence is replay-unavailable, never an empty complete manifest. */
export type ExactRetainedOperationManifestRowV1 = {
    readonly kind: "absent";
} | {
    readonly kind: "present";
    readonly exactManifestBytes: Uint8Array;
    /** Non-reused adapter revision used to prevent ABA. */
    readonly recordRevision: bigint;
};
/**
 * Exact rows copied by one future read-only transaction.
 *
 * For a present manifest, `operations` must contain exactly one row for every
 * named ID and no other row. Missing rows are represented by omission and fail
 * validation; an absent manifest must have an empty row list.
 */
export interface RetainedOperationWindowExactCaptureV1 {
    readonly manifest: ExactRetainedOperationManifestRowV1;
    readonly operations: readonly RetainedOperationContentRowV1[];
}
export type ValidatedRetainedOperationWindowCaptureV1 = {
    readonly kind: "unavailable";
} | {
    readonly kind: "available";
    readonly exactManifestRow: Extract<ExactRetainedOperationManifestRowV1, {
        readonly kind: "present";
    }>;
    readonly manifest: RetainedOperationWindowManifestV1;
    readonly operations: readonly RetainedOperationContentRowV1[];
};
export interface InitializeRetainedOperationWindowOptionsV1 {
    readonly roomContextId: Uint8Array;
    readonly referenceWindow: bigint;
    readonly retainThroughLogicalWindow: bigint;
    readonly maxRetainedValidOperationsPerRoom: number;
    readonly maxRetainedValidOperationBytesPerRoom: bigint;
}
export type PreparedRetainedOperationStoreMutationV1 = {
    readonly kind: "initialize-window";
    readonly exactNextManifestBytes: Uint8Array;
} | {
    readonly kind: "insert-operation-and-replace-manifest";
    readonly operation: RetainedOperationContentRowV1;
    readonly exactNextManifestBytes: Uint8Array;
} | {
    readonly kind: "mark-incomplete-overcapacity";
    readonly firstRejectedOperationId: Uint8Array;
    readonly exactNextManifestBytes: Uint8Array;
};
/**
 * Closed future CAS request. The adapter compares the exact manifest
 * bytes/revision and every expected content row before applying the mutation.
 * Admission mutations additionally require the candidate content key to be
 * absent; finding it without the matching manifest is a conflict/corruption,
 * not an invitation to repair state heuristically.
 */
export interface RetainedOperationStoreCasRequestV1 {
    readonly version: 1;
    readonly locator: RetainedOperationWindowLocatorV1;
    readonly expected: RetainedOperationWindowExactCaptureV1;
    readonly candidateOperationId: Uint8Array | null;
    readonly mutation: PreparedRetainedOperationStoreMutationV1;
}
export type RetainedOperationStoreCasResultV1 = {
    readonly status: "committed";
    readonly exactManifestRow: Extract<ExactRetainedOperationManifestRowV1, {
        readonly kind: "present";
    }>;
} | {
    readonly status: "conflict";
    readonly fence: "manifest" | "operation";
};
/**
 * Source-internal byte-store port for the later IndexedDB adapter.
 *
 * `readExactWindowCapture` must own all returned buffers and resolve only
 * after its read transaction completes. `compareAndSwap` performs no crypto
 * and awaits no promise while its write transaction is live.
 *
 * @internal
 */
export interface RetainedOperationStorePortV1 {
    readExactWindowCapture(locator: RetainedOperationWindowLocatorV1): Promise<RetainedOperationWindowExactCaptureV1>;
    compareAndSwap(request: RetainedOperationStoreCasRequestV1): Promise<RetainedOperationStoreCasResultV1>;
}
export type RetainedOperationAdmissionPlanV1 = {
    readonly kind: "unavailable";
} | {
    readonly kind: "duplicate";
} | {
    readonly kind: "sticky-incomplete-overcapacity";
    readonly firstRejectedOperationId: Uint8Array;
} | {
    readonly kind: "accept-operation";
    readonly request: RetainedOperationStoreCasRequestV1;
} | {
    readonly kind: "mark-incomplete-overcapacity";
    readonly request: RetainedOperationStoreCasRequestV1;
};
export declare class RetainedOperationStoreError extends Error {
    readonly name = "RetainedOperationStoreError";
    constructor(message: string);
}
/**
 * Encode one strict local manifest. The descriptor is intentionally not
 * exported and the bytes carry no interoperability or protocol provenance.
 */
export declare const encodeRetainedOperationWindowManifestV1: (value: RetainedOperationWindowManifestV1) => Uint8Array;
/** Decode, own, and semantically validate one exact local manifest. */
export declare const decodeRetainedOperationWindowManifestV1: (exactBytes: Uint8Array) => RetainedOperationWindowManifestV1;
/**
 * Own one content row and prove only its canonical bytes/OperationId
 * association. This is not signature, room, policy, temporal, or Core
 * validation.
 */
export declare const validateAndCopyRetainedOperationContentRowV1: (value: unknown) => Promise<RetainedOperationContentRowV1>;
export declare const validateAndCopyRetainedOperationWindowExactCaptureV1: (value: unknown) => Promise<ValidatedRetainedOperationWindowCaptureV1>;
/**
 * Explicitly prepare a new empty complete window. This is the only path that
 * turns expected absence into a manifest; replay reads never infer that an
 * absent row means an empty room.
 */
export declare const prepareRetainedOperationWindowInitializationV1: (value: unknown) => RetainedOperationStoreCasRequestV1;
/**
 * Plan one deterministic retained-operation admission.
 *
 * The input capture is fully correlated before a candidate can affect state.
 * Duplicate exact rows have zero resource delta. Once a manifest is
 * incomplete, normal admission never parses a candidate or repairs/replaces
 * the first-rejected witness; only a separate future full reconciliation may
 * create a new complete manifest after capacity changes.
 */
export declare const planRetainedOperationAdmissionV1: (captureValue: unknown, candidateValue: unknown) => Promise<RetainedOperationAdmissionPlanV1>;
