/**
 * Constants-only registry for the complete pair-bootstrap suite selected by
 * RoomPolicyV4 and encoded in PairBootstrapHeaderV1.
 *
 * This is the ID-to-cryptography SSOT. Schema geometry, policy validation,
 * HPKE bootstrap, and established pair flights must project from this object
 * rather than independently assigning meaning to suite ID 1.
 */
export declare const PAIR_BOOTSTRAP_SUITE_ID_V1 = 1;
export declare const PAIR_BOOTSTRAP_SUITE_V1: Readonly<{
    readonly id: 1;
    readonly hybridKem: Readonly<{
        readonly standardName: "MLKEM768-X25519";
        readonly specification: "draft-irtf-cfrg-concrete-hybrid-kems-04";
        readonly seedBytes: 32;
        readonly publicKeyBytes: 1216;
        readonly secretKeyBytes: 32;
        readonly ciphertextBytes: 1120;
        readonly sharedSecretBytes: 32;
        readonly randomnessBytes: 64;
    }>;
    readonly hpke: Readonly<{
        readonly specification: Readonly<{
            kem: "draft-ietf-hpke-pq-05";
            kemKeyDerivation: "draft-ietf-hpke-hpke-03";
            keySchedule: "RFC 9180";
        }>;
        readonly kemId: 25722;
        readonly kdfId: 1;
        readonly aeadId: 3;
        readonly publicKeyBytes: 1216;
        readonly secretKeyBytes: 32;
        readonly encapsulatedKeyBytes: 1120;
        readonly sharedSecretBytes: 32;
        readonly keyBytes: 32;
        readonly nonceBytes: 12;
        readonly tagBytes: 16;
        readonly pskBytes: 32;
        readonly pskIdBytes: 32;
    }>;
    readonly establishedPairAead: Readonly<{
        standardName: "XChaCha20-Poly1305-IETF";
        kdfId: 1;
        keyBytes: number;
        nonceBytes: number;
        tagBytes: number;
    }>;
    readonly routingTagBytes: 32;
}>;
export declare const PAIR_BOOTSTRAP_SUITES_BY_ID: Readonly<{
    readonly 1: Readonly<{
        readonly id: 1;
        readonly hybridKem: Readonly<{
            readonly standardName: "MLKEM768-X25519";
            readonly specification: "draft-irtf-cfrg-concrete-hybrid-kems-04";
            readonly seedBytes: 32;
            readonly publicKeyBytes: 1216;
            readonly secretKeyBytes: 32;
            readonly ciphertextBytes: 1120;
            readonly sharedSecretBytes: 32;
            readonly randomnessBytes: 64;
        }>;
        readonly hpke: Readonly<{
            readonly specification: Readonly<{
                kem: "draft-ietf-hpke-pq-05";
                kemKeyDerivation: "draft-ietf-hpke-hpke-03";
                keySchedule: "RFC 9180";
            }>;
            readonly kemId: 25722;
            readonly kdfId: 1;
            readonly aeadId: 3;
            readonly publicKeyBytes: 1216;
            readonly secretKeyBytes: 32;
            readonly encapsulatedKeyBytes: 1120;
            readonly sharedSecretBytes: 32;
            readonly keyBytes: 32;
            readonly nonceBytes: 12;
            readonly tagBytes: 16;
            readonly pskBytes: 32;
            readonly pskIdBytes: 32;
        }>;
        readonly establishedPairAead: Readonly<{
            standardName: "XChaCha20-Poly1305-IETF";
            kdfId: 1;
            keyBytes: number;
            nonceBytes: number;
            tagBytes: number;
        }>;
        readonly routingTagBytes: 32;
    }>;
}>;
export type PairBootstrapSuiteIdV1 = keyof typeof PAIR_BOOTSTRAP_SUITES_BY_ID;
export declare const getPairBootstrapSuite: (suiteId: number) => typeof PAIR_BOOTSTRAP_SUITE_V1;
