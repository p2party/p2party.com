/**
 * Reservation-gated identity HELLO opener.
 *
 * This module is the sole current path from a committed pair-open reservation
 * to HPKE work. It derives every transcript input from opaque trial
 * provenance, authenticates the complete HELLO identity bundle, and retains
 * HelloRoot only inside an opaque process-local result.
 *
 * The only next-state transition consumes the open into an opaque admission
 * claim while leaving HelloRoot in this module's private custody.
 * Pair-ledger persistence, ACCEPT construction, and any release of HelloRoot
 * remain deliberately out of scope. This module is absent from the package
 * barrel.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { ActivePairOperationCandidateSnapshotV1, VerifiedHistoricalPairPresenceSnapshotV1 } from "./coreReduce";
import type { ExpectedIdentityHelloTrialV1, LocalHelloReceiverCustodySnapshotV1 } from "./identityHelloTrial";
import type { PairAttemptLeaseV1 } from "./admissionPolicy";
import type { AdmissionGrantV1 } from "./operationPayload";
import type { PairOuterBindingV1, PairPlaintextV1 } from "./pairPlaintext";
import type { ReservedIdentityHelloOpenV1 } from "./pairOpenReservation";
import type { RoomPolicyV4 } from "./roomPolicyV4";
declare const verifiedIdentityHelloOpenBrand: unique symbol;
declare const identityHelloAdmissionClaimBrand: unique symbol;
declare const consumedIdentityHelloAdmissionClaimBrand: unique symbol;
/** Opaque authenticated HELLO result. HelloRoot is never structurally exposed. */
export interface VerifiedIdentityHelloOpenV1 {
    readonly [verifiedIdentityHelloOpenBrand]: true;
}
/**
 * Process-local claim on one authenticated HELLO and its root custody.
 *
 * This is deliberately not `VerifiedAdmissionContextV1`: that fact may only
 * be minted after the admission boundary has atomically captured and
 * correlated every trusted state fence. This internal type is absent from the
 * package barrel and never exposes HelloRoot.
 */
export interface IdentityHelloAdmissionClaimV1 {
    readonly [identityHelloAdmissionClaimBrand]: true;
}
/**
 * Internal one-use transfer of an admission claim into asynchronous
 * verification custody. It exposes no fields and retains the same private
 * HelloRoot allocation; no secret is copied across this transition.
 */
export interface ConsumedIdentityHelloAdmissionClaimV1 {
    readonly [consumedIdentityHelloAdmissionClaimBrand]: true;
}
export interface IdentityHelloAdmissionClaimSnapshotV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly roomPolicy: RoomPolicyV4;
    /** Current-Core fence at the successful open; a later capture may advance. */
    readonly exactOpenedCoreStateBytes: Uint8Array;
    /** Exact HELLO-time Core row selecting the complete evidence bundle. */
    readonly exactHistoricalEvidenceCoreStateBytes: Uint8Array;
    /** Canonical Core + remote/local PRESENCE + author-prefix evidence. */
    readonly exactHistoricalEvidenceBundleBytes: Uint8Array;
    readonly openedAtReferenceWindow: bigint;
    readonly receiverKeyRecordRevision: bigint;
    readonly localIdentityKeyRecordRevision: bigint;
    readonly localStableEd25519PublicKey: Uint8Array;
    readonly decisionRole: "hello-responder";
    readonly operationId: Uint8Array;
    readonly kind: "IDENTITY_HELLO";
    readonly logicalWindow: bigint;
    readonly validThroughLogicalWindow: bigint;
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly direction: 0;
    readonly pairSequence: 0n;
    readonly previousPairOperationId: null;
    readonly pairDependencies: readonly [];
    readonly stableEd25519PublicKey: Uint8Array;
    readonly claimedStableIdentityCommitment: Uint8Array;
    readonly optionalGrant: AdmissionGrantV1 | null;
    readonly pairIdentitySignatureHash: Uint8Array;
    readonly admittedPresenceOperationId: Uint8Array;
    readonly admittedPresenceEvidenceRetainThroughLogicalWindow: bigint;
    readonly basePairAttemptLease: PairAttemptLeaseV1;
}
export interface VerifiedIdentityHelloOpenSnapshotV1 {
    readonly version: 1;
    readonly helloOperationId: Uint8Array;
    readonly activeCandidate: ActivePairOperationCandidateSnapshotV1;
    readonly pairOuterBinding: PairOuterBindingV1;
    readonly plaintext: PairPlaintextV1;
    readonly localPresenceEvidence: VerifiedHistoricalPairPresenceSnapshotV1;
    readonly remotePresenceEvidence: VerifiedHistoricalPairPresenceSnapshotV1;
    readonly pairIdentitySignatureHash: Uint8Array;
    /**
     * Pre-admission base lease. Sole Admit may validate a carried grant, narrow
     * this horizon, and persist the result atomically; this opener may not.
     */
    readonly basePairAttemptLease: PairAttemptLeaseV1;
    readonly trialOrdinal: number;
    readonly receiverKeyRecordRevision: bigint;
    readonly localIdentityKeyRecordRevision: bigint;
    readonly localStableEd25519PublicKey: Uint8Array;
}
export type OpenReservedIdentityHelloResultV1 = {
    readonly kind: "opened";
    readonly value: VerifiedIdentityHelloOpenV1;
} | {
    readonly kind: "not-this-trial";
} | {
    readonly kind: "rejected";
} | {
    readonly kind: "deferred";
    readonly reason: "missing-presence-evidence";
};
export declare class IdentityHelloOpenError extends Error {
    readonly name = "IdentityHelloOpenError";
    constructor(message: string);
}
/**
 * Consume one committed reservation and try its exact expected HELLO trial.
 *
 * Reservation and trial consumption happen synchronously before the first
 * await. `not-this-trial` means the routing tag or HPKE authentication did not
 * match. `rejected` means authenticated bytes failed the closed HELLO identity
 * gate. Provenance, programming, storage, or cryptographic infrastructure
 * failures throw.
 */
export declare const openReservedIdentityHelloV1: (capability: ReservedIdentityHelloOpenV1, trial: ExpectedIdentityHelloTrialV1, module: LibCrypto) => Promise<OpenReservedIdentityHelloResultV1>;
/** Return a fresh deeply owned snapshot containing no HelloRoot. */
export declare const snapshotVerifiedIdentityHelloOpenV1: (value: VerifiedIdentityHelloOpenV1) => VerifiedIdentityHelloOpenSnapshotV1;
/**
 * Consume one authenticated HELLO into the only admission-claim handle.
 *
 * The transition is synchronous and moves, rather than copies, the private
 * state. The old handle becomes unusable before control returns, and no root
 * bytes cross the API.
 */
export declare const takeVerifiedIdentityHelloOpenForAdmissionV1: (value: VerifiedIdentityHelloOpenV1) => IdentityHelloAdmissionClaimV1;
/** @internal Fresh deeply owned claim projection containing no HelloRoot. */
export declare const snapshotIdentityHelloAdmissionClaimV1: (value: IdentityHelloAdmissionClaimV1) => IdentityHelloAdmissionClaimSnapshotV1;
/**
 * Synchronously spend one admission claim into in-flight verification custody.
 *
 * The source entry is deleted before return, so reentrancy and concurrent
 * verification cannot reuse it. The private state and HelloRoot allocation are
 * moved without copying. A minting failure wipes the transferred root.
 *
 * @internal
 */
export declare const takeIdentityHelloAdmissionClaimForVerificationV1: (value: IdentityHelloAdmissionClaimV1) => ConsumedIdentityHelloAdmissionClaimV1;
/** @internal Fresh owned non-secret projection of one live consumed claim. */
export declare const snapshotConsumedIdentityHelloAdmissionClaimV1: (value: ConsumedIdentityHelloAdmissionClaimV1) => IdentityHelloAdmissionClaimSnapshotV1;
/**
 * Assert and project the exact live receiver/stable custody carried through
 * the authenticated HELLO transition.
 *
 * This internal accessor returns no capability or secret. Its only caller is
 * the admission capture verifier, which compares both persisted revisions and
 * the captured local-ownership row before minting trusted policy context.
 *
 * @internal
 */
export declare const snapshotConsumedIdentityHelloAdmissionLocalCustodyV1: (value: ConsumedIdentityHelloAdmissionClaimV1) => LocalHelloReceiverCustodySnapshotV1;
/** Wipe in-flight HelloRoot custody. Idempotent for a genuine handle. */
export declare const destroyConsumedIdentityHelloAdmissionClaimV1: (value: ConsumedIdentityHelloAdmissionClaimV1) => void;
/** Wipe the retained HelloRoot. Idempotent for a genuine claim handle. */
export declare const destroyIdentityHelloAdmissionClaimV1: (value: IdentityHelloAdmissionClaimV1) => void;
/** Wipe the retained HelloRoot. Idempotent for a genuine handle. */
export declare const destroyVerifiedIdentityHelloOpenV1: (value: VerifiedIdentityHelloOpenV1) => void;
export {};
