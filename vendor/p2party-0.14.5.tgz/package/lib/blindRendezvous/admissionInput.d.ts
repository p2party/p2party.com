/**
 * Closed error for malformed or fabricated inputs at the trusted admission
 * kernel boundary. Policy denials are ordinary result values and never use
 * this error.
 */
export declare class AdmissionInputError extends Error {
    readonly name = "AdmissionInputError";
    readonly code: "invalid-admission-kernel-input";
    constructor(message: string);
}
export declare const invalidAdmissionInput: (message: string) => never;
