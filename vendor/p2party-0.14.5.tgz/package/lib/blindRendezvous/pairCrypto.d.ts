/**
 * Pair-bootstrap HPKE and established-flight AEAD (Section 4.11).
 *
 * This module owns only cryptographic sealing/opening and exact transcript
 * binding. It deliberately does not own one-use routing-tag consumption,
 * predecessor/dependency state, identity/admission decisions, persistence, or
 * SDP dispatch. Those effectful gates consume this module's authenticated
 * output and must commit their state before exposing it to WebRTC.
 */
import type { LibCrypto } from "../cryptography/libcrypto";
import type { RoomPqMode } from "../roomPolicy";
import type { OperationPayloadClassV1 } from "./operation";
import type { PairBootstrapInfoV1, PairFlightSlotV1, PairOuterBindingV1, PairOuterPrebindingV1, PairPlaintextV1 } from "./pairPlaintext";
import type { PairStepEnvelopeV1 } from "./pairStepEnvelope";
export declare class PairCryptoError extends Error {
    readonly name: string;
    constructor(message: string);
}
/**
 * A bootstrap plaintext authenticated under one HPKE info value but carrying
 * another identity-flight kind. Recipients may classify this exact
 * peer-authenticated protocol fault without parsing an error message.
 */
export declare class PairBootstrapPlaintextKindError extends PairCryptoError {
    readonly name = "PairBootstrapPlaintextKindError";
    constructor();
}
export type PairBootstrapOuterFieldsV1 = Omit<PairOuterPrebindingV1, "bootstrapHeaderHash" | "nonce">;
export interface PairBootstrapSealOptionsV1 {
    readonly module: LibCrypto;
    readonly recipientHybridKemPublicKey: Uint8Array;
    /** RoomRoot for HELLO or the validated HelloRoot for ACCEPT. */
    readonly psk: Uint8Array;
    readonly bootstrapInfo: PairBootstrapInfoV1;
    readonly outerFields: PairBootstrapOuterFieldsV1;
    readonly roomPqMode: RoomPqMode;
    /**
     * Called only after the HPKE header, one-use tag, and exact outer binding
     * exist, allowing the stable identity signature to cover that binding.
     */
    readonly createSignedPlaintext: (binding: PairOuterBindingV1) => PairPlaintextV1 | Promise<PairPlaintextV1>;
}
export interface PairBootstrapSealResultV1 {
    readonly envelope: PairStepEnvelopeV1;
    readonly binding: PairOuterBindingV1;
    readonly plaintext: PairPlaintextV1;
    /**
     * HelloRoot or AcceptRoot. The caller owns these bytes and must wipe them
     * after deriving/persisting the next protected state.
     */
    readonly bootstrapRoot: Uint8Array;
}
/**
 * Seal one HELLO or ACCEPT. Normal encapsulation always uses the hybrid KEM's
 * CSPRNG path; deterministic conformance hooks are intentionally unreachable
 * from this protocol API.
 */
export declare const sealPairBootstrapV1: (options: PairBootstrapSealOptionsV1) => Promise<PairBootstrapSealResultV1>;
export interface PairBootstrapOpenOptionsV1 {
    readonly module: LibCrypto;
    readonly recipientHybridKemSecretKey: Uint8Array;
    readonly psk: Uint8Array;
    readonly bootstrapInfo: PairBootstrapInfoV1;
    readonly prebinding: PairOuterPrebindingV1;
    readonly envelope: PairStepEnvelopeV1;
    readonly operationPayloadClass: OperationPayloadClassV1;
    readonly roomPqMode: RoomPqMode;
    /**
     * The trusted pair-state layer verifies the stable transcript signature,
     * identity/commitment binding, exact presences, and state-owned slot before
     * the bootstrap root is released.
     */
    readonly validateAuthenticatedPlaintext: (binding: PairOuterBindingV1, plaintext: PairPlaintextV1) => void | Promise<void>;
}
export interface PairBootstrapOpenResultV1 {
    readonly binding: PairOuterBindingV1;
    readonly plaintext: PairPlaintextV1;
    readonly bootstrapRoot: Uint8Array;
}
/**
 * Try one budgeted HELLO/ACCEPT receiver key and expected info candidate.
 *
 * A routing-tag or HPKE authentication mismatch is `null` (not this
 * candidate). Authenticated noncanonical/invalid pair plaintext throws and
 * must be accounted as a rejected pair attempt by the caller.
 */
export declare const openPairBootstrapV1: (options: PairBootstrapOpenOptionsV1) => Promise<PairBootstrapOpenResultV1 | null>;
export interface SealPairStepOptionsV1 {
    readonly module: LibCrypto;
    /** EstablishedPairRoot before promotion, one-use PqSlotSecret afterwards. */
    readonly baseSecret: Uint8Array;
    readonly expectedSlot: PairFlightSlotV1;
    readonly prebinding: PairOuterPrebindingV1;
    readonly plaintext: PairPlaintextV1;
    readonly roomPqMode: RoomPqMode;
}
export interface SealPairStepResultV1 {
    readonly envelope: PairStepEnvelopeV1;
    readonly binding: PairOuterBindingV1;
    readonly plaintext: PairPlaintextV1;
}
/** Seal one non-HPKE pair flight under the exact suite-1 DRY construction. */
export declare const sealPairStepV1: (options: SealPairStepOptionsV1) => Promise<SealPairStepResultV1>;
export interface OpenPairStepOptionsV1 {
    readonly module: LibCrypto;
    readonly baseSecret: Uint8Array;
    /** One member of the closed candidate-slot set selected by pair state. */
    readonly expectedSlot: PairFlightSlotV1;
    readonly prebinding: PairOuterPrebindingV1;
    readonly envelope: PairStepEnvelopeV1;
    readonly operationPayloadClass: OperationPayloadClassV1;
    readonly roomPqMode: RoomPqMode;
}
export interface OpenPairStepResultV1 {
    readonly binding: PairOuterBindingV1;
    readonly plaintext: PairPlaintextV1;
}
/**
 * Try one state-selected established-flight slot. A tag/authentication
 * mismatch is `null`; authenticated slot/body/padding disagreement throws.
 */
export declare const openPairStepV1: (options: OpenPairStepOptionsV1) => Promise<OpenPairStepResultV1 | null>;
