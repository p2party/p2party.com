/**
 * Pure accepted-slot ledger for pair-private operations.
 *
 * This boundary starts only after pair opening has authenticated an operation
 * and checked its state-derived inner slot. Invalid tag/AEAD trials therefore
 * never consume a slot or routing tag here. Persistence, budgets, pair-machine
 * state, WebRTC effects, and response publication remain outside this module.
 *
 * The coordinate deliberately excludes `kind`: two authenticated kinds at
 * the same edge/endpoint/direction/sequence coordinate are a fork. Consumed
 * routing tags and retained fork-stall evidence are projections of entries,
 * never separately mutable state. The pair machine separately owns overall
 * edge status, including non-fork failures and causal expiry.
 */
import type { PairAuthorChainPrefixEvidenceV1 } from "./coreReduce";
import type { PairStepKindV1 } from "./pairPlaintext";
declare const pairAcceptedSlotLedgerBrand: unique symbol;
/** Process-local immutable ledger handle. Persist only its canonical snapshot. */
export interface PairAcceptedSlotLedgerV1 {
    readonly [pairAcceptedSlotLedgerBrand]: true;
}
export interface PairAcceptedSlotCoordinateV1 {
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly direction: 0 | 1;
    readonly pairSequence: bigint;
}
/**
 * Structural input for the post-authentication boundary.
 *
 * Production pair ingress must construct this only from its opaque successful
 * open result. This ledger owns and validates the shape but does not itself
 * prove pair AEAD, signatures, bindings, or operation-ID derivation.
 */
export interface PairSlotAcceptanceCandidateV1 {
    readonly coordinate: PairAcceptedSlotCoordinateV1;
    readonly kind: PairStepKindV1;
    readonly acceptedOperationId: Uint8Array;
    readonly exactOperationBytes: Uint8Array;
    readonly acceptedLogicalWindow: bigint;
    readonly retainThroughLogicalWindow: bigint;
    readonly routingTag: Uint8Array;
    readonly authorChainPrefix: readonly PairAuthorChainPrefixEvidenceV1[];
    readonly cachedExactResponse: Uint8Array | null;
}
export interface PairAcceptedSlotEntryV1 extends PairSlotAcceptanceCandidateV1 {
    readonly version: 1;
    /**
     * A null cached response is durable only for a locally denied
     * IDENTITY_HELLO or terminal PAIR_CHECKPOINT. The former still reserves its
     * authenticated slot so a later conflicting HELLO cannot win by arrival.
     */
    readonly cachedExactResponse: Uint8Array | null;
    /**
     * Bytewise-lowest two distinct authenticated IDs observed at this
     * coordinate. These are a bounded fork-evidence index; the validated outer
     * operation store remains the SSOT for the referenced signed bytes.
     */
    readonly forkProofOperationIds: readonly [Uint8Array, Uint8Array] | null;
}
/** Durable, deeply owned structural representation. */
export interface PairAcceptedSlotLedgerSnapshotV1 {
    readonly version: 1;
    readonly entries: readonly PairAcceptedSlotEntryV1[];
}
export type PairAcceptedSlotTransitionV1 = {
    readonly result: "accepted";
    readonly ledger: PairAcceptedSlotLedgerV1;
} | {
    readonly result: "replay";
    /** Exact cached bytes are freshly owned by this result. */
    readonly cachedExactResponse: Uint8Array | null;
    /** Replay is a no-op and preserves handle identity. */
    readonly ledger: PairAcceptedSlotLedgerV1;
} | {
    readonly result: "fork";
    readonly forkProofOperationIds: readonly [Uint8Array, Uint8Array];
    readonly ledger: PairAcceptedSlotLedgerV1;
} | {
    readonly result: "edge-stalled";
    readonly ledger: PairAcceptedSlotLedgerV1;
};
/**
 * Read-only classification at the authenticated pair-slot boundary.
 *
 * `unoccupied` is deliberately not called `accepted`: no durable entry or
 * fork proof exists until `recordAcceptedPairSlotV1` succeeds.
 */
export type AuthenticatedPairSlotPreviewV1 = {
    readonly result: "unoccupied";
} | {
    readonly result: "replay";
    /** Exact cached bytes are freshly owned by this result. */
    readonly cachedExactResponse: Uint8Array | null;
} | {
    readonly result: "fork";
    readonly forkProofOperationIds: readonly [Uint8Array, Uint8Array];
} | {
    readonly result: "edge-stalled";
};
export declare class PairLedgerError extends Error {
    readonly name = "PairLedgerError";
    constructor(message: string);
}
/** Create the unique empty ledger value. */
export declare const createEmptyPairAcceptedSlotLedgerV1: () => PairAcceptedSlotLedgerV1;
/** Deep-copy the complete state for the durable transaction adapter. */
export declare const snapshotPairAcceptedSlotLedgerV1: (ledger: PairAcceptedSlotLedgerV1) => PairAcceptedSlotLedgerSnapshotV1;
/** Canonical durable bytes for one genuine process-local ledger. */
export declare const encodePairAcceptedSlotLedgerV1: (ledger: PairAcceptedSlotLedgerV1) => Uint8Array;
/**
 * Strict structural reconstruction boundary.
 *
 * This restores ledger shape and invariants, not cryptographic provenance.
 * The durable pair transaction must revalidate exact accepted operation bytes
 * and pair state before using a restored ledger for protocol effects.
 */
export declare const restorePairAcceptedSlotLedgerV1: (snapshotValue: unknown) => PairAcceptedSlotLedgerV1;
/**
 * Strict canonical durable-byte reconstruction.
 *
 * This restores structural ledger invariants only. The trusted pair
 * transaction must still revalidate the retained signed operation bytes
 * before the restored handle can authorize protocol effects.
 */
export declare const decodePairAcceptedSlotLedgerV1: (encoded: Uint8Array) => PairAcceptedSlotLedgerV1;
/**
 * Classify one fully authenticated candidate without creating any durable
 * entry, fork proof, consumed-tag projection, or replacement ledger handle.
 *
 * A new IDENTITY_HELLO may be previewed with a null cached response so the
 * caller can run admission and construct that response. The subsequent record
 * call revalidates the candidate and requires the exact response atomically.
 */
export declare const previewAuthenticatedPairSlotV1: (ledger: PairAcceptedSlotLedgerV1, candidateValue: PairSlotAcceptanceCandidateV1) => AuthenticatedPairSlotPreviewV1;
export declare const recordAcceptedPairSlotV1: (ledger: PairAcceptedSlotLedgerV1, candidateValue: PairSlotAcceptanceCandidateV1) => PairAcceptedSlotTransitionV1;
/**
 * Persist a stable-signature-valid HELLO that current local policy denies.
 *
 * Denial sends no sensitive response, so an exact replay remains a null
 * response. Reserving the authenticated slot is nevertheless load-bearing:
 * a later byte-different HELLO at the same coordinate is a fork rather than
 * an arrival-order winner. Only the trusted admission transaction may call
 * this after its sole policy kernel returns deny.
 */
export declare const recordDeniedIdentityHelloSlotV1: (ledger: PairAcceptedSlotLedgerV1, candidateValue: PairSlotAcceptanceCandidateV1) => PairAcceptedSlotTransitionV1;
/** True exactly while retained fork evidence stalls this edge. */
export declare const pairEdgeIsStalledV1: (ledger: PairAcceptedSlotLedgerV1, pairEdgeId: Uint8Array) => boolean;
/**
 * Canonical unique routing-tag projection. There is intentionally no
 * separately persisted consumed-tag collection.
 */
export declare const consumedPairRoutingTagsV1: (ledger: PairAcceptedSlotLedgerV1) => readonly Uint8Array[];
export {};
