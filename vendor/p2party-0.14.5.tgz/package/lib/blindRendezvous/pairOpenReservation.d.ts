/**
 * Effectful pair-open budget reservation boundary.
 *
 * The pure reducer in pairOpenBudget.ts describes the next durable row. This
 * module is the only bridge from that structural transition to permission for
 * one expensive identity-HELLO open: it derives every coordinate and fence
 * from opaque provenance, commits the exact row with one storage CAS, and only
 * then mints an object-identity capability.
 *
 * The storage adapter treats canonical rows as opaque bytes. An IndexedDB
 * implementation performs compare + optional replacement in one readwrite
 * transaction over the Core, receiver-key, and budget stores and resolves
 * "committed" only after `transaction.oncomplete`. No cryptography or other
 * promise is awaited while that transaction is live.
 */
import type { ActivePairOperationCandidateV1 } from "./coreReduce";
import type { ExpectedIdentityHelloTrialV1 } from "./identityHelloTrial";
import type { PairOpenBudgetLimitsV1 } from "./pairOpenBudget";
/** Storage subject shared by the Core, receiver-key, and budget lookups. */
export interface PairOpenBudgetSubjectV1 {
    readonly localRoomId: string;
    readonly localPresenceOperationId: Uint8Array;
}
/**
 * Exact durable budget-row state. `absent` is distinct from malformed, empty,
 * or deleted-and-recreated bytes.
 */
export type ExactPairOpenBudgetRowV1 = {
    readonly kind: "absent";
} | {
    readonly kind: "present";
    readonly exactBytes: Uint8Array;
};
export interface PairOpenReservationCasRequestV1 {
    readonly subject: PairOpenBudgetSubjectV1;
    /** Exact canonical Core bytes, not only `operationsDigest` or a revision. */
    readonly expectedExactCoreStateBytes: Uint8Array;
    /**
     * Exact canonical HELLO-time Core bytes identifying the complete retained
     * historical evidence view. This may intentionally differ from the current
     * Core fence for a delayed HELLO.
     *
     * The durable row selected by this fence owns the exact presence operations
     * and author prefixes for every observed presence in that Core view. An
     * adapter must conflict if the row or any of that complete evidence is no
     * longer retained.
     */
    readonly expectedExactEvidenceCoreStateBytes: Uint8Array;
    /**
     * Exact revision at the subject's receiver-key row. Revisions must never be
     * reused after replacement or retirement, so deletion cannot create ABA.
     */
    readonly expectedReceiverKeyRecordRevision: bigint;
    /** Exact prior bytes (or exact absence), never revision-only equality. */
    readonly expectedBudgetRow: ExactPairOpenBudgetRowV1;
    readonly budgetMutation: {
        /** A sticky saturated row is still fenced, but needs no rewrite. */
        readonly kind: "keep";
    } | {
        /** Canonical prepared or newly saturated replacement bytes. */
        readonly kind: "replace";
        readonly exactNextBytes: Uint8Array;
    };
}
export type PairOpenReservationCasResultV1 = {
    readonly status: "committed";
    /**
     * Exact row visible at commit. For `keep`, this is the prior row; for
     * `replace`, this is the replacement. The service verifies this echo.
     */
    readonly exactBudgetRowBytes: Uint8Array;
} | {
    readonly status: "conflict";
    /**
     * Adapters compare in this order: current Core, historical evidence
     * view, receiver key, then budget row. The first mismatch determines
     * this closed result.
     */
    readonly fence: "core" | "historical-evidence" | "receiver-key" | "budget";
};
/**
 * Minimal byte-store port. Implementations own all input before retaining it
 * and return fresh bytes; this module additionally snapshots every boundary.
 */
export interface PairOpenReservationStorePortV1 {
    /**
     * Read the one current budget row for this room/presence subject. This read
     * need not share a transaction with the later CAS: the exact returned bytes
     * become the CAS fence.
     */
    readExactBudgetRow(subject: PairOpenBudgetSubjectV1): Promise<ExactPairOpenBudgetRowV1>;
    /**
     * In one atomic transaction, compare exact current Core bytes, the complete
     * exact historical-evidence view, receiver-key record revision, and exact
     * budget row/absence, then apply the requested mutation.
     *
     * If physical budget keys include `budgetLogicalWindow`, a replacement that
     * advances the window deletes the old key and writes the new key in this
     * same transaction.
     */
    compareAndSwap(request: PairOpenReservationCasRequestV1): Promise<PairOpenReservationCasResultV1>;
}
declare const reservedIdentityHelloOpenBrand: unique symbol;
/**
 * One process-local permission for one already charged HELLO open.
 *
 * It intentionally exposes no structural fields. Spread, structured clone,
 * persistence, or a type assertion cannot reproduce its WeakMap provenance.
 */
export interface ReservedIdentityHelloOpenV1 {
    readonly [reservedIdentityHelloOpenBrand]: true;
}
export type ReserveIdentityHelloOpenResultV1 = {
    readonly kind: "reserved";
    readonly capability: ReservedIdentityHelloOpenV1;
} | {
    readonly kind: "saturated";
    readonly condition: "pair-control-DoS/stalled";
} | {
    readonly kind: "retry";
    readonly reason: "budget-conflict";
} | {
    readonly kind: "stale";
    readonly reason: "core-changed" | "historical-evidence-changed" | "receiver-key-changed";
};
export interface PairOpenReservationServiceV1 {
    /**
     * Perform one read/reduce/CAS attempt. Budget contention is returned to the
     * deterministic pair scheduler; this method never spins or reorders trials.
     */
    reserveIdentityHelloOpen(candidate: ActivePairOperationCandidateV1, trial: ExpectedIdentityHelloTrialV1): Promise<ReserveIdentityHelloOpenResultV1>;
}
export declare class PairOpenReservationError extends Error {
    readonly name = "PairOpenReservationError";
    constructor(message: string);
}
/**
 * Create the trusted effectful boundary around one concrete storage adapter.
 *
 * The adapter and validated local resource policy are captured once; callers
 * cannot supply a transition, charge, coordinate, fence, or commit result per
 * trial.
 */
export declare const createPairOpenReservationServiceV1: (port: PairOpenReservationStorePortV1, limits: PairOpenBudgetLimitsV1) => PairOpenReservationServiceV1;
/**
 * Consume one exact reservation before any trial-secret transfer or KEM work.
 *
 * Deletion is synchronous and precedes return, so reentrancy and a second
 * attempt cannot reuse the capability. The returned value is the opaque
 * candidate privately stored at reservation time; the gated trial-secret
 * transfer compares it to the candidate sealed inside the trial. No
 * structural transition or secret-bearing snapshot is returned.
 *
 * @internal
 */
export declare const consumeReservedIdentityHelloOpenV1: (capability: ReservedIdentityHelloOpenV1, trial: ExpectedIdentityHelloTrialV1) => ActivePairOperationCandidateV1;
export {};
