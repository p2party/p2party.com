/**
 * `RoomPolicyV4`: the immutable security semantics of a blind room.
 *
 * Section 4.1 keeps delivery profiles, stores, routes, planner preferences,
 * and local frontend controls out of this object: it is hashed into
 * `RoomContextId`, so anything that can change without creating a different
 * room must live elsewhere.
 *
 * The existing 32-byte `RoomPolicyV1` session policy is nested by value, not
 * copied field by field, so `authMode`, `pqMode`, `rendezvousMode`, and the
 * cover schedule keep exactly one encoder and one source of truth.
 */
import { PAIR_BOOTSTRAP_SUITE_ID_V1 } from "./pairBootstrapSuite";
import type { RoomPolicyV1 } from "../roomPolicy";
export type AdmissionFloorV4 = {
    mode: "capability";
} | {
    mode: "authority-grant";
    authorityEd25519PublicKey: Uint8Array;
    maxAuthorityCredentialLifetimeWindows: number;
};
export interface RoomProtocolLimitsV1 {
    logicalWindowMs: bigint;
    maxClockSkewWindows: number;
    operationRetentionWindows: number;
    pairControlRetentionWindows: number;
    receiverKeyOverlapWindows: number;
    maxFutureLogicalWindows: number;
    maxDependenciesPerOperation: number;
    maxOperationsPerAuthorWindow: number;
}
export interface RoomPolicyV4 {
    version: 4;
    /** Exact `encodeRoomPolicyV1(...)` bytes. */
    sessionPolicyV1: Uint8Array;
    roomCryptoSuite: 1;
    operationCodec: 1;
    pairBootstrapSuite: typeof PAIR_BOOTSTRAP_SUITE_ID_V1;
    protocolLimits: RoomProtocolLimitsV1;
    admissionFloor: AdmissionFloorV4;
    maxRoomMembers: number;
}
export declare class RoomPolicyV4Error extends Error {
    readonly name = "RoomPolicyV4Error";
    constructor(message: string);
}
/**
 * Semantic validation beyond the canonical encoding's width checks.
 *
 * The schema already rejects out-of-range widths, unknown enum values, and
 * noncanonical encodings. This adds the Section 4.1 cross-field inequalities
 * and the nested-session-policy requirement, which no width check can express.
 */
export declare const validateRoomPolicyV4: (policy: RoomPolicyV4) => void;
/** The unique canonical encoding of a validated policy. */
export declare const encodeRoomPolicyV4: (policy: RoomPolicyV4) => Uint8Array;
/** Decode, prove the bytes are the unique encoding, then validate semantics. */
export declare const decodeRoomPolicyV4: (encoded: Uint8Array) => RoomPolicyV4;
export declare const roomPoliciesEqualV4: (left: RoomPolicyV4, right: RoomPolicyV4) => boolean;
/**
 * The nested session policy of the byte-frozen blind default: the existing
 * canonical v1 default (revision 0, no PIN, ML-KEM-768, immediate cover) with
 * only `rendezvousMode` changed to `blind-meeting-point`.
 *
 * Section 4.1 publishes these exact 32 bytes; `tests/blindRendezvous`
 * re-derives them from `encodeRoomPolicyV1` rather than trusting the literal.
 */
export declare const DEFAULT_BLIND_SESSION_POLICY_V1: Readonly<RoomPolicyV1>;
/**
 * The room policy a capability-only `v2.` invitation resolves to.
 *
 * Fixing this here rather than reading a mutable application default is the
 * point: a later default change must not reinterpret an already shared bare v2
 * invitation.
 *
 * Status: the field values are transcribed from Section 4.1, but the object's
 * canonical bytes and therefore its `PolicyHash` depend on the unfrozen
 * `canonicalSchema`. Neither is a published v0.4 release artifact yet.
 */
export declare const DEFAULT_BLIND_POLICY_V4_0: Readonly<RoomPolicyV4>;
/**
 * A fresh, independently owned copy of the blind default policy.
 *
 * `Object.freeze` does not protect the elements of a `Uint8Array`, and
 * `Object.freeze` on a non-empty typed array throws, so the only way to keep
 * `DEFAULT_BLIND_POLICY_V4_0` byte-frozen in practice is to never hand out a
 * reference to its `sessionPolicyV1` storage. Callers that resolve a bare v2
 * invitation get this copy.
 */
export declare const copyBlindDefaultPolicy: () => RoomPolicyV4;
