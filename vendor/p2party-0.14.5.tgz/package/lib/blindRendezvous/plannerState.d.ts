/**
 * Canonical local planner/topology persistence state.
 *
 * Core room reduction deliberately contains no local topology preference.
 * This module is the one local SSOT for planner policy, explicit requests,
 * provisional pair edges, and active stable edges. Counts are always derived
 * from canonical edge sets; there are no independently mutable counters.
 *
 * This module deliberately exposes no desired-neighbor or reservation
 * authority yet. That transition must consume an opaque result of the trusted
 * local `Project`, then compare-and-swap this exact captured row with every
 * other admission fence. Raw caller-supplied "selected" booleans are not a
 * planner proof.
 */
export type ConnectionPlannerModeV1 = "explicit" | "sparse-ring" | "full-mesh-small-room";
export interface ConnectionPlannerPolicyV1 {
    readonly version: 1;
    readonly mode: ConnectionPlannerModeV1;
    readonly sparseRadius: number;
    readonly maxProvisionalEdges: number;
    readonly maxActiveStableEdges: number;
    readonly fullMeshMaxMembers: number;
    readonly allowOnDemandEdges: boolean;
}
export interface ProvisionalTopologyEdgeV1 {
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly remoteLocalPeerId: string;
}
export interface ActiveStableTopologyEdgeV1 {
    readonly stableEdgeId: Uint8Array;
    readonly remoteLocalPeerId: string;
}
export interface PlannerAndExplicitStateV1 {
    readonly version: 1;
    readonly roomContextId: Uint8Array;
    readonly plannerPolicy: ConnectionPlannerPolicyV1;
    readonly requestedExplicitPeerIds: readonly string[];
    readonly provisionalEdges: readonly ProvisionalTopologyEdgeV1[];
    readonly activeStableEdges: readonly ActiveStableTopologyEdgeV1[];
}
export interface PlannerStateValidationLimitsV1 {
    readonly maxRoomMembers: number;
    readonly maxPairLedgerEntriesPerRoom: number;
}
export declare class PlannerStateError extends Error {
    readonly name = "PlannerStateError";
    constructor(message: string);
}
/** Strictly own and validate one complete planner/topology state. */
export declare const validateAndCopyPlannerAndExplicitStateV1: (value: unknown, limitsValue: PlannerStateValidationLimitsV1) => PlannerAndExplicitStateV1;
/** Canonical durable planner/topology bytes. */
export declare const encodePlannerAndExplicitStateV1: (value: unknown, limits: PlannerStateValidationLimitsV1) => Uint8Array;
/** Strictly restore and own one canonical durable planner/topology row. */
export declare const decodePlannerAndExplicitStateV1: (encoded: Uint8Array, limits: PlannerStateValidationLimitsV1) => PlannerAndExplicitStateV1;
/**
 * Prove every persisted provisional edge is bound to this exact room.
 *
 * All state and room bytes are owned before the first hash promise begins.
 */
export declare const assertPlannerStateRoomBindingV1: (stateValue: unknown, roomContextIdValue: Uint8Array, limits: PlannerStateValidationLimitsV1) => Promise<PlannerAndExplicitStateV1>;
