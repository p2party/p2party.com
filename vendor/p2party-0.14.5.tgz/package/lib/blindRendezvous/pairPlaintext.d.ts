/**
 * Canonical pair-private plaintext codec (Sections 4.11–4.13).
 *
 * This module begins only after pair AEAD has authenticated a candidate. It
 * owns the closed body union, initial direction/sequence/predecessor shapes,
 * candidate-ID ordering, and the unique class-sized all-zero padding suffix.
 * Pair secrets, HPKE, AEAD, admission, exact predecessor IDs, and durable fork
 * state deliberately remain outside this codec.
 *
 * Status: PROPOSED, NOT FROZEN. Release use still requires the Phase-0
 * canonical vectors and registry freeze named by the specification.
 */
import { PAIR_BOOTSTRAP_SUITE_ID_V1 } from "./pairBootstrapSuite";
import type { AdmissionGrantV1 } from "./operationPayload";
import type { OperationPayloadClassV1 } from "./operation";
import type { RoomPqMode } from "../roomPolicy";
export type PairStepKindV1 = "IDENTITY_HELLO" | "IDENTITY_ACCEPT" | "TRANSPORT_OFFER" | "TRANSPORT_ANSWER" | "V4_HANDSHAKE" | "PQ_CONTROL" | "QUIESCE_PROPOSE" | "QUIESCE_ACK" | "HEAL_COMPLETE" | "PAIR_CHECKPOINT";
export type PairAttemptModeV1 = "planner" | "explicit";
export interface StableIdentityBundleV1 {
    readonly ed25519PublicKey: Uint8Array;
    readonly x25519PublicKey: Uint8Array;
    readonly x25519CrossSignature: Uint8Array;
}
export interface PairIdentityHelloUnsignedV1 {
    readonly version: 1;
    readonly attemptMode: PairAttemptModeV1;
    readonly senderIdentity: StableIdentityBundleV1;
    readonly senderPresenceCommitment: Uint8Array;
    readonly senderAdmissionGrant: AdmissionGrantV1 | null;
    readonly responseHybridKemPublicKey: Uint8Array;
}
export interface PairIdentityHelloV1 extends PairIdentityHelloUnsignedV1 {
    readonly identityTranscriptSignature: Uint8Array;
}
export interface PairIdentityAcceptUnsignedV1 {
    readonly version: 1;
    readonly responderIdentity: StableIdentityBundleV1;
    readonly responderPresenceCommitment: Uint8Array;
    readonly responderAdmissionGrant: AdmissionGrantV1 | null;
}
export interface PairIdentityAcceptV1 extends PairIdentityAcceptUnsignedV1 {
    readonly identityTranscriptSignature: Uint8Array;
}
export interface StableEdgeAttemptClaimUnsignedV1 {
    readonly version: 1;
    readonly stableEdgeId: Uint8Array;
    readonly pairEdgeId: Uint8Array;
    readonly confirmedPairTranscriptId: Uint8Array;
    readonly claimantStableEd25519PublicKey: Uint8Array;
    readonly claimNotBeforeLogicalWindow: bigint;
    readonly claimNotAfterLogicalWindow: bigint;
}
export interface StableEdgeAttemptClaimV1 extends StableEdgeAttemptClaimUnsignedV1 {
    readonly claimantSignature: Uint8Array;
}
export type PairTransportCandidateV1 = {
    readonly version: 1;
    readonly kind: "webrtc-complete";
    readonly exactSdpUtf8: Uint8Array;
} | {
    readonly version: 1;
    readonly kind: "operation-carrier";
} | {
    readonly version: 1;
    readonly kind: "registered-local-link";
    readonly adapterProtocolId: number;
    readonly fixedCanonicalCandidate: Uint8Array;
};
export interface PairTransportOfferV1 {
    readonly version: 1;
    readonly initiatorStableEdgeClaim: StableEdgeAttemptClaimV1;
    readonly candidates: readonly PairTransportCandidateV1[];
}
export interface PairTransportAnswerV1 {
    readonly version: 1;
    readonly responderStableEdgeClaim: StableEdgeAttemptClaimV1;
    readonly selectedOfferCandidateId: Uint8Array;
    readonly answer: PairTransportCandidateV1;
}
export interface QuiesceProposeV1 {
    readonly version: 1;
    readonly pqEpoch: bigint;
}
export interface QuiesceAckV1 {
    readonly version: 1;
    readonly pqEpoch: bigint;
}
export interface HealCompleteV1 {
    readonly version: 1;
    readonly newPqEpoch: bigint;
}
export interface PairCheckpointV1 {
    readonly version: 1;
    readonly pqEpoch: bigint;
}
export type PairStepBodyV1 = {
    readonly kind: "IDENTITY_HELLO";
    readonly value: PairIdentityHelloV1;
} | {
    readonly kind: "IDENTITY_ACCEPT";
    readonly value: PairIdentityAcceptV1;
} | {
    readonly kind: "TRANSPORT_OFFER";
    readonly value: PairTransportOfferV1;
} | {
    readonly kind: "TRANSPORT_ANSWER";
    readonly value: PairTransportAnswerV1;
} | {
    readonly kind: "V4_HANDSHAKE";
    readonly value: Uint8Array;
} | {
    readonly kind: "PQ_CONTROL";
    readonly value: Uint8Array;
} | {
    readonly kind: "QUIESCE_PROPOSE";
    readonly value: QuiesceProposeV1;
} | {
    readonly kind: "QUIESCE_ACK";
    readonly value: QuiesceAckV1;
} | {
    readonly kind: "HEAL_COMPLETE";
    readonly value: HealCompleteV1;
} | {
    readonly kind: "PAIR_CHECKPOINT";
    readonly value: PairCheckpointV1;
};
export interface PairPlaintextV1 {
    readonly version: 1;
    readonly kind: PairStepKindV1;
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly direction: 0 | 1;
    readonly pairSequence: bigint;
    readonly previousPairOperationId: Uint8Array | null;
    readonly pairDependencies: readonly Uint8Array[];
    readonly body: PairStepBodyV1;
    readonly pairPadding: Uint8Array;
}
export type PairIdentityUnsignedBodyV1 = {
    readonly kind: "IDENTITY_HELLO";
    readonly value: PairIdentityHelloUnsignedV1;
} | {
    readonly kind: "IDENTITY_ACCEPT";
    readonly value: PairIdentityAcceptUnsignedV1;
};
export interface PairIdentityUnsignedProjectionV1 {
    readonly version: 1;
    readonly kind: "IDENTITY_HELLO" | "IDENTITY_ACCEPT";
    readonly pairEdgeId: Uint8Array;
    readonly endpointPresenceOperationIds: readonly [Uint8Array, Uint8Array];
    readonly direction: 0 | 1;
    readonly pairSequence: bigint;
    readonly previousPairOperationId: Uint8Array | null;
    readonly pairDependencies: readonly Uint8Array[];
    readonly body: PairIdentityUnsignedBodyV1;
    readonly pairPadding: Uint8Array;
}
export interface PairOuterPrebindingV1 {
    readonly version: 1;
    readonly roomContextConfirmation: Uint8Array;
    readonly policyHash: Uint8Array;
    readonly logicalWindow: bigint;
    readonly expiresAfterWindow: bigint;
    readonly lifetime: "PAIR_CAUSAL";
    readonly authorEpochEd25519Key: Uint8Array;
    readonly authorSequence: bigint;
    readonly previousAuthorOperationId: Uint8Array | null;
    readonly kind: "PAIR_STEP";
    readonly dependencies: readonly [];
    readonly operationPayloadClass: OperationPayloadClassV1;
    readonly bootstrapHeaderHash: Uint8Array;
    readonly nonce: Uint8Array | null;
}
export interface PairOuterBindingV1 {
    readonly prebinding: PairOuterPrebindingV1;
    readonly pairRoutingTag: Uint8Array;
    readonly semanticSlot: Uint8Array;
}
export interface PairFlightSlotV1 {
    readonly kind: PairStepKindV1;
    readonly direction: 0 | 1;
    readonly pairSequence: bigint;
}
export type PairBootstrapRecipientBindingV1 = {
    readonly kind: "presence";
    readonly presenceOperationId: Uint8Array;
} | {
    readonly kind: "hello-response";
    readonly helloOperationId: Uint8Array;
};
export interface PairBootstrapInfoV1 {
    readonly version: 1;
    readonly pairBootstrapSuite: typeof PAIR_BOOTSTRAP_SUITE_ID_V1;
    readonly roomContextConfirmation: Uint8Array;
    readonly policyHash: Uint8Array;
    readonly stepKind: "IDENTITY_HELLO" | "IDENTITY_ACCEPT";
    readonly logicalWindow: bigint;
    readonly expiresAfterWindow: bigint;
    readonly authorEpochEd25519Key: Uint8Array;
    readonly authorSequence: bigint;
    readonly previousAuthorOperationId: Uint8Array | null;
    readonly operationPayloadClass: OperationPayloadClassV1;
    readonly recipientBinding: PairBootstrapRecipientBindingV1;
}
export declare class PairPlaintextError extends Error {
    readonly name = "PairPlaintextError";
    constructor(message: string);
}
export declare const validatePairFlightSlotV1: (value: PairFlightSlotV1) => void;
export declare const validatePairBootstrapInfoV1: (value: PairBootstrapInfoV1) => void;
/** Canonical HPKE `info` bytes after the complete bootstrap-info gate. */
export declare const encodePairBootstrapInfoV1: (value: PairBootstrapInfoV1) => Uint8Array;
/**
 * Select the numerically smallest class for an empty-padding plaintext.
 *
 * This calculation is intentionally available before encryption. A receiver
 * invokes the same rule only after AEAD opening exposes the plaintext.
 */
export declare const pairOperationPayloadClassForV1: (plaintextWithEmptyPadding: PairPlaintextV1, bootstrapHeaderPresent: boolean) => OperationPayloadClassV1;
/** Validate an already decoded pair plaintext without mutating caller bytes. */
export declare const validatePairPlaintextV1: (plaintext: PairPlaintextV1, operationPayloadClass: OperationPayloadClassV1, bootstrapHeaderPresent: boolean, roomPqMode: RoomPqMode) => Promise<void>;
/**
 * Fill the unique authenticated zero suffix and return the selected outer
 * class together with an independently owned plaintext.
 */
export declare const padPairPlaintextV1: (plaintextWithEmptyPadding: PairPlaintextV1, bootstrapHeaderPresent: boolean, roomPqMode: RoomPqMode) => Promise<{
    readonly operationPayloadClass: OperationPayloadClassV1;
    readonly plaintext: PairPlaintextV1;
}>;
/** Encode only the one canonical, minimally classified, target-sized value. */
export declare const encodePairPlaintextV1: (plaintext: PairPlaintextV1, operationPayloadClass: OperationPayloadClassV1, bootstrapHeaderPresent: boolean, roomPqMode: RoomPqMode) => Promise<Uint8Array>;
/** Strictly decode and validate the signed outer class/header state. */
export declare const decodePairPlaintextV1: (encoded: Uint8Array, operationPayloadClass: OperationPayloadClassV1, bootstrapHeaderPresent: boolean, roomPqMode: RoomPqMode) => Promise<PairPlaintextV1>;
/**
 * Remove exactly the nested stable-identity transcript signature.
 *
 * The result uses a record descriptor rather than a new top-level union tag;
 * every outer field and the exact pair padding remain in the projection.
 */
export declare const pairIdentityUnsignedProjectionV1: (plaintext: PairPlaintextV1) => PairIdentityUnsignedProjectionV1;
