/**
 * Wall-clock watchdog over the signaling server's heartbeats.
 *
 * A WebSocket that the platform silently half-opened (page frozen with the
 * radio off, NAT binding dropped) fires no `close` event until the TCP stack
 * notices, which can take minutes. Meanwhile the server, which pings on a
 * fixed interval, has already closed its end. This watchdog owns no browser
 * globals: the caller injects the clock, the interval scheduler and the wake
 * event source, so it is exactly testable and inert outside a browser.
 *
 * `check()` runs on the interval and immediately on every wake event
 * (`visibilitychange` while visible, `pageshow`, `online`, `focus`), because
 * timers are throttled or suspended while a page is hidden and the first
 * useful moment to notice a dead socket is the moment the page wakes up.
 */
export type SignalingWakeEventName = "visibilitychange" | "pageshow" | "online" | "focus";
export interface SignalingHeartbeatWatchdogScheduler<Handle> {
    readonly setInterval: (callback: () => void, intervalMs: number) => Handle;
    readonly clearInterval: (handle: Handle) => void;
}
export interface SignalingHeartbeatWatchdogEnv {
    readonly addListener: (name: SignalingWakeEventName, listener: () => void) => void;
    readonly removeListener: (name: SignalingWakeEventName, listener: () => void) => void;
    /** Consulted on `visibilitychange`; a page going hidden is not a wake. */
    readonly isVisible: () => boolean;
}
export interface SignalingHeartbeatWatchdogOptions<Handle> {
    /** Wall clock in milliseconds; must keep advancing while the page sleeps. */
    readonly now: () => number;
    readonly timeoutMs: number;
    readonly checkEveryMs: number;
    readonly schedule: SignalingHeartbeatWatchdogScheduler<Handle>;
    readonly env?: SignalingHeartbeatWatchdogEnv;
    /** Invoked at most once; the watchdog has already stopped itself. */
    readonly onDead: () => void;
}
export interface SignalingHeartbeatWatchdog {
    /** Record that a server heartbeat was just answered. */
    beat(): void;
    /** Declare the socket dead if the heartbeat window has elapsed. */
    check(): void;
    /** Release the interval and wake listeners; idempotent and terminal. */
    stop(): void;
}
export declare const createSignalingHeartbeatWatchdog: <Handle>(options: SignalingHeartbeatWatchdogOptions<Handle>) => SignalingHeartbeatWatchdog;
