export declare const MAX_SIGNALING_INGRESS_BACKLOG = 128;
export declare const MAX_SIGNALING_INGRESS_BYTES: number;
export type SignalingHeartbeatKind = "raw" | "json";
/**
 * Heartbeats bypass protocol work so an ICE/IndexedDB operation cannot make a
 * healthy client miss the server timeout. Parsing is restricted to a tiny
 * input and the JSON form must be exactly `{type:"ping"}`.
 */
export declare const classifySignalingHeartbeat: (data: unknown) => SignalingHeartbeatKind | null;
export interface SignalingHeartbeatResponders {
    readonly raw: () => void;
    readonly json: () => void;
}
/** Answer one exact heartbeat synchronously; return false for protocol data. */
export declare const answerImmediateSignalingHeartbeat: (data: unknown, responders: SignalingHeartbeatResponders) => boolean;
export interface SignalingIngressQueueOptions {
    readonly maxPending?: number;
    readonly maxPendingBytes?: number;
    readonly onOverflow: () => void;
    readonly onTaskError?: (error: unknown) => void;
}
/**
 * Synchronously revocable ownership for handlers already running on a socket.
 * Closing a WebSocket is asynchronous, so exact-socket identity alone remains
 * true until `close`; this lease makes overflow/oversize rejection immediate.
 */
export declare class SignalingSocketIngressLease {
    #private;
    isCurrent(ownsSocket: () => boolean): boolean;
    invalidate(): void;
}
/**
 * A socket-local, bounded FIFO for signaling frames.
 *
 * WebSocket EventTarget ignores promises returned by `onmessage`; assigning an
 * async handler therefore starts unbounded concurrent protocol and IndexedDB
 * work. This queue preserves wire order and closes admission before invoking
 * the overflow callback, so a synchronous burst cannot schedule more work
 * while the socket close handshake is in flight.
 */
export declare class SignalingIngressQueue {
    #private;
    constructor(options: SignalingIngressQueueOptions);
    get pendingCount(): number;
    get pendingBytes(): number;
    get isClosed(): boolean;
    enqueue(task: () => void | Promise<void>, byteLength?: number): boolean;
    close(): void;
}
