export interface SignalingAttempt {
    readonly token: symbol;
    readonly cancelled: Promise<void>;
}
/**
 * SSOT for socket-attempt ownership, prompt cancellation, and serialized
 * identity bootstrap. Cancellation settles independently of a blocked
 * IndexedDB/crypto operation; the bootstrap lock remains held until that
 * operation unwinds, so its replacement cannot race identity mutation.
 */
export declare class SignalingAttemptLifecycle {
    private activeToken;
    private cancelCurrent;
    private identityPurgeRequests;
    private readonly bootstrapMutex;
    begin(label: string): SignalingAttempt;
    isCurrent(token: symbol): boolean;
    hasActiveAttempt(): boolean;
    assertCurrent(token: symbol): void;
    addCancellationEffect(token: symbol, effect: () => void): boolean;
    disarmCancellation(token: symbol): boolean;
    clear(token: symbol): boolean;
    cancelActive(): void;
    isIdentityPurgeActive(): boolean;
    acquireBootstrap(token: symbol): Promise<() => void>;
    /**
     * Cancel any socket/bootstrap attempt, then enter the same exclusive
     * identity boundary used by bootstrap. Purge uses this so no cancelled
     * bootstrap can persist or dispatch an identity after deletion.
     */
    cancelAndAcquireBootstrap(): Promise<() => void>;
}
export declare const signalingAttemptLifecycle: SignalingAttemptLifecycle;
