/**
 * One invocation-order boundary for signaling joins, disconnects, and purges.
 *
 * A join places all awaited prework inside this boundary. A later terminal
 * action therefore runs after it and owns the final state; a later invalid
 * join never cancels an earlier valid one before its own validation succeeds.
 */
export declare class SignalingRoomOperationLifecycle {
    #private;
    runJoin<T>(operation: () => Promise<T>): Promise<T>;
    runRoomTerminal<T>(_roomUrl: string, operation: () => Promise<T>): Promise<T>;
    runGlobalTerminal<T>(operation: () => Promise<T>): Promise<T>;
}
export declare const signalingRoomOperationLifecycle: SignalingRoomOperationLifecycle;
