import type { TurnCredentials, WebSocketMessageChallengeRequest, WebSocketMessageSuccessfulChallenge } from "./interfaces";
export declare const MIN_TURN_CREDENTIAL_REMAINING_SECONDS = 30;
export declare const MAX_TURN_CREDENTIAL_LIFETIME_SECONDS: number;
/** Stale bearer-shaped key fields never authenticate a replacement socket. */
export declare const hasCurrentSocketProof: (keyPair: {
    peerId: string;
    challenge: string;
    signature: string;
}, signalingServer: {
    isConnected: boolean;
    isVerified: boolean;
}) => boolean;
/**
 * Exact protocol-v3 server challenge. Legacy reconnect credentials are
 * deliberately not accepted: every WebSocket must prove possession anew.
 */
export declare const isFreshV3Challenge: (value: unknown) => value is WebSocketMessageChallengeRequest;
/** Exact protocol-v3 proof-success response. TURN is issued only at room join. */
export declare const isV3ChallengeSuccess: (value: unknown) => value is WebSocketMessageSuccessfulChallenge;
/**
 * Decode the one nested TURN credential object used by room responses.
 *
 * The server controls the relay, but only bounded `turn:`/`turns:` URIs may
 * reach the browser ICE stack. Rejecting the complete object on one malformed
 * field keeps this a closed wire contract rather than a best-effort filter.
 */
export declare const parseTurnCredentials: (value: unknown, nowMs?: number, expectedPublicKey?: string) => TurnCredentials | null;
