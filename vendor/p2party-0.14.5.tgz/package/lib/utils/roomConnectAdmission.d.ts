import type { RoomPolicyV1 } from "../roomPolicy";
export interface RoomConnectAdmissionInput {
    readonly existingPolicy?: RoomPolicyV1;
    readonly persistedPolicy?: RoomPolicyV1;
    readonly requestedPolicy?: RoomPolicyV1;
    readonly providedPin?: unknown;
    readonly hasTransientPin: boolean;
}
/**
 * One pure admission decision for every public room-connect entry point.
 *
 * In particular, an empty Redux store does not imply a new no-PIN room when
 * IndexedDB retains an immutable PIN policy for the same capability.
 */
export declare const resolveRoomConnectAdmission: ({ existingPolicy, persistedPolicy, requestedPolicy, providedPin, hasTransientPin, }: RoomConnectAdmissionInput) => RoomPolicyV1;
