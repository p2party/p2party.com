export declare const canonicalSignalingServerUrl: (value: string) => string;
export declare const buildSignalingWebSocketUrl: (signalingServerUrl: string, publicKey: string) => string;
export interface SignalingServerSelection {
    requestedServerUrl: string;
    currentServerUrl: string;
    hasActiveRooms: boolean;
    isConnected: boolean;
    isEstablishingConnection: boolean;
}
/** Enforce the SDK's one-server provenance for every retained active room. */
export declare const selectSignalingServerUrl: ({ requestedServerUrl, currentServerUrl, hasActiveRooms, isConnected, isEstablishingConnection, }: SignalingServerSelection) => string;
