import { MAX_ACTIVE_SIGNALING_ROOMS } from "./constants";
import type { WebSocketMessageRoomIdRequest } from "./interfaces";
export { MAX_ACTIVE_SIGNALING_ROOMS };
export declare const MAX_PENDING_ROOM_REQUESTS = 256;
export declare const MAX_ROOM_REQUEST_RETRY_WAITERS = 256;
export declare const ROOM_RESPONSE_TIMEOUT_MS = 15000;
export declare const SOCKET_PROOF_TIMEOUT_MS = 15000;
export declare const TURN_REFRESH_LEAD_MS: number;
export declare const MIN_TURN_REFRESH_DELAY_MS = 1000;
export declare const TURN_REFRESH_RETRY_BASE_MS = 1000;
export declare const MAX_TURN_REFRESH_RETRY_MS = 30000;
export declare const MAX_TURN_REFRESH_ATTEMPTS = 8;
export interface AppliedRoomResponse {
    roomUrl: string;
    roomId: string;
    roomRequestId: string;
    requestGeneration: number;
    expiresAtUnixSeconds: number | null;
}
type SendRoomRequest = (request: WebSocketMessageRoomIdRequest) => void | Promise<unknown>;
export interface RoomCredentialRefreshReservation {
    readonly roomUrl: string;
    readonly token: symbol;
}
export declare const buildRoomRequest: (peerId: string, roomUrl: string) => WebSocketMessageRoomIdRequest;
/**
 * Start one wire-bound room request, or join the exact in-flight request.
 *
 * A fresh UUID is carried on the wire and must be echoed by the server. Merely
 * keeping a local generation would not distinguish an old same-room response
 * that arrived during a later request.
 */
export declare const requestRoomResponse: (peerId: string, roomUrl: string, send: SendRoomRequest, options?: {
    readonly timeoutMs?: number;
}) => Promise<AppliedRoomResponse>;
export interface PendingRoomResponseClaim {
    readonly roomUrl: string;
    readonly roomRequestId: string;
    readonly requestGeneration: number;
}
/** Claim only the exact echoed UUID of the current single-flight request. */
export declare const claimRoomResponse: (roomUrl: string, roomRequestId: string) => PendingRoomResponseClaim | null;
export declare const completeRoomResponse: (response: AppliedRoomResponse) => boolean;
export declare const rejectRoomResponse: (roomUrl: string, roomRequestId: string, error: Error) => boolean;
export declare const pendingRoomRequestId: (roomUrl: string) => string | null;
/** True only while the exact claimed response still owns its pending slot. */
export declare const isRoomResponseClaimCurrent: (claim: PendingRoomResponseClaim) => boolean;
export declare const waitForFreshSocketProof: (alreadyVerified: boolean, timeoutMs?: number, lifecycleEpoch?: number) => Promise<void>;
export declare const markFreshSocketProof: (lifecycleEpoch?: number) => void;
export declare const currentRoomRequestLifecycleEpoch: () => number;
export declare const isRoomRequestLifecycleCurrent: (lifecycleEpoch: number) => boolean;
export declare const waitForRoomRequestRetry: (roomUrl: string, lifecycleEpoch: number, delayMs: number) => Promise<void>;
export declare const turnRefreshDelayMs: (expiresAtUnixSeconds: number, nowMs?: number, minimumDelayMs?: number) => number;
export interface RoomCredentialRefreshOptions {
    /** Test seam; production uses Date.now(). */
    nowMs?: number;
    /** Dynamic test seam for time that can advance while refresh is awaited. */
    now?: () => number;
    /** Test seams; production uses the bounded constants above. */
    retryBaseMs?: number;
    maxRetryMs?: number;
    maxAttempts?: number;
    minimumInitialDelayMs?: number;
}
export declare const turnRefreshRetryDelayMs: (attempt: number, remainingMs: number, options?: RoomCredentialRefreshOptions) => number;
export declare const scheduleRoomCredentialRefresh: (roomUrl: string, expiresAtUnixSeconds: number | null, refresh: () => Promise<unknown>, expire?: () => void | Promise<void>, options?: RoomCredentialRefreshOptions, ownerToken?: symbol) => void;
/**
 * Preflight used immediately before publishing a room response.
 *
 * A replacement owns its existing slot; a STUN-only response needs no slot.
 * Callers recheck after asynchronous live-PC configuration, then publish and
 * schedule synchronously so the bound cannot change between those operations.
 */
export declare function canScheduleRoomCredentialRefresh(roomUrl: string, expiresAtUnixSeconds: number | null): boolean;
export declare const reserveRoomCredentialRefresh: (roomUrl: string, expiresAtUnixSeconds: number | null) => RoomCredentialRefreshReservation;
export declare const isRoomCredentialRefreshReservationCurrent: (reservation: RoomCredentialRefreshReservation) => boolean;
export declare const releaseRoomCredentialRefreshReservation: (reservation: RoomCredentialRefreshReservation) => boolean;
export declare const finalizeRoomCredentialRefresh: (reservation: RoomCredentialRefreshReservation, expiresAtUnixSeconds: number | null, refresh: () => Promise<unknown>, expire?: () => void | Promise<void>, options?: RoomCredentialRefreshOptions) => void;
/**
 * Release whichever refresh object this exact response still owns.
 *
 * A stale handler must never clear a replacement reservation/timer installed
 * for the same room URL after delete/reactivate or socket reset.
 */
export declare const clearRoomCredentialRefreshIfOwned: (reservation: RoomCredentialRefreshReservation) => boolean;
export declare const clearRoomCredentialRefresh: (roomUrl: string) => void;
/** Cancel every coordinator handle owned by one retained room. */
export declare const cancelRoomRequestLifecycle: (roomUrl: string, reason?: string) => void;
/**
 * Socket teardown invalidates responses and fails closed on managed TURN.
 *
 * With no authenticated path available to refresh, keeping a credential timer
 * but losing its refresh context risks stale use after background suspension.
 * Remove the managed bundle now; a later proof repopulates it before repair.
 */
export declare const resetRoomRequestLifecycle: (reason?: string) => void;
/** Test-only observability without exposing mutable coordinator maps. */
export declare const roomRequestCoordinatorCounts: () => {
    pending: number;
    proofWaiters: number;
    retryWaiters: number;
    refreshTimers: number;
    refreshReservations: number;
};
