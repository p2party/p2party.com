/**
 * Final transport-construction gate after every preceding async operation.
 * A purge/reset or identity rotation invalidates the captured constructor.
 */
export declare const assertTransportIdentityCurrent: (initialPublicKey: string, currentPublicKey: string) => void;
