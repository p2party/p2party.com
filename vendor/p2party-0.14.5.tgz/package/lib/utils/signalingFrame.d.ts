import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { WebSocketPeerConnectionParams } from "./interfaces";
export type WebSocketBaseResult = {
    data: undefined;
} | {
    error: string;
};
type SignalingQueryApi = Pick<BaseQueryApi, "dispatch" | "getState">;
type SignalingSocket = Pick<WebSocket, "readyState" | "send">;
export interface AuthenticatedSignalingFrame<Content extends {
    fromPeerId: string;
} = {
    fromPeerId: string;
}> {
    content: Content;
}
export declare const sendAuthenticatedSignalingFrame: <Content extends {
    fromPeerId: string;
}>(socket: SignalingSocket, message: AuthenticatedSignalingFrame<Content>, api: SignalingQueryApi, isCurrentSocket: () => boolean) => WebSocketBaseResult;
export declare const sendPeerConnectionRequest: (socket: SignalingSocket, { peerId, peerPublicKey, roomId }: WebSocketPeerConnectionParams, api: SignalingQueryApi, isCurrentSocket: () => boolean) => WebSocketBaseResult;
export {};
