export declare const UUID_V4_PATTERN: RegExp;
export declare const isUuidV4: (value: string) => boolean;
/** One SSOT for every request/ack correlation nonce carried on the wire. */
export declare const randomUuidV4: () => string;
