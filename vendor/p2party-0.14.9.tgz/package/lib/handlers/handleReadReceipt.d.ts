import { persistOutboundReceipt } from "./outbox";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { ScheduledReceiptDependencies } from "./scheduledReceiptAcceptance";
export interface ReadReceiptDependencies {
    readonly persist?: typeof persistOutboundReceipt;
    readonly getChunk?: ScheduledReceiptDependencies["getChunk"];
}
export type ReadReceiptOutcome = {
    kind: "ignored";
    peerId: string;
} | {
    kind: "chunk-acked";
    peerId: string;
    transferId: string;
    chunkIndex: number;
    newlyAccepted: boolean;
} | {
    kind: "peer-complete";
    peerId: string;
    transferId: string;
    newlyAccepted: boolean;
};
export declare const handleReadReceipt: (receivedChunkHash: Uint8Array, channel: string, peerId: string, roomId: string, api: BaseQueryApi, dependencies?: ReadReceiptDependencies) => Promise<ReadReceiptOutcome>;
