import { forgetReceiveMessageKeyDurably } from "./ratchetPersist";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { MessageData } from "../db/types";
type ForgetReceiveMessageKey = typeof forgetReceiveMessageKeyDurably;
type ReceiveProgress = Pick<MessageData, "savedSize" | "totalSize">;
/**
 * Bind the authenticated transfer root to the receive-ratchet key used by all
 * of its cells. Completion of the real bytes does not end this lifetime: valid
 * padded/cover cells may still be draining from an unordered data channel.
 */
export declare const bindReceiveMessageKey: (epc: IRTCPeerConnection, merkleRootHex: string, cacheKey: string) => void;
/**
 * Durably retire the key mapped to one transfer. The root binding is removed
 * only after persistence succeeds, so failure leaves an idempotent retry path.
 */
export declare const forgetMappedReceiveMessageKey: (epc: IRTCPeerConnection, roomId: string, merkleRootHex: string, forget?: ForgetReceiveMessageKey) => Promise<boolean>;
/**
 * A normal channel close retires a receive key only after its queue drained and
 * the durable manifest confirms all real bytes. Incomplete transfers retain
 * their key so a failed transport can resume; explicit cancel uses the
 * unconditional helper above.
 */
export declare const forgetCompletedReceiveMessageKey: (epc: IRTCPeerConnection, roomId: string, merkleRootHex: string, progress: ReceiveProgress | undefined, forget?: ForgetReceiveMessageKey) => Promise<boolean>;
/** Capture BEFORE expiry touches storage; a later receive may reuse the root. */
export declare const captureReceiveMessageKey: (epc: IRTCPeerConnection, merkleRootHex: string) => {
    epc: IRTCPeerConnection;
    roomId: string;
    peerId: string;
    merkleRootHex: string;
    cache: Map<string, Uint8Array<ArrayBufferLike>>;
    cacheKey: string;
    isCurrent: () => boolean;
    clearBinding: () => void;
} | undefined;
export type ReceiveMessageKeySnapshot = NonNullable<ReturnType<typeof captureReceiveMessageKey>>;
/** Absence and generation checks execute INSIDE the crypto mutation lock. */
export declare const forgetExpiredReceiveMessageKey: (snapshot: ReceiveMessageKeySnapshot, stillAbsent: () => Promise<boolean>, forget?: (epc: IRTCPeerConnection, roomId: string, cache: Map<string, Uint8Array>, cacheKey: string, canRetire: (() => Promise<boolean>) | undefined, persist?: import("./ratchetPersist").PersistRatchetState) => Promise<boolean>) => Promise<boolean>;
export {};
