import type { IRTCDataChannel } from "../api/webrtc/interfaces";
/** The opener promises that a close may pause a transfer. Legacy `raw` keeps its close-as-cancel contract. */
export declare const IMMEDIATE_RESUME_PROTOCOL = "p2party-resume-v1";
export declare const FRAME_TYPE_IMMEDIATE_DISPOSITION = 6;
export declare const bindImmediateDisposition: (channel: IRTCDataChannel, root: Uint8Array, incoming: boolean, authenticated: () => boolean) => void;
export declare const immediateCloseMeansPause: (channel?: IRTCDataChannel) => boolean;
export declare const hasImmediateRemoteCancel: (channel?: IRTCDataChannel) => boolean;
/** Echo only on marked incoming message channels, after the DTLS-bound identity gate opens. */
export declare const sendImmediateResumeCapability: (channel: IRTCDataChannel) => void;
/**
 * No signaling relay carries this control: the authenticated concrete SCTP
 * channel and its fixed Merkle root are the scope. Unknown, stale, cross-root,
 * pre-authentication and malformed controls have no effect.
 */
export declare const acceptImmediateDisposition: (channel: IRTCDataChannel, bytes: Uint8Array) => "capability" | "cancel" | undefined;
/** Queue explicit user cancellation before terminal close; an interrupted attempt sends no CANCEL. */
export declare const sendImmediateCancel: (channel: IRTCDataChannel) => Promise<void>;
