import type { Peer } from "../reducers/roomSlice";
import type { RoomPeer } from "../utils/interfaces";
export interface SelfPeerIdentity {
    peerId: string;
    publicKey: string;
}
/** Validate the whole snapshot before replacing prior membership. */
export declare const parsePeerRosterSnapshot: (peers: readonly RoomPeer[], self: SelfPeerIdentity) => Peer[];
/**
 * Server `peers` messages are accepted-peer deltas, not room snapshots.
 * Preserve prior members and upsert only canonical, non-conflicting additions.
 * Peer removal belongs to explicit transport teardown/disconnect handling.
 */
export declare const mergePeerRosterDelta: (current: readonly Peer[], delta: readonly RoomPeer[], self: SelfPeerIdentity) => Peer[];
