export interface ScheduledReceiptOwner {
    readonly roomId: string;
    readonly peerId: string;
    readonly peerPublicKey: string;
    readonly transferId: string;
    readonly merkleRootHex: string;
}
export interface ScheduledReceiptDependencies {
    readonly getChunk: (root: string, token: string) => Promise<{
        readonly transferId: string;
        readonly merkleRoot: string;
        readonly receiptToken: string;
        readonly chunkIndex: number;
    } | undefined>;
    /** Persist before exposing an ACK to selective resume or UI state. */
    readonly persist: (receipt: ScheduledReceiptOwner & {
        readonly chunkIndex?: number;
    }) => Promise<boolean>;
    readonly persistCancellation?: (owner: ScheduledReceiptOwner) => Promise<boolean>;
}
/** Called only after CoverRuntime authenticated the edge, epoch and replay window. */
export declare const acceptScheduledReceipt: (owner: ScheduledReceiptOwner, token: Uint8Array, kind: "chunk" | "terminal", isCurrent: () => boolean, dependencies?: ScheduledReceiptDependencies) => Promise<boolean>;
/** Authenticated refusal uses the same owner and persistence boundary as ACKs. */
export declare const acceptScheduledCancellation: (owner: ScheduledReceiptOwner, isCurrent: () => boolean, dependencies?: ScheduledReceiptDependencies) => Promise<boolean>;
