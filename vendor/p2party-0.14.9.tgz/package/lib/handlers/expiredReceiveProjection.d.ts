import { getDBMessageData } from "../db/api";
import { sweepTransferStorageDetails } from "./outbox";
import { forgetExpiredReceiveMessageKey } from "./receiveMessageKeyLifetime";
import type { IRTCPeerConnection } from "../api/webrtc/interfaces";
import type { Room } from "../reducers/roomSlice";
export interface ExpiredReceiveProjectionDependencies {
    getRooms: () => readonly Pick<Room, "id" | "messages">[];
    getPeers: () => readonly IRTCPeerConnection[];
    dropMessage: (roomId: string, merkleRootHex: string) => void;
    sweep?: typeof sweepTransferStorageDetails;
    readProgress?: typeof getDBMessageData;
    forgetKey?: typeof forgetExpiredReceiveMessageKey;
}
/** Project only committed expiry deletions, never a scan's stale candidates. */
export declare const sweepExpiredReceiveState: ({ getRooms, getPeers, dropMessage, sweep, readProgress, forgetKey, }: ExpiredReceiveProjectionDependencies) => Promise<void>;
/** Metadata polling shares one lazy maintenance pass at most every 30 seconds. */
export declare const createExpiredReceiveMaintenance: (dependencies: ExpiredReceiveProjectionDependencies, now?: () => number) => (() => Promise<void>);
