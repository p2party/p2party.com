export { discardRoomOutbox } from "./outbox";
type Resume = (roomId: string) => Promise<unknown>;
interface Clock {
    now(): number;
    sleep(delayMs: number): Promise<void>;
}
/** Each actual authentication event permits a pass; failures never schedule one. */
export declare const createOutboxResumeCoordinator: (clock?: Clock, debounceMs?: number) => {
    register(handler: Resume): void;
    resume(roomId: string): Promise<void>;
};
export declare const registerOutboxResume: (handler: Resume) => void;
export declare const resumeRoomOutbox: (roomId: string) => Promise<void>;
