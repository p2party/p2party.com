import type { HandshakeRetryStatus } from "../handlers/handshakeFailure";
/**
 * Bounded discovery and missing-member retries after signaling events stop.
 * Before a snapshot, the caller uses the room id as the discovery key. Once
 * membership is known, each missing member has its own room/peer key so one
 * offline member cannot exhaust another member's recovery budget. Healthy
 * siblings do not cancel a missing member's retries.
 *
 * Store-free on purpose: the caller injects the timeout scheduler and decides,
 * at each attempt, whether that key still needs recovery. Nothing here reads a
 * clock, a store or a browser global, so the whole backoff is exercisable in
 * virtual time.
 */
/**
 * Runs one reconciliation attempt for a room or room/peer key. Returns whether it is
 * still stranded and the backoff should continue; `false` retires it.
 */
export type RoomRosterReconcileTick = (roomId: string) => boolean;
export interface RoomRosterReconcilerScheduler<Handle> {
    readonly setTimeout: (callback: () => void, delayMs: number) => Handle;
    readonly clearTimeout: (handle: Handle) => void;
}
export interface RoomRosterReconcilerOptions<Handle> {
    readonly schedule: RoomRosterReconcilerScheduler<Handle>;
    /** Delay before attempt n; the last entry is the cap for every attempt after. */
    readonly delaysMs: readonly number[];
    /** Total attempts allowed for one uninterrupted strand. */
    readonly maxAttempts: number;
}
export interface RoomRosterReconciler {
    /**
     * Report that a room is stranded. Idempotent: a room already under a backoff
     * keeps its schedule and its attempt count, and only its tick is refreshed,
     * so repeated observations can never rewind the backoff or stack timers. A
     * room that already spent its attempts stays retired until `cancel`.
     */
    arm(roomId: string, tick: RoomRosterReconcileTick): void;
    /** Forget a room: releases its timer and resets its attempt budget. */
    cancel(roomId: string): void;
    /** Forget every room, for a lost socket or a purged store. */
    cancelAll(): void;
    /** Rooms this reconciler still tracks, retired ones included. */
    armedRooms(): readonly string[];
}
export declare const createRoomRosterReconciler: <Handle>(options: RoomRosterReconcilerOptions<Handle>) => RoomRosterReconciler;
/** The shape of a room this predicate needs; a superset of the reducer's. */
export interface ReconcilableRoom {
    readonly id: string;
    readonly signalingActive?: boolean;
    readonly peers: readonly {
        readonly peerId: string;
        readonly peerPublicKey?: string;
    }[];
    /** Last eligible membership snapshot; survives transport teardown. */
    readonly knownPeers?: ReconcilableRoom["peers"];
    readonly handshakeStatusByPeer?: Readonly<Record<string, HandshakeRetryStatus | undefined>>;
}
export interface ReconcilableSocket {
    readonly isConnected: boolean;
    readonly isVerified: boolean;
}
/** Known peers all need a deliberate authentication retry, not another roster. */
export declare const hasOnlyTerminalPeerHandshakeFailures: (room: ReconcilableRoom) => boolean;
/**
 * Whether a room is worth asking about again.
 *
 * "Nobody to talk to" is not the same as "no peers": a roster full of edges
 * that never finished authenticating is just as empty in practice, and the
 * server re-introducing this client is what gives those edges a fresh start.
 * A room the user left (`signalingActive === false`, which `deleteRoom` sets),
 * a room with no signaling identity yet, and any socket that is not both
 * connected and verified are all excluded — a request on those either cannot
 * be sent or would be an unwanted rejoin.
 */
export declare const isRoomRosterStranded: (room: ReconcilableRoom, socket: ReconcilableSocket) => boolean;
