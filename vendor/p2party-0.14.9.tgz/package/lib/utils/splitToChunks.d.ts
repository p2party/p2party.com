import type { OutboxLease } from "../db/outboxTypes";
import type { BaseQueryApi } from "@reduxjs/toolkit/query";
import type { Room } from "../reducers/roomSlice";
import type { LibCrypto } from "../cryptography/libcrypto";
import type { TransferAbortHandle } from "../handlers/transferAbort";
export declare const metadataSchemaVersions: number[];
export declare const planMessageChunkCount: (totalSize: number, minChunks?: number, chunkSize?: number, percentageFilledChunk?: number) => number;
export declare const OUTBOUND_CHUNK_RECORD_OVERHEAD = 2048;
export declare const estimateOutboundStagingBytes: (totalSize: number, totalChunks: number, chunkSize: number) => number;
/**
 * Splits a Uint8Array into chunks of a specified size, padding with noise if necessary.
 * Ensures a minimum number of chunks are created.
 * Returns the chunks and the last valid byte index in the last chunk before padding.
 *
 * @param data - The Uint8Array to be split.
 * @param minChunks - The minimum number of chunks to produce.
 * @param chunkSize - The desired size of each chunk.
 * @param percentageFilledChunk - Useful-data fraction, range (0, 0.99]. The
 * remaining RNG padding gives each send a fresh Merkle-root namespace.
 * @returns An object containing the chunks, their merkle proofs and the last valid byte index.
 */
export declare const splitToChunks: (message: string | File, api: BaseQueryApi, label: string, room: Room, merkleModule: LibCrypto, transfer: Pick<TransferAbortHandle, "transferId" | "signal" | "bindHash"> & {
    outboxLease?: OutboxLease;
}, minChunks?: number, chunkSize?: number, percentageFilledChunk?: number, metadataSchemaVersion?: number) => Promise<{
    merkleRoot: Uint8Array;
    merkleRootHex: string;
    hash: Uint8Array;
    hashHex: string;
    totalChunks: number;
    totalSize: number;
    messageType: number;
    chunkHashes: Uint8Array;
}>;
