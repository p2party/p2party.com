export type SignalingPeerRequestKind = "join" | "empty-roster" | "redial" | "reconcile";
/**
 * Bounds repeated peer-list requests only within one socket lifecycle.
 *
 * A reconnect must never inherit the previous socket's timestamp: the first
 * post-proof request is what rebuilds all WebRTC edges after teardown.
 */
export declare class SignalingPeerRequestDebouncer {
    #private;
    private readonly clock;
    get supportsRosterSnapshots(): boolean;
    confirmRosterSnapshots(): void;
    constructor(clock?: {
        now: () => number;
        setTimeout: (callback: () => void, ms: number) => NodeJS.Timeout;
        clearTimeout: (timer: ReturnType<typeof setTimeout>) => void;
    });
    /** Coalesce a burst, but never lose its final redial. The callback rechecks admission. */
    request(kind: SignalingPeerRequestKind, roomId: string, intervalMs: number, send: () => void): void;
    beginRosterRequest(roomId: string): string;
    isCurrentRosterRequest(roomId: string, requestId: unknown): boolean;
    completeRosterRequest(roomId: string, requestId: unknown): boolean;
    cancelRoom(roomId: string): void;
    shouldSend(kind: SignalingPeerRequestKind, roomId: string, minimumIntervalMs: number, now?: number): boolean;
    resetSocketLifecycle(): void;
}
export declare const signalingPeerRequestDebouncer: SignalingPeerRequestDebouncer;
