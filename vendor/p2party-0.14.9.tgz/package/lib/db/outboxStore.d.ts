import type { NewChunk } from "./types";
import type { OutboxLease, OutboxManifest, OutboxRequest, OutboxResponse } from "./outboxTypes";
export declare const OUTBOX_RETENTION_MS: number;
export declare const OUTBOX_STAGING_RETENTION_MS: number;
export declare const OUTBOX_LEASE_MS = 30000;
export declare const MAX_PENDING_OUTBOX = 32;
export declare const MAX_OUTBOX_RECIPIENTS = 64;
export declare const MAX_OUTBOX_STAGED_BYTES: number;
export declare const ownsOutbox: (row: OutboxManifest | undefined, lease: OutboxLease, now?: number) => row is OutboxManifest;
/** Every mutation uses one IDB transaction, so separate tab workers fence each other. */
export declare function executeOutbox(request: OutboxRequest): Promise<OutboxResponse>;
/** Admission and every queued staging/proof update share the same owner fence. */
export declare function storeOutboxChunk(chunk: NewChunk, lease?: OutboxLease): Promise<void>;
