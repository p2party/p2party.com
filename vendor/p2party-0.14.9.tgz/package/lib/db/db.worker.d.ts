export declare const INCOMPLETE_RECEIVE_RETENTION_MS: number;
